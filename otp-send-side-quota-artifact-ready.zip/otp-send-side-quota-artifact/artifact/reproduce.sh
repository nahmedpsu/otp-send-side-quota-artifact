#!/usr/bin/env bash
# Full reproduction of every reported arm, at the paper's trial counts, with
# the per-request event log. About two hours on two cores; --quick runs a
# reduced design (3 trials per cell) in about ten minutes.
#
# What this script does and does not do:
#   * It RE-RUNS every round-4 arm the paper reports (Table VI) into
#     results/repro/, with exactly the trial counts stated in the paper
#     (30 per cell; 10 for the sequential control; 20 for the worker and
#     declared-limit arms). It never overwrites the shipped run.
#   * It then runs regenerate.py twice: once on the shipped results (the
#     numbers in the paper) and once on your run (--results results/repro),
#     and prints the two side by side with study/compare_repro.py.
#   * Nothing from rounds 1 to 3 is re-run; those arms are historical and are
#     only reaggregated by regenerate.py, as the paper says.
#   * Before anything is re-run it verifies the shipped archive against its
#     manifest (study/manifest.py verify) and ABORTS if any listed file is
#     missing or changed or any unlisted file is present, so that a
#     difference in your run cannot be blamed on a damaged or altered copy.
#     --no-verify skips that gate for diagnostic runs on a tree you have
#     deliberately modified; the skip is printed.
#   * The service used is the shipped one (2.1.0); the shipped round-4 records
#     were produced by 2.0.0 (svc/archive/, svc/CHANGELOG.md). The difference
#     is a RETURNING clause on the read-modify-write counter's upsert, which
#     adds fields to its records and changes no decision.
set -eu
cd "$(dirname "$0")"

TRIALS=30; SEQ=10; SENS=20
VERIFY=1
for a in "$@"; do
  case "$a" in
    --quick)     TRIALS=3; SEQ=3; SENS=3 ;;
    --no-verify) VERIFY=0 ;;
    *) echo "usage: $0 [--quick] [--no-verify]"; exit 2 ;;
  esac
done

if [ "$VERIFY" = 1 ]; then
  echo "--- verifying the shipped archive against MANIFEST.sha256.json ---"
  if ! python3 study/manifest.py verify; then
    echo "ABORT: the archive differs from its manifest (see above). Nothing was re-run."
    echo "       Re-run with --no-verify only for a diagnostic run on a tree you have changed on purpose."
    exit 1
  fi
else
  echo "--- manifest verification SKIPPED (--no-verify): this is a diagnostic run ---"
fi

service postgresql start 2>/dev/null || true
sleep 3
su postgres -c "psql -tc \"SELECT 1 FROM pg_roles WHERE rolname='otp'\" | grep -q 1 \
  || psql -c \"CREATE USER otp WITH PASSWORD 'otp' SUPERUSER;\"" 2>/dev/null || true
su postgres -c "createdb -O otp otp" 2>/dev/null || true

RR=results/repro/r4
mkdir -p "$RR"
cp results/r4/classification_audit.csv "$RR/"          # Study 1 labels are not re-run
export EXP_PORT=8260
export EXP_DB=/tmp/otp_repro.db

run () { local name=$1; shift
  echo "--- $name ($(date -u +%FT%TZ)) ---"
  python3 study/run_experiments.py --arm "$name" --out "$RR/$name.csv" "$@"; }

run main_sqlite   --backend sqlite   --concurrency 1 2 4 8 16 32 --trials "$TRIALS" --randomize
run main_postgres --backend postgres --concurrency 1 2 4 8 16 32 --trials "$TRIALS" --randomize
run sequential    --backend sqlite   --concurrency 8 16 32 --trials "$SEQ" --mode sequential --randomize
run latency       --backend sqlite   --concurrency 8 --provider-ms 0 10 50 200 --trials "$TRIALS" --randomize
run workers       --backend sqlite   --concurrency 8 32 --workers 1 2 8 --trials "$SENS" --randomize
run limits        --backend sqlite   --concurrency 16 --limit 1 5 10 --trials "$SENS" --randomize
OTP_PG_POOL=8 run postgres_pooled --backend postgres --concurrency 8 32 --trials "$TRIALS" --randomize

echo "--- boundary tests ($(date -u +%FT%TZ)) ---"
python3 study/boundary_test.py --backend sqlite   --trials "$TRIALS" --out "$RR/boundary_sqlite.csv"
python3 study/boundary_test.py --backend postgres --trials "$TRIALS" --out "$RR/boundary_postgres.csv"

echo "--- executing django-otp 1.7.3 ($(date -u +%FT%TZ)) ---"
python3 study/run_package_exec.py --trials "$TRIALS" --db /tmp/otp_pkgexec_repro.sqlite3 --out "$RR/pkg_exec.csv"

echo "--- regenerating: shipped run, then your run ---"
python3 regenerate.py > /dev/null
if [ "$VERIFY" = 1 ]; then
  echo "--- the derived files are byte-for-byte reproducible: the manifest must still verify ---"
  python3 study/manifest.py verify > /tmp/manifest_after_regenerate.txt \
    || { tail -3 /tmp/manifest_after_regenerate.txt; echo "ABORT: regenerate.py changed a derived file"; exit 1; }
  tail -1 /tmp/manifest_after_regenerate.txt
fi
for f in survey_candidates.json survey_fetch_log.json survey_final.csv; do cp "results/$f" results/repro/; done
mkdir -p results/repro/r2 && cp results/r2/detector_sample.json results/r2/near_duplicates.json results/r2/pattern_provenance.csv results/repro/r2/
python3 regenerate.py --results results/repro > /dev/null
python3 study/compare_repro.py
echo "done. shipped numbers: results/paper_numbers.md; your numbers: results/repro/paper_numbers.md"
