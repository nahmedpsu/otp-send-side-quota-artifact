#!/usr/bin/env python3
"""
Regenerate every reported number in the manuscript from the raw event logs,
and classify every observed overrun against the exact declared policy.

Round 4. The reviewer's decisive question was: for every reported policy
violation and legitimate cross-window total, what exact event is being
counted, and can the artifact independently prove that event's window
assignment for every request?

The event is the ADMISSION (svc/app.py, module docstring): the completion of
the implementation's own granting state update. Every request in every
round-4 arm has one record in results/r4/<arm>.events.jsonl with, for an
admission, the window its granting statement counted it in (returned by the
database for atomic_update and reserve_commit; computed and written by the
request for cache_get_set) or the admission timestamp the implementation
used in its own check (sliding-window implementations).
This script reads those records, evaluates the policy on them with
study/policy.py, derives every per-trial summary from them, checks that the
trial CSVs the harness wrote agree, and only then builds the tables. The
per-overrun classification (results/overrun_classification.csv) is derived
from the same records and carries the per-window admission counts for each
overrun so that the assignment can be checked row by row.

The round-1 to round-3 arms had no event log. They are kept and summarised
under "historical", their overruns are classified by policy type only, and
the one trial of a one-step implementation that exceeded its limit in total
in round 2 is marked indeterminate: nothing in the retained records can
assign its admissions to windows.

Run:  python3 regenerate.py [--results DIR]
"""
import argparse
import csv
import json
import math
import os
import re
import statistics as st
import sys
from collections import Counter, defaultdict

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
from study import events as E  # noqa: E402
from study import policy as P  # noqa: E402

R = os.path.join(ROOT, "results")
OUT = {}

LAB = {"naive_count": "Count-then-insert",
       "cache_get_set": "Read-modify-write counter",
       "after_send": "Increment after send",
       "atomic_update": "Conditional atomic update",
       "immediate_txn": "Guarded write transaction",
       "reserve_commit": "Reserve before send"}
ORDER = list(LAB)
ONE_STEP = ("atomic_update", "immediate_txn", "reserve_commit")
POLICY = {"naive_count": "sliding", "after_send": "sliding",
          "immediate_txn": "sliding", "cache_get_set": "fixed",
          "atomic_update": "fixed", "reserve_commit": "fixed"}


def rows(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def wilson(x, n, z=1.96):
    if n == 0:
        return (0.0, 0.0)
    ph = x / n
    den = 1 + z * z / n
    c = (ph + z * z / (2 * n)) / den
    h = z * ((ph * (1 - ph) / n + z * z / (4 * n * n)) ** 0.5) / den
    return (max(0.0, c - h), min(1.0, c + h))


def pct(lo_hi):
    return [round(100 * lo_hi[0], 1), round(100 * lo_hi[1], 1)]


# ---------------------------------------------------------------- Study 1
def study1():
    s1 = {}
    cand = json.load(open(f"{R}/survey_candidates.json"))
    fetched = json.load(open(f"{R}/survey_fetch_log.json"))
    final = rows(f"{R}/survey_final.csv")
    pop = [r for r in final if r["in_population"] == "True"]
    audit = rows(f"{R}/r4/classification_audit.csv")
    assert len(audit) == len(pop) == 42

    s1["index_projects"] = cand["index_size"]
    s1["name_matches"] = cand["name_matches"]
    s1["metadata_kept"] = len(cand["kept"])
    s1["downloaded_ok"] = sum(1 for x in fetched if x.get("ok"))
    s1["detector_flagged"] = len(final)
    s1["excluded_by_hand"] = len(final) - len(pop)
    s1["retained"] = len(pop)

    lvl = Counter(a["send_control_evidence_level"] for a in audit)
    s1["send_control_evidence_levels"] = dict(lvl)
    send_yes = [a for a in audit if a["send_control"] == "yes"]
    in_pkg = [a for a in audit if a["send_control_evidence_level"].startswith("in_package")]
    delegated = [a for a in audit if a["send_control_evidence_level"] == "delegated_provider"]
    ver_yes = [a for a in audit if a["verify_control"] == "yes"]
    both = [a for a in audit if a["both"] == "yes"]
    n = len(audit)
    s1["send_control_yes"] = len(send_yes)              # in-package or delegated
    s1["send_control_in_package"] = len(in_pkg)
    s1["send_control_in_package_delivery_path"] = lvl["in_package_delivery_path"]
    s1["send_control_in_package_framework_throttle"] = lvl["in_package_framework_throttle"]
    s1["send_control_delegated_provider"] = len(delegated)
    s1["send_control_helper_not_wired"] = lvl["helper_not_wired"]
    s1["send_control_none_in_package"] = lvl["none_in_package"]
    s1["send_control_no"] = n - len(send_yes)
    s1["send_control_yes_pct"] = round(100 * len(send_yes) / n, 1)
    s1["send_control_no_pct"] = round(100 * (n - len(send_yes)) / n, 1)
    s1["send_control_in_package_pct"] = round(100 * len(in_pkg) / n, 1)
    s1["send_control_not_in_package"] = n - len(in_pkg)
    s1["send_control_not_in_package_pct"] = round(100 * (n - len(in_pkg)) / n, 1)
    s1["send_control_yes_ci_pct"] = pct(wilson(len(send_yes), n))
    s1["send_control_in_package_ci_pct"] = pct(wilson(len(in_pkg), n))
    s1["verify_control_yes"] = len(ver_yes)
    s1["both_controls"] = len(both)
    s1["send_only"] = len(send_yes) - len(both)
    s1["verify_only"] = len(ver_yes) - len(both)
    s1["neither"] = n - len(send_yes) - len(ver_yes) + len(both)
    s1["crosstab"] = {"send_yes_verify_yes": len(both),
                      "send_yes_verify_no": len(send_yes) - len(both),
                      "send_no_verify_yes": len(ver_yes) - len(both),
                      "send_no_verify_no": s1["neither"]}
    s1["verify_only_packages"] = sorted(a["package"] for a in audit
                                        if a["send_control"] == "no" and a["verify_control"] == "yes")
    s1["both_packages"] = sorted(a["package"] for a in both)
    s1["delegated_packages"] = sorted(a["package"] for a in delegated)
    s1["helper_not_wired_packages"] = sorted(a["package"] for a in audit
                                             if a["send_control_evidence_level"] == "helper_not_wired")
    s1["changed_in_round4"] = {a["package"]: a["send_control_evidence"] for a in audit
                               if a["changed_in_round4"] == "yes"}
    s1["verify_only_share_of_unguarded_pct"] = round(100 * s1["verify_only"] / s1["send_control_no"], 1)
    s1["concurrency_evaluated_packages"] = [a["package"] for a in audit
                                            if a["concurrency_evaluated"] == "yes"]
    s1["send_guards_not_executed"] = len(send_yes) - len(s1["concurrency_evaluated_packages"])
    s1["guard_kinds"] = dict(Counter(a["send_control_kind"] for a in send_yes))

    chan = Counter(a["channel"] for a in audit)
    s1["channel_breakdown"] = {}
    for c, m in chan.items():
        g = sum(1 for a in audit if a["channel"] == c and a["send_control"] == "yes")
        gi = sum(1 for a in audit if a["channel"] == c
                 and a["send_control_evidence_level"].startswith("in_package"))
        s1["channel_breakdown"][c] = {"packages": m, "guarded": g, "guarded_in_package": gi,
                                      "unguarded": m - g}
    sms = [a for a in audit if "SMS" in a["channel"]]
    s1["sms_capable"] = len(sms)
    s1["sms_capable_guarded"] = sum(1 for a in sms if a["send_control"] == "yes")
    s1["sms_capable_guarded_in_package"] = sum(
        1 for a in sms if a["send_control_evidence_level"].startswith("in_package"))
    s1["sms_capable_guarded_packages"] = sorted(
        (a["package"], a["send_control_evidence_level"]) for a in sms if a["send_control"] == "yes")
    s1["sms_capable_unguarded"] = len(sms) - s1["sms_capable_guarded"]
    named = {"SMS", "SMS+email", "SMS+voice", "SMS+hosted"}
    s1["sms_in_other_combinations"] = sorted(
        (a["package"], a["channel"]) for a in sms if a["channel"] not in named)

    ds = json.load(open(f"{R}/r2/detector_sample.json"))
    nv, x = ds["adjudication"]["sampled"], ds["adjudication"]["misses"]
    rej = ds["population_rejected"]
    lo, hi = wilson(x, nv)
    s1["detector_precision_pct"] = round(100 * len(pop) / len(final), 1)
    s1["validation_sample"] = nv
    s1["validation_misses"] = x
    s1["validation_missed_packages"] = ds["adjudication"]["missed_packages"]
    s1["detector_rejected"] = rej
    s1["miss_rate_pct"] = round(100 * x / nv, 1)
    s1["miss_rate_ci_pct"] = [round(100 * lo, 1), round(100 * hi, 1)]
    s1["est_missed_in_screened_set"] = round(rej * x / nv)
    s1["est_missed_ci"] = [round(rej * lo), round(rej * hi)]
    s1["est_relevant_in_screened_set"] = round(len(pop) + rej * x / nv)
    s1["est_relevant_ci"] = [round(len(pop) + rej * lo), round(len(pop) + rej * hi)]
    s1["detector_recall_pct"] = round(100 * len(pop) / (len(pop) + rej * x / nv), 1)
    s1["detector_recall_ci_pct"] = [round(100 * len(pop) / (len(pop) + rej * hi), 1),
                                    round(100 * len(pop) / (len(pop) + rej * lo), 1)]
    s1["recall_scope"] = ("detector stage only, within the downloaded candidates; "
                          "name and metadata filters were not validated")

    dup = json.load(open(f"{R}/r2/near_duplicates.json"))
    s1["near_duplicate_pairs"] = dup
    # collapsing the three django-otp delivery plugins (all unguarded) into one
    s1["unguarded_share_collapsing_django_otp_plugins_pct"] = round(
        100 * (s1["send_control_no"] - 2) / (n - 2), 1)
    prov = rows(f"{R}/r2/pattern_provenance.csv")
    s1["patterns_with_instance"] = sorted({p["shape"] for p in prov if p["instance"] == "yes"})
    s1["patterns_without_instance"] = sorted({p["shape"] for p in prov if p["instance"] == "no"})
    return s1


# ---------------------------------------------------------------- Study 2, round 4 (event-logged)
def cell_stats(v, lim, policy_over):
    q = st.quantiles(v, n=4) if len(v) >= 4 else [v[0]] * 3
    over = sum(1 for x in v if x > lim)
    return {"n": len(v), "median": st.median(v), "max": max(v), "min": min(v),
            "q1": q[0], "q3": q[2],
            "over_total": over, "over_total_ci_pct": pct(wilson(over, len(v))),
            "policy_violations": policy_over,
            "policy_violations_ci_pct": pct(wilson(policy_over, len(v))),
            "distribution": dict(sorted(Counter(v).items()))}


def sweep_from_events(trials, groupby=("strategy", "concurrency")):
    """Per-cell statistics from per-trial event summaries."""
    cells = defaultdict(list)
    for key, evs in trials.items():
        meta = dict(zip(E.TRIAL_KEYS, key))
        s = E.summarise(evs)
        cells[tuple(meta[g] for g in groupby)].append(s)
    tab = {}
    for ck, ss in sorted(cells.items(), key=lambda kv: (ORDER.index(kv[0][0]), kv[0][1:])):
        lim = ss[0]["limit"]
        v = [s["admits"] for s in ss]
        pv = sum(1 for s in ss if s["policy_overrun"] > 0)
        c = cell_stats(v, lim, pv)
        c["provider_calls_equal_admits_all_trials"] = int(all(s["admits_equal_provider_calls"] for s in ss))
        c["errors"] = sum(s["errors"] for s in ss)
        c["cross_window_trials"] = sum(1 for s in ss if s["windows_touched"] > 1)
        c["elapsed_events_s_median"] = round(st.median(s["elapsed_events_s"] for s in ss), 3)
        tab["|".join(str(x) for x in ck)] = c
    return tab


def check_against_csv(arm, trials):
    """The trial CSV must agree with the events on every count. Stop if not."""
    csvrows = rows(f"{R}/r4/{arm}.csv")
    bykey = {}
    for r in csvrows:
        key = tuple(type_of(k, r[k]) for k in E.TRIAL_KEYS)
        bykey[key] = r
    mism = []
    for key, evs in trials.items():
        s = E.summarise(evs)
        r = bykey.get(key)
        if r is None:
            mism.append(("missing csv row", key))
            continue
        for a, b in (("provider_sends", s["provider_calls"]), ("admits", s["admits"]),
                     ("requests_logged", s["requests"]), ("max_in_window", s["max_per_policy"]),
                     ("policy_overrun", s["policy_overrun"]), ("windows_touched", s["windows_touched"])):
            if int(r[a]) != int(b):
                mism.append((a, key, r[a], b))
    if len(bykey) != len(trials):
        mism.append(("row count", len(bykey), len(trials)))
    if mism:
        raise SystemExit(f"{arm}: trial CSV disagrees with the event log: {mism[:5]}")
    return len(trials)


def type_of(k, v):
    if k in ("limit", "workers", "concurrency", "window_s", "trial"):
        return int(v)
    if k == "provider_ms":
        return float(v)
    return v


def timing_from_events(trials, groupby=("strategy", "concurrency")):
    per = defaultdict(lambda: {"adm": [], "ref": [], "spread": []})
    for key, evs in trials.items():
        meta = dict(zip(E.TRIAL_KEYS, key))
        s = E.summarise(evs)
        g = per[tuple(meta[x] for x in groupby)]
        g["adm"] += s["read_to_write_ms_admitted"]
        g["ref"] += s["read_to_write_ms_refused"]
        g["spread"].append(s["arrival_spread_ms"])
    out = {}
    for ck, g in sorted(per.items(), key=lambda kv: (ORDER.index(kv[0][0]), kv[0][1:])):
        adm = sorted(g["adm"]); ref = sorted(g["ref"]); sp = sorted(g["spread"])
        out["|".join(str(x) for x in ck)] = {
            "admitted_read_to_write_ms_median": round(st.median(adm), 2) if adm else None,
            "admitted_read_to_write_ms_p90": round(adm[int(0.9 * len(adm)) - 1], 2) if adm else None,
            "admitted_n": len(adm),
            "refused_statement_ms_median": round(st.median(ref), 2) if ref else None,
            "refused_n": len(ref),
            "arrival_spread_ms_median": round(st.median(sp), 2),
            "arrival_spread_ms_max": round(max(sp), 2)}
    return out


def interleaving_from_events(trials, groupby=("strategy", "concurrency")):
    per = defaultdict(list)
    for key, evs in trials.items():
        meta = dict(zip(E.TRIAL_KEYS, key))
        per[tuple(meta[x] for x in groupby)].append(E.interleaving(evs, int(meta["limit"])))
    return {"|".join(str(x) for x in ck): E.aggregate_interleaving(v)
            for ck, v in sorted(per.items(), key=lambda kv: (ORDER.index(kv[0][0]), kv[0][1:]))}


def BASIS(strategy):
    """What the window (or admission timestamp) of an admission record rests on."""
    if strategy in ("atomic_update", "reserve_commit"):
        return ("admission events: window ids returned by the database from the "
                "conditional UPDATE that granted the admission")
    if strategy == "cache_get_set":
        return ("admission events: window ids computed by the application and written by "
                "the request's own upsert (the read-modify-write counter decides in the "
                "application; no database-returned value exists for it in round 4)")
    return "admission events: admission timestamps used by the implementation's check"


def window_provenance_check(arms):
    """Audit the window field of every fixed-window admission in the round-4 logs.

    One-step implementations (atomic_update, reserve_commit): window_id was
    returned by the granting statement. Read-modify-write counter
    (cache_get_set): window_id is the value the request computed and wrote,
    so the check is that it is consistent with the request's own record: an
    aligned window start, current at the instant the request read the row
    (t_recv - window_s < window_id <= t_read), and equal to the aligned window
    of the read instant. Records whose receipt and read fall in different
    aligned windows are counted as boundary-ambiguous and reported.
    """
    out = {}
    for strat in ("cache_get_set", "atomic_update", "reserve_commit"):
        out[strat] = dict(admissions=0, aligned=0, current_at_read=0, equals_floor_of_read=0,
                          boundary_ambiguous=0, inconsistent=0)
    ids = dict(records=0, service_records=0, unique_rids=0, unique_trial_rid=0,
               package_records=0, unique_package_keys=0)
    rids, trial_rids, pkg_keys = set(), set(), set()
    for arm in arms:
        path = f"{R}/r4/{arm}.events.jsonl"
        try:
            E.resolve(path)
        except FileNotFoundError:
            continue
        for e in E.load(path):
            ids["records"] += 1
            if arm == "pkg_exec":
                ids["package_records"] += 1
                pkg_keys.add((e.get("mode"), e.get("concurrency"), e.get("trial"), e.get("call")))
                continue
            ids["service_records"] += 1
            rids.add(e.get("rid"))
            trial_rids.add((arm, e.get("strategy"), e.get("trial"), e.get("concurrency"),
                            e.get("limit"), e.get("workers"), e.get("provider_ms"),
                            e.get("mode"), e.get("rid")))
            st = e.get("strategy")
            if st not in out or e.get("decision") != "admit":
                continue
            c = out[st]
            ws = e["window_s"]
            w = e["window_id"]
            c["admissions"] += 1
            aligned = abs(w % ws) < 1e-6
            current = (e["t_recv"] - ws < w <= e["t_read"] + 1e-9)
            fr = math.floor(e["t_read"] / ws) * ws
            fv = math.floor(e["t_recv"] / ws) * ws
            c["aligned"] += int(aligned)
            c["current_at_read"] += int(current)
            c["equals_floor_of_read"] += int(abs(w - fr) < 1e-6)
            c["boundary_ambiguous"] += int(fr != fv)
            c["inconsistent"] += int(not (aligned and current))
    ids["unique_rids"] = len(rids)
    ids["unique_trial_rid"] = len(trial_rids)
    ids["unique_package_keys"] = len(pkg_keys)
    out["record_identity"] = ids
    out["service_version_that_produced_round_4"] = "2.0.0 (svc/archive/)"
    return out


def round5_check():
    """Round-5 check arms, service v2.1.0, cache_get_set only (results/r5/).

    For every admission the record carries both the window and counter the
    request submitted to its upsert and the values the database returned
    from the same statement (RETURNING). Reports whether they were equal in
    every admission, and the per-cell outcome beside the round-4 cell.
    """
    out = {}
    for arm in ("cgs_sqlite", "cgs_postgres", "cgs_boundary_sqlite", "cgs_boundary_postgres"):
        path = f"{R}/r5/{arm}.events.jsonl"
        try:
            E.resolve(path)
        except FileNotFoundError:
            continue
        boundary = arm.startswith("cgs_boundary")
        keys = (("arm", "backend", "strategy", "policy", "trial", "k", "limit", "window_s", "boundary")
                if boundary else E.TRIAL_KEYS)
        cells = defaultdict(list)
        adm = dict(admissions=0, returned_equals_submitted=0, window_source_submitted=0,
                   service_version="2.1.0")
        for key, evs in E.trials(path, keys).items():
            meta = dict(zip(keys, key))
            for e in evs:
                if e.get("decision") != "admit":
                    continue
                adm["admissions"] += 1
                adm["window_source_submitted"] += int(e.get("window_source") == "submitted")
                adm["returned_equals_submitted"] += int(
                    e.get("window_id_returned") == e["window_id"]
                    and e.get("counter_returned") == e["counter_after"])
            sm = E.summarise(evs)
            k = meta["k"] if boundary else meta["concurrency"]
            cells[k].append(sm)
        cell_out = {}
        for k, sms in sorted(cells.items()):
            v = sorted(x["admits"] for x in sms)
            lim = sms[0]["limit"]
            cell_out[str(k)] = dict(n=len(v), median=st.median(v), max=max(v),
                                    over_total=sum(1 for x in v if x > lim),
                                    policy_violations=sum(1 for x in sms if x["policy_overrun"] > 0),
                                    max_per_policy=max(x["max_per_policy"] for x in sms))
        out[arm] = dict(admission_audit=adm, cells=cell_out)
    return out


def study2():
    s2 = {"event_definition": (
        "An admission is the completion of the implementation's granting state update. "
        "One-step fixed-window implementations (atomic_update, reserve_commit): the window is the "
        "window_start the counter row held when the conditional UPDATE was applied, returned by the "
        "database in that statement. Read-modify-write counter (cache_get_set): the window is the "
        "window_start the request computed (the row's if current, else its own clock's) and wrote "
        "in its upsert; it is an application-side value, as everything in that pattern is. "
        "Sliding-window implementations: the admission timestamp is the value the implementation "
        "used in its own check. Provider-call instants are recorded but never used to assign windows.")}
    arms = {}
    for arm in ("main_sqlite", "main_postgres", "sequential", "latency", "workers", "limits",
                "postgres_pooled"):
        path = f"{R}/r4/{arm}.events.jsonl"
        if not os.path.exists(f"{R}/r4/{arm}.csv"):
            continue                      # arm not finished or not run
        try:
            E.resolve(path)
        except FileNotFoundError:
            continue
        tr = E.trials(path)
        n = check_against_csv(arm, tr)
        arms[arm] = n
        gb = {"latency": ("strategy", "provider_ms"), "workers": ("strategy", "workers", "concurrency"),
              "limits": ("strategy", "limit")}.get(arm, ("strategy", "concurrency"))
        s2[arm] = sweep_from_events(tr, gb)
        s2[arm + "_trials"] = n
        s2[arm + "_provider_calls_equal_admits_every_trial"] = int(
            all(E.summarise(evs)["admits_equal_provider_calls"] for evs in tr.values()))
        s2[arm + "_errors"] = sum(E.summarise(evs)["errors"] for evs in tr.values())
        if arm in ("main_sqlite", "main_postgres", "postgres_pooled"):
            s2[arm + "_timing"] = timing_from_events(tr)
            s2[arm + "_interleaving"] = interleaving_from_events(tr)
            el = defaultdict(list)
            for key, evs in tr.items():
                meta = dict(zip(E.TRIAL_KEYS, key))
                el[(meta["strategy"], meta["concurrency"])].append(E.summarise(evs)["elapsed_events_s"])
            cl = defaultdict(list)
            for r in rows(f"{R}/r4/{arm}.csv"):
                cl[(r["strategy"], int(r["concurrency"]))].append(float(r["elapsed_s"]))
            s2[arm + "_elapsed"] = {f"{k[0]}|k={k[1]}": {"server_span_median_s": round(st.median(v), 3),
                                                        "client_burst_median_s": round(st.median(cl[k]), 3),
                                                        "n": len(v)}
                                    for k, v in sorted(el.items(), key=lambda kv: (ORDER.index(kv[0][0]), kv[0][1]))}
    if "main_sqlite" in s2:
        s2["declared_limit"] = 3
        s2["concurrency_levels"] = sorted({int(k.split("|")[1]) for k in s2["main_sqlite"]})
        s2["main_sqlite_summary"] = {
            s: {"over_total": sum(s2["main_sqlite"][f"{s}|{k}"]["over_total"] for k in s2["concurrency_levels"]),
                "policy_violations": sum(s2["main_sqlite"][f"{s}|{k}"]["policy_violations"] for k in s2["concurrency_levels"]),
                "worst_amplification": round(max(s2["main_sqlite"][f"{s}|{k}"]["max"] for k in s2["concurrency_levels"]) / 3, 1)}
            for s in ORDER}
    if "main_postgres" in s2:
        s2["main_postgres_summary"] = {
            s: {"over_total": sum(s2["main_postgres"][f"{s}|{k}"]["over_total"] for k in s2["concurrency_levels"]),
                "policy_violations": sum(s2["main_postgres"][f"{s}|{k}"]["policy_violations"] for k in s2["concurrency_levels"]),
                "worst_amplification": round(max(s2["main_postgres"][f"{s}|{k}"]["max"] for k in s2["concurrency_levels"]) / 3, 1)}
            for s in ORDER}
    if "sequential" in s2:
        v = [c for c in s2["sequential"].values()]
        s2["sequential_all_equal_limit"] = int(all(c["min"] == c["max"] == 3 for c in v))

    # boundary tests
    for arm in ("boundary_sqlite", "boundary_postgres"):
        path = f"{R}/r4/{arm}.events.jsonl"
        if not os.path.exists(f"{R}/r4/{arm}.csv"):
            continue
        try:
            E.resolve(path)
        except FileNotFoundError:
            continue
        keys = ("arm", "backend", "strategy", "policy", "trial", "k", "limit", "window_s", "boundary")
        tr = E.trials(path, keys)
        b = {}
        for key, evs in tr.items():
            meta = dict(zip(keys, key))
            s = E.summarise(evs)
            admits = [e for e in evs if e["decision"] == "admit"]
            before = (sum(1 for e in admits if e["window_id"] < meta["boundary"]) if meta["policy"] == "fixed"
                      else sum(1 for e in admits if e["policy_ts"] < meta["boundary"]))
            d = b.setdefault(meta["strategy"], {"policy": meta["policy"], "trials": 0, "straddled": 0,
                                                "total_exceeds_limit": 0, "policy_violated": 0,
                                                "max_per_policy": 0, "admits_before_after": Counter(),
                                                "provider_calls_equal_admits": 0})
            d["trials"] += 1
            d["straddled"] += int(s["windows_touched"] > 1)
            d["total_exceeds_limit"] += int(s["admits"] > meta["limit"])
            d["policy_violated"] += int(s["policy_overrun"] > 0)
            d["max_per_policy"] = max(d["max_per_policy"], s["max_per_policy"])
            d["admits_before_after"][f"{before}+{s['admits'] - before}"] += 1
            d["provider_calls_equal_admits"] += s["admits_equal_provider_calls"]
        for d in b.values():
            d["admits_before_after"] = dict(d["admits_before_after"])
        s2[arm] = b
        s2[arm + "_trials"] = len(tr)
        csvn = len(rows(f"{R}/r4/{arm}.csv"))
        if csvn != len(tr):
            raise SystemExit(f"{arm}: csv rows {csvn} != event trials {len(tr)}")
        arms[arm] = len(tr)

    # the executed package, from its per-call events
    path = f"{R}/r4/pkg_exec.events.jsonl"
    try:
        if not os.path.exists(f"{R}/r4/pkg_exec.csv"):
            raise FileNotFoundError(path)
        E.resolve(path)
        pe_rows = rows(f"{R}/r4/pkg_exec.csv")
        tr = defaultdict(list)
        for e in E.load(path):
            tr[(e["mode"], int(e["concurrency"]), int(e["trial"]))].append(e)
        p = {}
        cross = 0
        for (mode, k, t), evs in tr.items():
            admits = sum(1 for e in evs if e["decision"] == "admit")
            deliveries = sum(len(e.get("t_send_mail", [])) for e in evs)
            r = next(x for x in pe_rows if x["mode"] == mode and int(x["concurrency"]) == k and int(x["trial"]) == t)
            if int(r["deliveries"]) != deliveries or int(r["admits"]) != admits:
                raise SystemExit(f"pkg_exec: csv disagrees with events at {(mode, k, t)}")
            cross += int(admits == deliveries)
            p.setdefault(f"{mode}|k={k}", []).append(deliveries)
        pk = {}
        for key, v in sorted(p.items()):
            over = sum(1 for x in v if x > 1)
            q = st.quantiles(v, n=4) if len(v) >= 4 else [v[0]] * 3
            pk[key] = {"n": len(v), "median": st.median(v), "max": max(v), "min": min(v),
                       "q1": q[0], "q3": q[2], "over_limit": over,
                       "over_limit_ci_pct": pct(wilson(over, len(v))),
                       "distribution": dict(sorted(Counter(v).items()))}
        conc = [(k, v) for k, v in p.items() if k.startswith("concurrent")]
        s2["package_exec"] = pk
        s2["package_exec_trials"] = len(tr)
        s2["package_exec_admits_equal_deliveries_every_trial"] = int(cross == len(tr))
        s2["package_exec_concurrent_over_all_k"] = sum(1 for k, v in conc for x in v if x > 1)
        s2["package_exec_concurrent_trials_all_k"] = sum(len(v) for k, v in conc)
        s2["package_exec_concurrent_over_k_ge_2"] = sum(1 for k, v in conc if int(k.split("=")[1]) >= 2 for x in v if x > 1)
        s2["package_exec_concurrent_trials_k_ge_2"] = sum(len(v) for k, v in conc if int(k.split("=")[1]) >= 2)
        s2["package_exec_sequential_over"] = sum(1 for k, v in p.items() if k.startswith("sequential") for x in v if x > 1)
        s2["package_exec_errors"] = sum(int(r["errors"]) for r in pe_rows)
        # the mechanism, from the events: every admission beyond the first in a
        # trial loaded an instance whose cooldown timestamp was still null
        excess_null = sum(1 for evs in tr.values()
                          for e in sorted((x for x in evs if x["decision"] == "admit"), key=lambda x: x["t_call_end"])[1:]
                          if e.get("observed_last_generated") is None)
        excess_all = sum(max(0, sum(1 for e in evs if e["decision"] == "admit") - 1) for evs in tr.values())
        s2["package_exec_excess_admissions"] = excess_all
        s2["package_exec_excess_admissions_loaded_null_cooldown"] = excess_null
        arms["package_exec"] = len(tr)
    except FileNotFoundError:
        pass

    # the counter values the database returned to one-step admissions: within
    # one trial and one window they must be distinct and lie in [1, limit]
    chk = {"trials_checked": 0, "admissions_checked": 0, "violations": 0, "cross_window_trials": 0}
    for arm in ("main_sqlite", "main_postgres", "sequential", "latency", "workers", "limits",
                "postgres_pooled"):
        path = f"{R}/r4/{arm}.events.jsonl"
        if not os.path.exists(f"{R}/r4/{arm}.csv"):
            continue
        for key, evs in E.trials(path).items():
            meta = dict(zip(E.TRIAL_KEYS, key))
            if meta["strategy"] not in ONE_STEP:
                continue
            chk["trials_checked"] += 1
            seen = defaultdict(set)
            for e in evs:
                if e["decision"] != "admit":
                    continue
                chk["admissions_checked"] += 1
                w = e.get("window_id", int(e["policy_ts"] // meta["window_s"]))
                v = e["counter_after"]
                if not (1 <= v <= meta["limit"]) or v in seen[w]:
                    chk["violations"] += 1
                seen[w].add(v)
            if len(seen) > 1:
                chk["cross_window_trials"] += 1
    s2["one_step_counter_check"] = chk
    s2["window_provenance_check"] = window_provenance_check(list(arms) + ["pkg_exec"])
    s2["round5_check"] = round5_check()
    s2["arms"] = arms
    s2["arms_total"] = sum(arms.values())
    one_step = 0
    for arm in arms:
        fn = f"{R}/r4/{'pkg_exec' if arm == 'package_exec' else arm}.csv"
        one_step += sum(1 for r in rows(fn) if r.get("strategy") in ONE_STEP)
    s2["one_step_trials_all_r4_arms"] = one_step
    return s2


# ---------------------------------------------------------------- historical (rounds 1-3)
def historical():
    """The round-1 to round-3 arms, reaggregated. No per-request events."""
    h = {"note": ("Rounds 1-3 recorded provider_sends per trial (and, in the instrumented arms, "
                  "application instants) but no admission events; the classification of these "
                  "trials rests on policy type and arm-level timestamps only.")}

    def sweep_table(rs):
        cells = defaultdict(list)
        for r in rs:
            cells[(r["strategy"], int(r["concurrency"]))].append(int(r["provider_sends"]))
        lim = int(rs[0]["limit"])
        tab = {}
        for (s, k), v in sorted(cells.items(), key=lambda kv: (ORDER.index(kv[0][0]), kv[0][1])):
            tab[f"{s}|{k}"] = {"n": len(v), "median": st.median(v), "max": max(v), "min": min(v),
                               "over_total": sum(1 for x in v if x > lim)}
        return tab
    files = {"main_sqlite_r1": "main_sweep.csv", "sequential_r1": "sequential.csv",
             "latency_r1": "latency.csv", "latency_r2": "r2/latency_rest.csv",
             "main_postgres_r2": "r2/pg_main.csv", "postgres_pooled_r2": "r2/pg_pool.csv",
             "main_sqlite_randomised_r2": "r2/sqlite_main_rand.csv", "workers_r2": "r2/workers.csv",
             "limits_r2": "r2/limits.csv", "instrumented_sqlite_r2": "r2/timing_sqlite.csv",
             "instrumented_postgres_r2": "r2/timing_pg.csv", "anomaly_repro_r2": "r2/atomic_repro.csv",
             "window_1s_a_r2": "r2/window_boundary.csv", "window_1s_b_r2": "r2/window_boundary2.csv",
             "instrumented_sqlite_k_r3": "r3/timing_sqlite_k.csv",
             "instrumented_postgres_pooled_r3": "r3/timing_pg_pooled.csv",
             "boundary_r3": "r3/boundary_test.csv", "package_exec_r2": "r2/pkg_exec.csv"}
    arms = {}
    for key, fn in files.items():
        p = f"{R}/{fn}"
        if os.path.exists(p):
            rs = rows(p)
            arms[key] = len(rs)
            if "strategy" in rs[0] and "concurrency" in rs[0] and "provider_sends" in rs[0]:
                h[key] = sweep_table(rs)
    h["arms"] = arms
    h["arms_total"] = sum(arms.values())
    h["window_1s_note"] = ("intended OTP_WINDOW_S=1 but the round-2 harness set the window to 3600 s "
                           "itself; these trials ran at the default window and are inconclusive")
    # the round-2 anomalous trial, located by replaying the seed (study/locate_anomaly.py)
    try:
        from study import locate_anomaly as LA
        h["anomaly_r2_located"] = LA.main(verbose=False)
    except Exception as e:  # pragma: no cover
        h["anomaly_r2_located"] = f"unavailable: {type(e).__name__}"
    h["anomaly_r2_classification"] = (
        "indeterminate: no per-request admission events were retained for round-2 arms, so the "
        "window of each of its six admissions cannot be established from the records; the "
        "wall-clock reconstruction is consistent with a boundary crossing but does not prove it")
    return h


# ---------------------------------------------------------- overrun classifier
def classify_overruns(s2):
    out = []
    # round-4 arms: every trial whose admissions exceeded the limit, from events
    for arm in ("main_sqlite", "main_postgres", "sequential", "latency", "workers", "limits",
                "postgres_pooled"):
        path = f"{R}/r4/{arm}.events.jsonl"
        if not os.path.exists(f"{R}/r4/{arm}.csv"):
            continue
        try:
            E.resolve(path)
        except FileNotFoundError:
            continue
        for key, evs in E.trials(path).items():
            meta = dict(zip(E.TRIAL_KEYS, key))
            s = E.summarise(evs)
            if s["admits"] <= meta["limit"]:
                continue
            viol = s["policy_overrun"] > 0
            out.append(dict(
                round=4, arm=arm, strategy=meta["strategy"], implementation=LAB[meta["strategy"]],
                policy=meta["policy"], backend=meta["backend"], limit=meta["limit"],
                concurrency=meta["concurrency"], trial=meta["trial"],
                admissions=s["admits"], provider_calls=s["provider_calls"],
                excess_over_limit=s["admits"] - meta["limit"],
                windows_touched=s["windows_touched"], max_per_policy=s["max_per_policy"],
                per_window_admissions=json.dumps(s["per_window"]) if s["per_window"] else "",
                classification=("policy violation" if viol else "legitimate cross-window total"),
                basis=BASIS(meta["strategy"]),
                events_file=f"results/r4/{arm}.events.jsonl", requests_logged=s["requests"]))
    for arm in ("boundary_sqlite", "boundary_postgres"):
        path = f"{R}/r4/{arm}.events.jsonl"
        if not os.path.exists(f"{R}/r4/{arm}.csv"):
            continue
        try:
            E.resolve(path)
        except FileNotFoundError:
            continue
        keys = ("arm", "backend", "strategy", "policy", "trial", "k", "limit", "window_s", "boundary")
        for key, evs in E.trials(path, keys).items():
            meta = dict(zip(keys, key))
            s = E.summarise(evs)
            if s["admits"] <= meta["limit"]:
                continue
            viol = s["policy_overrun"] > 0
            out.append(dict(
                round=4, arm=arm, strategy=meta["strategy"], implementation=LAB[meta["strategy"]],
                policy=meta["policy"], backend=meta["backend"], limit=meta["limit"],
                concurrency=meta["k"], trial=meta["trial"],
                admissions=s["admits"], provider_calls=s["provider_calls"],
                excess_over_limit=s["admits"] - meta["limit"],
                windows_touched=s["windows_touched"], max_per_policy=s["max_per_policy"],
                per_window_admissions=json.dumps(s["per_window"]) if s["per_window"] else "",
                classification=("policy violation" if viol else "legitimate cross-window total"),
                basis=BASIS(meta["strategy"]),
                events_file=f"results/r4/{arm}.events.jsonl", requests_logged=s["requests"]))
    # the executed package, from its per-call events
    path = f"{R}/r4/pkg_exec.events.jsonl"
    try:
        if not os.path.exists(f"{R}/r4/pkg_exec.csv"):
            raise FileNotFoundError(path)
        E.resolve(path)
        tr = defaultdict(list)
        for e in E.load(path):
            tr[(e["mode"], int(e["concurrency"]), int(e["trial"]))].append(e)
        for (mode, k, t), evs in sorted(tr.items()):
            d = sum(len(e.get("t_send_mail", [])) for e in evs)
            if d > 1:
                nulls = sum(1 for e in evs if e["decision"] == "admit" and e.get("observed_last_generated") is None)
                out.append(dict(
                    round=4, arm="package_exec", strategy="django-otp 1.7.3 EmailDevice",
                    implementation="django-otp 1.7.3 cooldown (executed as shipped)",
                    policy="one generation per cooldown from the last generation (3600 s)",
                    backend="django+sqlite", limit=1, concurrency=k, trial=t,
                    admissions=sum(1 for e in evs if e["decision"] == "admit"), provider_calls=d,
                    excess_over_limit=d - 1, windows_touched="", max_per_policy=d,
                    per_window_admissions=f"admissions whose loaded instance carried a null cooldown timestamp: {nulls}",
                    classification="policy violation",
                    basis="per-call events: send_mail calls recorded by the counting backend; all within one burst of under a second",
                    events_file="results/r4/pkg_exec.events.jsonl", requests_logged=len(evs)))
    except FileNotFoundError:
        pass
    # historical arms, by policy type only
    hist = {
        "main_sweep_r1": f"{R}/main_sweep.csv", "sequential_r1": f"{R}/sequential.csv",
        "latency_r1": f"{R}/latency.csv", "latency_r2": f"{R}/r2/latency_rest.csv",
        "postgres_main_r2": f"{R}/r2/pg_main.csv", "postgres_pooled_r2": f"{R}/r2/pg_pool.csv",
        "sqlite_randomised_r2": f"{R}/r2/sqlite_main_rand.csv", "workers_r2": f"{R}/r2/workers.csv",
        "limits_r2": f"{R}/r2/limits.csv", "instrumented_sqlite_r2": f"{R}/r2/timing_sqlite.csv",
        "instrumented_postgres_r2": f"{R}/r2/timing_pg.csv", "anomaly_repro_r2": f"{R}/r2/atomic_repro.csv",
        "window_1s_a_r2": f"{R}/r2/window_boundary.csv", "window_1s_b_r2": f"{R}/r2/window_boundary2.csv",
        "instrumented_sqlite_k_r3": f"{R}/r3/timing_sqlite_k.csv",
        "instrumented_postgres_pooled_r3": f"{R}/r3/timing_pg_pooled.csv",
    }
    logs = {"limits_r2": f"{R}/r2/limits.log", "workers_r2": f"{R}/r2/workers.log",
            "postgres_main_r2": f"{R}/r2/pg_main.log", "postgres_pooled_r2": f"{R}/r2/pg_pool.log",
            "sqlite_randomised_r2": f"{R}/r2/sqlite_main_rand.log", "latency_r2": f"{R}/r2/latency_rest.log",
            "main_sweep_r1": f"{R}/main_sweep.log", "sequential_r1": f"{R}/sequential.log",
            "latency_r1": f"{R}/latency.log"}

    def crossed_hour(logfn):
        try:
            ts = re.findall(r"\[(\d\d):(\d\d):(\d\d)\]", open(logfn).read())
        except OSError:
            return None
        return len({t[0] for t in ts}) > 1
    for arm, fn in hist.items():
        if not os.path.exists(fn):
            continue
        crossed = crossed_hour(logs[arm]) if arm in logs else None
        for r in rows(fn):
            lim, n, s = int(r["limit"]), int(r["provider_sends"]), r["strategy"]
            if n <= lim:
                continue
            pol = POLICY[s]
            if pol == "sliding":
                cls, basis = "policy violation", "historical: sliding policy, burst shorter than the window"
            elif s in ONE_STEP:
                cls = "indeterminate (historical: no admission events retained)"
                basis = ("historical: arm log crossed an hour boundary" if crossed
                         else "historical: arm log within one hour")
            elif n > 2 * lim:
                cls, basis = "policy violation", "historical: total exceeds twice the limit, impossible across two windows"
            elif crossed:
                cls = "policy violation, probable (historical: arm crossed an hour boundary; no admission events)"
                basis = "historical: arm log timestamps; two-step shape"
            else:
                cls, basis = "policy violation", "historical: fixed policy, arm did not cross a boundary"
            out.append(dict(round=1 if arm.endswith("_r1") else 2 if arm.endswith("_r2") else 3,
                            arm=arm, strategy=s, implementation=LAB[s], policy=pol,
                            backend=r.get("backend", "sqlite"), limit=lim,
                            concurrency=r["concurrency"], trial=r["trial"],
                            admissions="", provider_calls=n, excess_over_limit=n - lim,
                            windows_touched=r.get("windows_touched", ""), max_per_policy=r.get("max_in_window", ""),
                            per_window_admissions="", classification=cls, basis=basis,
                            events_file="", requests_logged=""))
    with open(f"{R}/overrun_classification.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)
    r4 = [o for o in out if o["round"] == 4]
    summary = Counter((o["implementation"], o["classification"]) for o in r4)
    hsum = Counter((o["implementation"], o["classification"]) for o in out if o["round"] != 4)
    return {"round4_overruns_recorded": len(r4),
            "round4_by_implementation_and_class": {f"{k[0]} :: {k[1]}": v for k, v in summary.items()},
            "round4_one_step_policy_violations": sum(
                v for k, v in summary.items() if k[0] in (LAB[s] for s in ONE_STEP) and k[1] == "policy violation"),
            "round4_one_step_legitimate_cross_window": sum(
                v for k, v in summary.items() if k[0] in (LAB[s] for s in ONE_STEP) and k[1].startswith("legitimate")),
            "round4_two_step_policy_violations": sum(
                v for k, v in summary.items() if k[0] in (LAB[s] for s in ORDER if s not in ONE_STEP) and k[1] == "policy violation"),
            "round4_package_policy_violations": sum(v for k, v in summary.items() if "django-otp" in k[0]),
            "historical_overruns_recorded": len(out) - len(r4),
            "historical_by_implementation_and_class": {f"{k[0]} :: {k[1]}": v for k, v in hsum.items()},
            "historical_indeterminate": sum(v for k, v in hsum.items() if k[1].startswith("indeterminate"))}


def main(argv=None):
    """argv=None parses the command line; pass [] when calling from a notebook."""
    global R
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default=R, help="results root (default: ./results)")
    args = ap.parse_args(argv)
    R = os.path.abspath(args.results)
    OUT["version"] = open(f"{ROOT}/VERSION").read().strip() if os.path.exists(f"{ROOT}/VERSION") else "unversioned"
    OUT["study1"] = study1()
    OUT["study2"] = study2()
    OUT["historical"] = historical()
    OUT["overruns"] = classify_overruns(OUT["study2"])
    json.dump(OUT, open(f"{R}/paper_numbers.json", "w"), indent=1, default=str)
    # The SHA-256 manifest of the archive is written and verified by
    # study/manifest.py, last, after every derived file exists.

    s1, s2, ov, h = OUT["study1"], OUT["study2"], OUT["overruns"], OUT["historical"]
    L = [f"# Every reported number, regenerated  (artifact {OUT['version']})\n", "## Study 1\n"]
    for k in ("index_projects", "name_matches", "metadata_kept", "downloaded_ok", "detector_flagged",
              "excluded_by_hand", "retained", "send_control_evidence_levels", "send_control_yes",
              "send_control_yes_pct", "send_control_yes_ci_pct", "send_control_in_package",
              "send_control_in_package_pct", "send_control_in_package_ci_pct", "send_control_delegated_provider",
              "send_control_helper_not_wired", "send_control_none_in_package", "send_control_no",
              "send_control_no_pct", "verify_control_yes", "both_controls", "send_only", "verify_only",
              "neither", "crosstab", "verify_only_packages", "both_packages", "delegated_packages",
              "helper_not_wired_packages", "changed_in_round4", "send_guards_not_executed", "guard_kinds",
              "sms_capable", "sms_capable_guarded", "sms_capable_guarded_in_package",
              "sms_capable_guarded_packages", "sms_in_other_combinations", "channel_breakdown",
              "detector_precision_pct", "validation_sample", "validation_misses", "miss_rate_pct",
              "miss_rate_ci_pct", "est_missed_in_screened_set", "est_missed_ci",
              "est_relevant_in_screened_set", "est_relevant_ci", "detector_recall_pct",
              "detector_recall_ci_pct", "recall_scope", "unguarded_share_collapsing_django_otp_plugins_pct"):
        L.append(f"- {k}: {s1[k]}")
    L.append("\n## Study 2, round 4 (every trial event-logged)\n")
    L.append(f"- event definition: {s2['event_definition']}")
    L.append(f"- arms: {s2['arms']}; total {s2['arms_total']}; one-step trials {s2['one_step_trials_all_r4_arms']}")
    for name in ("main_sqlite", "main_postgres", "postgres_pooled"):
        if name not in s2:
            continue
        ks = sorted({int(k.split('|')[1]) for k in s2[name]})
        L.append(f"\n### {name} ({s2[name + '_trials']} trials; provider calls == admissions in every trial: {s2[name + '_provider_calls_equal_admits_every_trial']}; errors {s2[name + '_errors']})\n")
        L.append("| implementation | " + " | ".join(f"k={k}" for k in ks) + " |")
        L.append("|---|" + "---|" * len(ks))
        for s in ORDER:
            cells = []
            for k in ks:
                c = s2[name].get(f"{s}|{k}")
                cells.append(f"{c['median']:g}/{c['max']} ({c['over_total']}; pv {c['policy_violations']})" if c else "-")
            L.append(f"| {LAB[s]} | " + " | ".join(cells) + " |")
        L.append(f"- timing (admitted read-to-write ms median/p90; refused statement ms; spread): {s2[name + '_timing']}")
        L.append(f"- interleaving: {s2[name + '_interleaving']}")
        L.append(f"- elapsed: {s2[name + '_elapsed']}")
    for name in ("sequential", "latency", "workers", "limits"):
        if name in s2:
            L.append(f"\n### {name} ({s2[name + '_trials']} trials)\n- " + json.dumps(
                {k: {kk: v[kk] for kk in ('n', 'median', 'max', 'min', 'over_total', 'policy_violations')} for k, v in s2[name].items()}))
    for name in ("boundary_sqlite", "boundary_postgres"):
        if name in s2:
            L.append(f"\n### {name} ({s2[name + '_trials']} trials)\n- {s2[name]}")
    L.append("\n### one-step counter check (sweep arms)\n- " + json.dumps(s2["one_step_counter_check"]))
    L.append("\n### window provenance check (every fixed-window admission, round 4)\n- "
             + json.dumps(s2["window_provenance_check"]))
    L.append("\n### round-5 check arms (service v2.1.0, cache_get_set only; a provenance check reported separately, replacing no round-4 result)\n- "
             + json.dumps(s2["round5_check"]))
    if "package_exec" in s2:
        L.append(f"\n### django-otp 1.7.3 executed ({s2['package_exec_trials']} trials; admits == deliveries every trial: {s2['package_exec_admits_equal_deliveries_every_trial']})\n")
        L.append(f"- {s2['package_exec']}")
        L.append(f"- concurrent over the limit, all k: {s2['package_exec_concurrent_over_all_k']} of {s2['package_exec_concurrent_trials_all_k']}; k>=2: {s2['package_exec_concurrent_over_k_ge_2']} of {s2['package_exec_concurrent_trials_k_ge_2']}; sequential over: {s2['package_exec_sequential_over']}; errors {s2['package_exec_errors']}; excess admissions {s2['package_exec_excess_admissions']}, of which loaded a null cooldown {s2['package_exec_excess_admissions_loaded_null_cooldown']}")
    L.append("\n## Overrun classification\n")
    L.append(f"- {ov}")
    L.append("\n## Historical arms (rounds 1-3, reaggregated; no admission events)\n")
    L.append(f"- arms: {h['arms']}; total {h['arms_total']}")
    L.append(f"- anomaly r2: {h['anomaly_r2_classification']}")
    L.append(f"- located: {h['anomaly_r2_located']}")
    open(f"{R}/paper_numbers.md", "w").write("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
