#!/usr/bin/env bash
# Compile a LaTeX document and refuse to accept the result if anything is
# unresolved. Exit status is non-zero when the log reports an undefined
# reference or citation, a multiply-defined label, a missing file, or an
# error, or when the text extracted from the PDF contains "??" or "[?]".
#
#     bash paper/build.sh paper/otp_preview_ieeetran.tex
#     bash paper/build.sh review/rebuttal_round5.tex
#
# The gate is what "checked after the final compile" means in the rebuttal
# letters from round 5 on; its output for the shipped PDFs is kept beside them
# as <name>.gate.txt.
set -u
src=$1
dir=$(dirname "$src"); base=$(basename "$src" .tex)
cd "$dir" || exit 2
run() { pdflatex -interaction=nonstopmode -halt-on-error "$base.tex" > /dev/null 2>&1; }
run || { echo "GATE: pdflatex failed on pass 1"; grep -n "^!" "$base.log" | head; exit 1; }
if grep -q '\\citation' "$base.aux" 2>/dev/null; then
  bibtex "$base" > /dev/null 2>&1 || { echo "GATE: bibtex failed"; exit 1; }
fi
run || { echo "GATE: pdflatex failed on pass 2"; exit 1; }
run || { echo "GATE: pdflatex failed on pass 3"; exit 1; }
status=0
report="$base.gate.txt"
: > "$report"
echo "gate report for $base.pdf ($(date -u +%FT%TZ))" >> "$report"
for pat in "Reference .* undefined" "Citation .* undefined" "There were undefined" \
           "multiply defined" "multiply-defined" "No file" "^! " "Missing character"; do
  n=$(grep -c -E "$pat" "$base.log")
  echo "log: '$pat' -> $n" >> "$report"
  if [ "$n" != "0" ] && [ "$pat" != "Missing character" ]; then status=1; fi
done
n=$(pdftotext -layout "$base.pdf" - 2>/dev/null | grep -c -E '\?\?|\[\?\]')
echo "pdf text: '??' or '[?]' -> $n" >> "$report"
if [ "$n" != "0" ]; then status=1; fi
echo "overfull hboxes: $(grep -c 'Overfull \\hbox' "$base.log")" >> "$report"
echo "pages: $(pdfinfo "$base.pdf" 2>/dev/null | awk '/^Pages/ {print $2}')" >> "$report"
if [ $status = 0 ]; then echo "GATE PASSED" >> "$report"; else echo "GATE FAILED" >> "$report"; fi
cat "$report"
exit $status
