"""Execute the reproduction notebook with nbclient and save the outputs.

    python3 execute_notebook.py [--reduced]

--reduced flips REDUCED = False to True in Part B before executing, for a
six-minute smoke test. Without it the notebook runs at the paper's trial
counts (about 40 minutes).
"""
import sys
import time

import nbformat
from nbclient import NotebookClient

SRC = "notebooks/otp_quota_reproduction.ipynb"
OUT = "notebooks/otp_quota_reproduction_executed.ipynb"

nb = nbformat.read(SRC, as_version=4)
if "--reduced" in sys.argv:
    for c in nb.cells:
        if c.cell_type == "code" and "REDUCED = False" in c.source:
            c.source = c.source.replace("REDUCED = False", "REDUCED = True")
t0 = time.time()
NotebookClient(nb, timeout=5400, kernel_name="python3", resources={"metadata": {"path": "."}}).execute()
nbformat.write(nb, OUT)
print(f"executed {SRC} -> {OUT} in {time.time() - t0:.0f}s")
