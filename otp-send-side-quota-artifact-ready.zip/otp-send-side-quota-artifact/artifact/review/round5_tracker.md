# Round-5 tracker: Reviewer 2 report on manuscript v3.2 (minor revision) → manuscript v3.3, artifact v3.3-r5

Status key: DONE (closed with evidence in the PDF/artifact), PARTLY (narrowed, limitation stated), OPEN (stated as open; user action).
Page numbers refer to `manuscript_v3.3.pdf` (30 pages), checked by `paper/build.sh` (exit 0, `otp_preview_ieeetran.gate.txt`).

| # | Reviewer item | Status | Where in v3.3 | Artifact evidence |
|---|---|---|---|---|
| 1 | Fixed-window provenance: the database does not return the window for `cache_get_set` | DONE (option 2, plus code and a check arm) | Abstract p.1; §I p.2; §IV-B "The policy event" p.10 (`window_source`; 6,762-admission audit); Table XIX caption p.24; §V-J "The round-5 check" p.23; App. A "The service" p.28 | `svc/app.py`, `svc/app_pg.py` 2.1.0: `admitted_fixed(..., source)`; `RETURNING` on the upsert with `window_id_returned`/`counter_returned`; `svc/archive/` (2.0.0 verbatim, hashes match the v3.2-r4 manifest); `svc/CHANGELOG.md`; `regenerate.py` `window_provenance_check` (cache_get_set 6,762/6,762 aligned, current at read, equal to floor of read; one-step 2,810+2,810) and `round5_check` (results/r5: 1,469+742+479+467 admissions, returned == submitted in all); `overrun_classification.csv` basis column per implementation |
| 2 | "Section ??" on p.20; add a compilation gate | DONE | p.20 now "Section V-J" | `paper/build.sh`: pdflatex×3+bibtex, exits 1 on undefined reference/citation, multiply-defined label, missing file, LaTeX error, or `??`/`[?]` in `pdftotext` output; report shipped as `paper/otp_preview_ieeetran.gate.txt` and `review/rebuttal_round5.gate.txt` |
| 3 | Manifest scope | DONE | App. A p.27 | `study/manifest.py write|verify`; manifest covers every file in the archive except itself (event logs, raw results, derived files, scripts, `reproduce.sh`, `requirements-lock.txt`, `Dockerfile`, both notebooks, paper source and PDF); written last at packaging; `reproduce.sh` verifies it first |
| 4 | Notebook scope wording | DONE | App. A p.28; notebook title cell; README | reviewer's sentence adopted verbatim in the notebook; Part C wording narrowed |
| 5 | Disclosure placeholder | DONE (truthful statement); OPEN (the notification itself) | §V-H p.20 | "As of 23 September 2026 ... had not been notified"; USER ACTION before publication |
| 6 | Figure 8 readability | DONE | Fig. 8 p.20 | two panels (sequential / concurrent), count matrix, no per-point labels; `study/make_figs.py` |
| T1 | Abstract "every number is derived from those records" | DONE | Abstract p.1 | "every server-side Study 2 count and policy classification is derived from those records" |
| T2 | Appendix "returning the window identifier of every fixed-window admission" | DONE | App. A p.28 | restricted to the two one-step implementations; 2.0.0/2.1.0 provenance stated |
| T3 | Discussion "Each link in that chain is measured" | DONE | §VI-A p.24 | "The principal components of that chain are measured separately ... What is not measured is the chain end to end" |
| T4 | Rebuttal absolute wording about checks | DONE | rebuttal round 5 "How to read this letter" | wording tied to the gate's output; gate reports shipped |
| R21 | RESTgym reference note | DONE | ref. [21] p.29 | note removed; `doi = {10.1109/ICST62969.2025.10988956}` (doi.org resolves to Xplore document 10988956); IEEEtran prints no DOI for any entry, so the entry carries the doi.org URL |
| SC | Duplicated assignments in the service | DONE | App. A p.28 | no pattern assigns admission fields; one helper per policy type does (`admitted_fixed`, `admitted_sliding`); the derived `counter_after` of the sliding-window patterns documented; `svc/CHANGELOG.md` |
| — | "Table XVIII remains dense" (observation) | noted | Table XVIII p.22 | unchanged |

## What did not change
Every reported number (Study 1, round-4 Study 2, historical) is the same as in v3.2; the reviewer's independent
classification of the round-4 records agrees with them and the JSON differs from v3.2-r4 only by the version
string, the added `window_provenance_check` and `round5_check` entries and a longer `event_definition` string. The round-4 event logs and
CSVs are byte-identical to v3.2-r4. Compiled table/figure numbering is unchanged (Tables VII–XIX, Figs. 5–8).

## Errors found in our own work during this round
- `\ref{sec:eval-boundary}` referred to a label that does not exist; introduced in the v3.2 final pass and not
  caught because the compile check read only the head of the log. The gate now fails the build.
- The provenance claim for the read-modify-write counter was written as if it shared the one-step
  implementations' `RETURNING`; the record format did not distinguish the two sources. It now does.

## Round-5 arms (service 2.1.0, results/r5/, used for no reported number)
cgs_sqlite 180, cgs_postgres 180, cgs_boundary_sqlite 30, cgs_boundary_postgres 30 = 420 trials; 3,157 admissions;
returned window and counter equal to submitted in every one.
