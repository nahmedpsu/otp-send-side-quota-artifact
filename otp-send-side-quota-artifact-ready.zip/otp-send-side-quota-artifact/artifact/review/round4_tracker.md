# Round-4 tracker: Reviewer 2 report on manuscript v3.1 → manuscript v3.2, artifact v3.2-r4

Status key: DONE (closed with evidence in the PDF/artifact), PARTLY (narrowed, limitation stated), OPEN (stated as open).
Page numbers refer to `manuscript_v3.2.pdf`.

| # | Reviewer item | Status | Where in v3.2 | Artifact evidence |
|---|---|---|---|---|
| 7 | Decisive question: what event is counted; can the artifact prove its window assignment for every request | DONE | §IV-B "The policy event" and "The event log" p.9; §V-J pp.21–22; App. A p.27 | `svc/app.py` (RETURNING window_start; event record per request), `study/policy.py`, `results/r4/*.events.jsonl` (68,700 records), `regenerate.py` (derives every summary from records, stops on CSV disagreement), `results/overrun_classification.csv` (per-window counts per overrun) |
| 2.1 | Oracle measured provider instants, not admissions | DONE | §IV-B; §VI-E p.25 (reviewer's counterexample acknowledged) | round-3 oracle removed; new oracle on admission events |
| 2.2 | Raw send events not preserved | DONE | §IV-B "The event log"; App. A p.27 | every round-4 trial keeps one record per request; CSV is derived and verified |
| 2.3 | Table XVI population (all rows vs admitted) | DONE | Table XVII (v3.1's XVI) p.21; §V-I p.20 | admitted-only window; refused statement time separate; "falls with k" sentence removed |
| 2.4 | maykin mislabelled; audit evidence levels | DONE | §V-C p.14; Table VIII (evidence levels) p.14; Tables VII, IX, X; Table IV note | `results/r4/classification_audit.csv`: maykin → verification-only; django-otp-admin → helper not wired; 10 in-package / 3 delegated / 29 none |
| 2.5 | reproduce.sh trial-count arithmetic; rerun vs reaggregate | DONE | App. A; Table VI (round-4 vs historical) | `reproduce.sh` exact counts (30/10/20), results/repro, `compare_repro.py`; rounds 1–3 not re-run and said so |
| 2.6 | Interleaving claims beyond timestamp evidence | DONE | Table XVIII (v3.1's XVII) p.22; §V-I; §VI-E "Application instants are not the database's order" | primary columns from database-returned values (observed state, written counters); instant columns labelled (app) |
| 3.1 | "The error was in the oracle, not in the implementation" | DONE (withdrawn) | §V-J | anomaly classified indeterminate in `overrun_classification.csv` |
| 3.2 | "No one-step implementation violated its policy in any trial of any arm" | DONE (restated) | §V-J; abstract | 0 violations in 2430 event-logged one-step trials; historical excluded |
| 3.3 | "falls with k because 29 of 32 change no row" | DONE (removed) | §V-I | admitted-only medians 0.48 / 0.69 / 1.3 ms |
| 3.4 | "intervals shrank ... fraction barely moved" | DONE (replaced) | §V-I pooling paragraph; §V-G | counts stated: 20/30 unpooled vs 26/30 pooled |
| 3.5 | "classifies each observed overrun against the exact policy" | DONE (now true for round 4) | App. A | historical rows marked; no per-window counts claimed for them |
| 4.1 | 13 vs 14 unexecuted guards | DONE | §V-B | audited number: 12 (13 with a bound, 1 executed) |
| 4.2–4.3 | 10 vs 11, 20 vs 21 trials | DONE | Table VI; reproduce.sh | round-4 arms run with 10 and 20 |
| 4.4 | Timing medians | DONE | Table XVII; §V-I p.20 (0.48 / 0.69 / 1.3 ms admitted; refused 0.02–0.03 ms) | — |
| 4.5 | Historical anomaly | DONE (indeterminate) | §V-J | — |
| 6.9 | Uncertainty intervals for 30 trials | DONE | §IV-B "Trial count and intervals"; Table VII caption; `paper_numbers.json` per-cell Wilson CIs | — |
| — | End-to-end recall | PARTLY | stated | — |
| — | One coder | PARTLY | evidence and location for every label | — |
| — | Database commit order | PARTLY | ordering claims rest on database-returned values; instants labelled | — |
| — | Independent replication | OPEN | `reproduce.sh`, `compare_repro.py` | — |
| — | Disclosure date | OPEN | visible paragraph §V-H | user action at submission |

## Errors found in our own earlier work during this round (all stated in the paper)
- The round-3 oracle assigned windows from provider-call instants (after the admission and the provider delay); the reviewer's two-request counterexample is exact.
- The round-3 "resolution" of the round-2 anomaly rested on a reconstruction, not on records; the trial is indeterminate.
- Table XVI mixed refused and admitted statements; the "falls with k" sentence followed from that.
- maykin-django-two-factor-auth was labelled by inheritance; its delivery path has no check. django-otp-admin's cooldown helper is never called.
- reproduce.sh ran 11 and 21 trials where the paper said 10 and 20.
- "Barely moved" contradicted the counts in the same paragraph.

## Round-4 arms (all event-logged, results/r4/)
main_sqlite 1080, main_postgres 1080, sequential 180, latency 720, workers 720, limits 360, postgres_pooled 360, boundary_sqlite 180, boundary_postgres 180, pkg_exec 360 = 5,220 trials; 68,700 event records.
