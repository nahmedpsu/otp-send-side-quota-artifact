# Round-3 tracker: Reviewer 2 report on manuscript v3.0 → manuscript v3.1, artifact v3.1-r3

Status key: DONE (closed with evidence in the PDF/artifact), PARTLY (narrowed, limitation stated), OPEN (stated as open).
Page numbers refer to `manuscript_v3.1.pdf` (26 pages, IEEEtran preview build).

| # | Reviewer item | Status | Where in v3.1 | Artifact evidence |
|---|---|---|---|---|
| 7 | One versioned artifact regenerating every count and classifying every overrun | DONE | App. A p.24; §V-J p.20 | `regenerate.py`, `VERSION`, `MANIFEST.sha256.json`, `results/paper_numbers.{json,md}`, `results/overrun_classification.csv` (2,512 rows: 2,428 violations, 23 probable, 61 legitimate cross-window; 0 one-step violations in 3,780 trials) |
| 2A | "No package has both controls" contradicted by django-otp | DONE | Table X p.13; §V-C p.13; Table VII; abstract; contributions p.2; §VI-A p.21; §VII p.23; §VI-E p.22 | `results/r3/classification_audit.csv` (four fields + evidence per package): both 8, send-only 7, verify-only 9, neither 18; 17 any verification control |
| 2B | Recall scope; why cohort stays 42 | DONE | abstract; §I p.2; §V-B p.12; §VI-E p.22; §VII p.23 | `study1.recall_scope` in paper_numbers.json |
| 2C.1 | Atomicity explanation wrong | DONE | §V-I p.18 ("Why atomic admission is correct") | 30/870 and 59/150 refused-before-T3 (`results/r3/interleaving.json`) |
| 2C.2 | Separate duration measurements | DONE | Table XVI p.19 | `results/r3/timing_sqlite_k.*`, `timing_pg_pooled.*` (round-3 arms, 270 + 90 trials) |
| 2C.3 | Evidence that interleavings caused overruns | DONE | Table XVII p.19; §V-I | `study/interleaving.py`; 137/137, 201/204, 172 lost updates, 26/30 at k=2 |
| 2C.4 | "Interval shrinks with k" only measured at k=8 | DONE (retracted) | §V-I p.18; §V-D p.14 | window widens 1.5 → 3.9 → 20.7 ms; spread 28 ms vs T3 17 ms at k=32 |
| 2C.5 | Pooling vs staggering contradiction | DONE | §V-I p.19; §V-G p.17 | pooled: read spread 48 → 6.7 ms, T3 41 → 5.2 ms; outcomes 14/30 vs 27/30 |
| 2C.6 | Mechanisms per pattern (V-F vs V-G) | DONE | §V-F p.15; §V-I | — |
| 2D | Anomaly unresolved; "three safe implementations" | DONE | §V-J p.20; Table XVIII p.21; §VI-B p.21 | `study/locate_anomaly.py` (trial 10/20, 7.95 s before, straddles for overhead 2.2–3.1 s), `study/boundary_test.py` (30/30 straddled, max/window 5, 0 violated), `/otp/sends`, `evaluate_policy`; round-2 1 s-window arm found ineffective (harness override) and said so |
| 2E.1 | Analogy vs equivalence | DONE | §IV p.7; Table IV p.9 (split: exact source vs fixture); abstract; §VI-E p.23 | `results/r2/pattern_provenance.csv` |
| 2E.2 | Device loading / instances / transactions in V-H | DONE | §V-H p.17 | `study/run_package_exec.py` (load after barrier, per-thread instance and connection, autocommit, busy timeout 30 s) |
| 3.1 | 178 vs 120 | DONE | §V-H p.17; abstract | `package_exec_concurrent_over_all_k` = 120/180; `_k_ge_2` = 120/150 |
| 3.2 | 1,620 vs 1,080 | DONE | §V-G p.16; §VI-B p.21 | — |
| 3.3 | 1,740 vs 6,000 vs 6,460 | DONE | Table VI p.12 (7,320 incl. 780 follow-up + 540 round-3); Table III p.6; Fig. 4 p.10 | `study2.arms` |
| 3.4 | "5 of the 15 guarded" | DONE | §VI-A p.21 ("9 of those 27") | — |
| 3.5 | Table VIII 17 vs 20 | DONE | Table VIII p.13 (edumfa, LinOTP, sendotp named) | `study1.sms_in_other_combinations` |
| 4.1 | "Only the two atomic counters would survive" | DONE | §V-B p.12 | — |
| 4.2 | "default path with no guard on it" | DONE | §VI-A p.21 | — |
| 4.3 | "direction of any error is bounded" | DONE (withdrawn) | §VI-E p.22 | — |
| 4.4 | "Local synchronisation is an upper bound" | DONE (withdrawn) | §II-E p.5; §VI-E p.23 | — |
| 4.5 | "tighter policy buys nothing" | DONE | §V-J p.20 | — |
| 4.6 | "moving a to 1 is worth more than any filtering" | DONE | §VI-C p.22 | — |
| 4.7 | "two thirds of one ecosystem" | DONE | §VII p.23 | — |
| 4.8 | "billable sends" everywhere | DONE | all tables/figures/§V-A p.11 | figures regenerated (`study/make_figs.py`) |
| 5.1 | census remnants | DONE | only disavowals (§I p.2, §V-B p.12) | — |
| 5.2 | Figure 5 hidden series | DONE | Fig. 5 p.15 (six legend entries) | — |
| 5.3 | Quartiles/exceedance per cell | DONE | Table XII p.15; per-cell counts in Tables XI, XIII, XIV, XV | `paper_numbers.json` per-cell n/min/q1/median/q3/max/over/distribution |
| 5.4 | Invisible disclosure placeholder | DONE (visible) | §V-H p.18 | user action: file the django-otp report at submission and record the date |
| 5.5 | Nonexistent "Section IV-C" | DONE | App. A p.24 | — |
| 6.1 | Novelty vs DRF docs | DONE | §II-F p.5 (quote + cite `drf2026throttling`); contributions p.2; §VII p.23 | verified at django-rest-framework.org |
| 6.2 | Fig. 4 counts | DONE | p.10 | — |
| 6.3 | Figs 7–8 multiplicity | DONE | pp.16, 18 (marker area ∝ count, labels) | `study/make_figs.py` |
| 6.4 | Table IV split | DONE | p.9 | — |
| 6.5 | Real elapsed-time numbers | DONE | §VI-C p.22 (earlier "guarded txn materially slower" withdrawn) | `main_sqlite_elapsed`, `main_postgres_elapsed`, `main_sqlite_randomised_elapsed` |
| 6.6 | Appendix A location/version | DONE | p.24 | archive `otp_quota_artifact_v3.1-r3.zip`; DOI on acceptance |
| 6.7 | Conclusion crossed design | DONE | §VII p.23; §VI-E p.23 | — |
| — | End-to-end recall | PARTLY | stated unknown | — |
| — | One coder | PARTLY | stated | audit ships with evidence |
| — | Race prevalence across packages | PARTLY | one executed, fourteen guards unexecuted, stated | — |
| — | Independent replication | OPEN | stated | `reproduce.sh`, `study/compare_repro.py` |
| — | Disclosure date | OPEN | visible paragraph | to be filled by the author |

## Errors found in our own earlier work during this round (all stated in the paper)
- Verification-side field populated only for send-unguarded packages → "both = 0" was wrong (8 have both).
- Oracle counted totals across fixed-window boundaries → the one "anomaly" was a false overrun.
- Round-2 harness overrode `OTP_WINDOW_S`, so the "one-second window" arm ran at 3600 s.
- Round-2 rebuttal: 178 of 180 was an arithmetic error (120).
- "Interval shrinks with k" was asserted from k=8 alone; it widens.
- "Guarded transaction materially slower under SQLite" was not supported by the recorded elapsed times.
- Several round-2 scripted text replacements failed silently (census, billable, 5 of the 15, invisible disclosure).

## Independent verification performed before freezing v3.1
A separate agent checked every numerical statement in `body.tex` against `paper_numbers.md`; its findings (four "eight in every trial" sentences, one mixed pair of arms, "thirteen" for fourteen, missing caption names, "probable" qualifier, "exact package" remnant, figure captions without multiplicity, Table XVII missing column, rebuttal page slips) were all corrected.
