# Rewrite notes, manuscript v3.1 / artifact v3.1-r3 (round 3)

What changed since v3.0 and why, for the next session. Sources of truth: `results/paper_numbers.json`
(from `regenerate.py`) and `review/round3_tracker.md`. Deliverables are in
`/mnt/user-data/outputs/OTP DDOS/ieee-access-v3.1/` (manuscript_v3.1.pdf, rebuttal_round3.pdf,
otp_quota_artifact_v3.1-r3.zip and the unpacked folder, executed notebook, overrun_classification.csv).

## Decisions taken
- Single regeneration script (`regenerate.py`) is the answer to the reviewer's decisive question; every
  number in the paper was re-derived from its output. Medians are now exact (9.5, 5.5, 4.5, 7.5).
- The round-2 "anomaly" was an oracle error: the conditional atomic update enforces a FIXED window
  (aligned 3600 s), the arm crossed 21:00:00 UTC, and the trial (position 10 of 20, located by replaying
  the seed) straddled it. Deterministic boundary test (`study/boundary_test.py`) confirms: 10 sends per
  straddling trial, 5 per window, 0 violations. Wording "three safe implementations" removed everywhere;
  now "one-step" (structure) / "no policy violation observed in 3,780 trials" (behaviour).
- Discovered and disclosed: the round-2 "one-second window" arm ran at 3600 s (harness overrode
  OTP_WINDOW_S). Stated in V-J, VI-E, README.
- Atomicity explained by indivisibility, not speed; timing (V-I) split into (1) correctness, (2) duration
  at k=2,8,32 and pooled PG, (3) per-trial interleaving evidence (`study/interleaving.py`, Table XVII).
  "Interval shrinks with k" retracted (it widens); non-monotonic median explained by arrival spread
  (28 ms) vs time to third write (17 ms). Pooling reconciled (both intervals shrink ~7x; outcome barely moves).
- Four-field classification audit (`results/r3/classification_audit.csv`): both 8 / send-only 7 /
  verify-only 9 / neither 18; 17 with any verification control. All dependent text updated.
- Recall scoped to detector stage within 756 candidates; cohort stays 42 (explained).
- Table IV split (exact source behaviour vs fixture); "structurally analogous" everywhere.
- V-H protocol specified (load after barrier, per-thread instance/connection, autocommit, busy timeout).
- DRF throttling docs cited (`drf2026throttling`); novelty reframed in II-F, contributions, VII.
- Performance paragraph now uses recorded elapsed medians; earlier "guarded txn materially slower" withdrawn.
- Tables XI/XIV carry per-cell exceedance; new Table XII (quartiles); Fig 5 six series; Figs 7-8
  multiplicity; Table VI totals 7,320 (780 follow-up + 270 + 90 + 180 round-3 arms).
- Disclosure paragraph is visible text in V-H. USER ACTION: file the django-otp report at submission and
  record the date/response there.
- Appendix A: VERSION v3.1-r3, MANIFEST.sha256.json, archive name; DOI on acceptance.

## Verification done
- Independent agent check of every number in body.tex vs paper_numbers.md; all findings fixed.
- regenerate.py re-run from the unpacked zip: output identical; manifest verified.
- Notebook executed end to end at full trial counts (Part B 1,080 trials in 794 s, 0 errors);
  executed copy shipped beside the clean one.
- Rebuttal page references checked against the compiled PDF with pdftotext.

## Still open (stated in the paper)
End-to-end recall unknown; one coder; race prevalence beyond the one executed package; no independent
replication; disclosure date.
