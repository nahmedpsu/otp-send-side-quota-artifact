# Reviewer 2 response tracker

Every finding in the report, with the disposition and where it is answered.
Statuses: **Addressed** (changed in the manuscript or artifact), **Addressed with
new evidence** (a new experiment or analysis was run), **Partly addressed**
(narrowed or bounded, but not fully closed), **Not addressed** (cannot be closed
by us; stated as a limitation).

---

## A. Population construction (M1–M13)

| ID | Disposition | Where |
|---|---|---|
| M1 Not a census | **Addressed with new evidence.** Recall estimated at 64.5% (95% CI 34.7–86.8%) from a hand-labelled random sample of 60 rejected packages. The word *census* is removed from the title, abstract and body; the 42 are described as a sample throughout. | Title; Abstract; §IV-B; §V-B |
| M2 Search strategy underspecified | **Addressed.** The full protocol is now in the paper: the exact name patterns, the metadata fields consulted, normalisation, the collection date, duplicate handling and the version policy. | §IV-B, Table (search protocol) |
| M3 No recall estimate | **Addressed with new evidence.** Two misses in 60 sampled rejections give an estimated 23 missed packages (95% CI 6–79) and an estimated true population of 65 (95% CI 48–121). | §V-B |
| M4 No independent adjudication | **Not addressed.** We have no second coder. Stated plainly as a limitation; the complete per-package evidence ships so a second coder can be run by anyone. | §VI-D |
| M5 Detector not validated | **Addressed with new evidence.** Precision 68.9% (42 of 61 flagged survived full manual reading); recall as above. The sampling script, the sample and every verdict ship with the artifact. | §V-B; `study/validate_detector.py` |
| M6 Static inspection misses behaviour | **Addressed with new evidence.** One of the two misses, `django-otp-sms` 1.3, is exactly this case: the delivery function resolves its adapter through `import_string` and the outbound call lives in a different module, so neither body satisfies both halves of the detector's test. Reported as a worked example of the failure mode. | §V-B; §VI-D |
| M7 Package-local absence is not an unprotected deployment | **Addressed.** Every sentence converting "no guard in this package" into "unbounded send path" is rewritten. The finding is now stated as where responsibility lands by default. | §I; §V-B; §VI-A; §VII |
| M8 Channel scope inconsistent | **Addressed with new evidence.** The population is broken down by channel. Twenty of the 42 can deliver by SMS; four of those twenty guard the send path. | §V-B, Table (channel breakdown) |
| M9 Package importance ignored | **Partly addressed.** Repository presence and declared dependencies are reported per package. Download counts were not retrievable from this environment, and we do not estimate adoption without them. | §V-B; §VI-D |
| M10 Forks and near-duplicates | **Addressed with new evidence.** Shingle overlap over each package's own Python finds two near-duplicate pairs, both `django-otp-twilio` against its MessageBird and Signal siblings. Collapsing all three to one moves the unguarded share from 64% to 62.5%. | §V-B |
| M11 Binary label too coarse | **Addressed with new evidence.** The single flag is replaced by a guard-type taxonomy: cooldown, max sends, framework throttle, atomic counter, hosted service, other. | §V-B, Table (guard types) |
| M12 Exclusion sensitivity is circular | **Partly addressed.** The objection is correct and the bound is now stated as conditional on the same reading that produced it. The recall estimate is the non-circular bound and is reported alongside. | §VI-D |
| M13 Snapshot not anchored in the paper | **Addressed.** Collection date, index size, per-package versions and the artifact file that holds the snapshot are named in the paper. | §IV-B |

## B. Connection between the two studies (M14–M17)

| ID | Disposition | Where |
|---|---|---|
| M14 No traceable mapping | **Addressed with new evidence.** Each shape is mapped to a package, version, file, function and line span. | §IV-A, Table (pattern provenance) |
| M15 Prevalence of each pattern unknown | **Addressed with new evidence.** The shape of every guard in the population is classified and counted. | §V-B |
| M16 Suspiciously balanced design | **Addressed.** The design is not balanced by sampling and never was. Three shapes were found in the surveyed code; the three safe ones are remedies we wrote, and the paper now says so. No surveyed package uses a transaction or a reservation on the send path. | §IV-A |
| M17 Experiments do not execute real packages | **Addressed with new evidence.** `django-otp` 1.7.3 is now executed under the harness. Against its own declared cooldown, concurrent calls delivered more than one token; sequential calls delivered exactly one. | §V-E |

## C. Experimental validity (M18–M35)

| ID | Disposition | Where |
|---|---|---|
| M18 One technology stack | **Partly addressed.** A second datastore is added. The web framework and server are unchanged and this is stated. | §V-F; §VI-D |
| M19 One storage system | **Addressed with new evidence.** PostgreSQL 16, 1,080 trials, with and without a connection pool. | §V-F |
| M20 Worker count fixed at four | **Addressed with new evidence.** Swept over one, two, four and eight workers. | §V-G |
| M21 Local rather than network-realistic | **Partly addressed.** The experiment remains local. Server-side instrumentation now shows how much of the barrier's simultaneity survives to the critical section, and the claim is narrowed accordingly. | §V-H; §VI-D |
| M22 Arrival synchronisation not measured | **Addressed with new evidence.** The service records receipt, read, decide, write and provider-call instants. The race window is now measured. | §V-H |
| M23 One quota only | **Addressed with new evidence.** Declared limits of 1, 3, 5 and 10 are swept. | §V-G |
| M24 One identity per trial | **Not addressed.** Multi-user contention was not run. Stated as a limitation and as future work. | §VI-D |
| M25 Provider is only a sleep stub | **Partly addressed.** The stub is unchanged, and what it does and does not model is now enumerated explicitly rather than left implicit. | §IV-C; §VI-D |
| M26 Billable send assumed | **Not addressed.** We contacted no provider and observed no invoice. The paper reports attempted provider calls and says so in those words. | §IV-C; §VI-D |
| M27 Latency range unjustified | **Partly addressed.** The range is now presented as a span chosen to bracket plausible round trips, not as a measurement of any provider, and the conclusion rests on the 0 ms case. | §V-I |
| M28 Latency arm covers four of six | **Addressed with new evidence.** All six patterns are now run at all four latencies. | §V-I |
| M29 No randomisation | **Addressed with new evidence.** Arm and cell order are randomised under a recorded seed, and a randomised replication of the main sweep is reported beside the original. | §IV-C; §V-D |
| M30 No environment specification | **Addressed.** Hardware, kernel, Python, package versions and a lockfile are reported and shipped. | §IV-C; Appendix A |
| M31 No warm-up protocol | **Addressed.** The reset-per-trial protocol and the server readiness probe are described. | §IV-C |
| M32 No resource measurements | **Partly addressed.** The instrumented run reports the read-to-write interval per request, which is the quantity the non-monotone result turns on. CPU and lock-wait counters were not collected. | §V-H; §VI-D |
| M33 Request failures not reported | **Addressed.** Every client outcome, including exception type, is recorded and reported. Across the new runs the count is zero. | §IV-C; §V-D |
| M34 No independent replication | **Not addressed.** Nobody outside the author group has re-run this. The artifact exists so that they can. | §VI-D |
| M35 No performance evaluation of the recommended controls | **Addressed with new evidence.** Per-trial elapsed time is reported for all six patterns, so the cost of the safe ones is visible. | §V-J |

## D. Statistics and analysis (M36–M42)

| ID | Disposition | Where |
|---|---|---|
| M36 Thirty trials unjustified | **Addressed.** A precision rationale is given in terms of the width of the interval the design can resolve. | §IV-C |
| M37 Maxima without uncertainty | **Addressed.** Quartiles and the count of trials exceeding the limit accompany every cell. | §V-D |
| M38 Median and maximum conceal shape | **Addressed with new evidence.** Every observation is plotted, and the raw per-trial files ship. | §V-D, Fig. (distributions) |
| M39 Non-monotone result treated as stable | **Addressed.** It is now reported as a property of this configuration, with the measured read-to-write interval as the mechanism, and not as a property of the pattern. | §V-D; §V-H |
| M40 Independence not demonstrated | **Partly addressed.** The randomised replication agrees with the original, which is evidence against order effects but not a proof of independence. | §V-D |
| M41 Sequential control changes more than concurrency | **Addressed.** The claim is narrowed to what the control supports. | §V-D |
| M42 No false-positive analysis for the oracle | **Partly addressed.** What the provider-call count does and does not capture is enumerated, including the asynchronous and compensating cases it would miss. | §VI-C |

## E. Threat model (M43–M46)

| ID | Disposition | Where |
|---|---|---|
| M43 Remote synchronisation assumed | **Addressed.** Kettle's single-packet technique is cited and the difference from a local barrier is stated; the capability is no longer described as costless. | §II-E; §III-C; §VI-A |
| M44 Interacting protections omitted | **Addressed.** A layered-control subsection covers CAPTCHA, device and number reputation, session binding, IP and ASN throttling, and provider-side fraud controls, with the vendor documentation cited. | §II-F; §III-C |
| M45 No economic model | **Addressed.** A parameterised cost model is given. We do not assert a unit price; the model is stated in terms of one, so a reader can substitute their own contract. | §VI-B |
| M46 No legitimate-user model | **Addressed.** The cost of stronger controls to shared devices, NATed users and recycled numbers is discussed. | §VI-B |

## F. Artifact (M47–M54)

| ID | Disposition | Where |
|---|---|---|
| M47 Notebook not self-contained | **Addressed.** The submission package now contains every module and result file the notebook imports. | Appendix A |
| M48 Outputs from an external path | **Addressed.** The notebook resolves its root relative to itself and is re-executed from a clean checkout. | Appendix A |
| M49 QUICK default | **Addressed.** The default is now full reproduction; the reduced mode is opt-in. | Appendix A |
| M50 Raw census evidence absent | **Addressed.** The package list, the per-package adjudication with reasons, the detector sample and its verdicts all ship. | Appendix A |
| M51 No environment lock | **Addressed.** A pinned requirements file and a container recipe ship. | Appendix A |
| M52 Exceptions suppressed | **Addressed.** No execution path swallows an exception; every one is recorded with its type. | `study/run_experiments.py` |
| M53 Numbering drift | **Addressed.** The notebook refers to the manuscript's numbering. | Appendix A |
| M54 "Everything needed" is false | **Addressed.** The claim is qualified to what is actually in the package, and the package is made to match. | Appendix A |

## G. Overstated claims (O1–O23)

All twenty-three sentences are rewritten or deleted. The table of before and
after is in the rebuttal letter.

## H. Numerical and reporting inconsistencies (N1–N7)

| ID | Disposition |
|---|---|
| N1 | **Correct, and corrected.** The safe patterns deliver min(k, limit). The sentence now says so. |
| N2 | **Correct, and corrected.** 540 is three safe patterns at 180 trials each. Attribution fixed. |
| N3 | **Correct, and corrected.** One reproduction time, measured, used everywhere. |
| N4 | **Correct, and corrected.** The cross-tabulation shows all five verification-only packages are among the 27 without a send-side guard, not among the 15 with one. The Discussion sentence was wrong. |
| N5 | **Corrected.** k=1 is in the table. |
| N6 | **Corrected.** Full reproduction is the default. |
| N7 | **Corrected.** Numbering aligned. |

## I. Related work (R1–R7)

| ID | Disposition |
|---|---|
| R1 | Walfish et al., NSDI 2006, added and discussed. |
| R2 | Raghavan et al., SIGCOMM 2007, added and discussed. |
| R3 | Kettle 2023 added; the local barrier is compared with single-packet synchronisation. |
| R4 | Twilio's *Preventing Fraud in Verify* added, with its named controls. |
| R5 | AWS End User Messaging SMS protections added, with its named controls. |
| R6 | Idempotence and reservation literature already cited is now discussed in depth against our recommendation. |
| R7 | Framework throttles are now part of the evidence: three surveyed packages delegate to Django REST Framework throttle classes, and that path is described. |

## J. Presentation (P1–P16)

| ID | Disposition |
|---|---|
| P1 | The vantage-point figure is recast as a description of observation scope, with the selection method for the compared work stated. |
| P2 | Both crowded figures are split and simplified. |
| P3 | The illustrative timeline is replaced by an observed trace from the instrumented run. |
| P4 | The safe patterns are drawn as separate series with their elapsed-time cost. |
| P5 | Every observation is shown. |
| P6 | The three-way comparison table is reframed as three incomparable measurements, with the incomparability as the point rather than a caveat. |
| P7 | Exclusion reasons and the send-side against verification-side cross-tabulation are both in the paper. |
| P8 | k=1 included. |
| P9 | All six patterns at all four latencies. |
| P10 | Captions describe what was measured. |
| P11 | The problem statement and the three questions are explicit. |
| P12 | Terminology is fixed to one set of definitions and used consistently. |
| P13 | The abstract leads with what was measured and states the external-validity limitation. |
| P14 | Page balance fixed. |
| P15 | Built as a submission, not a preview. |
| P16 | Notebook aligned to this revision. |

## The question that can sink the paper

> Which exact surveyed package and version instantiates each of the six
> experimental patterns, and can the artifact automatically execute those real
> implementations under the same concurrency harness?

Answered in §IV-A and §V-E. The mapping names package, version, file, function
and line span for each shape found in the wild. For the check-then-act shape the
artifact executes the real package: `study/run_package_exec.py` drives
`django-otp` 1.7.3's own `EmailDevice.generate_challenge` under the same barrier
protocol. Two of the six shapes have no instance in the surveyed population, and
the paper now says which two and why that is itself a finding.
