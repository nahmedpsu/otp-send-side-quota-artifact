# Service changelog

The service is the fixture every Study 2 arm runs against. Its version is
the `version=` string of the FastAPI application in `svc/app.py` and
`svc/app_pg.py`. The sources of every version that produced a shipped event
log are archived verbatim under `svc/archive/`.

## 2.1.0 (round 5, artifact v3.3-r5)

Produced: `results/r5/` (the round-5 check arms: a provenance check reported separately
in the paper; they replace or recompute no round-4 result).

- **Read-modify-write counter (`cache_get_set`): `RETURNING window_start,
  used` on the upsert.** The record now carries the value the database
  returned (`window_id_returned`, `counter_returned`) beside the value the
  request submitted (`window_id`, `counter_after`). The upsert sets the columns
  to the submitted values, so the two are equal by the statement's semantics;
  `regenerate.py` (`round5_check`) confirms it for every admission in
  `results/r5/`. The returned value certifies the committed transition, not
  the state the row was in before it; that state is what this pattern never
  asks the database to adjudicate.
- **`window_source` on every fixed-window admission record**: `"returning"`
  for `atomic_update` and `reserve_commit` (the conditional UPDATE returned
  the row's window), `"submitted"` for `cache_get_set` (the request computed
  the window and wrote it).
- **Admission fields assigned by one helper per policy type.**
  `admitted_fixed()` sets `window_id`, `policy_ts`, `counter_after` and
  `window_source`; `admitted_sliding()` sets `policy_ts` and `counter_after`.
  Previously each pattern assigned them itself: the fixed-window patterns
  assigned the same row value to `window_id` and `policy_ts` on consecutive
  lines, and the sliding-window patterns assigned a derived `counter_after`
  (observed + 1) without saying so. `policy_ts` is kept on fixed-window
  records (equal to `window_id`) so that every admission record has it.
- Module docstrings state, per implementation, where the recorded window
  comes from.

No other behaviour changed: the SQL of every pattern except the upsert's
`RETURNING` clause, the provider stub, the event-record fields that existed
before, the endpoints and the environment variables are the same as in 2.0.0.

Diff against 2.0.0: `diff svc/archive/app_v2.0.0.py svc/app.py` and
`diff svc/archive/app_pg_v2.0.0.py svc/app_pg.py`.

## 2.0.0 (round 4, artifact v3.2-r4)

Produced: `results/r4/` (every reported Study 2 number).

- The policy event defined as the admission; one event record per request,
  appended after the request to a per-worker file; `GET /otp/events`.
- `RETURNING window_start, used` on the conditional UPDATE of `atomic_update`
  and `reserve_commit`; `_roll_window` made idempotent within a window.
- SHA-256 in the v3.2-r4 manifest: `svc/app.py`
  `332152e6800384bf62dd9a655e8188f0c1a4233c75e948417967dcd4320b4fcc`,
  `svc/app_pg.py`
  `b1a7ad0468c6033404c94063c403fe193561b6a8dc8c78596a144c4e0a404a9e`;
  the archived copies have these hashes.

## 1.x (rounds 1 to 3)

Provider-call rows only, no event records. The runs are historical
(`results/`, `results/r2/`, `results/r3/`); they replace or contribute to no round-4
result and appear in the paper only in the comparison with round 4.
