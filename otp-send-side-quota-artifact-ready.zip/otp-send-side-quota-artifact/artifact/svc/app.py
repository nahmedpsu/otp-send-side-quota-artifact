"""
OTP send endpoint with selectable quota-enforcement strategies. SQLite backend.

Each strategy is a structural analogue of a pattern found in surveyed OTP
packages or in the application code that wraps them. The service is
deliberately ordinary: FastAPI, SQLite in WAL mode, multiple worker processes.
Nothing here is instrumented to make a race easier to hit; the only tunable is
how long the simulated provider call takes.

The policy event (added in round 4)
-----------------------------------
Every implementation declares a limit of LIMIT admissions per phone number per
window. An ADMISSION is the completion of the implementation's own granting
state update: the conditional increment (one-step, fixed window), the counter
write (two-step, fixed window), or the decision to insert a record (sliding
window). The policy is evaluated on admission events, never on provider-call
instants, because the provider call happens after the admission and its
timestamp can fall in a later window.

Where the window of a fixed-window admission comes from differs between the
one-step and the two-step implementations, and the record says which
(`window_source`):

  atomic_update, reserve_commit ("returning"): the conditional UPDATE both
      decides and reports; the window_id is the window_start the counter row
      held when that statement was applied, returned by the database in the
      statement itself (RETURNING). The application never computes it.
  cache_get_set ("submitted"): the read-modify-write counter computes
      everything in the application, as the pattern does: it reads the row,
      keeps the row's window_start if it is still current or computes a new
      one from its own clock, and writes used+1 with that window_start back.
      The window_id is the window_start the request's own upsert wrote. Since
      version 2.1.0 the upsert carries RETURNING and the record also holds
      the value the database returned (window_id_returned); the upsert sets
      the column to the submitted value, so the two are equal by the
      statement's semantics and the returned value certifies the committed
      transition, not the state the row was in before it. That state is what
      the pattern never asks the database to adjudicate, and its loss under
      concurrency is the defect being measured.

For the sliding-window implementations the admission timestamp (policy_ts)
is the `now` value the implementation itself used in its check and stored in
its record; there is no window identifier.

Every request, admitted or refused, writes one event record with its request
id, the instants at which it was received, read the state, decided and wrote,
the state it observed, the decision, the window identifier or admission
timestamp, the counter value after the update, and, for admitted requests, the
provider-call start and end instants and message id. Records are appended to
a per-worker file (OTP_EVENT_DIR/events-<pid>.jsonl) after the request has
finished, so the log never touches the database and never sits inside the
interval being measured. GET /otp/events?phone= returns them.

Environment:
  OTP_STRATEGY    one of the keys in STRATEGIES (default: naive_count)
  OTP_LIMIT       declared admissions allowed per phone per window (default: 3)
  OTP_WINDOW_S    window length in seconds (default: 3600)
  OTP_PROVIDER_MS simulated provider round trip in milliseconds (default: 50)
  OTP_DB          path to the SQLite database
  OTP_EVENT_DIR   directory for the per-worker event logs (default: <db>.events)
"""
import glob
import json
import os
import sqlite3
import time
import uuid

from fastapi import FastAPI
from pydantic import BaseModel

DB = os.environ.get("OTP_DB", "/tmp/otp.db")
STRATEGY = os.environ.get("OTP_STRATEGY", "naive_count")
LIMIT = int(os.environ.get("OTP_LIMIT", "3"))
WINDOW_S = int(os.environ.get("OTP_WINDOW_S", "3600"))
PROVIDER_MS = float(os.environ.get("OTP_PROVIDER_MS", "50"))
EVENT_DIR = os.environ.get("OTP_EVENT_DIR", DB + ".events")
# The policy each implementation enforces. "fixed": at most LIMIT admissions
# per aligned window of WINDOW_S seconds. "sliding": at most LIMIT admissions
# in any trailing interval of WINDOW_S seconds.
POLICY = {"naive_count": "sliding", "after_send": "sliding",
          "immediate_txn": "sliding", "cache_get_set": "fixed",
          "atomic_update": "fixed", "reserve_commit": "fixed"}

app = FastAPI(title="OTP send service", version="2.1.0")
_event_file = None


def conn():
    c = sqlite3.connect(DB, timeout=30.0, isolation_level=None)
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA busy_timeout=30000")
    return c


def init_db():
    c = conn()
    c.executescript(
        """
        CREATE TABLE IF NOT EXISTS attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT NOT NULL,
            ts REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS ix_attempts ON attempts(phone, ts);
        CREATE TABLE IF NOT EXISTS counters (
            phone TEXT PRIMARY KEY,
            used INTEGER NOT NULL DEFAULT 0,
            window_start REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS provider_sends (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT NOT NULL,
            message_id TEXT NOT NULL,
            ts REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS reservations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT NOT NULL,
            state TEXT NOT NULL,
            ts REAL NOT NULL
        );
        """
    )
    c.close()
    os.makedirs(EVENT_DIR, exist_ok=True)


def record_event(ev):
    """Append one event record to this worker's log, after the request."""
    global _event_file
    if _event_file is None:
        os.makedirs(EVENT_DIR, exist_ok=True)
        _event_file = open(os.path.join(EVENT_DIR, f"events-{os.getpid()}.jsonl"), "a")
    ev["pid"] = os.getpid()
    ev["strategy"] = STRATEGY
    ev["policy"] = POLICY[STRATEGY]
    ev["limit"] = LIMIT
    ev["window_s"] = WINDOW_S
    _event_file.write(json.dumps(ev) + "\n")
    _event_file.flush()


def provider_send(phone: str, ev) -> str:
    """Stand-in for the aggregator API call. Records one provider-call attempt.

    The start and end instants are recorded in the event; the provider_sends
    row keeps its own instant so the two records can be cross-checked.
    """
    ev["t_provider_start"] = time.time()
    if PROVIDER_MS > 0:
        time.sleep(PROVIDER_MS / 1000.0)
    mid = uuid.uuid4().hex
    c = conn()
    c.execute(
        "INSERT INTO provider_sends(phone, message_id, ts) VALUES (?,?,?)",
        (phone, mid, time.time()),
    )
    c.close()
    ev["t_provider_end"] = time.time()
    ev["message_id"] = mid
    return mid


def window_floor(now: float) -> float:
    return now - (now % WINDOW_S)


def new_event(phone):
    return {"rid": uuid.uuid4().hex, "phone": phone, "t_recv": time.time()}


def finish(ev, decision, note):
    ev["decision"] = decision
    ev["t_done"] = time.time()
    record_event(ev)
    return decision == "admit", note


def admitted_fixed(ev, window_start, used_after, source):
    """Record a fixed-window admission. `source` is "returning" when the
    granting statement returned the window (one-step) and "submitted" when
    the request computed it and wrote it (read-modify-write counter).
    policy_ts is set to the same value so that every admission record carries
    it; the oracle reads window_id for fixed-window policies."""
    ev["window_id"] = window_start
    ev["policy_ts"] = window_start
    ev["counter_after"] = used_after
    ev["window_source"] = source


def admitted_sliding(ev, now, used_after):
    """Record a sliding-window admission: the timestamp the check used, and
    the count the check observed plus this admission. The latter is a derived
    value, not a counter the pattern wrote (these patterns insert records);
    it is kept so that every admission record carries counter_after."""
    ev["policy_ts"] = now
    ev["counter_after"] = used_after


# --------------------------------------------------------------------------
# Strategies. Each returns (allowed: bool, note: str).
# --------------------------------------------------------------------------

def s_naive_count(phone):
    """Count rows, compare, then insert. No transaction around the pair."""
    ev = new_event(phone)
    now = time.time()
    c = conn()
    used = c.execute(
        "SELECT COUNT(*) FROM attempts WHERE phone=? AND ts>=?",
        (phone, now - WINDOW_S),
    ).fetchone()[0]
    ev["t_read"], ev["observed"] = time.time(), used
    if used >= LIMIT:
        c.close()
        ev["t_decide"] = time.time()
        return finish(ev, "refuse", "over_quota")
    ev["t_decide"] = time.time()
    cur = c.execute("INSERT INTO attempts(phone, ts) VALUES (?,?)", (phone, now))
    ev["t_write"] = time.time()
    ev["record_id"] = cur.lastrowid          # database-assigned insertion order
    c.close()
    admitted_sliding(ev, now, used + 1)      # `now` is the timestamp the check used
    provider_send(phone, ev)
    return finish(ev, "admit", "sent")


def s_cache_get_set(phone):
    """Read counter, add one, write it back. The cache-style pattern."""
    ev = new_event(phone)
    now = time.time()
    c = conn()
    row = c.execute(
        "SELECT used, window_start FROM counters WHERE phone=?", (phone,)
    ).fetchone()
    ev["t_read"] = time.time()
    if row is None or now - row[1] >= WINDOW_S:
        used, wstart = 0, window_floor(now)
    else:
        used, wstart = row[0], row[1]
    ev["observed"] = used
    if used >= LIMIT:
        c.close()
        ev["t_decide"] = time.time()
        return finish(ev, "refuse", "over_quota")
    ev["t_decide"] = time.time()
    row = c.execute(
        "INSERT INTO counters(phone, used, window_start) VALUES (?,?,?) "
        "ON CONFLICT(phone) DO UPDATE SET used=?, window_start=? "
        "RETURNING window_start, used",
        (phone, used + 1, wstart, used + 1, wstart),
    ).fetchone()
    ev["t_write"] = time.time()
    c.close()
    # The window this admission counts in is the one the request wrote
    # (application-computed: the row's if current, else its own clock's).
    # The RETURNING clause echoes the committed row; see the module docstring.
    admitted_fixed(ev, wstart, used + 1, "submitted")
    ev["window_id_returned"], ev["counter_returned"] = row[0], row[1]
    provider_send(phone, ev)
    return finish(ev, "admit", "sent")


def s_after_send(phone):
    """Check, send, then increment. Quota is consumed only on success."""
    ev = new_event(phone)
    now = time.time()
    c = conn()
    used = c.execute(
        "SELECT COUNT(*) FROM attempts WHERE phone=? AND ts>=?",
        (phone, now - WINDOW_S),
    ).fetchone()[0]
    c.close()
    ev["t_read"], ev["observed"] = time.time(), used
    if used >= LIMIT:
        ev["t_decide"] = time.time()
        return finish(ev, "refuse", "over_quota")
    ev["t_decide"] = time.time()
    admitted_sliding(ev, now, used + 1)      # `now` is the timestamp the check used
    provider_send(phone, ev)
    c = conn()
    rec_ts = time.time()
    cur = c.execute("INSERT INTO attempts(phone, ts) VALUES (?,?)", (phone, rec_ts))
    ev["t_write"] = time.time()
    ev["record_id"] = cur.lastrowid
    ev["record_ts"] = rec_ts                 # what the implementation stored
    c.close()
    return finish(ev, "admit", "sent")


def _roll_window(c, phone, now):
    """Fixed-window reset, conditional on the stored window start, so it is
    idempotent within a window and cannot clear a counter another request
    has advanced in the same window."""
    c.execute(
        "INSERT OR IGNORE INTO counters(phone, used, window_start) VALUES (?,0,?)",
        (phone, window_floor(now)),
    )
    c.execute(
        "UPDATE counters SET used=0, window_start=? WHERE phone=? AND ?-window_start>=?",
        (window_floor(now), phone, now, WINDOW_S),
    )


def s_atomic_update(phone):
    """Single conditional UPDATE; the database decides and reports the window."""
    ev = new_event(phone)
    now = time.time()
    c = conn()
    _roll_window(c, phone, now)
    ev["t_read"] = time.time()               # statement issue instant
    row = c.execute(
        "UPDATE counters SET used=used+1 WHERE phone=? AND used<? "
        "RETURNING window_start, used", (phone, LIMIT)
    ).fetchone()
    ev["t_decide"] = ev["t_write"] = time.time()
    c.close()
    if row is None:
        return finish(ev, "refuse", "over_quota")
    admitted_fixed(ev, row[0], row[1], "returning")
    provider_send(phone, ev)
    return finish(ev, "admit", "sent")


def s_immediate_txn(phone):
    """Check and increment inside one write transaction."""
    ev = new_event(phone)
    now = time.time()
    c = conn()
    try:
        c.execute("BEGIN IMMEDIATE")
        used = c.execute(
            "SELECT COUNT(*) FROM attempts WHERE phone=? AND ts>=?",
            (phone, now - WINDOW_S),
        ).fetchone()[0]
        ev["t_read"], ev["observed"] = time.time(), used
        if used >= LIMIT:
            c.execute("ROLLBACK")
            c.close()
            ev["t_decide"] = time.time()
            return finish(ev, "refuse", "over_quota")
        ev["t_decide"] = time.time()
        cur = c.execute("INSERT INTO attempts(phone, ts) VALUES (?,?)", (phone, now))
        ev["record_id"] = cur.lastrowid
        c.execute("COMMIT")
        ev["t_write"] = time.time()
    except Exception as e:
        try:
            c.execute("ROLLBACK")
        except Exception:
            pass
        c.close()
        ev["error"] = type(e).__name__
        return finish(ev, "error", "error")
    c.close()
    admitted_sliding(ev, now, used + 1)
    provider_send(phone, ev)
    return finish(ev, "admit", "sent")


def s_reserve_commit(phone):
    """Reserve atomically before the send; release if the send fails."""
    ev = new_event(phone)
    now = time.time()
    c = conn()
    _roll_window(c, phone, now)
    ev["t_read"] = time.time()
    row = c.execute(
        "UPDATE counters SET used=used+1 WHERE phone=? AND used<? "
        "RETURNING window_start, used", (phone, LIMIT)
    ).fetchone()
    ev["t_decide"] = ev["t_write"] = time.time()
    if row is None:
        c.close()
        return finish(ev, "refuse", "over_quota")
    c.execute(
        "INSERT INTO reservations(phone, state, ts) VALUES (?, 'held', ?)", (phone, now)
    )
    c.close()
    admitted_fixed(ev, row[0], row[1], "returning")
    try:
        provider_send(phone, ev)
    except Exception as e:
        c = conn()
        c.execute("UPDATE counters SET used=used-1 WHERE phone=?", (phone,))
        c.close()
        ev["error"] = type(e).__name__
        return finish(ev, "released", "provider_error")
    return finish(ev, "admit", "sent")


STRATEGIES = {
    "naive_count": s_naive_count,
    "cache_get_set": s_cache_get_set,
    "after_send": s_after_send,
    "atomic_update": s_atomic_update,
    "immediate_txn": s_immediate_txn,
    "reserve_commit": s_reserve_commit,
}


class OTPRequest(BaseModel):
    phone: str


@app.on_event("startup")
def _startup():
    init_db()


@app.post("/otp/request")
def otp_request(req: OTPRequest):
    """Request an OTP for a phone number."""
    fn = STRATEGIES[STRATEGY]
    allowed, note = fn(req.phone)
    if allowed:
        return {"status": "sent", "note": note}
    return {"status": "rejected", "note": note}


@app.get("/otp/stats")
def stats(phone: str):
    """Provider-call attempts recorded for a phone number."""
    c = conn()
    n = c.execute(
        "SELECT COUNT(*) FROM provider_sends WHERE phone=?", (phone,)
    ).fetchone()[0]
    c.close()
    return {"phone": phone, "provider_sends": n, "limit": LIMIT,
            "strategy": STRATEGY, "provider_ms": PROVIDER_MS,
            "policy": POLICY[STRATEGY], "window_s": WINDOW_S}


@app.get("/otp/sends")
def sends(phone: str):
    """Every provider call recorded for this number, with its instant.

    Provider-call instants are NOT the policy event; see the module docstring.
    They are returned so the harness can cross-check that every admission
    produced exactly one provider call.
    """
    c = conn()
    rows = c.execute("SELECT ts, message_id FROM provider_sends WHERE phone=? ORDER BY ts",
                     (phone,)).fetchall()
    c.close()
    return {"phone": phone, "limit": LIMIT, "window_s": WINDOW_S,
            "ts": [r[0] for r in rows], "message_ids": [r[1] for r in rows]}


@app.get("/otp/events")
def events(phone: str):
    """Every request event recorded for this number, from all worker logs."""
    out = []
    for fn in glob.glob(os.path.join(EVENT_DIR, "events-*.jsonl")):
        with open(fn) as f:
            for line in f:
                if not line.strip():
                    continue
                ev = json.loads(line)
                if ev.get("phone") == phone:
                    out.append(ev)
    out.sort(key=lambda e: e["t_recv"])
    return {"phone": phone, "limit": LIMIT, "window_s": WINDOW_S,
            "policy": POLICY[STRATEGY], "events": out}


@app.post("/admin/reset")
def reset():
    c = conn()
    for t in ("attempts", "counters", "provider_sends", "reservations"):
        c.execute(f"DELETE FROM {t}")
    c.close()
    return {"status": "reset"}
