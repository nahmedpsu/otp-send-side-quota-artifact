"""
OTP send endpoint, PostgreSQL backend.

The same six quota-enforcement strategies as svc/app.py, written the way each
would idiomatically be written against PostgreSQL rather than SQLite. Keeping
the two files side by side rather than abstracting over the driver is
deliberate: a reader can diff them and see exactly what changed between the two
datastores and what did not.

The policy event and the per-request event log are defined in svc/app.py and
are identical here, including where the window of a fixed-window admission
comes from (`window_source`): for atomic_update and reserve_commit it is the
window_start the counter row held when the conditional UPDATE was applied,
returned by PostgreSQL in that statement ("returning"); for cache_get_set it
is the window_start the request's own upsert wrote, computed by the
application ("submitted"; since 2.1.0 the upsert's RETURNING clause echoes
it as window_id_returned). The admission timestamp of a sliding-window
admission is the `now` the implementation used in its own check. Events are
appended to a per-worker file after the request.

Environment:
  OTP_STRATEGY     one of the keys in STRATEGIES (default: naive_count)
  OTP_LIMIT        declared admissions allowed per phone per window (default: 3)
  OTP_WINDOW_S     window length in seconds (default: 3600)
  OTP_PROVIDER_MS  simulated provider round trip in milliseconds (default: 50)
  OTP_PG_DSN       libpq connection string
  OTP_PG_POOL      connection pool size; 0 (default) opens one connection per request
  OTP_EVENT_DIR    directory for the per-worker event logs
"""
import glob
import json
import os
import time
import uuid

import psycopg
from psycopg_pool import ConnectionPool
from fastapi import FastAPI
from pydantic import BaseModel

DSN = os.environ.get("OTP_PG_DSN", "dbname=otp user=otp password=otp host=127.0.0.1")
STRATEGY = os.environ.get("OTP_STRATEGY", "naive_count")
LIMIT = int(os.environ.get("OTP_LIMIT", "3"))
WINDOW_S = int(os.environ.get("OTP_WINDOW_S", "3600"))
PROVIDER_MS = float(os.environ.get("OTP_PROVIDER_MS", "50"))
EVENT_DIR = os.environ.get("OTP_EVENT_DIR", "/tmp/otp_pg.events")
# Connection model. Opening a connection per request matches the SQLite
# backend and isolates the datastore change; pooling is what a production
# deployment would do, and setting OTP_PG_POOL to a size runs that instead.
POOL_SIZE = int(os.environ.get("OTP_PG_POOL", "0"))
POLICY = {"naive_count": "sliding", "after_send": "sliding",
          "immediate_txn": "sliding", "cache_get_set": "fixed",
          "atomic_update": "fixed", "reserve_commit": "fixed"}
_pool = None
_event_file = None

app = FastAPI(title="OTP send service (PostgreSQL)", version="2.1.0")


def _get_pool():
    global _pool
    if _pool is None:
        _pool = ConnectionPool(DSN, min_size=1, max_size=POOL_SIZE,
                               kwargs={"autocommit": True}, open=True)
    return _pool


class _Pooled:
    """Context manager that yields a pooled connection and returns it."""

    def __enter__(self):
        self._cm = _get_pool().connection()
        return self._cm.__enter__()

    def __exit__(self, *a):
        return self._cm.__exit__(*a)


def conn():
    if POOL_SIZE > 0:
        return _Pooled()
    return psycopg.connect(DSN, autocommit=True)


def init_db():
    with conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS attempts (
                id BIGSERIAL PRIMARY KEY,
                phone TEXT NOT NULL,
                ts DOUBLE PRECISION NOT NULL)""")
        c.execute("CREATE INDEX IF NOT EXISTS ix_attempts ON attempts(phone, ts)")
        c.execute("""
            CREATE TABLE IF NOT EXISTS counters (
                phone TEXT PRIMARY KEY,
                used INTEGER NOT NULL DEFAULT 0,
                window_start DOUBLE PRECISION NOT NULL)""")
        c.execute("""
            CREATE TABLE IF NOT EXISTS provider_sends (
                id BIGSERIAL PRIMARY KEY,
                phone TEXT NOT NULL,
                message_id TEXT NOT NULL,
                ts DOUBLE PRECISION NOT NULL)""")
        c.execute("""
            CREATE TABLE IF NOT EXISTS reservations (
                id BIGSERIAL PRIMARY KEY,
                phone TEXT NOT NULL,
                state TEXT NOT NULL,
                ts DOUBLE PRECISION NOT NULL)""")
    os.makedirs(EVENT_DIR, exist_ok=True)


def record_event(ev):
    global _event_file
    if _event_file is None:
        os.makedirs(EVENT_DIR, exist_ok=True)
        _event_file = open(os.path.join(EVENT_DIR, f"events-{os.getpid()}.jsonl"), "a")
    ev["pid"] = os.getpid()
    ev["strategy"] = STRATEGY
    ev["policy"] = POLICY[STRATEGY]
    ev["limit"] = LIMIT
    ev["window_s"] = WINDOW_S
    ev["backend"] = "postgres" + ("-pooled" if POOL_SIZE > 0 else "")
    _event_file.write(json.dumps(ev) + "\n")
    _event_file.flush()


def provider_send(phone, ev):
    """Stand-in for the aggregator API call. Records one provider-call attempt."""
    ev["t_provider_start"] = time.time()
    if PROVIDER_MS > 0:
        time.sleep(PROVIDER_MS / 1000.0)
    mid = uuid.uuid4().hex
    with conn() as c:
        c.execute("INSERT INTO provider_sends(phone,message_id,ts) VALUES (%s,%s,%s)",
                  (phone, mid, time.time()))
    ev["t_provider_end"] = time.time()
    ev["message_id"] = mid
    return mid


def window_floor(now):
    return now - (now % WINDOW_S)


def new_event(phone):
    return {"rid": uuid.uuid4().hex, "phone": phone, "t_recv": time.time()}


def finish(ev, decision, note):
    ev["decision"] = decision
    ev["t_done"] = time.time()
    record_event(ev)
    return decision == "admit", note


def admitted_fixed(ev, window_start, used_after, source):
    """Record a fixed-window admission (see svc/app.py)."""
    ev["window_id"] = window_start
    ev["policy_ts"] = window_start
    ev["counter_after"] = used_after
    ev["window_source"] = source


def admitted_sliding(ev, now, used_after):
    """Record a sliding-window admission (see svc/app.py): the timestamp the
    check used and the derived count observed + 1."""
    ev["policy_ts"] = now
    ev["counter_after"] = used_after


# --------------------------------------------------------------------------
# Two-step patterns: read the state, then write it.
# --------------------------------------------------------------------------

def s_naive_count(phone):
    """Count rows, compare, then insert. No transaction around the pair."""
    ev = new_event(phone)
    now = time.time()
    with conn() as c:
        used = c.execute("SELECT COUNT(*) FROM attempts WHERE phone=%s AND ts>=%s",
                         (phone, now - WINDOW_S)).fetchone()[0]
        ev["t_read"], ev["observed"] = time.time(), used
        if used >= LIMIT:
            ev["t_decide"] = time.time()
            return finish(ev, "refuse", "over_quota")
        ev["t_decide"] = time.time()
        rid = c.execute("INSERT INTO attempts(phone,ts) VALUES (%s,%s) RETURNING id",
                        (phone, now)).fetchone()[0]
        ev["t_write"] = time.time()
        ev["record_id"] = rid
    admitted_sliding(ev, now, used + 1)
    provider_send(phone, ev)
    return finish(ev, "admit", "sent")


def s_cache_get_set(phone):
    """Read counter, add one, write it back. The cache-style pattern."""
    ev = new_event(phone)
    now = time.time()
    with conn() as c:
        row = c.execute("SELECT used, window_start FROM counters WHERE phone=%s",
                        (phone,)).fetchone()
        ev["t_read"] = time.time()
        if row is None or now - row[1] >= WINDOW_S:
            used, wstart = 0, window_floor(now)
        else:
            used, wstart = row[0], row[1]
        ev["observed"] = used
        if used >= LIMIT:
            ev["t_decide"] = time.time()
            return finish(ev, "refuse", "over_quota")
        ev["t_decide"] = time.time()
        row = c.execute("INSERT INTO counters(phone,used,window_start) VALUES (%s,%s,%s) "
                        "ON CONFLICT(phone) DO UPDATE SET used=%s, window_start=%s "
                        "RETURNING window_start, used",
                        (phone, used + 1, wstart, used + 1, wstart)).fetchone()
        ev["t_write"] = time.time()
    # application-computed window, written by this request; RETURNING echoes it
    admitted_fixed(ev, wstart, used + 1, "submitted")
    ev["window_id_returned"], ev["counter_returned"] = row[0], row[1]
    provider_send(phone, ev)
    return finish(ev, "admit", "sent")


def s_after_send(phone):
    """Check, send, then increment. Quota is consumed only on success."""
    ev = new_event(phone)
    now = time.time()
    with conn() as c:
        used = c.execute("SELECT COUNT(*) FROM attempts WHERE phone=%s AND ts>=%s",
                         (phone, now - WINDOW_S)).fetchone()[0]
    ev["t_read"], ev["observed"] = time.time(), used
    if used >= LIMIT:
        ev["t_decide"] = time.time()
        return finish(ev, "refuse", "over_quota")
    ev["t_decide"] = time.time()
    admitted_sliding(ev, now, used + 1)
    provider_send(phone, ev)
    with conn() as c:
        rec_ts = time.time()
        rid = c.execute("INSERT INTO attempts(phone,ts) VALUES (%s,%s) RETURNING id",
                        (phone, rec_ts)).fetchone()[0]
    ev["t_write"] = time.time()
    ev["record_id"] = rid
    ev["record_ts"] = rec_ts
    return finish(ev, "admit", "sent")


# --------------------------------------------------------------------------
# One-step patterns: the datastore adjudicates.
# --------------------------------------------------------------------------

def _roll_window(c, phone, now):
    c.execute("INSERT INTO counters(phone,used,window_start) VALUES (%s,0,%s) "
              "ON CONFLICT(phone) DO NOTHING", (phone, window_floor(now)))
    c.execute("UPDATE counters SET used=0, window_start=%s "
              "WHERE phone=%s AND %s-window_start>=%s",
              (window_floor(now), phone, now, WINDOW_S))


def s_atomic_update(phone):
    """Single conditional UPDATE; the database decides and reports the window."""
    ev = new_event(phone)
    now = time.time()
    with conn() as c:
        _roll_window(c, phone, now)
        ev["t_read"] = time.time()
        row = c.execute("UPDATE counters SET used=used+1 WHERE phone=%s AND used<%s "
                        "RETURNING window_start, used", (phone, LIMIT)).fetchone()
        ev["t_decide"] = ev["t_write"] = time.time()
    if row is None:
        return finish(ev, "refuse", "over_quota")
    admitted_fixed(ev, row[0], row[1], "returning")
    provider_send(phone, ev)
    return finish(ev, "admit", "sent")


def s_immediate_txn(phone):
    """Check and increment under a transaction-scoped advisory lock.

    The PostgreSQL counterpart of SQLite's BEGIN IMMEDIATE: take the write lock
    for this phone number before reading, so no other request can interleave.
    """
    ev = new_event(phone)
    now = time.time()
    c = (_get_pool().getconn() if POOL_SIZE > 0 else psycopg.connect(DSN))
    c.autocommit = False
    refused = False
    try:
        with c.transaction():
            c.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", (phone,))
            used = c.execute("SELECT COUNT(*) FROM attempts WHERE phone=%s AND ts>=%s",
                             (phone, now - WINDOW_S)).fetchone()[0]
            ev["t_read"], ev["observed"] = time.time(), used
            if used >= LIMIT:
                ev["t_decide"] = time.time()
                refused = True
            else:
                ev["t_decide"] = time.time()
                rid = c.execute("INSERT INTO attempts(phone,ts) VALUES (%s,%s) RETURNING id",
                                (phone, now)).fetchone()[0]
                ev["record_id"] = rid
        ev["t_write"] = time.time()          # commit completed
    except Exception as e:
        ev["error"] = type(e).__name__
        return finish(ev, "error", "error")
    finally:
        if POOL_SIZE > 0:
            c.autocommit = True
            _get_pool().putconn(c)
        else:
            c.close()
    if refused:
        return finish(ev, "refuse", "over_quota")
    admitted_sliding(ev, now, used + 1)
    provider_send(phone, ev)
    return finish(ev, "admit", "sent")


def s_reserve_commit(phone):
    """Reserve atomically before the send; release the claim if the send fails."""
    ev = new_event(phone)
    now = time.time()
    with conn() as c:
        _roll_window(c, phone, now)
        ev["t_read"] = time.time()
        row = c.execute("UPDATE counters SET used=used+1 WHERE phone=%s AND used<%s "
                        "RETURNING window_start, used", (phone, LIMIT)).fetchone()
        ev["t_decide"] = ev["t_write"] = time.time()
        if row is None:
            return finish(ev, "refuse", "over_quota")
        c.execute("INSERT INTO reservations(phone,state,ts) VALUES (%s,'held',%s)",
                  (phone, now))
    admitted_fixed(ev, row[0], row[1], "returning")
    try:
        provider_send(phone, ev)
    except Exception as e:
        with conn() as c:
            c.execute("UPDATE counters SET used=used-1 WHERE phone=%s", (phone,))
        ev["error"] = type(e).__name__
        return finish(ev, "released", "provider_error")
    return finish(ev, "admit", "sent")


STRATEGIES = {
    "naive_count": s_naive_count,
    "cache_get_set": s_cache_get_set,
    "after_send": s_after_send,
    "atomic_update": s_atomic_update,
    "immediate_txn": s_immediate_txn,
    "reserve_commit": s_reserve_commit,
}


class OTPRequest(BaseModel):
    phone: str


@app.on_event("startup")
def _startup():
    init_db()


@app.post("/otp/request")
def otp_request(req: OTPRequest):
    allowed, note = STRATEGIES[STRATEGY](req.phone)
    return {"status": "sent" if allowed else "rejected", "note": note}


@app.get("/otp/stats")
def stats(phone: str):
    with conn() as c:
        n = c.execute("SELECT COUNT(*) FROM provider_sends WHERE phone=%s",
                      (phone,)).fetchone()[0]
    return {"phone": phone, "provider_sends": n, "limit": LIMIT,
            "strategy": STRATEGY, "provider_ms": PROVIDER_MS, "backend": "postgres",
            "policy": POLICY[STRATEGY], "window_s": WINDOW_S}


@app.get("/otp/sends")
def sends(phone: str):
    """Every provider call recorded for this number, with its instant.
    Not the policy event; used only to cross-check admissions."""
    with conn() as c:
        rows = c.execute("SELECT ts, message_id FROM provider_sends WHERE phone=%s ORDER BY ts",
                         (phone,)).fetchall()
    return {"phone": phone, "limit": LIMIT, "window_s": WINDOW_S,
            "ts": [r[0] for r in rows], "message_ids": [r[1] for r in rows]}


@app.get("/otp/events")
def events(phone: str):
    """Every request event recorded for this number, from all worker logs."""
    out = []
    for fn in glob.glob(os.path.join(EVENT_DIR, "events-*.jsonl")):
        with open(fn) as f:
            for line in f:
                if not line.strip():
                    continue
                ev = json.loads(line)
                if ev.get("phone") == phone:
                    out.append(ev)
    out.sort(key=lambda e: e["t_recv"])
    return {"phone": phone, "limit": LIMIT, "window_s": WINDOW_S,
            "policy": POLICY[STRATEGY], "events": out}


@app.post("/admin/reset")
def reset():
    with conn() as c:
        for tbl in ("attempts", "counters", "provider_sends", "reservations"):
            c.execute(f"DELETE FROM {tbl}")
    return {"status": "reset"}
