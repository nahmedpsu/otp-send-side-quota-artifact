"""
Download every candidate package and record what came back.

We prefer a source distribution because wheels sometimes omit the code we want
to read. Failures are recorded rather than silently dropped, so the census
denominator stays honest.
"""
import os as _os
_ROOT = _os.environ.get("OTP_ROOT",
    _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import json
import os
import subprocess
import sys
import tarfile
import zipfile

OUT = _ROOT + "/pkgs"
DL = os.path.join(OUT, "dl")
EX = os.path.join(OUT, "src")


def fetch(name):
    os.makedirs(DL, exist_ok=True)
    for extra in (["--no-binary", ":all:"], []):
        r = subprocess.run(
            [sys.executable, "-m", "pip", "download", "--no-deps", "--dest", DL,
             *extra, name],
            capture_output=True, text=True, timeout=180)
        if r.returncode == 0:
            return True, "sdist" if extra else "wheel"
    return False, (r.stderr or "").strip().splitlines()[-1][:180] if r.stderr else "failed"


def extract(name):
    os.makedirs(EX, exist_ok=True)
    key = name.lower().replace("-", "_")
    for fn in os.listdir(DL):
        base = fn.lower().replace("-", "_")
        if not base.startswith(key):
            continue
        dest = os.path.join(EX, name)
        try:
            if fn.endswith((".tar.gz", ".tgz")):
                with tarfile.open(os.path.join(DL, fn)) as t:
                    t.extractall(dest, filter="data")
                return dest
            if fn.endswith((".whl", ".zip")):
                with zipfile.ZipFile(os.path.join(DL, fn)) as z:
                    z.extractall(dest)
                return dest
        except Exception:
            return None
    return None


def main():
    cands = json.load(open("results/survey_candidates.json"))["kept"]
    log = []
    for i, rec in enumerate(cands, 1):
        name = rec["name"]
        if os.path.isdir(os.path.join(EX, name)):
            log.append(dict(name=name, ok=True, kind="cached"))
            continue
        ok, kind = fetch(name)
        path = extract(name) if ok else None
        log.append(dict(name=name, ok=bool(path), kind=kind,
                        path=path, version=rec.get("version")))
        if i % 25 == 0:
            good = sum(1 for x in log if x["ok"])
            print(f"  {i}/{len(cands)}  downloaded={good}", flush=True)
    with open("results/survey_fetch_log.json", "w") as f:
        json.dump(log, f, indent=2)
    good = sum(1 for x in log if x["ok"])
    print(f"downloaded and extracted {good}/{len(cands)}")


if __name__ == "__main__":
    main()
