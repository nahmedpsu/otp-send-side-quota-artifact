#!/usr/bin/env bash
# Follow-up arms: the window-boundary hypothesis, the completed instrumented
# run, and execution of a surveyed package.
set -u
cd "$(dirname "$0")/.."
R=results/r2
export EXP_PORT=8212

echo "=== A: does a window boundary crossing explain the atomic-update overrun? ==="
# A one-second window is crossed constantly, so if the window roll is the racy
# step this will show it; if the increment alone were the problem, the window
# length would not matter.
OTP_WINDOW_S=1 EXP_DB=/tmp/otp_win.db python3 study/run_experiments.py --backend sqlite \
  --strategies atomic_update immediate_txn reserve_commit --concurrency 16 --trials 60 \
  --provider-ms 50 --limit 5 --workers 4 --out "$R/window_boundary.csv" \
  > "$R/window_boundary.log" 2>&1
echo "exit=$?"

echo "=== B: instrumented SQLite run, all three instrumented patterns ==="
EXP_DB=/tmp/otp_tim2.db python3 study/run_experiments.py --backend sqlite \
  --strategies naive_count cache_get_set atomic_update --concurrency 8 --trials 30 \
  --provider-ms 50 --limit 3 --workers 4 --timing \
  --out "$R/timing_sqlite.csv" --timing-out "$R/timing_sqlite.json" \
  > "$R/timing_sqlite.log" 2>&1
echo "exit=$?"

echo "=== C: executing django-otp 1.7.3 under the harness ==="
python3 study/run_package_exec.py --k 1 2 4 8 16 32 --trials 30 \
  --out "$R/pkg_exec.csv" > "$R/pkg_exec.log" 2>&1
echo "exit=$?"
echo "ROUND2B_DONE"
