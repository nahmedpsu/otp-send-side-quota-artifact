"""
Compare a fresh run in results/repro/r4/ with the shipped run in results/r4/.

For every arm present in both, print the per-cell median, maximum, trials
over the limit in total and policy violations, side by side. Both runs are
summarised by the same code from their event logs (study/events.py).

    python3 study/compare_repro.py
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from study import events as E  # noqa: E402

ORDER = ["naive_count", "cache_get_set", "after_send",
         "atomic_update", "immediate_txn", "reserve_commit"]
GROUP = {"latency": ("strategy", "provider_ms"), "workers": ("strategy", "workers", "concurrency"),
         "limits": ("strategy", "limit")}


def cells(path, gb):
    out = {}
    for key, evs in E.trials(path).items():
        meta = dict(zip(E.TRIAL_KEYS, key))
        s = E.summarise(evs)
        out.setdefault(tuple(meta[g] for g in gb), []).append(s)
    return out


def fmt(ss):
    if not ss:
        return "        -        "
    v = sorted(s["admits"] for s in ss)
    lim = ss[0]["limit"]
    med = v[len(v) // 2] if len(v) % 2 else (v[len(v) // 2 - 1] + v[len(v) // 2]) / 2
    return (f"{med:g}/{max(v)} (over {sum(x > lim for x in v)}, "
            f"pv {sum(s['policy_overrun'] > 0 for s in ss)}, n {len(v)})")


def main():
    for arm in ("main_sqlite", "main_postgres", "sequential", "latency", "workers", "limits",
                "postgres_pooled"):
        a, b = f"{ROOT}/results/repro/r4/{arm}.events.jsonl", f"{ROOT}/results/r4/{arm}.events.jsonl"
        try:
            E.resolve(a); E.resolve(b)
        except FileNotFoundError:
            continue
        gb = GROUP.get(arm, ("strategy", "concurrency"))
        ca, cb = cells(a, gb), cells(b, gb)
        print(f"\n== {arm}   (your run | shipped)   median/max (trials over limit, policy violations, n)")
        for key in sorted(set(ca) | set(cb), key=lambda k: (ORDER.index(k[0]), k[1:])):
            print(f"  {key[0]:14s} {' '.join(str(x) for x in key[1:]):10s} "
                  f"{fmt(ca.get(key)):>34s} | {fmt(cb.get(key)):>34s}")
    for arm in ("boundary_sqlite", "boundary_postgres"):
        a, b = f"{ROOT}/results/repro/r4/{arm}.events.jsonl", f"{ROOT}/results/r4/{arm}.events.jsonl"
        try:
            E.resolve(a); E.resolve(b)
        except FileNotFoundError:
            continue
        keys = ("arm", "backend", "strategy", "policy", "trial", "k", "limit", "window_s", "boundary")
        print(f"\n== {arm}   trials / straddled / total>limit / policy violated   (your run | shipped)")
        for s in ORDER:
            line = []
            for path in (a, b):
                tr = [E.summarise(evs) for key, evs in E.trials(path, keys).items()
                      if dict(zip(keys, key))["strategy"] == s]
                if tr:
                    line.append(f"{len(tr)} / {sum(t['windows_touched'] > 1 for t in tr)} / "
                                f"{sum(t['admits'] > t['limit'] for t in tr)} / "
                                f"{sum(t['policy_overrun'] > 0 for t in tr)}")
                else:
                    line.append("-")
            print(f"  {s:14s} {line[0]:>22s} | {line[1]:>22s}")


if __name__ == "__main__":
    main()
