"""
Static pass over the downloaded packages.

Two questions per package:
  1. Does it contain an outbound send path (something that costs money)?
  2. If so, does anything in the package limit how often that path can run?

The pass is deliberately generous about what counts as a limit: any cooldown,
interval, throttle, quota or resend guard anywhere in the package counts as a
hit, so the "no limit" class is conservative. Every hit is recorded with the
file and line so it can be read by hand afterwards.
"""
import os as _os
_ROOT = _os.environ.get("OTP_ROOT",
    _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import json
import os
import re
from collections import defaultdict

SRC = _ROOT + "/pkgs/src"

PROVIDERS = re.compile(
    r"\b(twilio|messagebird|vonage|nexmo|plivo|kavenegar|ghasedak|smsir|sms_ir|"
    r"africastalking|infobip|sinch|telesign|clicksend|textlocal|termii|"
    r"aws_sns|boto3|sns_client|msg91|bulksms|smsc|gatewayapi|onesignal|"
    r"bale|engagelab|smtplib|send_mail|EmailMessage)\b", re.I)

SEND_DEF = re.compile(
    r"def\s+(send|deliver|dispatch|push|_?send_\w*|\w*_send|send_\w*)\s*\(", re.I)

SEND_CTX = re.compile(r"sms|otp|token|code|verif|message|challenge", re.I)

HTTP_SEND = re.compile(
    r"(requests|httpx|urllib|aiohttp)\s*\.\s*(post|get|request)", re.I)

# Anything that could bound how often a send happens.
SEND_LIMIT = re.compile(
    r"\b(cooldown|cool_down|throttl\w*|rate[_ ]?limit\w*|ratelimit\w*|"
    r"resend[_ ]?(interval|delay|timeout|after|cooldown|limit)|"
    r"send[_ ]?(interval|cooldown|limit|quota|throttle)|"
    r"min[_ ]?interval|max[_ ]?send\w*|quota|"
    r"last[_ ]?(sent|send|request)[_ ]?(at|time)?|"
    r"seconds[_ ]?between|time[_ ]?between|retry[_ ]?after)\b", re.I)

# Limits that apply to checking a code, not to sending one.
VERIFY_LIMIT = re.compile(
    r"\b(max[_ ]?(attempts?|tries|failures?)|attempt[_ ]?limit|"
    r"failure[_ ]?count|lock(ed)?[_ ]?out|lockout|wrong[_ ]?attempts?|"
    r"verification[_ ]?attempts?|throttling_failure|failure_count)\b", re.I)

ATOMIC = re.compile(
    r"select_for_update|transaction\.atomic|F\(|\bF\s*\(|"
    r"\bincr\b|INCRBY|atomic|with_for_update|SELECT .* FOR UPDATE|"
    r"get_or_create\(|update\(.*F\(", re.I)


def py_files(root):
    out = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames
                       if d not in {".git", "__pycache__", "node_modules", ".tox"}]
        for fn in filenames:
            if fn.endswith(".py"):
                out.append(os.path.join(dirpath, fn))
    return out


def scan(path):
    res = dict(send_provider=[], send_def=[], http_send=[],
               send_limit=[], verify_limit=[], atomic=[], loc=0, files=0)
    for f in py_files(path):
        try:
            text = open(f, encoding="utf-8", errors="replace").read()
        except Exception:
            continue
        res["files"] += 1
        lines = text.splitlines()
        res["loc"] += len(lines)
        rel = os.path.relpath(f, path)
        is_test = bool(re.search(r"(^|/)(tests?|testing)(/|_|\.)", rel, re.I))
        for i, line in enumerate(lines, 1):
            if PROVIDERS.search(line):
                res["send_provider"].append((rel, i, line.strip()[:160], is_test))
            if SEND_DEF.search(line) and SEND_CTX.search(line):
                res["send_def"].append((rel, i, line.strip()[:160], is_test))
            if HTTP_SEND.search(line) and SEND_CTX.search(line):
                res["http_send"].append((rel, i, line.strip()[:160], is_test))
            if SEND_LIMIT.search(line) and not VERIFY_LIMIT.search(line):
                res["send_limit"].append((rel, i, line.strip()[:160], is_test))
            if VERIFY_LIMIT.search(line):
                res["verify_limit"].append((rel, i, line.strip()[:160], is_test))
            if ATOMIC.search(line):
                res["atomic"].append((rel, i, line.strip()[:160], is_test))
    return res


def main():
    names = sorted(os.listdir(SRC)) if os.path.isdir(SRC) else []
    out = {}
    for i, name in enumerate(names, 1):
        p = os.path.join(SRC, name)
        if not os.path.isdir(p):
            continue
        r = scan(p)
        nontest = lambda key: [x for x in r[key] if not x[3]]
        r["in_scope"] = bool(nontest("send_provider") or nontest("send_def")
                             or nontest("http_send"))
        r["has_send_limit"] = bool(nontest("send_limit"))
        r["has_verify_limit"] = bool(nontest("verify_limit"))
        r["has_atomic"] = bool(nontest("atomic"))
        out[name] = r
        if i % 100 == 0:
            print(f"  scanned {i}/{len(names)}", flush=True)
    with open("results/survey_static.json", "w") as f:
        json.dump(out, f, indent=2)

    scope = [n for n, r in out.items() if r["in_scope"]]
    lim = [n for n in scope if out[n]["has_send_limit"]]
    ver = [n for n in scope if out[n]["has_verify_limit"]]
    print(f"packages scanned      : {len(out)}")
    print(f"with an outbound send : {len(scope)}")
    print(f"  any send-side limit : {len(lim)}")
    print(f"  verify-side limit   : {len(ver)}")
    print(f"  neither             : {len([n for n in scope if not out[n]['has_send_limit'] and not out[n]['has_verify_limit']])}")


if __name__ == "__main__":
    main()
