"""Turn the raw run files into the tables and plot data used in the paper."""
import csv
import json
import os
import statistics as st
from collections import defaultdict

R = os.environ.get(
    "OTP_RESULTS",
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results"),
)
LABEL = {
    "naive_count": "Count-then-insert",
    "cache_get_set": "Read-modify-write counter",
    "after_send": "Increment after send",
    "atomic_update": "Conditional atomic update",
    "immediate_txn": "Guarded write transaction",
    "reserve_commit": "Reserve before send",
}
ORDER = ["naive_count", "cache_get_set", "after_send",
         "atomic_update", "immediate_txn", "reserve_commit"]


def load(fn):
    try:
        return list(csv.DictReader(open(f"{R}/{fn}")))
    except FileNotFoundError:
        return []


def main():
    out = {}
    main_rows = load("main_sweep.csv")
    seq_rows = load("sequential.csv")
    lat_rows = load("latency.csv")

    # ---- concurrent sweep -------------------------------------------------
    cells = defaultdict(list)
    for r in main_rows:
        cells[(r["strategy"], int(r["concurrency"]))].append(int(r["provider_sends"]))
    limit = int(main_rows[0]["limit"])
    conc = sorted({int(r["concurrency"]) for r in main_rows})

    table = []
    for s in ORDER:
        row = {"strategy": s, "label": LABEL[s]}
        for k in conc:
            v = cells[(s, k)]
            row[f"k{k}_median"] = st.median(v)
            row[f"k{k}_max"] = max(v)
            row[f"k{k}_exceed"] = sum(1 for x in v if x > limit)
            row[f"k{k}_n"] = len(v)
        worst = max(max(cells[(s, k)]) for k in conc)
        row["worst_sends"] = worst
        row["worst_amp"] = round(worst / limit, 1)
        row["any_exceed"] = any(cells[(s, k)] and max(cells[(s, k)]) > limit for k in conc)
        table.append(row)
    out["limit"] = limit
    out["concurrency_levels"] = conc
    out["trials_per_cell"] = len(cells[(ORDER[0], conc[0])])
    out["main_table"] = table

    # ---- sequential control ----------------------------------------------
    seq = defaultdict(list)
    for r in seq_rows:
        seq[r["strategy"]].append(int(r["provider_sends"]))
    out["sequential"] = {s: {"n": len(v), "min": min(v), "max": max(v),
                             "median": st.median(v)} for s, v in seq.items()}

    # ---- provider-latency sensitivity ------------------------------------
    lat = defaultdict(list)
    for r in lat_rows:
        lat[(r["strategy"], float(r["provider_ms"]))].append(int(r["provider_sends"]))
    out["latency"] = {f"{s}|{p}": {"median": st.median(v), "max": max(v),
                                   "exceed": sum(1 for x in v if x > limit),
                                   "n": len(v)}
                      for (s, p), v in sorted(lat.items())}

    # ---- package survey ---------------------------------------------------
    rows = list(csv.DictReader(open(f"{R}/survey_final.csv")))
    pop = [r for r in rows if r["in_population"] == "True"]
    gated = [r for r in pop if r["send_path_gated"] == "yes"]
    vonly = [r for r in pop if r["verify_side_only"]]
    cand = json.load(open(f"{R}/survey_candidates.json"))
    out["survey"] = dict(
        index_projects=cand["index_size"],
        name_matches=cand["name_matches"],
        summary_kept=len(cand["kept"]),
        downloaded=sum(1 for x in json.load(open(f"{R}/survey_fetch_log.json"))
                       if x.get("ok")),
        delivery_sites=len(rows),
        excluded=len(rows) - len(pop),
        population=len(pop),
        gated=len(gated),
        ungated=len(pop) - len(gated),
        verify_only=len(vonly),
        gated_pct=round(100 * len(gated) / len(pop), 1),
        ungated_pct=round(100 * (len(pop) - len(gated)) / len(pop), 1),
    )

    json.dump(out, open(f"{R}/analysis.json", "w"), indent=2)

    # ---- console summary --------------------------------------------------
    print(f"declared limit = {limit}, trials per cell = {out['trials_per_cell']}\n")
    hdr = "pattern".ljust(28) + "".join(f"k={k:<7}" for k in conc) + "worst"
    print(hdr)
    for row in table:
        line = row["label"].ljust(28)
        for k in conc:
            line += f"{row[f'k{k}_median']:.0f}/{row[f'k{k}_max']}".ljust(9)
        line += f"  {row['worst_amp']}x"
        print(line)
    print("\nsequential control (10 trials per cell, k up to 32):")
    for s in ORDER:
        if s in out["sequential"]:
            v = out["sequential"][s]
            print(f"  {LABEL[s]:<28} min={v['min']} max={v['max']}")
    print("\nprovider latency at k=8:")
    for key, v in out["latency"].items():
        print(f"  {key:<28} median={v['median']:.0f} max={v['max']} "
              f"exceeded={v['exceed']}/{v['n']}")
    s = out["survey"]
    print(f"\nsurvey: {s['index_projects']} projects -> {s['name_matches']} name matches "
          f"-> {s['summary_kept']} candidates -> {s['delivery_sites']} with a delivery site "
          f"-> {s['population']} in population")
    print(f"  send path gated: {s['gated']} ({s['gated_pct']}%)   "
          f"no send-side limit: {s['ungated']} ({s['ungated_pct']}%)")


if __name__ == "__main__":
    main()
