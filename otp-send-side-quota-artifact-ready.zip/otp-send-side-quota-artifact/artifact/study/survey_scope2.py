"""
Population definition, third pass.

A package is in the population only if its own code contains a *delivery site*:
a function whose body both (a) calls out to a messaging provider, an email
sender, or an HTTP endpoint, and (b) references the one-time code value being
delivered. That distinguishes packages that send a code to a user from
packages that merely consume a code the user already holds -- which is what the
AWS credential helpers do.

For each delivery site we then look, within the enclosing module, for any guard
that could bound how often the site runs, and record whether that guard is
applied to sending or only to verification.
"""
import os as _os
_ROOT = _os.environ.get("OTP_ROOT",
    _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import ast
import json
import os
import re

SRC = _ROOT + "/pkgs/src"
VENDORED = re.compile(
    r"(^|/)(site-packages|venv|\.venv|vendor|vendored|third_party|node_modules|"
    r"\.eggs|dist-packages)(/|$)", re.I)
TESTPATH = re.compile(r"(^|/)(tests?|testing)(/|$)|(^|/)test_[^/]*\.py$|_test\.py$", re.I)

PROVIDER = re.compile(
    r"\b(twilio|messagebird|vonage|nexmo|plivo|kavenegar|ghasedak|sms_ir|smsir|"
    r"africastalking|infobip|sinch|telesign|clicksend|textlocal|termii|msg91|"
    r"bulksms|gatewayapi|smsapi|melipayamak|signalwire|bandwidth|sns_client|"
    r"send_sms|sendsms|send_message|send_text|publish)\b", re.I)
EMAIL = re.compile(r"\b(send_mail|EmailMessage|EmailMultiAlternatives|smtplib|"
                   r"sendmail|send_email)\b")
HTTP = re.compile(r"\b(requests|httpx|aiohttp|urlopen|urllib)\b", re.I)
CODEVAL = re.compile(r"\b(otp|token|code|secret|pin|challenge|password)\b", re.I)

GUARD_SEND = re.compile(
    r"\b(cooldown|cool_down|throttl|rate.?limit|ratelimit|resend|"
    r"min.?interval|interval|seconds_between|time_between|"
    r"max.?send|send.?limit|send.?quota|"
    r"last.?sent|last.?send|next.?allowed|wait|retry.?after|"
    r"ThrottlingMixin|SimpleRateThrottle|ScopedRateThrottle|UserRateThrottle)\b",
    re.I)
GUARD_VERIFY_ONLY = re.compile(
    r"\b(max.?attempts?|attempt.?limit|failure.?count|lock.?out|lockout|"
    r"wrong.?attempts?|verification.?attempts?|throttling_failure)\b", re.I)
ATOMIC = re.compile(
    r"select_for_update|transaction\.atomic|\bF\(|\.incr\(|INCRBY|"
    r"with_for_update|FOR UPDATE|update_or_create\(", re.I)


def own_py(root):
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in {".git", "__pycache__"}]
        for f in fn:
            if not f.endswith(".py"):
                continue
            rel = os.path.relpath(os.path.join(dp, f), root).replace(os.sep, "/")
            if VENDORED.search(rel) or rel.endswith("setup.py"):
                continue
            yield rel, os.path.join(dp, f)


def delivery_sites(text):
    """Functions whose body both calls out and mentions the code value."""
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    lines = text.splitlines()
    sites = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        lo = node.lineno - 1
        hi = getattr(node, "end_lineno", node.lineno) or node.lineno
        body = "\n".join(lines[lo:hi])
        calls_out = bool(PROVIDER.search(body) or EMAIL.search(body) or
                         (HTTP.search(body) and re.search(r"\.(post|request)\(", body)))
        has_code = bool(CODEVAL.search(body))
        looks_send = bool(re.search(r"\b(send|deliver|dispatch|notify|transmit|"
                                    r"challenge|generate_challenge)\w*\b",
                                    node.name, re.I))
        if calls_out and has_code and (looks_send or PROVIDER.search(body) or EMAIL.search(body)):
            sites.append((node.name, node.lineno, hi))
    return sites


def main():
    cands = {c["name"]: c for c in
             json.load(open("results/survey_candidates.json"))["kept"]}
    out = {}
    names = sorted(n for n in os.listdir(SRC) if os.path.isdir(os.path.join(SRC, n)))
    for idx, name in enumerate(names, 1):
        root = os.path.join(SRC, name)
        rec = dict(sites=[], guards=[], verify_guards=[], atomic=[], loc=0,
                   summary=cands.get(name, {}).get("summary", ""),
                   version=cands.get(name, {}).get("version", ""))
        for rel, full in own_py(root):
            try:
                text = open(full, encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            rec["loc"] += text.count("\n")
            if TESTPATH.search(rel):
                continue
            sites = delivery_sites(text)
            if sites:
                lines = text.splitlines()
                for fn_name, lo, hi in sites:
                    rec["sites"].append([rel, lo, fn_name,
                                         "\n".join(lines[lo - 1:min(hi, lo + 24)])[:700]])
                for i, line in enumerate(text.splitlines(), 1):
                    if GUARD_SEND.search(line) and not GUARD_VERIFY_ONLY.search(line):
                        rec["guards"].append([rel, i, line.strip()[:140]])
                    if GUARD_VERIFY_ONLY.search(line):
                        rec["verify_guards"].append([rel, i, line.strip()[:140]])
                    if ATOMIC.search(line):
                        rec["atomic"].append([rel, i, line.strip()[:140]])
        rec["in_pop"] = bool(rec["sites"])
        out[name] = rec
        if idx % 200 == 0:
            print(f"  {idx}/{len(names)}", flush=True)
    json.dump(out, open("results/survey_pop.json", "w"), indent=2)
    pop = [n for n, r in out.items() if r["in_pop"]]
    print(f"scanned {len(out)}; population {len(pop)}")
    g = [n for n in pop if out[n]["guards"]]
    print(f"  with a send-side guard signal: {len(g)}")


if __name__ == "__main__":
    main()
