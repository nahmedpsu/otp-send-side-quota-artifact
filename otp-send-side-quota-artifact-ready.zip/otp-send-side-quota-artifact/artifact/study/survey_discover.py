"""
Discovery step for the package survey.

We take the full PyPI project index, keep names that look like OTP / two-factor
/ phone-verification packages, then pull each candidate's metadata and keep the
ones whose summary indicates they actually send or manage one-time codes.
Everything here is reproducible from the recorded index snapshot.
"""
import json
import re
import sys
import time

import requests

INDEX = "https://pypi.org/simple/"
NAME_PATTERNS = [
    r"otp", r"2fa", r"two[-_]?factor", r"mfa",
    r"phone[-_]?verif", r"sms[-_]?verif", r"verif.*code", r"code.*verif",
    r"sms[-_]?auth", r"phone[-_]?auth", r"one[-_]?time[-_]?pass",
]
SUMMARY_KEEP = re.compile(
    r"otp|one[- ]time|two[- ]factor|2fa|mfa|verification code|sms|phone number "
    r"verif|authenticator", re.I)
SUMMARY_DROP = re.compile(
    r"\btotp only\b|hardware token|yubikey|bitcoin|blockchain", re.I)


def fetch_index():
    r = requests.get(INDEX, timeout=120, headers={"Accept": "text/html"})
    r.raise_for_status()
    names = re.findall(r">([^<]+)</a>", r.text)
    return names


def main():
    print("fetching PyPI project index ...", flush=True)
    names = fetch_index()
    print(f"index contains {len(names)} projects", flush=True)
    pat = re.compile("|".join(NAME_PATTERNS), re.I)
    cands = sorted({n for n in names if pat.search(n)})
    print(f"{len(cands)} names match the OTP/2FA/verification name patterns",
          flush=True)

    kept, skipped = [], []
    for i, name in enumerate(cands, 1):
        if i % 25 == 0:
            print(f"  metadata {i}/{len(cands)}", flush=True)
        try:
            r = requests.get(f"https://pypi.org/pypi/{name}/json", timeout=30)
            if r.status_code != 200:
                skipped.append((name, f"http{r.status_code}"))
                continue
            info = r.json()["info"]
        except Exception as e:
            skipped.append((name, type(e).__name__))
            continue
        summary = (info.get("summary") or "") + " " + (info.get("description") or "")[:800]
        rec = dict(
            name=name,
            version=info.get("version"),
            summary=(info.get("summary") or "").strip()[:300],
            home=info.get("home_page") or info.get("project_url") or "",
            requires_dist=info.get("requires_dist") or [],
        )
        if SUMMARY_KEEP.search(summary) and not SUMMARY_DROP.search(summary):
            kept.append(rec)
        else:
            skipped.append((name, "summary_filter"))
        time.sleep(0.05)

    with open("results/survey_candidates.json", "w") as f:
        json.dump({"kept": kept, "skipped": skipped,
                   "index_size": len(names),
                   "name_matches": len(cands)}, f, indent=2)
    print(f"kept {len(kept)} candidates; wrote results/survey_candidates.json")


if __name__ == "__main__":
    sys.exit(main())
