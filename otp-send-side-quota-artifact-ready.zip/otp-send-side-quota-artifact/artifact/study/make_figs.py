"""Generate the distribution figures and the pgfplots coordinates of the
line and bar figures from the round-4 trial files (admissions per trial)."""
import csv, os, random
from collections import defaultdict
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LAB = {"naive_count": "Count-then-\ninsert", "cache_get_set": "Read-modify-\nwrite",
       "after_send": "Increment\nafter send", "atomic_update": "Conditional\natomic update",
       "immediate_txn": "Guarded write\ntransaction", "reserve_commit": "Reserve\nbefore send"}
ORDER = list(LAB)


def load(fn, k="concurrency", v="admits"):
    d = defaultdict(list)
    for r in csv.DictReader(open(fn)):
        d[(r["strategy"], int(r[k]))].append(int(r[v]))
    return d


def strip(ax, data, ks, limit, title):
    """One marker per distinct (cell, value); marker area and a printed count
    show how many of the 30 trials share that value, so coincident
    observations are not hidden behind one dot."""
    from collections import Counter
    for i, s in enumerate(ORDER):
        for j, kk in enumerate(ks):
            cnt = Counter(data[(s, kk)])
            x = i + (j - (len(ks) - 1) / 2) * 0.14
            for v, c in cnt.items():
                ax.scatter([x], [v], s=6 + 2.2 * c, alpha=0.75, linewidths=0.3,
                           edgecolors="black",
                           color=plt.cm.Greys(0.35 + 0.55 * j / max(1, len(ks) - 1)))
                if c >= 10:
                    ax.annotate(str(c), (x, v), xytext=(0, 3),
                                textcoords="offset points", ha="center",
                                fontsize=4.6, color="black")
    ax.axhline(limit, color="black", ls="--", lw=1)
    ax.set_xticks(range(len(ORDER)))
    ax.set_xticklabels([LAB[s] for s in ORDER], fontsize=6.5)
    ax.set_ylabel("Admissions (= provider calls)", fontsize=8)
    ax.set_title(title, fontsize=8.5)
    ax.tick_params(labelsize=7)
    ax.set_ylim(0, 35)


def main():
    sq = load(f"{ROOT}/results/r4/main_sqlite.csv")
    pg = load(f"{ROOT}/results/r4/main_postgres.csv")
    ks = [1, 2, 4, 8, 16, 32]
    fig, axes = plt.subplots(2, 1, figsize=(7.0, 5.4), sharex=True)
    strip(axes[0], sq, ks, 3, "SQLite (WAL), four workers: every trial, all six levels of $k$")
    strip(axes[1], pg, ks, 3, "PostgreSQL 16, four workers: every trial, all six levels of $k$")
    axes[0].annotate("declared limit", xy=(5.2, 3), xytext=(5.05, 5.2), fontsize=7)
    fig.tight_layout()
    out = f"{ROOT}/paper/fig_distributions.pdf"
    fig.savefig(out, bbox_inches="tight")
    print("wrote", out)

    # package execution distribution: two panels, one per release mode.
    # Each panel is a count matrix (k on the x axis, tokens delivered on the
    # y axis); every non-empty cell prints the number of the 30 trials that
    # produced that count, so nothing overlaps and nothing is hidden.
    d = defaultdict(list)
    for r in csv.DictReader(open(f"{ROOT}/results/r4/pkg_exec.csv")):
        d[(r["mode"], int(r["concurrency"]))].append(int(r["deliveries"]))
    from collections import Counter
    vmax = max(v for vs in d.values() for v in vs)
    fig, axes = plt.subplots(1, 2, figsize=(3.5, 2.9), sharey=True,
                             gridspec_kw={"width_ratios": [1, 1]})
    for ax, mode in zip(axes, ("sequential", "concurrent")):
        for i, kk in enumerate(ks):
            cnt = Counter(d[(mode, kk)])
            for v, c in cnt.items():
                shade = 0.92 - 0.72 * (c / 30.0)          # darker = more trials
                ax.add_patch(plt.Rectangle((i - 0.45, v - 0.45), 0.9, 0.9,
                                           facecolor=str(shade), edgecolor="0.35",
                                           linewidth=0.4))
                ax.text(i, v, str(c), ha="center", va="center", fontsize=5.5,
                        color="white" if shade < 0.5 else "black")
        ax.axhline(1.5, color="black", ls="--", lw=0.8)
        ax.set_xlim(-0.6, len(ks) - 0.4)
        ax.set_ylim(0.4, vmax + 0.6)
        ax.set_xticks(range(len(ks)))
        ax.set_xticklabels(ks, fontsize=7)
        ax.set_yticks([1] + list(range(2, vmax + 1, 2)))
        ax.tick_params(labelsize=7, length=2)
        ax.set_title(mode, fontsize=8)
        ax.set_xlabel("Calls released", fontsize=8)
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
    axes[0].set_ylabel("Tokens delivered per trial", fontsize=8)
    axes[0].text(-0.3, 3.0, "dashed line:\ndeclared limit\nof one token", fontsize=6,
                 va="bottom", ha="left", color="0.25")
    axes[0].text(-0.3, 7.0, "cell value:\ntrials of 30\nwith that count", fontsize=6,
                 va="bottom", ha="left", color="0.25")
    fig.tight_layout(w_pad=0.6)
    out = f"{ROOT}/paper/fig_pkgexec.pdf"
    fig.savefig(out, bbox_inches="tight")
    print("wrote", out)


def pgf_coords():
    """Write the coordinates of Fig. 5 (medians against k) and Fig. 6 (k=32,
    simultaneous against sequential) for pgfplots, from the round-4 files."""
    import statistics as st
    G = f"{ROOT}/paper/gen"
    os.makedirs(G, exist_ok=True)
    sq = load(f"{ROOT}/results/r4/main_sqlite.csv")
    seq = load(f"{ROOT}/results/r4/sequential.csv")
    ks = [1, 2, 4, 8, 16, 32]
    med = {s: [st.median(sq[(s, k)]) for k in ks] for s in ORDER}
    styles = {
        "after_send": ("blue!65!black, thick, mark=*, mark size=1.7pt", "Increment after send"),
        "cache_get_set": ("orange!80!black, thick, dashdotted, mark=square*, mark size=1.7pt", "Read-modify-write"),
        "naive_count": ("teal!70!black, thick, densely dotted, mark=triangle*, mark size=2.2pt", "Count-then-insert"),
        "immediate_txn": ("black!60, thick, mark=o, mark size=3.6pt, mark options={line width=0.9pt}", "Guarded write transaction"),
        "atomic_update": ("black!72, thick, mark=diamond*, mark size=2.2pt", "Conditional atomic update"),
        "reserve_commit": ("red!60!black, thick, densely dashdotted, mark=x, mark size=2.4pt, mark options={line width=0.9pt}", "Reserve before send"),
    }
    with open(f"{G}/fig_concurrency.tex", "w") as f:
        f.write("% generated by study/make_figs.py from results/r4/main_sqlite.csv; do not edit\n")
        for s in ("after_send", "cache_get_set", "naive_count", "immediate_txn", "atomic_update", "reserve_commit"):
            pts = "".join(f"({k},{m:g})" for k, m in zip(ks, med[s]))
            f.write(f"\\addplot[{styles[s][0]}]\n  coordinates {{{pts}}};\n\\addlegendentry{{{styles[s][1]}}}\n")
    short = {"naive_count": "Count-insert", "cache_get_set": "Read-mod-write", "after_send": "After send",
             "atomic_update": "Atomic update", "immediate_txn": "Guarded txn", "reserve_commit": "Reserve"}
    with open(f"{G}/fig_seqvscon.tex", "w") as f:
        f.write("% generated by study/make_figs.py from results/r4/{main_sqlite,sequential}.csv; do not edit\n")
        con = " ".join(f"({st.median(sq[(s, 32)]):g},{short[s]})" for s in ORDER)
        sq32 = " ".join(f"({st.median(seq[(s, 32)]):g},{short[s]})" for s in ORDER)
        f.write("\\addplot[fill=blue!25, draw=blue!60!black, postaction={pattern=north east lines,\n"
                "         pattern color=blue!55!black}] coordinates {\n  " + con + "};\n"
                "\\addlegendentry{Released simultaneously}\n")
        f.write("\\addplot[fill=black!12, draw=black!55] coordinates {\n  " + sq32 + "};\n"
                "\\addlegendentry{Released one at a time}\n")
    print("wrote", f"{G}/fig_concurrency.tex", f"{G}/fig_seqvscon.tex")


if __name__ == "__main__":
    main()
    pgf_coords()
