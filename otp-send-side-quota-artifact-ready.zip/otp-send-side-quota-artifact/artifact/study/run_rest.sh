#!/usr/bin/env bash
# Remaining two experiment arms, run one after another on distinct ports.
cd "$(dirname "$0")/.."

EXP_PORT=8111 EXP_DB=/tmp/otp_seq.db python3 study/run_concurrency.py \
  --concurrency 8 16 32 --trials 10 --provider-ms 50 --limit 3 --mode sequential \
  --out results/sequential.csv > results/sequential.log 2>&1
echo "SEQ_EXIT=$?"

EXP_PORT=8112 EXP_DB=/tmp/otp_lat.db python3 study/run_concurrency.py \
  --strategies naive_count cache_get_set after_send atomic_update \
  --concurrency 8 --trials 30 --provider-ms 0 10 50 200 --limit 3 \
  --out results/latency.csv > results/latency.log 2>&1
echo "LAT_EXIT=$?"
echo BOTH_DONE
