"""
SHA-256 manifest of the artifact archive.

    python3 study/manifest.py write            # hash every file under the artifact root
    python3 study/manifest.py verify           # recompute and compare; exit 1 on ANY difference
    python3 study/manifest.py verify --strict  # as above, and count generated files as unlisted too
    python3 study/manifest.py inspect          # diagnostic: same report, always exit 0
    python3 study/test_manifest.py             # negative tests: missing, changed, unlisted -> failure

The manifest (MANIFEST.sha256.json at the artifact root) covers every regular
file under the root except itself: raw data and event logs, derived files
(paper_numbers.json, overrun_classification.csv, the generated table bodies),
every script, the environment files (requirements-lock.txt, Dockerfile), the
notebooks including the executed copy, the manuscript source and PDF, and the
review material. It is written last, when the archive is assembled, so that
every derived file it names is the one shipped.

`verify` walks the WHOLE tree under the root, not a list of expected
directories, and fails (exit 1) if any listed file is missing, any listed
file has changed, or any file is present that the manifest does not list,
wherever it is. The only files it does not count as unlisted are the ones the
artifact's own commands generate locally after unpacking, and every one of
them is printed by name under "ignored (generated locally)":

  * Python bytecode caches (__pycache__/, *.pyc), which importing any module
    creates;
  * LaTeX build products under paper/ and review/ (.aux .log .out .bbl .blg
    .toc .synctex.gz .fdb_latexmk .fls), which paper/build.sh creates;
  * results/repro/, which reproduce.sh creates.

`verify --strict` counts those as unlisted as well. A file you have
regenerated or re-executed since unpacking is reported as changed, which is
the intended behaviour: the derived files are byte-for-byte reproducible, so
re-running regenerate.py leaves `verify` passing (reproduce.sh checks this).
"""
import hashlib
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = "MANIFEST.sha256.json"
# What the archive contains, relative to its root. The packaging step copies
# exactly these entries. The manifest itself is NOT limited to them: `write`
# and `verify` walk the whole tree under the root.
ARCHIVED = ("svc", "study", "results", "notebooks", "review", "paper",
            "regenerate.py", "reproduce.sh", "build_notebook.py", "execute_notebook.py",
            "VERSION", "README.md", "LICENSE", "Dockerfile", "requirements-lock.txt")
# Files the artifact's own commands generate after unpacking (see docstring).
GENERATED_DIRS = ("__pycache__",)
GENERATED_SUFFIXES = (".pyc",)
TEX_DIRS = ("paper", "review")
TEX_PRODUCTS = (".aux", ".log", ".out", ".bbl", ".blg", ".toc", ".synctex.gz",
                ".fdb_latexmk", ".fls")
REPRO_DIR = os.path.join("results", "repro")


def is_generated(rel):
    """True for a path the artifact's own commands create locally."""
    parts = rel.split(os.sep)
    fn = parts[-1]
    if any(p in GENERATED_DIRS for p in parts[:-1]) or fn.endswith(GENERATED_SUFFIXES):
        return True
    if parts[0] in TEX_DIRS and fn.endswith(TEX_PRODUCTS):
        return True
    if rel == REPRO_DIR or rel.startswith(REPRO_DIR + os.sep):
        return True
    return False


def walk(root=ROOT):
    """Every regular file under root except the manifest, as (rel, generated)."""
    out = []
    for dp, dns, fns in os.walk(root):
        dns.sort()
        for fn in sorted(fns):
            full = os.path.join(dp, fn)
            if os.path.islink(full) or not os.path.isfile(full):
                continue
            rel = os.path.relpath(full, root)
            if rel == NAME:
                continue
            out.append((rel, is_generated(rel)))
    return out


def files(root=ROOT):
    """The files the manifest lists: everything under root that is not
    generated locally and not the manifest itself."""
    return [rel for rel, gen in walk(root) if not gen]


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def build(root=ROOT):
    return {rel: digest(os.path.join(root, rel)) for rel in files(root)}


def write(root=ROOT):
    m = build(root)
    with open(os.path.join(root, NAME), "w") as f:
        json.dump(m, f, indent=1)
    print(f"wrote {NAME}: {len(m)} files")
    return m


def check(root=ROOT, strict=False):
    """Compare the tree under root with its manifest.

    Returns (ok, report) where report has the lists missing, changed, new
    and ignored. ok is True only if missing, changed and new are all empty;
    with strict=True the generated files count as new instead of ignored.
    """
    path = os.path.join(root, NAME)
    if not os.path.exists(path):
        return False, dict(missing=[], changed=[], new=[], ignored=[], listed=0,
                           error=f"{NAME} not found under {root}")
    with open(path) as f:
        m = json.load(f)
    present = walk(root)
    ignored = [rel for rel, gen in present if gen and not strict]
    now = {rel: digest(os.path.join(root, rel)) for rel, gen in present if strict or not gen}
    missing = sorted(k for k in m if k not in now)
    changed = sorted(k for k in m if k in now and now[k] != m[k])
    new = sorted(k for k in now if k not in m)
    ok = not (missing or changed or new)
    return ok, dict(missing=missing, changed=changed, new=new, ignored=sorted(ignored),
                    listed=len(m), verified=len(m) - len(missing) - len(changed))


def report(ok, r, strict=False):
    if "error" in r:
        print("ERROR  ", r["error"])
    for k in r["missing"]:
        print("MISSING", k)
    for k in r["changed"]:
        print("CHANGED", k)
    for k in r["new"]:
        print("UNLISTED", k)
    for k in r["ignored"]:
        print("ignored (generated locally)", k)
    print(f"{r['listed']} files listed; {r.get('verified', 0)} verified; "
          f"{len(r['missing'])} missing; {len(r['changed'])} changed; "
          f"{len(r['new'])} unlisted; {len(r['ignored'])} ignored as generated locally"
          + (" (strict: none ignored)" if strict else ""))
    print("MANIFEST OK" if ok else "MANIFEST MISMATCH")


def verify(root=ROOT, strict=False):
    ok, r = check(root, strict)
    report(ok, r, strict)
    return ok


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    flags = [a for a in sys.argv[1:] if a.startswith("--")]
    cmd = args[0] if args else "verify"
    root = args[1] if len(args) > 1 else ROOT
    strict = "--strict" in flags
    if cmd == "write":
        write(root)
    elif cmd == "verify":
        sys.exit(0 if verify(root, strict) else 1)
    elif cmd == "inspect":
        verify(root, strict)
        print("(inspect: diagnostic mode, exit status 0 regardless)")
    elif cmd == "list":
        print("\n".join(files(root)))
    else:
        sys.exit(__doc__)
