"""
Load the per-request event logs and derive every per-trial quantity from them.

Every round-4 arm writes <arm>.events.jsonl, one JSON record per request, with
the trial's identity (arm, backend, strategy, provider_ms, limit, workers,
mode, concurrency, window_s, policy, trial, phone) and the service's event
fields (rid, t_recv, t_read, t_decide, t_write, observed, decision, window_id
or policy_ts, counter_after, t_provider_start, t_provider_end, message_id,
t_done; from service 2.1.0 also window_source and, for the read-modify-write
counter, window_id_returned and counter_returned). This module groups the records by trial and evaluates the declared
policy on the admission events with study/policy.py. Nothing here reads the
trial CSVs; regenerate.py compares the two and stops if they disagree.
"""
import gzip
import json
import os
import statistics as st
from collections import defaultdict

from study import policy as P

TRIAL_KEYS = ("arm", "backend", "strategy", "provider_ms", "limit", "workers",
              "mode", "concurrency", "window_s", "policy", "trial")


def resolve(path):
    """Accept either <path> or <path>.gz, whichever exists (str or Path)."""
    path = os.fspath(path)
    if os.path.exists(path):
        return path
    if os.path.exists(path + ".gz"):
        return path + ".gz"
    raise FileNotFoundError(path)


def load(path):
    """Yield event records from a .events.jsonl or .events.jsonl.gz file."""
    path = resolve(path)
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


def trials(path, keys=TRIAL_KEYS):
    """Group a log's records by trial. Returns {trial_key_tuple: [events]}.

    The service stamps its own `backend` on every record ("postgres-pooled"
    when a pool is in use); the trial identity uses the harness's backend
    name ("postgres"), so the pooled suffix is dropped for grouping only.
    """
    out = defaultdict(list)
    for e in load(path):
        key = tuple((e.get(k).replace("-pooled", "") if k == "backend" and isinstance(e.get(k), str)
                     else e.get(k)) for k in keys)
        out[key].append(e)
    return out


def summarise(events):
    """Every per-trial quantity the paper uses, from the events alone."""
    lim, win, pol = int(events[0]["limit"]), int(events[0]["window_s"]), events[0]["policy"]
    ev = P.evaluate(events, lim, win, pol)
    admits = [e for e in events if e["decision"] == "admit"]
    ev["limit"], ev["window_s"], ev["policy"] = lim, win, pol
    ev["elapsed_events_s"] = (max(e["t_done"] for e in events) - min(e["t_recv"] for e in events)
                              if events else 0.0)
    ev["arrival_spread_ms"] = ((max(e["t_recv"] for e in events) - min(e["t_recv"] for e in events)) * 1000
                               if events else 0.0)
    # read-to-write interval over admitted requests (the race window for the
    # two-step shapes; the statement's execution time for the one-step ones)
    rw = [(e["t_write"] - e["t_read"]) * 1000 for e in admits
          if e.get("t_write") is not None and e.get("t_read") is not None]
    ev["read_to_write_ms_admitted"] = rw
    ev["read_to_write_ms_refused"] = [(e["t_write"] - e["t_read"]) * 1000 for e in events
                                      if e["decision"] == "refuse" and e.get("t_write") is not None
                                      and e.get("t_read") is not None]
    return ev


def interleaving(events, limit):
    """Per-trial interleaving evidence, separated by what each rests on.

    Database-visible state: `observed` is the count or counter value the
    request's own read returned, i.e. the committed state visible to that
    read. An admitted request beyond the limit necessarily observed a value
    below the limit; the number of such requests is evidence that stale
    state was read, independent of any clock.

    Lost updates (read-modify-write counter): `counter_after` is the value
    each admitted request wrote. The largest value ever written is at most
    the number of admissions; the difference, admissions minus the largest
    written value, is a lower bound on the number of increments that were
    overwritten, again independent of ordering or clocks.

    Application-observed instants: t_read and t_write are taken around the
    SQL calls by the application, not from the database's commit log, so
    comparisons between them across requests are proxies for the database's
    order, and are reported as such.
    """
    admits = sorted([e for e in events if e["decision"] == "admit"],
                    key=lambda e: e.get("t_write") or e.get("t_decide"))
    refused = [e for e in events if e["decision"] == "refuse"]
    rec = dict(requests=len(events), admitted=len(admits), refused=len(refused), limit=limit)
    excess = admits[limit:]
    rec["excess"] = len(excess)
    rec["excess_observed_below_limit"] = sum(1 for e in excess
                                            if e.get("observed") is not None and e["observed"] < limit)
    if events and events[0]["strategy"] == "cache_get_set" and admits:
        written = [e["counter_after"] for e in admits]
        rec["max_counter_written"] = max(written)
        rec["lost_updates_lower_bound"] = len(admits) - max(written)
    if len(admits) >= limit:
        T_L = admits[limit - 1].get("t_write") or admits[limit - 1].get("t_decide")
        rec["first_arrival_to_Lth_write_ms"] = (T_L - min(e["t_recv"] for e in events)) * 1000
        rec["excess_read_before_Lth_write_app"] = sum(1 for e in excess if e["t_read"] < T_L)
        rec["refused_issued_before_Lth_write_app"] = sum(1 for e in refused if e["t_read"] < T_L)
        rec["requests_read_before_Lth_write_app"] = sum(1 for e in events if e["t_read"] < T_L)
    rec["arrival_spread_ms"] = (max(e["t_recv"] for e in events) - min(e["t_recv"] for e in events)) * 1000
    rec["read_spread_ms"] = (max(e["t_read"] for e in events) - min(e["t_read"] for e in events)) * 1000
    return rec


def aggregate_interleaving(recs):
    """Sum per-trial interleaving records into one summary."""
    agg = defaultdict(int)
    spans = []
    for r in recs:
        agg["trials"] += 1
        agg["overrun_trials"] += int(r["admitted"] > r["limit"])
        agg["excess_admissions"] += r["excess"]
        agg["excess_observed_below_limit"] += r["excess_observed_below_limit"]
        agg["refused"] += r["refused"]
        if "lost_updates_lower_bound" in r:
            agg["lost_updates_lower_bound"] += r["lost_updates_lower_bound"]
            agg["trials_with_lost_update"] += int(r["lost_updates_lower_bound"] > 0)
        if "first_arrival_to_Lth_write_ms" in r:
            agg["excess_read_before_Lth_write_app"] += r["excess_read_before_Lth_write_app"]
            agg["refused_issued_before_Lth_write_app"] += r["refused_issued_before_Lth_write_app"]
            agg["trials_admitted_equals_reads_before_Lth_write_app"] += int(
                r["requests_read_before_Lth_write_app"] == r["admitted"])
            spans.append((r["first_arrival_to_Lth_write_ms"], r["arrival_spread_ms"], r["read_spread_ms"]))
    out = dict(agg)
    if spans:
        out["first_arrival_to_Lth_write_ms_median"] = round(st.median(s[0] for s in spans), 2)
        out["arrival_spread_ms_median"] = round(st.median(s[1] for s in spans), 2)
        out["read_spread_ms_median"] = round(st.median(s[2] for s in spans), 2)
    return out
