"""
Negative tests for study/manifest.py: the verifier must FAIL when a listed
file is missing, when a listed file has changed, and when a file is present
that the manifest does not list, at the root or anywhere below it; it must
PASS on an untouched tree and after the artifact's own generated files
appear (bytecode caches, LaTeX build products, results/repro/), and it must
fail on those too under --strict.

    python3 study/test_manifest.py

Runs on a temporary tree, never on the artifact itself. Exit status 0 iff
every test passed.
"""
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from study import manifest as M  # noqa: E402


def put(root, rel, content="x"):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w") as f:
        f.write(content)


class ManifestTests(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix="manifest-test-")
        for rel, c in (("VERSION", "v0\n"), ("regenerate.py", "print(1)\n"),
                       ("results/r4/a.events.jsonl", "{}\n"), ("results/r4/a.csv", "h\n1\n"),
                       ("study/manifest.py", "# copy\n"), ("paper/body.tex", "x\n")):
            put(self.root, rel, c)
        M.write(self.root)

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def cli(self, *args):
        """Exit status of the command-line verifier on the test tree."""
        r = subprocess.run([sys.executable, os.path.join(HERE, "manifest.py"), *args, self.root],
                           capture_output=True, text=True)
        return r.returncode, r.stdout

    def test_untouched_tree_passes(self):
        ok, r = M.check(self.root)
        self.assertTrue(ok)
        self.assertEqual(self.cli("verify")[0], 0)

    def test_missing_file_fails(self):
        os.remove(os.path.join(self.root, "results/r4/a.csv"))
        ok, r = M.check(self.root)
        self.assertFalse(ok)
        self.assertEqual(r["missing"], ["results/r4/a.csv"])
        self.assertEqual(self.cli("verify")[0], 1)

    def test_changed_file_fails(self):
        put(self.root, "results/r4/a.events.jsonl", '{"changed": 1}\n')
        ok, r = M.check(self.root)
        self.assertFalse(ok)
        self.assertEqual(r["changed"], ["results/r4/a.events.jsonl"])
        self.assertEqual(self.cli("verify")[0], 1)

    def test_unlisted_file_under_results_fails(self):
        put(self.root, "results/temp.txt")
        ok, r = M.check(self.root)
        self.assertFalse(ok)
        self.assertEqual(r["new"], ["results/temp.txt"])
        code, out = self.cli("verify")
        self.assertEqual(code, 1)
        self.assertIn("UNLISTED results/temp.txt", out)
        self.assertIn("MANIFEST MISMATCH", out)

    def test_unlisted_top_level_file_fails(self):
        put(self.root, "stray.bin")
        ok, r = M.check(self.root)
        self.assertFalse(ok)
        self.assertEqual(r["new"], ["stray.bin"])
        self.assertEqual(self.cli("verify")[0], 1)

    def test_unlisted_directory_outside_archived_set_fails(self):
        put(self.root, "extra/deep/file.txt")
        ok, r = M.check(self.root)
        self.assertFalse(ok)
        self.assertEqual(r["new"], ["extra/deep/file.txt"])
        self.assertEqual(self.cli("verify")[0], 1)

    def test_generated_files_are_ignored_by_default_and_counted_under_strict(self):
        put(self.root, "study/__pycache__/manifest.cpython-311.pyc")
        put(self.root, "paper/body.aux")
        put(self.root, "results/repro/r4/main_sqlite.csv")
        ok, r = M.check(self.root)
        self.assertTrue(ok)
        self.assertEqual(sorted(r["ignored"]),
                         ["paper/body.aux", "results/repro/r4/main_sqlite.csv",
                          "study/__pycache__/manifest.cpython-311.pyc"])
        self.assertEqual(self.cli("verify")[0], 0)
        ok, r = M.check(self.root, strict=True)
        self.assertFalse(ok)
        self.assertEqual(len(r["new"]), 3)
        self.assertEqual(self.cli("verify", "--strict")[0], 1)

    def test_missing_manifest_fails(self):
        os.remove(os.path.join(self.root, M.NAME))
        ok, r = M.check(self.root)
        self.assertFalse(ok)
        self.assertEqual(self.cli("verify")[0], 1)

    def test_inspect_reports_but_exits_zero(self):
        put(self.root, "results/temp.txt")
        code, out = self.cli("inspect")
        self.assertEqual(code, 0)
        self.assertIn("MANIFEST MISMATCH", out)


if __name__ == "__main__":
    unittest.main(verbosity=2)
