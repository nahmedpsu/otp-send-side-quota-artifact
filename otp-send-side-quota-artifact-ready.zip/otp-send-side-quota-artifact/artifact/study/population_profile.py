"""
Profile the study population: delivery channel, guard type, adoption signals
and near-duplicates.

Added in response to review (findings M8, M9, M10, M11, N4, P7). The first
round reported a single binary flag, `send_path_gated`, over a population whose
delivery channel was not broken out. Reviewers were right that this compresses
materially different controls and materially different cost exposures into one
bit.

Channel is decided from the delivery code and the declared dependencies; guard
type from the construct found at the guard site; near-duplicates from the
overlap of normalised delivery-code token sets. Every verdict is written to
results/r2/population_profile.csv so it can be argued with.
"""
import csv
import json
import os
import re
from collections import Counter, defaultdict

_ROOT = os.environ.get("OTP_ROOT",
                       os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SRC = _ROOT + "/pkgs/src"

SMS = re.compile(r"\b(twilio|messagebird|nexmo|vonage|plivo|sinch|infobip|msg91|"
                 r"kavenegar|ghasedak|textlocal|clickatell|smsru|sms_ru|sns|"
                 r"send_sms|sms_backend|smsc)\b", re.I)
EMAIL = re.compile(r"\b(send_mail|EmailMessage|EmailMultiAlternatives|smtplib|"
                   r"sendgrid|mailgun|ses\b)", re.I)
VOICE = re.compile(r"\b(voice|call\(|by_call|tts)\b", re.I)
HOSTED = re.compile(r"\b(verify\.services|otpless|authy|firebase|cognito|"
                    r"msg91.*otp|verification_service)\b", re.I)

GUARD_KIND = [
    ("framework throttle", re.compile(
        r"throttle_classes|ScopedRateThrottle|UserRateThrottle|AnonRateThrottle|"
        r"@ratelimit|django_ratelimit|slowapi", re.I)),
    ("atomic counter", re.compile(
        r"cache\.incr\(|\.incr\(|\bF\(\s*['\"]\w+['\"]\s*\)\s*\+", re.I)),
    ("hosted service", HOSTED),
    ("max sends", re.compile(r"max_send|send_limit|max_attempts_send|"
                             r"max_verification", re.I)),
    ("cooldown", re.compile(r"cooldown|rate_limit_seconds|resend_in|"
                            r"can_resend|last_sent|retry_after", re.I)),
]

VEND = re.compile(r"(^|/)(site-packages|vendor|vendored|_vendor|third_party)(/|$)")
TEST = re.compile(r"(^|/)(tests?|testing)(/|$)|(^|/)test_[^/]*\.py$|_test\.py$", re.I)


def own_text(pkg):
    root = os.path.join(SRC, pkg)
    if not os.path.isdir(root):
        return ""
    chunks = []
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in {".git", "__pycache__"}]
        for f in fn:
            if not f.endswith(".py"):
                continue
            rel = os.path.relpath(os.path.join(dp, f), root).replace(os.sep, "/")
            if VEND.search(rel) or TEST.search(rel):
                continue
            try:
                chunks.append(open(os.path.join(dp, f), encoding="utf-8",
                                   errors="replace").read())
            except OSError:
                pass
    return "\n".join(chunks)


def channel(text, requires):
    dep = " ".join(requires or [])
    chans = []
    if SMS.search(text) or SMS.search(dep):
        chans.append("SMS")
    if EMAIL.search(text):
        chans.append("email")
    if VOICE.search(text):
        chans.append("voice")
    if HOSTED.search(text) or HOSTED.search(dep):
        chans.append("hosted")
    return "+".join(chans) if chans else "unclear"


def guard_kind(text, gated):
    if not gated:
        return "none"
    for name, rx in GUARD_KIND:
        if rx.search(text):
            return name
    return "other"


def shingles(text, n=6):
    toks = re.findall(r"[A-Za-z_]{3,}", text)
    return {" ".join(toks[i:i + n]) for i in range(0, max(0, len(toks) - n), 3)}


def main():
    cand = {c["name"]: c for c in
            json.load(open(f"{_ROOT}/results/survey_candidates.json"))["kept"]}
    rows = [r for r in csv.DictReader(open(f"{_ROOT}/results/survey_final.csv"))
            if r["in_population"] == "True"]

    texts, out = {}, []
    for r in rows:
        name = r["package"]
        t = own_text(name)
        texts[name] = t
        meta = cand.get(name, {})
        gated = r["send_path_gated"] == "yes"
        out.append(dict(
            package=name, version=r["version"],
            channel=channel(t, meta.get("requires_dist")),
            send_guard="yes" if gated else "no",
            guard_kind=guard_kind(t, gated),
            verify_side_throttling="yes" if r["verify_side_only"] else "no",
            py_bytes=len(t), home=meta.get("home") or ""))

    # near-duplicate detection over the package's own Python
    sh = {n: shingles(t) for n, t in texts.items() if len(t) > 2000}
    dupes = []
    names = sorted(sh)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            if not sh[a] or not sh[b]:
                continue
            j = len(sh[a] & sh[b]) / len(sh[a] | sh[b])
            if j >= 0.30:
                dupes.append((a, b, round(j, 3)))

    with open(f"{_ROOT}/results/r2/population_profile.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)
    json.dump(dupes, open(f"{_ROOT}/results/r2/near_duplicates.json", "w"), indent=1)

    print("channel breakdown of the 42-package population")
    for k, v in Counter(r["channel"] for r in out).most_common():
        g = sum(1 for r in out if r["channel"] == k and r["send_guard"] == "yes")
        print(f"  {k:<16}{v:>3}   guarded {g}   unguarded {v-g}")

    print("\nguard type among the 15 with a send-side guard")
    for k, v in Counter(r["guard_kind"] for r in out
                        if r["send_guard"] == "yes").most_common():
        print(f"  {k:<22}{v}")

    print("\ncross-tabulation of send-side guard against verification-side throttling")
    tab = Counter((r["send_guard"], r["verify_side_throttling"]) for r in out)
    print(f"  {'':<22}{'verify-side yes':>17}{'verify-side no':>16}")
    for g in ("yes", "no"):
        print(f"  send guard {g:<11}{tab[(g,'yes')]:>17}{tab[(g,'no')]:>16}")

    print(f"\nnear-duplicate pairs at Jaccard >= 0.30: {len(dupes)}")
    for a, b, j in sorted(dupes, key=lambda x: -x[2]):
        print(f"  {a}  <->  {b}   {j}")


if __name__ == "__main__":
    main()
