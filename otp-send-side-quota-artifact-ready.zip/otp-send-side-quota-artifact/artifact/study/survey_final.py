"""
Manual adjudication of the 61 auto-detected packages.

Every exclusion is recorded with a reason so the census denominator can be
audited. The rule applied is: the package must exist to deliver a one-time or
verification code to an end user. Packages whose name merely collides with the
search patterns, packages that consume a code the user already holds, and
general-purpose senders that are not about one-time codes are excluded.
"""
import os as _os
_ROOT = _os.environ.get("OTP_ROOT",
    _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import csv
import json

GATE = json.load(open(_ROOT + "/results/survey_gate.json"))

EXCLUDE = {
    # name collision with the search patterns; unrelated functionality
    "bootpay": "payment gateway client; 'quota' means instalment months",
    "chatbotpackage": "chatbot toolkit; vendored web stack",
    "dotpromptz-py": "prompt template format; matched on 'otp' inside name",
    "efootprint": "environmental footprint model",
    "hotpath": "inference profiler",
    "idiotproof": "GPU media sandbox client",
    "memfault-cli": "device telemetry CLI",
    "mfaliquot": "number theory utility",
    "mlx-mfa": "matrix attention kernels",
    "potpie": "unrelated product distribution",
    "qq-botpy-sdk": "chat bot SDK; retry_after is an API error field",
    "robotpy-installer": "robotics installer",
    "spotpdf": "PDF spot colour tool",
    "twotp": "Erlang node protocol",
    # MFA tooling that consumes rather than delivers a code
    "MFASweep.py": "audits Azure MFA configuration; sends nothing",
    "mfa-servicenow-mcp": "ServiceNow MCP server; throttle is a browser session guard",
    # general senders, not one-time-code delivery
    "mailer-otphero": "general email sender",
    "mailing2fast-fastapi": "general mailing module",
    "smsauth": "general SMS API wrapper, not a one-time-code flow",
    "cubicweb-forgotpwd": "password reset link, not a one-time code challenge",
}

# Send-path gating confirmed by reading the code (see notes column).
CONFIRMED_GATED = {
    "django-otp": "EmailDevice.generate_challenge calls cooldown_set and refuses "
                  "inside the cooldown window",
    "django-two-factor-auth": "PhoneDevice.generate_challenge consults "
                              "verify_is_allowed before sending",
    "maykin-django-two-factor-auth": "fork of django-two-factor-auth; same gate",
    "django-twilio-2fa": "client.send_verification enforces a cooldown and a "
                         "max-sends limit",
    "django-mfa": "rate-limit check runs before the delivery adapter",
    "django-otp-admin": "cooldown sentinel in cache keyed on the address",
    "fastapi-otp-auth": "request_otp applies a rate limit before issuing",
    "fastapi-otp-authentication": "router checks otp_rate_limit_seconds before issue",
    "django-otp-auth": "module-level per-mobile last-sent map",
    "django-drf-otp-auth": "DRF ScopedRateThrottle on the request-OTP view",
    "drf-jwt-2fa": "DRF throttle class on the code-token endpoint",
    "drf-simple-jwt-2fa": "DRF throttle class on the code-token endpoint",
    "celonix-otp": "explicit one-minute rate limit before send",
    "django-mfa3": "MFA_RATE_LIMIT_REQUESTS window applied to code requests",
    "msg91-otp": "delegates to the provider's own retry endpoint semantics",
    "OTPLessAuthSDK": "hosted provider performs the limiting",
    "django-sage-otp": "last_sent_at consulted before reissue",
}

# Verification-side only: throttles guessing, not sending.
VERIFY_ONLY_NOTE = {
    "django-otp-twilio": "ThrottlingMixin guards verify_token; generate_challenge "
                         "posts to Twilio with no send-side check",
    "django-otp-messagebird": "same pattern as django-otp-twilio",
    "django-otp-signal": "same pattern as django-otp-twilio",
    "otpme": "server-side throttling applies to authentication attempts",
    "smart-2fa-secure": "attempt limits only",
}


def main():
    rows = []
    for name, v in sorted(GATE.items()):
        excluded = name in EXCLUDE
        gated = name in CONFIRMED_GATED
        rows.append(dict(
            package=name,
            version=v["version"],
            in_population=not excluded,
            exclusion_reason=EXCLUDE.get(name, ""),
            send_path_gated=("yes" if gated else ("no" if not excluded else "")),
            gate_evidence=CONFIRMED_GATED.get(name, ""),
            verify_side_only=VERIFY_ONLY_NOTE.get(name, ""),
            detector_flagged=v["gated"],
            summary=v["summary"][:160],
        ))
    with open(_ROOT + "/results/survey_final.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    pop = [r for r in rows if r["in_population"]]
    gated = [r for r in pop if r["send_path_gated"] == "yes"]
    vonly = [r for r in pop if r["verify_side_only"]]
    print(f"auto-detected delivery packages : {len(rows)}")
    print(f"excluded after manual reading   : {len(rows) - len(pop)}")
    print(f"population                      : {len(pop)}")
    print(f"  send path gated               : {len(gated)}  "
          f"({100*len(gated)/len(pop):.0f}%)")
    print(f"  no send-side limit            : {len(pop) - len(gated)}  "
          f"({100*(len(pop)-len(gated))/len(pop):.0f}%)")
    print(f"  documented verification-only  : {len(vonly)}")


if __name__ == "__main__":
    main()
