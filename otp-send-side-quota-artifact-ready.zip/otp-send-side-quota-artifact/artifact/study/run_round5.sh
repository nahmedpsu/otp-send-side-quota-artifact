#!/usr/bin/env bash
# Round-5 check arms (service v2.1.0). The round-4 arms in results/r4/ are
# the reported results and were produced by service v2.0.0 (archived verbatim
# in svc/archive/). Version 2.1.0 adds a RETURNING clause to the upsert of the
# read-modify-write counter (cache_get_set) so that its records also carry the
# value the database returned. These arms re-run that implementation only,
# with the paper's cell design, to check two things on the records:
#   1. the returned window and counter equal the submitted ones in every
#      admission (the upsert writes what it is given, so they must);
#   2. the per-cell outcome distribution is the same as round 4's.
# Outputs go to results/r5/. Nothing in results/r4/ is touched; these arms
# replace or recompute no round-4 result and are reported in the paper only
# as a provenance check.
set -u
cd "$(dirname "$0")/.."
R=results/r5
mkdir -p "$R"
export EXP_PORT=8260
export EXP_DB=/tmp/otp_r5.db

run () {  # name, then harness arguments
  local name=$1; shift
  echo "=== $name  ($(date -u +%FT%TZ)) ==="
  python3 study/run_experiments.py --arm "$name" --out "$R/$name.csv" "$@" > "$R/$name.log" 2>&1
  echo "exit=$?"
}

run cgs_sqlite   --backend sqlite   --strategies cache_get_set --concurrency 1 2 4 8 16 32 --trials 30 --randomize
run cgs_postgres --backend postgres --strategies cache_get_set --concurrency 1 2 4 8 16 32 --trials 30 --randomize

echo "=== cgs_boundary_sqlite  ($(date -u +%FT%TZ)) ==="
python3 study/boundary_test.py --backend sqlite --strategies cache_get_set --trials 30 --out "$R/cgs_boundary_sqlite.csv" > "$R/cgs_boundary_sqlite.log" 2>&1
echo "exit=$?"
echo "=== cgs_boundary_postgres  ($(date -u +%FT%TZ)) ==="
python3 study/boundary_test.py --backend postgres --strategies cache_get_set --trials 30 --out "$R/cgs_boundary_postgres.csv" > "$R/cgs_boundary_postgres.log" 2>&1
echo "exit=$?"
echo "ROUND5_DONE $(date -u +%FT%TZ)"
