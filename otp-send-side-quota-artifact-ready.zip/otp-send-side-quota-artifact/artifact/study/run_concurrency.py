"""
Concurrency experiment: how many billable sends does an attacker obtain from a
phone number whose declared quota is L?

For every (strategy, provider latency, concurrency) cell we reset the service,
release k requests for the same number at the same instant, wait for all of
them to finish, and then ask the service how many sends actually reached the
provider boundary. Sequential trials use the same code path with k releases one
after another.
"""
import argparse
import csv
import itertools
import json
import os
import signal
import subprocess
import sys
import tempfile
import threading
import time

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = int(os.environ.get("EXP_PORT", "8099"))
BASE = f"http://127.0.0.1:{PORT}"
DB = os.environ.get("EXP_DB", os.path.join(tempfile.gettempdir(), "otp_exp.db"))


def start_server(strategy, limit, provider_ms, workers=4):
    env = dict(os.environ)
    env.update(
        OTP_STRATEGY=strategy,
        OTP_LIMIT=str(limit),
        OTP_PROVIDER_MS=str(provider_ms),
        OTP_DB=DB,
        OTP_WINDOW_S="3600",
        PYTHONPATH=ROOT,
    )
    for f in (DB, DB + "-wal", DB + "-shm"):
        try:
            os.remove(f)
        except FileNotFoundError:
            pass
    p = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "svc.app:app",
         "--host", "127.0.0.1", "--port", str(PORT),
         "--workers", str(workers), "--log-level", "error"],
        env=env, cwd=ROOT,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        preexec_fn=os.setsid,
    )
    for _ in range(200):
        try:
            httpx.get(f"{BASE}/otp/stats", params={"phone": "warm"}, timeout=1.0)
            return p
        except Exception:
            time.sleep(0.15)
    raise RuntimeError(f"server did not start for {strategy}")


def stop_server(p):
    try:
        os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        p.wait(timeout=10)
    except Exception:
        try:
            os.killpg(os.getpgid(p.pid), signal.SIGKILL)
        except Exception:
            pass


def burst(phone, k, timeout=60.0):
    """Release k requests simultaneously; return the server's own replies."""
    barrier = threading.Barrier(k)
    replies = [None] * k

    def worker(i):
        with httpx.Client(timeout=timeout) as c:
            barrier.wait()
            try:
                r = c.post(f"{BASE}/otp/request", json={"phone": phone})
                replies[i] = r.json().get("status")
            except Exception as e:
                replies[i] = f"error:{type(e).__name__}"

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(k)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return replies


def sequential(phone, k, timeout=60.0):
    replies = []
    with httpx.Client(timeout=timeout) as c:
        for _ in range(k):
            try:
                r = c.post(f"{BASE}/otp/request", json={"phone": phone})
                replies.append(r.json().get("status"))
            except Exception as e:
                replies.append(f"error:{type(e).__name__}")
    return replies


def sends_for(phone):
    r = httpx.get(f"{BASE}/otp/stats", params={"phone": phone}, timeout=30.0)
    return r.json()["provider_sends"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strategies", nargs="+", default=[
        "naive_count", "cache_get_set", "after_send",
        "atomic_update", "immediate_txn", "reserve_commit"])
    ap.add_argument("--concurrency", nargs="+", type=int, default=[1, 2, 4, 8, 16, 32])
    ap.add_argument("--provider-ms", nargs="+", type=float, default=[50.0])
    ap.add_argument("--limit", type=int, default=3)
    ap.add_argument("--trials", type=int, default=30)
    ap.add_argument("--mode", choices=["concurrent", "sequential"], default="concurrent")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    rows = []
    for strategy, pms in itertools.product(args.strategies, args.provider_ms):
        print(f"[{time.strftime('%H:%M:%S')}] {strategy} provider_ms={pms}", flush=True)
        p = start_server(strategy, args.limit, pms)
        try:
            for k in args.concurrency:
                for trial in range(args.trials):
                    phone = f"+100{strategy[:4]}{int(pms)}{k}{trial}"
                    httpx.post(f"{BASE}/admin/reset", timeout=30.0)
                    t0 = time.time()
                    if args.mode == "concurrent":
                        replies = burst(phone, k)
                    else:
                        replies = sequential(phone, k)
                    elapsed = time.time() - t0
                    n = sends_for(phone)
                    rows.append(dict(
                        strategy=strategy, provider_ms=pms, mode=args.mode,
                        concurrency=k, trial=trial, limit=args.limit,
                        provider_sends=n,
                        overrun=max(0, n - args.limit),
                        accepted_replies=sum(1 for x in replies if x == "sent"),
                        rejected_replies=sum(1 for x in replies if x == "rejected"),
                        errors=sum(1 for x in replies if str(x).startswith("error")),
                        elapsed_s=round(elapsed, 4),
                    ))
                print(f"   k={k:>3}  sends per trial: "
                      f"{[r['provider_sends'] for r in rows[-args.trials:]]}", flush=True)
        finally:
            stop_server(p)

    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {len(rows)} rows to {args.out}")


if __name__ == "__main__":
    main()
