#!/usr/bin/env bash
# Round-3 follow-up arms: timing across concurrency levels, and pooled
# PostgreSQL timing, so that two claims made in round 2 can be checked rather
# than asserted.
set -u
cd "$(dirname "$0")/.."
R=results/r3
export EXP_PORT=8230

echo "=== A: instrumented SQLite at k = 2, 8, 32 ==="
EXP_DB=/tmp/otp_r3a.db python3 study/run_experiments.py --backend sqlite \
  --strategies naive_count cache_get_set atomic_update --concurrency 2 8 32 \
  --trials 30 --provider-ms 50 --limit 3 --workers 4 --timing \
  --out "$R/timing_sqlite_k.csv" --timing-out "$R/timing_sqlite_k.json" \
  > "$R/timing_sqlite_k.log" 2>&1
echo "exit=$?"

echo "=== B: instrumented PostgreSQL, pooled connections, k = 8 ==="
OTP_PG_POOL=8 python3 study/run_experiments.py --backend postgres \
  --strategies naive_count cache_get_set atomic_update --concurrency 8 \
  --trials 30 --provider-ms 50 --limit 3 --workers 4 --timing \
  --out "$R/timing_pg_pooled.csv" --timing-out "$R/timing_pg_pooled.json" \
  > "$R/timing_pg_pooled.log" 2>&1
echo "exit=$?"
echo "ROUND3_DONE"
