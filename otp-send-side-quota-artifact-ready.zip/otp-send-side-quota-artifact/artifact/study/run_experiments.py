"""
Concurrency experiment harness (round 4).

Same burst protocol as the earlier rounds; what is new is that every trial
keeps the complete per-request event log. After each burst the harness
fetches one event record per request from the service (GET /otp/events),
appends the records to <out>.events.jsonl with the trial's identity, and
evaluates the declared policy on the ADMISSION events with study/policy.py.
The trial CSV holds only summaries; regenerate.py recomputes every summary
from the event log and refuses to proceed if the two disagree.

  --backend {sqlite,postgres}   run against either datastore
  --workers N                   vary the worker-process count
  --limit L                     vary the declared quota
  --randomize                   randomise the order in which cells are run
  --window-s S                  length of the policy window in seconds

Nothing is silently swallowed. A request that raises is counted and its
exception type is written to the output row, because a failed client
observation is not the same thing as no provider action.
"""
import argparse
import csv
import itertools
import json
import os
import random
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time

import httpx

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from study import policy as P  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = int(os.environ.get("EXP_PORT", "8099"))
BASE = f"http://127.0.0.1:{PORT}"
SQLITE_DB = os.environ.get("EXP_DB", os.path.join(tempfile.gettempdir(), "otp_exp.db"))
EVENT_DIR = os.environ.get("EXP_EVENT_DIR", SQLITE_DB + ".events")
PG_DSN = os.environ.get("OTP_PG_DSN",
                        "dbname=otp user=otp password=otp host=127.0.0.1")

ALL = ["naive_count", "cache_get_set", "after_send",
       "atomic_update", "immediate_txn", "reserve_commit"]
POLICY = {"naive_count": "sliding", "after_send": "sliding",
          "immediate_txn": "sliding", "cache_get_set": "fixed",
          "atomic_update": "fixed", "reserve_commit": "fixed"}


def start_server(strategy, limit, provider_ms, backend, workers, window_s=3600):
    env = dict(os.environ)
    env.update(OTP_STRATEGY=strategy, OTP_LIMIT=str(limit),
               OTP_PROVIDER_MS=str(provider_ms), OTP_WINDOW_S=str(window_s),
               OTP_EVENT_DIR=EVENT_DIR, PYTHONPATH=ROOT)
    shutil.rmtree(EVENT_DIR, ignore_errors=True)
    if backend == "sqlite":
        env["OTP_DB"] = SQLITE_DB
        module = "svc.app:app"
        for f in (SQLITE_DB, SQLITE_DB + "-wal", SQLITE_DB + "-shm"):
            try:
                os.remove(f)
            except FileNotFoundError:
                pass
    else:
        env["OTP_PG_DSN"] = PG_DSN
        module = "svc.app_pg:app"
    p = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", module, "--host", "127.0.0.1",
         "--port", str(PORT), "--workers", str(workers), "--log-level", "error"],
        env=env, cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        preexec_fn=os.setsid)
    for _ in range(300):
        try:
            httpx.get(f"{BASE}/otp/stats", params={"phone": "warm"}, timeout=1.0)
            return p
        except Exception:
            time.sleep(0.15)
    raise RuntimeError(f"server did not start: {strategy}/{backend}")


def stop_server(p):
    try:
        os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        p.wait(timeout=15)
    except Exception:
        try:
            os.killpg(os.getpgid(p.pid), signal.SIGKILL)
        except Exception:
            pass


def burst(phone, k, timeout=120.0):
    """Release k requests simultaneously. Returns one outcome string each."""
    barrier = threading.Barrier(k)
    out = [None] * k

    def worker(i):
        with httpx.Client(timeout=timeout) as c:
            barrier.wait()
            try:
                r = c.post(f"{BASE}/otp/request", json={"phone": phone})
                out[i] = r.json().get("status", f"http_{r.status_code}")
            except Exception as e:          # recorded, never swallowed
                out[i] = f"error:{type(e).__name__}"

    ts = [threading.Thread(target=worker, args=(i,)) for i in range(k)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    return out


def sequential(phone, k, timeout=120.0):
    out = []
    with httpx.Client(timeout=timeout) as c:
        for _ in range(k):
            try:
                r = c.post(f"{BASE}/otp/request", json={"phone": phone})
                out.append(r.json().get("status", f"http_{r.status_code}"))
            except Exception as e:
                out.append(f"error:{type(e).__name__}")
    return out


def sends_for(phone):
    return httpx.get(f"{BASE}/otp/stats", params={"phone": phone},
                     timeout=60.0).json()["provider_sends"]


def events_for(phone):
    """Every request event the service recorded for this number."""
    r = httpx.get(f"{BASE}/otp/events", params={"phone": phone}, timeout=60.0).json()
    return r["events"], int(r["limit"]), int(r["window_s"]), r["policy"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strategies", nargs="+", default=ALL)
    ap.add_argument("--concurrency", nargs="+", type=int, default=[1, 2, 4, 8, 16, 32])
    ap.add_argument("--provider-ms", nargs="+", type=float, default=[50.0])
    ap.add_argument("--limit", nargs="+", type=int, default=[3])
    ap.add_argument("--workers", nargs="+", type=int, default=[4])
    ap.add_argument("--backend", default="sqlite", choices=["sqlite", "postgres"])
    ap.add_argument("--trials", type=int, default=30)
    ap.add_argument("--mode", choices=["concurrent", "sequential"], default="concurrent")
    ap.add_argument("--randomize", action="store_true")
    ap.add_argument("--seed", type=int, default=20260922)
    ap.add_argument("--window-s", type=int, default=3600,
                    help="length of the policy window in seconds")
    ap.add_argument("--arm", default=None, help="arm name written into every record")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    arm = args.arm or os.path.splitext(os.path.basename(args.out))[0]
    events_path = os.path.splitext(args.out)[0] + ".events.jsonl"

    rng = random.Random(args.seed)
    arms = list(itertools.product(args.strategies, args.provider_ms,
                                  args.limit, args.workers))
    if args.randomize:
        rng.shuffle(arms)

    rows = []
    ef = open(events_path, "w")
    for strategy, pms, limit, workers in arms:
        print(f"[{time.strftime('%H:%M:%S')}] {args.backend} {strategy} "
              f"ms={pms} limit={limit} workers={workers} "
              f"start_utc={time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}", flush=True)
        p = start_server(strategy, limit, pms, args.backend, workers, window_s=args.window_s)
        try:
            cells = [(k, t) for k in args.concurrency for t in range(args.trials)]
            if args.randomize:
                rng.shuffle(cells)
            for k, trial in cells:
                phone = f"+1{abs(hash((strategy,pms,limit,workers,k,trial)))%10**9:09d}"
                httpx.post(f"{BASE}/admin/reset", timeout=60.0)
                t0 = time.time()
                replies = (burst(phone, k) if args.mode == "concurrent"
                           else sequential(phone, k))
                elapsed = time.time() - t0
                n_provider = sends_for(phone)
                evs, lim_srv, win_srv, pol_srv = events_for(phone)
                assert pol_srv == POLICY[strategy]
                ev = P.evaluate(evs, lim_srv, win_srv, pol_srv)
                errs = [r for r in replies if str(r).startswith("error")]
                meta = dict(arm=arm, backend=args.backend, strategy=strategy,
                            provider_ms=pms, limit=limit, workers=workers,
                            mode=args.mode, concurrency=k, window_s=args.window_s,
                            policy=POLICY[strategy], trial=trial, phone=phone)
                for e in evs:
                    # the trial identity (meta) wins over any same-named
                    # field the service stamped on the record
                    ef.write(json.dumps({**e, **meta}) + "\n")
                ef.flush()
                rows.append(dict(
                    **{k_: v for k_, v in meta.items() if k_ != "phone"},
                    t_release=round(t0, 6),
                    provider_sends=n_provider,
                    admits=ev["admits"],
                    requests_logged=ev["requests"],
                    overrun=max(0, n_provider - limit),
                    windows_touched=ev["windows_touched"],
                    max_in_window=ev["max_per_policy"],
                    policy_overrun=ev["policy_overrun"],
                    cross_window=int(ev["windows_touched"] > 1),
                    admits_equal_provider_calls=ev["admits_equal_provider_calls"],
                    first_admit_ts=(ev["first_admit_ts"] if ev["first_admit_ts"] else ""),
                    last_admit_ts=(ev["last_admit_ts"] if ev["last_admit_ts"] else ""),
                    accepted_replies=sum(1 for x in replies if x == "sent"),
                    rejected_replies=sum(1 for x in replies if x == "rejected"),
                    errors=len(errs),
                    error_types=";".join(sorted(set(errs))),
                    elapsed_s=round(elapsed, 4)))
            done = [r for r in rows if r["strategy"] == strategy
                    and r["workers"] == workers and r["limit"] == limit
                    and r["provider_ms"] == pms]
            for k in args.concurrency:
                v = sorted(r["provider_sends"] for r in done if r["concurrency"] == k)
                pv = sum(1 for r in done if r["concurrency"] == k and r["policy_overrun"] > 0)
                print(f"   k={k:>3} sends {v}  policy_violations={pv}", flush=True)
        finally:
            stop_server(p)
    ef.close()

    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {len(rows)} rows to {args.out} and the event log to {events_path}")


if __name__ == "__main__":
    main()
