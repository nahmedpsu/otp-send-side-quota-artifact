"""
Does a guard actually gate the send?

Module-level keyword hits are too weak: a package can mention "throttle" in a
docstring and still send without limit. Here we ask a narrower question. For
each delivery site we look at the function itself and at every function in the
package that calls it, and we check whether a send-frequency guard appears in
that call path. We also record whether the package's own documentation says the
limit is the integrating application's responsibility.
"""
import os as _os
_ROOT = _os.environ.get("OTP_ROOT",
    _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import ast
import json
import os
import re

SRC = _ROOT + "/pkgs/src"
POP = json.load(open(_ROOT + "/results/survey_pop.json"))

GUARD = re.compile(
    r"\b(cooldown|cool_down|throttle|throttling|rate_limit|ratelimit|"
    r"resend_(interval|delay|after|cooldown)|min_interval|interval_seconds|"
    r"seconds_between|max_sends?|send_limit|send_quota|"
    r"last_sent|last_send|next_allowed|retry_after|"
    r"ThrottlingMixin|SimpleRateThrottle|ScopedRateThrottle|UserRateThrottle|"
    r"verify_is_allowed|throttle_increment|throttle_reset)\b", re.I)

DELEGATES = re.compile(
    r"(rate[- ]limit\w*|throttl\w*).{0,90}(your|the integrating|application|"
    r"project|caller|consumer|not (provided|included|handled))|"
    r"(you|applications?|integrators?).{0,60}(should|must|are expected to)"
    r".{0,40}(rate[- ]limit|throttl)", re.I)


def module_funcs(text):
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return {}, ""
    lines = text.splitlines()
    out = {}
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            lo = node.lineno - 1
            hi = getattr(node, "end_lineno", node.lineno)
            out[node.name] = "\n".join(lines[lo:hi])
    return out, text


def docs_text(root):
    blob = []
    for dp, dn, fn in os.walk(root):
        for f in fn:
            if re.search(r"(readme|docs?|usage|index)\.(md|rst|txt)$", f, re.I):
                try:
                    blob.append(open(os.path.join(dp, f), encoding="utf-8",
                                     errors="replace").read()[:20000])
                except Exception:
                    pass
    return "\n".join(blob)


def main():
    out = {}
    for name, rec in POP.items():
        if not rec["in_pop"]:
            continue
        root = os.path.join(SRC, name)
        gated, evidence = False, []
        site_funcs = {(s[0], s[2]) for s in rec["sites"]}
        for rel, lineno, fname, snippet in rec["sites"]:
            full = os.path.join(root, rel)
            try:
                text = open(full, encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            funcs, _ = module_funcs(text)
            body = funcs.get(fname, snippet)
            if GUARD.search(body):
                gated = True
                m = GUARD.search(body)
                evidence.append(["self", rel, fname, m.group(0)])
                continue
            # callers of this delivery site anywhere in the package
            for rel2, full2 in [(r, os.path.join(root, r)) for r, _, _, _ in rec["sites"]] + \
                               [(rel, full)]:
                pass
            for dp, dn, fn in os.walk(root):
                for f in fn:
                    if not f.endswith(".py"):
                        continue
                    p = os.path.join(dp, f)
                    try:
                        t2 = open(p, encoding="utf-8", errors="replace").read()
                    except Exception:
                        continue
                    if fname not in t2:
                        continue
                    f2, _ = module_funcs(t2)
                    for cname, cbody in f2.items():
                        if re.search(rf"\b{re.escape(fname)}\s*\(", cbody) and GUARD.search(cbody):
                            gated = True
                            evidence.append(
                                ["caller", os.path.relpath(p, root), cname,
                                 GUARD.search(cbody).group(0)])
                            break
                    if gated:
                        break
                if gated:
                    break
        doc = docs_text(root)
        out[name] = dict(
            version=rec["version"], summary=rec["summary"],
            gated=gated, evidence=evidence[:4],
            delegates=bool(DELEGATES.search(doc)),
            delegate_quote=(DELEGATES.search(doc).group(0)[:200]
                            if DELEGATES.search(doc) else ""),
            n_sites=len(rec["sites"]),
            atomic=bool(rec["atomic"]),
        )
    json.dump(out, open(_ROOT + "/results/survey_gate.json", "w"), indent=2)
    g = sum(1 for v in out.values() if v["gated"])
    d = sum(1 for v in out.values() if v["delegates"])
    print(f"population {len(out)}  gated {g}  documents delegation {d}")


if __name__ == "__main__":
    main()
