"""
Build the study population properly.

Inclusion: the package's own code (not vendored dependencies) must contain a
delivery path for a one-time or verification code -- an SMS/voice/messaging
provider call, or an HTTP/email call in a module that also handles codes.
Exclusion: code generators with no delivery, vendored third-party trees, and
packages whose name merely collides with the search patterns.

For every included package we then locate the send call site and look for any
guard that could bound how often it runs.
"""
import os as _os
_ROOT = _os.environ.get("OTP_ROOT",
    _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import json
import os
import re

SRC = _ROOT + "/pkgs/src"

VENDORED = re.compile(
    r"(^|/)(site-packages|venv|\.venv|vendor|vendored|third_party|node_modules|"
    r"\.eggs|dist-packages)(/|$)", re.I)

PROVIDER = re.compile(
    r"\b(twilio|messagebird|vonage|nexmo|plivo|kavenegar|ghasedak|sms_ir|smsir|"
    r"africastalking|infobip|sinch|telesign|clicksend|textlocal|termii|msg91|"
    r"bulksms|gatewayapi|smsapi|smsc|melipayamak|signalwire|bandwidth|"
    r"aws.?sns|boto3|sns)\b", re.I)

EMAIL_SEND = re.compile(r"\b(send_mail|EmailMessage|smtplib|send_message|sendmail)\b")
HTTP_CALL = re.compile(r"\b(requests|httpx|aiohttp|urllib)\b.{0,40}\b(post|request|get)\b", re.I)

CODE_CONCEPT = re.compile(r"\b(otp|one.?time|verification.?code|security.?code|"
                          r"token|challenge|pin.?code|auth.?code)\b", re.I)
SEND_VERB = re.compile(r"\b(send|deliver|dispatch|submit|transmit)\w*\b", re.I)

# any guard that could bound send frequency
GUARD = re.compile(
    r"\b(cooldown|cool_down|throttl\w*|rate.?limit\w*|resend\w*|"
    r"min.?interval|interval_seconds|seconds_between|time_between|"
    r"max.?send\w*|send.?limit|send.?quota|quota|"
    r"last.?sent|last.?send|last.?request|next.?allowed|wait_time|"
    r"ThrottlingMixin|SimpleRateThrottle|ScopedRateThrottle|"
    r"cache\.get\(.{0,40}(otp|code|sms|resend))\b", re.I)

ATOMIC = re.compile(
    r"select_for_update|transaction\.atomic|\bF\(|\.incr\(|INCRBY|"
    r"with_for_update|FOR UPDATE|get_or_create\(|update_or_create\(", re.I)


def own_files(root):
    out = []
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in {".git", "__pycache__"}]
        rel_dir = os.path.relpath(dp, root)
        if VENDORED.search(rel_dir.replace(os.sep, "/")):
            continue
        for f in fn:
            if f.endswith(".py"):
                rel = os.path.relpath(os.path.join(dp, f), root).replace(os.sep, "/")
                if VENDORED.search(rel):
                    continue
                out.append((rel, os.path.join(dp, f)))
    return out


def analyse(root):
    ev = dict(send=[], guard=[], atomic=[], loc=0, files=0, test_only_send=True)
    for rel, full in own_files(root):
        try:
            text = open(full, encoding="utf-8", errors="replace").read()
        except Exception:
            continue
        ev["files"] += 1
        lines = text.splitlines()
        ev["loc"] += len(lines)
        is_test = bool(re.search(r"(^|/)(tests?|testing)(/|_)|test_.*\.py$|_test\.py$",
                                 rel, re.I))
        file_has_code_concept = bool(CODE_CONCEPT.search(text))
        for i, line in enumerate(lines, 1):
            hit = None
            if PROVIDER.search(line) and (file_has_code_concept or CODE_CONCEPT.search(line)):
                hit = "provider"
            elif (EMAIL_SEND.search(line) or HTTP_CALL.search(line)) and \
                 file_has_code_concept and SEND_VERB.search(line):
                hit = "http_or_email"
            if hit:
                ev["send"].append([rel, i, line.strip()[:150], is_test, hit])
                if not is_test:
                    ev["test_only_send"] = False
            if GUARD.search(line):
                ev["guard"].append([rel, i, line.strip()[:150], is_test])
            if ATOMIC.search(line):
                ev["atomic"].append([rel, i, line.strip()[:150], is_test])
    return ev


def main():
    cands = {c["name"]: c for c in
             json.load(open("results/survey_candidates.json"))["kept"]}
    out = {}
    names = sorted(n for n in os.listdir(SRC) if os.path.isdir(os.path.join(SRC, n)))
    for i, n in enumerate(names, 1):
        ev = analyse(os.path.join(SRC, n))
        nontest_send = [x for x in ev["send"] if not x[3]]
        ev["in_scope_auto"] = bool(nontest_send)
        ev["nontest_guard"] = [x for x in ev["guard"] if not x[3]]
        ev["summary"] = cands.get(n, {}).get("summary", "")
        ev["version"] = cands.get(n, {}).get("version", "")
        out[n] = ev
        if i % 150 == 0:
            print(f"  {i}/{len(names)}", flush=True)
    json.dump(out, open("results/survey_scope.json", "w"), indent=2)
    scope = [n for n, e in out.items() if e["in_scope_auto"]]
    print(f"scanned {len(out)}; auto in-scope {len(scope)}")


if __name__ == "__main__":
    main()
