"""
Deterministic window-boundary test, evaluated on admission events.

Round 3 added this test to show that a burst straddling an aligned boundary of
a fixed window can legitimately exceed the limit in total while exceeding it in
no window. Round 4 changed what it measures: the window of every admission is
now the one its granting statement counted it in (returned by the database
for atomic_update and reserve_commit, written by the request for
cache_get_set; svc/app.py), not the instant of the later provider call, and
the evaluation is done by study/policy.py on the event log, which is kept.

The test starts the service with a short window, waits until the next aligned
boundary is `lead` seconds away, releases k/2 requests then and k/2 requests
50 ms after the boundary, and records for every trial the complete per-request
events plus: admissions per window id, the largest count in any window, and
whether the raw total exceeded the limit.

    python3 study/boundary_test.py --out results/r4/boundary_test.csv
"""
import argparse
import csv
import json
import os
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from study import run_experiments as RC  # noqa: E402
from study import policy as P  # noqa: E402
import httpx  # noqa: E402

RES = []


def wait_for_boundary(window_s, lead):
    """Sleep until the next window boundary is `lead` seconds away."""
    while True:
        now = time.time()
        remaining = window_s - (now % window_s)
        if lead - 0.02 <= remaining <= lead + 0.02:
            return now
        if remaining > lead:
            time.sleep(min(remaining - lead, 0.05))
        else:
            time.sleep(remaining)          # just missed it; catch the next one


def straddling_burst(phone, k, window_s, lead):
    """Release k/2 requests `lead` s before the next boundary and k/2 50 ms after."""
    t_rel = wait_for_boundary(window_s, lead)
    boundary = (int(t_rel // window_s) + 1) * window_s
    first = threading.Thread(target=lambda: RES.append(RC.burst(phone, k // 2)))
    first.start()
    while time.time() < boundary + 0.05:
        time.sleep(0.005)
    second = RC.burst(phone, k - k // 2)
    first.join()
    return t_rel, boundary, RES.pop() + second


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strategies", nargs="+",
                    default=["atomic_update", "reserve_commit", "cache_get_set",
                             "immediate_txn", "naive_count", "after_send"])
    ap.add_argument("--k", type=int, default=16)
    ap.add_argument("--limit", type=int, default=5)
    ap.add_argument("--window-s", type=int, default=4)
    ap.add_argument("--lead", type=float, default=1.0)
    ap.add_argument("--trials", type=int, default=30)
    ap.add_argument("--backend", default="sqlite", choices=["sqlite", "postgres"])
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    events_path = os.path.splitext(args.out)[0] + ".events.jsonl"
    ef = open(events_path, "w")

    rows = []
    for strategy in args.strategies:
        print(f"[{time.strftime('%H:%M:%S')}] {strategy} window={args.window_s}s "
              f"limit={args.limit} k={args.k} lead={args.lead}s", flush=True)
        p = RC.start_server(strategy, args.limit, 50.0, args.backend, 4,
                            window_s=args.window_s)
        try:
            for trial in range(args.trials):
                phone = f"+1{9_000_000_000 + hash((strategy, trial)) % 10**8:010d}"
                httpx.post(f"{RC.BASE}/admin/reset", timeout=60.0)
                t_release, boundary, replies = straddling_burst(
                    phone, args.k, args.window_s, args.lead)
                evs, lim, win, pol = RC.events_for(phone)
                ev = P.evaluate(evs, lim, win, pol)
                admits = [e for e in evs if e["decision"] == "admit"]
                # admissions before and after the boundary, by the admission
                # event's own window id (fixed) or admission timestamp (sliding)
                if pol == "fixed":
                    before = sum(1 for e in admits if e["window_id"] < boundary)
                else:
                    before = sum(1 for e in admits if e["policy_ts"] < boundary)
                meta = dict(arm="boundary_test", backend=args.backend, strategy=strategy,
                            policy=pol, trial=trial, k=args.k, limit=lim, window_s=win,
                            boundary=boundary, phone=phone)
                for e in evs:
                    ef.write(json.dumps({**meta, **e}) + "\n")
                ef.flush()
                rows.append(dict(
                    strategy=strategy, policy=pol, trial=trial, k=args.k, limit=lim,
                    window_s=win, boundary_utc=boundary,
                    released_before_boundary_s=round(boundary - t_release, 3),
                    requests_logged=ev["requests"], admits=ev["admits"],
                    provider_calls=ev["provider_calls"],
                    admits_equal_provider_calls=ev["admits_equal_provider_calls"],
                    admits_before_boundary=before,
                    admits_after_boundary=len(admits) - before,
                    windows_touched=ev["windows_touched"],
                    max_in_window=ev["max_per_policy"],
                    per_window=json.dumps(ev["per_window"]),
                    total_exceeds_limit=int(len(admits) > lim),
                    policy_violated=int(ev["policy_overrun"] > 0),
                    errors=sum(1 for r in replies if str(r).startswith("error"))))
            sel = [r for r in rows if r["strategy"] == strategy]
            print(f"   trials={len(sel)} straddled={sum(1 for r in sel if r['windows_touched'] > 1)} "
                  f"total>limit={sum(r['total_exceeds_limit'] for r in sel)} "
                  f"policy_violated={sum(r['policy_violated'] for r in sel)} "
                  f"max_in_window={max(r['max_in_window'] for r in sel)}", flush=True)
        finally:
            RC.stop_server(p)
    ef.close()
    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {len(rows)} rows to {args.out} and events to {events_path}")


if __name__ == "__main__":
    main()
