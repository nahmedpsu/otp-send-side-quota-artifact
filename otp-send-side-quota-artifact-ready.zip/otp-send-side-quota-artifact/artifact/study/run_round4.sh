#!/usr/bin/env bash
# Round-4 arms: every arm the paper reports, re-run with the per-request event
# log (svc/app.py, svc/app_pg.py) so that every policy classification can be
# derived from preserved admission events. Outputs go to results/r4/. Each arm
# writes <name>.csv (trial summaries) and <name>.events.jsonl (one record per
# request), and prints the UTC start of every server so that wall-clock
# boundaries of the 3600 s window can be located afterwards.
set -u
cd "$(dirname "$0")/.."
R=results/r4
mkdir -p "$R"
export EXP_PORT=8240
export EXP_DB=/tmp/otp_r4.db

run () {  # name, then harness arguments
  local name=$1; shift
  echo "=== $name  ($(date -u +%FT%TZ)) ==="
  python3 study/run_experiments.py --arm "$name" --out "$R/$name.csv" "$@" > "$R/$name.log" 2>&1
  echo "exit=$?"
}

run main_sqlite   --backend sqlite   --concurrency 1 2 4 8 16 32 --trials 30 --randomize
run main_postgres --backend postgres --concurrency 1 2 4 8 16 32 --trials 30 --randomize
run sequential    --backend sqlite   --concurrency 8 16 32 --trials 10 --mode sequential --randomize
run latency       --backend sqlite   --concurrency 8 --provider-ms 0 10 50 200 --trials 30 --randomize
run workers       --backend sqlite   --concurrency 8 32 --workers 1 2 8 --trials 20 --randomize
run limits        --backend sqlite   --concurrency 16 --limit 1 5 10 --trials 20 --randomize
OTP_PG_POOL=8 run postgres_pooled --backend postgres --concurrency 8 32 --trials 30 --randomize

echo "=== boundary_sqlite  ($(date -u +%FT%TZ)) ==="
python3 study/boundary_test.py --backend sqlite --trials 30 --out "$R/boundary_sqlite.csv" > "$R/boundary_sqlite.log" 2>&1
echo "exit=$?"
echo "=== boundary_postgres  ($(date -u +%FT%TZ)) ==="
python3 study/boundary_test.py --backend postgres --trials 30 --out "$R/boundary_postgres.csv" > "$R/boundary_postgres.log" 2>&1
echo "exit=$?"
echo "ROUND4_DONE $(date -u +%FT%TZ)"
