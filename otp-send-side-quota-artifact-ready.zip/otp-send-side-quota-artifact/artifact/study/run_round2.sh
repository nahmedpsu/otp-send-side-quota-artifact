#!/usr/bin/env bash
# Round-2 experiments, added in response to review.
# Run sequentially on an otherwise idle machine so that timing measurements are
# not contaminated by concurrent work.
set -u
cd "$(dirname "$0")/.."
R=results/r2
mkdir -p "$R"
export EXP_PORT=8205
S="naive_count cache_get_set after_send atomic_update immediate_txn reserve_commit"

echo "=== 1/7 PostgreSQL main sweep (connection per request) ==="
python3 study/run_experiments.py --backend postgres --strategies $S \
  --concurrency 1 2 4 8 16 32 --trials 30 --provider-ms 50 --limit 3 \
  --workers 4 --randomize --out "$R/pg_main.csv" > "$R/pg_main.log" 2>&1
echo "exit=$?"

echo "=== 2/7 PostgreSQL with a connection pool ==="
OTP_PG_POOL=8 python3 study/run_experiments.py --backend postgres --strategies $S \
  --concurrency 8 32 --trials 20 --provider-ms 50 --limit 3 --workers 4 \
  --randomize --out "$R/pg_pool.csv" > "$R/pg_pool.log" 2>&1
echo "exit=$?"

echo "=== 3/7 SQLite main sweep, randomised order (independence check) ==="
EXP_DB=/tmp/otp_r2a.db python3 study/run_experiments.py --backend sqlite --strategies $S \
  --concurrency 1 2 4 8 16 32 --trials 30 --provider-ms 50 --limit 3 \
  --workers 4 --randomize --out "$R/sqlite_main_rand.csv" > "$R/sqlite_main_rand.log" 2>&1
echo "exit=$?"

echo "=== 4/7 worker-count sensitivity ==="
EXP_DB=/tmp/otp_r2b.db python3 study/run_experiments.py --backend sqlite --strategies $S \
  --concurrency 8 32 --trials 20 --provider-ms 50 --limit 3 --workers 1 2 8 \
  --randomize --out "$R/workers.csv" > "$R/workers.log" 2>&1
echo "exit=$?"

echo "=== 5/7 declared-limit sensitivity ==="
EXP_DB=/tmp/otp_r2c.db python3 study/run_experiments.py --backend sqlite --strategies $S \
  --concurrency 16 --trials 20 --provider-ms 50 --limit 1 5 10 --workers 4 \
  --randomize --out "$R/limits.csv" > "$R/limits.log" 2>&1
echo "exit=$?"

echo "=== 6/7 latency arm, the two patterns previously omitted ==="
EXP_DB=/tmp/otp_r2d.db python3 study/run_experiments.py --backend sqlite \
  --strategies immediate_txn reserve_commit --concurrency 8 --trials 30 \
  --provider-ms 0 10 50 200 --limit 3 --workers 4 --randomize \
  --out "$R/latency_rest.csv" > "$R/latency_rest.log" 2>&1
echo "exit=$?"

echo "=== 7/7 instrumented runs: the race window, measured ==="
EXP_DB=/tmp/otp_r2e.db python3 study/run_experiments.py --backend sqlite \
  --strategies naive_count cache_get_set atomic_update --concurrency 8 --trials 30 \
  --provider-ms 50 --limit 3 --workers 4 --timing \
  --out "$R/timing_sqlite.csv" --timing-out "$R/timing_sqlite.json" \
  > "$R/timing_sqlite.log" 2>&1
echo "exit=$?"
python3 study/run_experiments.py --backend postgres \
  --strategies naive_count cache_get_set atomic_update --concurrency 8 --trials 30 \
  --provider-ms 50 --limit 3 --workers 4 --timing \
  --out "$R/timing_pg.csv" --timing-out "$R/timing_pg.json" \
  > "$R/timing_pg.log" 2>&1
echo "exit=$?"

echo "ROUND2_DONE"
