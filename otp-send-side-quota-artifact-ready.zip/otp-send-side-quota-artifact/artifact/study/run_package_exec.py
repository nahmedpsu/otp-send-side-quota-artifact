"""
Execute a real surveyed package under the concurrency harness.

Added in response to review. The reviewer's decisive question was whether the
measured behaviour characterises any surveyed package or only author-written
fixtures. This script answers it for django-otp 1.7.3, whose e-mail device is
the clearest instance in the population of the two-step shape: its
`generate_challenge` reads the cooldown through `generate_is_allowed()` and
`_deliver_token` writes it back with `cooldown_set()`, as two separate
statements with no transaction and no lock around the pair.

The same package locks rows with `select_for_update()` on the verification
path (`django_otp/__init__.py`, `devices_for_user(..., for_verify=True)`), so
the mechanism that would close this window exists in the package and is applied
to the other operation.

Safety: nothing is sent. The Django e-mail backend used here is a local
counter; no SMTP connection is opened, no address is contacted, and the only
"recipient" is a local test account. We count deliveries the package attempted,
which is the quantity that would have been billed.

Usage:
    python3 study/run_package_exec.py --k 8 --trials 30 --out results/r2/pkg_exec.csv
"""
import argparse
import csv
import json
import os
import sys
import threading
import time

import django
from django.conf import settings

def configure(db_path):
    if settings.configured:
        return
    settings.configure(
        DEBUG=False,
        SECRET_KEY="harness-only-not-a-real-key",
        DATABASES={"default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": db_path,
            "OPTIONS": {"timeout": 30},
        }},
        INSTALLED_APPS=[
            "django.contrib.contenttypes",
            "django.contrib.auth",
            "django_otp",
            "django_otp.plugins.otp_email",
        ],
        USE_TZ=True,
        EMAIL_BACKEND="study.mailcount.CountingEmailBackend",
        TEMPLATES=[{"BACKEND": "django.template.backends.django.DjangoTemplates",
                    "DIRS": [], "APP_DIRS": True, "OPTIONS": {}}],
        # A literal body template, so the harness needs no template files of its
        # own. This is the package's own documented setting and does not touch
        # the cooldown logic under test.
        OTP_EMAIL_BODY_TEMPLATE="Your code is {{ token }}.",
        OTP_EMAIL_COOLDOWN_DURATION=3600,
        OTP_EMAIL_TOKEN_VALIDITY=300,
        OTP_EMAIL_THROTTLE_FACTOR=1,
        PASSWORD_HASHERS=["django.contrib.auth.hashers.MD5PasswordHasher"],
    )
    django.setup()


def migrate():
    from django.core.management import call_command
    call_command("migrate", run_syncdb=True, verbosity=0, interactive=False)


def make_device(i):
    from django.contrib.auth.models import User
    from django_otp.plugins.otp_email.models import EmailDevice
    u, _ = User.objects.get_or_create(
        username=f"subject{i}", defaults={"email": f"subject{i}@harness.invalid"})
    u.email = f"subject{i}@harness.invalid"
    u.save()
    EmailDevice.objects.filter(user=u).delete()
    return EmailDevice.objects.create(user=u, name="default", confirmed=True)


def _call(device_pk, ev):
    """Load the device and call generate_challenge, recording the events.

    The policy event for this package is the in-memory cooldown check inside
    generate_challenge: it reads last_generated_timestamp from the instance
    that was loaded a moment earlier. The event record keeps the load instant,
    the timestamp the loaded instance carried (None means the cooldown was
    clear), the return instant, and the thread id so that the mail backend's
    per-call records can be joined to it.
    """
    from django_otp.plugins.otp_email.models import EmailDevice
    ev["thread"] = threading.get_ident()
    ev["t_load_start"] = time.time()
    d = EmailDevice.objects.get(pk=device_pk)
    ev["t_load_end"] = time.time()
    ev["observed_last_generated"] = (d.last_generated_timestamp.timestamp()
                                     if d.last_generated_timestamp else None)
    ev["t_call_start"] = time.time()
    msg = d.generate_challenge()
    ev["t_call_end"] = time.time()
    ev["message"] = str(msg)[:60]
    ev["decision"] = "admit" if str(msg) == "sent by email" else "refuse"
    return d


def burst(device_pk, k):
    """Release k calls to the real generate_challenge at the same instant.
    Returns (errors, events)."""
    from django.db import connections
    gate = threading.Barrier(k)
    errors, events = [], []

    def worker(i):
        ev = {"call": i}
        gate.wait()
        ev["t_release"] = time.time()
        try:
            _call(device_pk, ev)
        except Exception as e:
            errors.append(type(e).__name__)
            ev["error"] = type(e).__name__
            ev["decision"] = "error"
        finally:
            connections.close_all()
            events.append(ev)

    ts = [threading.Thread(target=worker, args=(i,)) for i in range(k)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    return errors, events


def sequential(device_pk, k):
    errors, events = [], []
    for i in range(k):
        ev = {"call": i, "t_release": time.time()}
        try:
            _call(device_pk, ev)
        except Exception as e:
            errors.append(type(e).__name__)
            ev["error"] = type(e).__name__
            ev["decision"] = "error"
        events.append(ev)
    return errors, events


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--k", nargs="+", type=int, default=[1, 2, 4, 8, 16, 32])
    ap.add_argument("--trials", type=int, default=30)
    ap.add_argument("--db", default="/tmp/otp_pkgexec.sqlite3")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    for f in (args.db, args.db + "-wal", args.db + "-shm"):
        try:
            os.remove(f)
        except FileNotFoundError:
            pass
    configure(args.db)
    migrate()
    from study import mailcount as _mc
    globals()["mailcount"] = _mc

    import django_otp
    from importlib.metadata import version as pkgversion
    ver = pkgversion("django-otp")
    print(f"django {django.get_version()}, django-otp {ver}")
    print("declared policy: one token per cooldown window "
          f"({settings.OTP_EMAIL_COOLDOWN_DURATION}s), i.e. a limit of 1\n")

    rows = []
    n = 0
    events_path = os.path.splitext(args.out)[0] + ".events.jsonl"
    ef = open(events_path, "w")
    for mode in ("concurrent", "sequential"):
        for k in args.k:
            for trial in range(args.trials):
                n += 1
                dev = make_device(n)
                mailcount.reset()
                errs, evs = (burst(dev.pk, k) if mode == "concurrent"
                             else sequential(dev.pk, k))
                sent = mailcount.sends()
                delivered = len(sent)
                # attribute each send_mail call to the generate_challenge call
                # on the same thread whose call interval contains its instant
                for ev in evs:
                    mine = [t_send for t_send, to, tid in sent
                            if tid == ev.get("thread")
                            and ev.get("t_call_start", 1e18) <= t_send <= ev.get("t_call_end", -1)]
                    ev.update(package="django-otp", version=ver, mode=mode,
                              concurrency=k, trial=trial, declared_limit=1,
                              cooldown_s=settings.OTP_EMAIL_COOLDOWN_DURATION,
                              t_send_mail=mine)
                    ef.write(json.dumps(ev) + "\n")
                assert sum(len(ev["t_send_mail"]) for ev in evs) == delivered, \
                    "every recorded delivery must be attributed to exactly one call"
                ef.flush()
                admits = sum(1 for e in evs if e.get("decision") == "admit")
                rows.append(dict(package="django-otp", version=ver,
                                 mode=mode, concurrency=k, trial=trial,
                                 declared_limit=1, deliveries=delivered,
                                 admits=admits, calls_logged=len(evs),
                                 admits_equal_deliveries=int(admits == delivered),
                                 errors=len(errs),
                                 error_types=";".join(sorted(set(errs)))))
            got = [r["deliveries"] for r in rows
                   if r["mode"] == mode and r["concurrency"] == k]
            print(f"  {mode:<11} k={k:>3}  deliveries {sorted(got)}", flush=True)

    ef.close()
    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"\nwrote {len(rows)} rows to {args.out} and events to {events_path}")


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    main()
