#!/usr/bin/env bash
# Second round-4 driver: waits for run_round4.sh to finish, then executes the
# surveyed package with per-call event records.
set -u
cd "$(dirname "$0")/.."
R=results/r4
while ! grep -q ROUND4_DONE "$R/driver4.log" 2>/dev/null; do sleep 30; done
echo "=== package_exec  ($(date -u +%FT%TZ)) ==="
python3 study/run_package_exec.py --k 1 2 4 8 16 32 --trials 30 --db /tmp/otp_pkgexec_r4.sqlite3 \
  --out "$R/pkg_exec.csv" > "$R/pkg_exec.log" 2>&1
echo "exit=$?"
echo "ROUND4B_DONE $(date -u +%FT%TZ)"
