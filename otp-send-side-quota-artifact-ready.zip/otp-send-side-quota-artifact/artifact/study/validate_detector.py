"""
Validate the code-delivery-site detector against a hand-labelled random sample.

Added in response to review (finding M5). The detector in study/survey_scope2.py
decides which downloaded packages reach manual adjudication. Its precision is
already known exactly, because every one of the 61 packages it flagged was read
by hand: 42 were kept and 19 rejected. What was missing is its recall, which
requires labelling packages the detector did *not* flag.

This script draws a reproducible random sample from the packages the detector
rejected, extracts for each the functions that plausibly deliver something, and
writes an adjudication sheet. The sheet is then filled in by hand and the
resulting labels are what the paper reports. The script does not assign labels
itself.

    python3 study/validate_detector.py --sample 60 --seed 20260922
"""
import argparse
import ast
import json
import os
import random
import re

_ROOT = os.environ.get("OTP_ROOT",
                       os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SRC = _ROOT + "/pkgs/src"

VENDORED = re.compile(
    r"(^|/)(site-packages|vendor|vendored|_vendor|third_party|node_modules)(/|$)")
TESTPATH = re.compile(r"(^|/)(tests?|testing)(/|$)|(^|/)test_[^/]*\.py$|_test\.py$", re.I)
OUTBOUND = re.compile(
    r"\b(twilio|messagebird|nexmo|vonage|plivo|sinch|infobip|msg91|kavenegar|"
    r"ghasedak|textlocal|clickatell|smtplib|send_mail|EmailMessage|"
    r"EmailMultiAlternatives|requests\.(post|get)|httpx\.(post|get)|"
    r"aiohttp|urlopen|boto3)\b", re.I)
CODEISH = re.compile(r"\b(otp|token|code|secret|pin|challenge|passcode|verif)\w*",
                     re.I)


def own_py(root):
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in {".git", "__pycache__"}]
        for f in fn:
            if not f.endswith(".py"):
                continue
            rel = os.path.relpath(os.path.join(dp, f), root).replace(os.sep, "/")
            if VENDORED.search(rel) or TESTPATH.search(rel) or rel.endswith("setup.py"):
                continue
            yield rel, os.path.join(dp, f)


def candidates(root, limit=4):
    """Functions worth a human look: they call out, or they mention a code."""
    found = []
    for rel, path in own_py(root):
        try:
            text = open(path, encoding="utf-8", errors="replace").read()
        except OSError:
            continue
        if not OUTBOUND.search(text):
            continue
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue
        lines = text.splitlines()
        for n in ast.walk(tree):
            if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            lo = n.lineno - 1
            hi = getattr(n, "end_lineno", n.lineno) or n.lineno
            body = "\n".join(lines[lo:hi])
            if OUTBOUND.search(body):
                found.append(dict(file=rel, function=n.name, lines=f"{n.lineno}-{hi}",
                                  mentions_code=bool(CODEISH.search(body)),
                                  excerpt="\n".join(body.splitlines()[:16])[:900]))
            if len(found) >= limit:
                return found
    return found


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample", type=int, default=60)
    ap.add_argument("--seed", type=int, default=20260922)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    fetched = [x["name"] for x in
               json.load(open(f"{_ROOT}/results/survey_fetch_log.json")) if x.get("ok")]
    flagged = {r["package"] for r in
               __import__("csv").DictReader(open(f"{_ROOT}/results/survey_final.csv"))}
    rejected = sorted(n for n in fetched if n not in flagged)

    rng = random.Random(args.seed)
    sample = rng.sample(rejected, min(args.sample, len(rejected)))

    sheet = []
    for name in sorted(sample):
        root = os.path.join(SRC, name)
        cands = candidates(root) if os.path.isdir(root) else []
        sheet.append(dict(package=name, n_outbound_functions=len(cands),
                          candidates=cands, label="", reason=""))

    out = args.out or f"{_ROOT}/results/r2/detector_sample.json"
    json.dump(dict(seed=args.seed, population_rejected=len(rejected),
                   sampled=len(sample), rows=sheet), open(out, "w"), indent=1)
    n_with = sum(1 for r in sheet if r["n_outbound_functions"])
    print(f"detector rejected {len(rejected)} of {len(fetched)} downloaded packages")
    print(f"sampled {len(sample)} of them with seed {args.seed}")
    print(f"{n_with} of the sample contain at least one outbound-call function "
          f"and need a human verdict")
    print(f"wrote the adjudication sheet to {out}")


if __name__ == "__main__":
    main()
