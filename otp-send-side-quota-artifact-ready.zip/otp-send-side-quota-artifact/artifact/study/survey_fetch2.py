"""
Faster fetch: ask the index for each project's file list and pull one
distribution directly, in parallel. Source distributions are preferred; wheels
are accepted because they still carry the Python source we read.
"""
import os as _os
_ROOT = _os.environ.get("OTP_ROOT",
    _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import io
import json
import os
import tarfile
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

EX = _ROOT + "/pkgs/src"
os.makedirs(EX, exist_ok=True)


def pick(files):
    sd = [f for f in files if f.get("packagetype") == "sdist"]
    wh = [f for f in files if f.get("packagetype") == "bdist_wheel"]
    for group in (sd, wh):
        for f in group:
            if f.get("url", "").endswith((".tar.gz", ".tgz", ".whl", ".zip")):
                return f
    return None


def one(rec):
    name = rec["name"]
    dest = os.path.join(EX, name)
    if os.path.isdir(dest):
        return name, True, "cached"
    try:
        m = requests.get(f"https://pypi.org/pypi/{name}/json", timeout=30)
        if m.status_code != 200:
            return name, False, f"meta{m.status_code}"
        data = m.json()
        ver = data["info"]["version"]
        f = pick(data["releases"].get(ver, []) or data.get("urls", []))
        if not f:
            return name, False, "no_dist"
        blob = requests.get(f["url"], timeout=120).content
        buf = io.BytesIO(blob)
        if f["url"].endswith((".tar.gz", ".tgz")):
            with tarfile.open(fileobj=buf) as t:
                t.extractall(dest, filter="data")
        else:
            with zipfile.ZipFile(buf) as z:
                z.extractall(dest)
        return name, True, f["packagetype"] + "|" + ver
    except Exception as e:
        return name, False, type(e).__name__


def main():
    cands = json.load(open("results/survey_candidates.json"))["kept"]
    log = []
    with ThreadPoolExecutor(max_workers=16) as ex:
        futs = {ex.submit(one, r): r["name"] for r in cands}
        for i, fut in enumerate(as_completed(futs), 1):
            name, ok, kind = fut.result()
            log.append(dict(name=name, ok=ok, kind=kind))
            if i % 100 == 0:
                print(f"  {i}/{len(cands)} ok={sum(1 for x in log if x['ok'])}",
                      flush=True)
    with open("results/survey_fetch_log.json", "w") as f:
        json.dump(log, f, indent=2)
    print(f"extracted {sum(1 for x in log if x['ok'])}/{len(log)}")


if __name__ == "__main__":
    main()
