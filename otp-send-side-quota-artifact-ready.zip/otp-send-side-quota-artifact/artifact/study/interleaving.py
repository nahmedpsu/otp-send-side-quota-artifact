"""
Per-trial interleaving evidence from the instrumented arms.

Added in response to the round-3 review, which asked that three things be
kept separate: the correctness argument for atomic admission, measurements of
operation duration, and evidence that particular request interleavings caused
particular overruns. This script produces the third.

For every instrumented trial of a two-step implementation it reconstructs the
interleaving from the server-side instants and tests the mechanism the paper
claims: an overrun consists of requests that read the quota state before the
L-th admitted request had written it back. Concretely, with T_L the write
instant of the L-th admitted request in write order,

  excess admission   an admitted request beyond the first L; the claim is that
                     its read instant precedes T_L and it observed used < L
  late rejection     a rejected request; the claim is that its read instant
                     follows T_L (allowing for commit visibility)

It also reports, per trial, the interval from first arrival to T_L against the
arrival spread of the burst, which is what decides how much of a burst is
admitted, and it is the quantity the round-2 text guessed at without measuring.

    python3 study/interleaving.py results/r2/timing_sqlite.json \
        results/r3/timing_sqlite_k.json results/r2/timing_pg.json \
        results/r3/timing_pg_pooled.json --out results/r3/interleaving.json
"""
import argparse
import json
import statistics as st
from collections import defaultdict


def analyse(path):
    d = json.load(open(path))
    trials = defaultdict(list)
    for r in d:
        trials[(r["strategy"], int(r["concurrency"]), int(r["trial"]))].append(r)
    out = {}
    for (s, k, t), rs in sorted(trials.items()):
        L = int(rs[0]["limit"])
        adm = sorted([r for r in rs if r["allowed"]], key=lambda r: r["t_write"])
        rej = [r for r in rs if not r["allowed"]]
        first = min(r["t_recv"] for r in rs)
        spread = (max(r["t_recv"] for r in rs) - first) * 1000
        rspread = (max(r["t_read"] for r in rs) - min(r["t_read"] for r in rs)) * 1000
        rec = dict(strategy=s, k=k, trial=t, requests=len(rs), admitted=len(adm),
                   rejected=len(rej), limit=L, arrival_spread_ms=round(spread, 2),
                   read_spread_ms=round(rspread, 2))
        if len(adm) >= L:
            T_L = adm[L - 1]["t_write"]
            rec["first_arrival_to_Lth_write_ms"] = round((T_L - first) * 1000, 2)
            excess = adm[L:]
            rec["excess"] = len(excess)
            rec["excess_read_before_Lth_write"] = sum(1 for r in excess if r["t_read"] < T_L)
            rec["excess_observed_below_limit"] = sum(1 for r in excess if r["observed_used"] < L)
            rec["rejected_read_after_Lth_write"] = sum(1 for r in rej if r["t_read"] >= T_L)
            rec["rejected_issued_before_Lth_write"] = sum(1 for r in rej if r["t_read"] < T_L)
            rec["requests_read_before_Lth_write"] = sum(1 for r in rs if r["t_read"] < T_L)
            rec["admitted_minus_reads_before_Lth_write"] = (
                len(adm) - rec["requests_read_before_Lth_write"])
        if s == "cache_get_set" and adm:
            # The read-modify-write counter writes observed+1. A write whose
            # value does not exceed the largest value written so far discards
            # a concurrent increment: a lost update. The final stored value is
            # therefore below the number of admissions.
            running, lost = 0, 0
            for r in adm:
                val = r["observed_used"] + 1
                if val <= running:
                    lost += 1
                running = max(running, val)
            rec["lost_updates"] = lost
            rec["final_counter_value"] = adm[-1]["observed_used"] + 1
            rec["counter_deficit"] = len(adm) - rec["final_counter_value"]
        out[f"{s}|k={k}|t={t}"] = rec
    return out


def summarise(per_trial):
    agg = defaultdict(lambda: defaultdict(int))
    spans = defaultdict(list)
    for rec in per_trial.values():
        key = f"{rec['strategy']}|k={rec['k']}"
        a = agg[key]
        a["trials"] += 1
        a["overrun_trials"] += int(rec["admitted"] > rec["limit"])
        a["excess_admissions"] += rec.get("excess", 0)
        a["excess_read_before_Lth_write"] += rec.get("excess_read_before_Lth_write", 0)
        a["excess_observed_below_limit"] += rec.get("excess_observed_below_limit", 0)
        a["rejected"] += rec["rejected"]
        a["rejected_read_after_Lth_write"] += rec.get("rejected_read_after_Lth_write", 0)
        a["rejected_issued_before_Lth_write"] += rec.get("rejected_issued_before_Lth_write", 0)
        if "lost_updates" in rec:
            a["lost_updates"] += rec["lost_updates"]
            a["trials_with_lost_update"] += int(rec["lost_updates"] > 0)
            a["counter_deficit_total"] += rec["counter_deficit"]
        if "requests_read_before_Lth_write" in rec:
            a["trials_admitted_equals_reads_before_Lth_write"] += int(
                rec["requests_read_before_Lth_write"] == rec["admitted"])
            a["trials_admitted_within_1_of_reads_before_Lth_write"] += int(
                abs(rec["admitted_minus_reads_before_Lth_write"]) <= 1)
            spans[key].append((rec["first_arrival_to_Lth_write_ms"], rec["arrival_spread_ms"],
                               rec["admitted_minus_reads_before_Lth_write"],
                               rec["read_spread_ms"]))
    for key, v in spans.items():
        agg[key]["first_arrival_to_Lth_write_ms_median"] = round(st.median(x[0] for x in v), 2)
        agg[key]["arrival_spread_ms_median"] = round(st.median(x[1] for x in v), 2)
        agg[key]["admitted_minus_reads_before_Lth_write_median"] = st.median(x[2] for x in v)
        agg[key]["read_spread_ms_median"] = round(st.median(x[3] for x in v), 2)
    return {k: dict(v) for k, v in agg.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    result = {}
    for fn in args.files:
        per = analyse(fn)
        result[fn] = {"per_trial": per, "summary": summarise(per)}
        print(f"== {fn}")
        for key, v in result[fn]["summary"].items():
            print(f"  {key}: {v}")
    json.dump(result, open(args.out, "w"), indent=1)
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
