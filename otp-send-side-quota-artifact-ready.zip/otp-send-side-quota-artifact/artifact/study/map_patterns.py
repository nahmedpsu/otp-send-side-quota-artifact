"""
Map each surveyed package's send-side guard onto one of the six enforcement
shapes used in Study 2.

Added in response to review. The reviewer's decisive question was: which exact
package, version, file and construct instantiates each experimental pattern?
This script answers it mechanically, and its output is then read by hand; the
hand verdict, not the regular expression, is what the paper reports.

For every package in the study population it locates the guard evidence found
by study/survey_gate.py, pulls the enclosing function, and records:

  package, version, file, function, line span, the construct found, and the
  shape it implies.

Shapes, matching the six implementations in Section IV:
  none            no send-side guard at all
  count_insert    read state, compare, then write it (two statements)
  read_write      read a counter or cache value, add one, write it back
  after_send      the state is written only after the provider call returns
  atomic_update   one statement the datastore adjudicates (F(), incr, UPDATE..WHERE)
  txn_guarded     check and write inside one transaction or under a lock
  reserve         claim the allowance before the send, release it on failure
  delegated       the bound is applied by a framework throttle or a hosted service
"""
import ast
import json
import os
import re
import sys

_ROOT = os.environ.get("OTP_ROOT",
                       os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SRC = _ROOT + "/pkgs/src"

# Constructs, most specific first. Order matters: a select_for_update inside a
# transaction is transaction-guarded even though it also reads then writes.
CONSTRUCTS = [
    ("txn_guarded", re.compile(
        r"select_for_update\(|transaction\.atomic|BEGIN\s+IMMEDIATE|"
        r"pg_advisory|with\s+transaction|LOCK\s+TABLE|threading\.Lock\(\)|"
        r"filelock|Redlock", re.I)),
    ("atomic_update", re.compile(
        r"\bF\(\s*['\"][\w]+['\"]\s*\)\s*\+|cache\.incr\(|\.incr\(|"
        r"INCR\b|\bupdate\([^)]*F\(|get_or_create\([^)]*defaults", re.I)),
    ("delegated", re.compile(
        r"throttle_classes|ScopedRateThrottle|UserRateThrottle|AnonRateThrottle|"
        r"@ratelimit|django_ratelimit|limiter\.limit|slowapi|"
        r"ratelimit\(|RateLimiter", re.I)),
    ("read_write", re.compile(
        r"cache\.get\(|\.get\(.*\)\s*or\s*0|cache\.set\(|"
        r"session\[[^\]]+\]\s*=|redis\.(get|set)\(", re.I)),
    ("count_insert", re.compile(
        r"\.count\(\)|\.filter\([^)]*\)\.exists\(\)|COUNT\(\*\)|"
        r"timesince|last_sent|created_at\s*[<>]|cooldown|"
        r"datetime\.now\(\)\s*-|timezone\.now\(\)\s*-", re.I)),
]

RESERVE = re.compile(r"reserv|rollback|compensat|release_claim", re.I)
SENDCALL = re.compile(
    r"\b(twilio|messagebird|nexmo|vonage|plivo|sinch|infobip|msg91|kavenegar|"
    r"ghasedak|send_sms|send_mail|EmailMessage|requests\.post|httpx\.post|"
    r"client\.messages\.create)\b", re.I)


def own_py(root):
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in {".git", "__pycache__"}]
        for f in fn:
            if f.endswith(".py"):
                rel = os.path.relpath(os.path.join(dp, f), root).replace(os.sep, "/")
                if re.search(r"(^|/)(site-packages|vendor|vendored|_vendor|third_party)(/|$)", rel):
                    continue
                yield rel, os.path.join(dp, f)


def functions(text):
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    lines = text.splitlines()
    out = []
    for n in ast.walk(tree):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            lo = n.lineno - 1
            hi = getattr(n, "end_lineno", n.lineno) or n.lineno
            out.append((n.name, n.lineno, hi, "\n".join(lines[lo:hi])))
    return out


def classify(body):
    """Return (shape, matched_construct). after_send is positional, not lexical."""
    send = SENDCALL.search(body)
    for shape, rx in CONSTRUCTS:
        m = rx.search(body)
        if not m:
            continue
        if send and m.start() > send.end() and shape in ("count_insert", "read_write"):
            return "after_send", m.group(0)
        if RESERVE.search(body) and shape in ("atomic_update", "txn_guarded"):
            return "reserve", m.group(0)
        return shape, m.group(0)
    return "none", ""


def main():
    gate = json.load(open(f"{_ROOT}/results/survey_gate.json"))
    import csv
    pop = [r for r in csv.DictReader(open(f"{_ROOT}/results/survey_final.csv"))
           if r["in_population"] == "True"]
    out = []
    for r in pop:
        name, ver = r["package"], r["version"]
        root = os.path.join(SRC, name)
        if not os.path.isdir(root):
            out.append(dict(package=name, version=ver, shape="unavailable",
                            file="", function="", lines="", construct=""))
            continue
        best = None
        for rel, path in own_py(root):
            try:
                text = open(path, encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            for fname, lo, hi, body in functions(text):
                shape, construct = classify(body)
                if shape == "none":
                    continue
                has_send = bool(SENDCALL.search(body))
                rank = (2 if has_send else 1,
                        0 if shape in ("none",) else 1)
                if best is None or rank > best[0]:
                    best = (rank, dict(package=name, version=ver, shape=shape,
                                       file=rel, function=fname,
                                       lines=f"{lo}-{hi}", construct=construct,
                                       calls_provider=has_send))
        out.append(best[1] if best else
                   dict(package=name, version=ver, shape="none", file="",
                        function="", lines="", construct="", calls_provider=False))

    with open(f"{_ROOT}/results/r2/pattern_map.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["package", "version", "shape", "file",
                                          "function", "lines", "construct",
                                          "calls_provider"])
        w.writeheader()
        for r in out:
            r.setdefault("calls_provider", False)
            w.writerow(r)

    from collections import Counter
    c = Counter(r["shape"] for r in out)
    print("shape distribution over the population:")
    for k, v in c.most_common():
        print(f"  {k:<16}{v}")
    print(f"\nwrote {len(out)} rows to results/r2/pattern_map.csv")


if __name__ == "__main__":
    main()
