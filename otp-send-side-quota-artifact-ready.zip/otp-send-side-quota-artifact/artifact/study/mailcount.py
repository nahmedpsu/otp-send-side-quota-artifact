"""Shared delivery counter for the real-package harness.

Lives in its own module so that the Django e-mail backend and the harness
share one counter: when the harness runs as __main__, importing it again by
name would otherwise create a second, separate module object.

Nothing here sends anything. It records what a package asked to deliver.
"""
import threading
import time

from django.core.mail.backends.base import BaseEmailBackend

SENT = []
LOCK = threading.Lock()


def reset():
    with LOCK:
        SENT.clear()


def count():
    with LOCK:
        return len(SENT)


class CountingEmailBackend(BaseEmailBackend):
    """Records the delivery a package attempted. Opens no connection."""

    def send_messages(self, email_messages):
        with LOCK:
            for m in email_messages:
                SENT.append((time.time(), tuple(m.to), threading.get_ident()))
        return len(email_messages)


def sends():
    """Every recorded delivery attempt: (instant, recipients, thread id)."""
    with LOCK:
        return list(SENT)
