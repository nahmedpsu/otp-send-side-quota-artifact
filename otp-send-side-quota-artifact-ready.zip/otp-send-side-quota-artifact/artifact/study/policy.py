"""
The policy oracle, evaluated on admission events.

This is the one place the declared policy is checked. The harness, the
boundary test and regenerate.py all import it, so the number that reaches the
paper is computed by the same code from the same event records.

An event record is one request (see svc/app.py). Only records with
decision == "admit" are policy events. For a fixed-window implementation each
admission carries window_id, the window the granting update counted it in:
for the one-step implementations (atomic_update, reserve_commit) the
window_start the counter row held when the conditional UPDATE was applied,
returned by the database in that statement; for the read-modify-write
counter (cache_get_set) the window_start the request computed and wrote in
its upsert (window_source says which). The policy holds iff no window_id has
more than `limit` admissions. For a
sliding-window implementation each admission carries policy_ts, the admission
timestamp the implementation used in its own check; the policy holds iff no
admission has more than `limit` admissions (itself included) in the trailing
interval [policy_ts - window_s, policy_ts].

Provider-call instants are not used to assign windows. They are counted, so
that the number of provider calls can be checked against the number of
admissions, which is what the paper reports as recorded provider-call
attempts.
"""
from collections import Counter


def evaluate(events, limit, window_s, policy):
    admits = [e for e in events if e.get("decision") == "admit"]
    refused = [e for e in events if e.get("decision") == "refuse"]
    errors = [e for e in events if e.get("decision") not in ("admit", "refuse")]
    provider_calls = sum(1 for e in admits if e.get("message_id"))
    if policy == "fixed":
        per_window = Counter(e["window_id"] for e in admits)
        worst = max(per_window.values()) if per_window else 0
        windows = len(per_window)
        detail = {str(k): v for k, v in sorted(per_window.items())}
    elif policy == "sliding":
        ts = sorted(e["policy_ts"] for e in admits)
        worst, j = 0, 0
        for i, t in enumerate(ts):
            while ts[j] < t - window_s:
                j += 1
            worst = max(worst, i - j + 1)
        # the number of distinct aligned windows the admissions fall in, for
        # information only; the sliding policy does not use aligned windows
        windows = len({int(t // window_s) for t in ts})
        detail = {}
    else:
        raise ValueError(policy)
    return {
        "requests": len(events),
        "admits": len(admits),
        "refused": len(refused),
        "errors": len(errors),
        "provider_calls": provider_calls,
        "admits_equal_provider_calls": int(provider_calls == len(admits)),
        "windows_touched": windows,
        "max_per_policy": worst,
        "policy_overrun": max(0, worst - limit),
        "total_over_limit": max(0, len(admits) - limit),
        "per_window": detail,
        "first_admit_ts": (min(e["policy_ts"] for e in admits) if admits else None),
        "last_admit_ts": (max(e["policy_ts"] for e in admits) if admits else None),
    }
