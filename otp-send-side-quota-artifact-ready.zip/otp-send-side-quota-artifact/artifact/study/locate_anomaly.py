"""
Locate the round-2 anomalous trial in wall-clock time.

The round-2 limit sweep (results/r2/limits.csv) recorded one trial of the
conditional atomic update, declared limit 5, k = 16, with six provider calls.
That arm ran with --randomize under seed 20260922, so the order in which its
20 trials executed is not the trial index. This script replays the harness's
random number consumption exactly (arm shuffle, then per-arm cell shuffle),
recovers the execution position of the anomalous trial, and sums the recorded
burst durations of the trials that ran before it. Together with the arm start
time printed in results/r2/limits.log, that places the trial in wall-clock
time to within the harness's unrecorded per-trial overhead.

    python3 study/locate_anomaly.py
"""
import csv
import itertools
import os
import random
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = os.path.join(ROOT, "results", "r2")
STRATEGIES = ["naive_count", "cache_get_set", "after_send",
              "atomic_update", "immediate_txn", "reserve_commit"]
SEED, LIMITS, K, TRIALS, WORKERS, PMS = 20260922, [1, 5, 10], 16, 20, 4, 50.0
WINDOW_S = 3600
ONE_STEP = ("atomic_update", "immediate_txn", "reserve_commit")


def main(verbose=True):
    rows = list(csv.DictReader(open(f"{R}/limits.csv")))
    log = open(f"{R}/limits.log").read()
    rng = random.Random(SEED)
    arms = list(itertools.product(STRATEGIES, [PMS], LIMITS, [WORKERS]))
    rng.shuffle(arms)

    # arm start times from the log, in the order they ran
    starts = re.findall(r"\[(\d\d):(\d\d):(\d\d)\] sqlite (\w+) ms=[\d.]+ limit=(\d+)", log)
    logged = [(f"{h}:{m}:{s}", strat, int(lim)) for h, m, s, strat, lim in starts]
    assert [(a[0], a[2]) for a in arms] == [(x[1], x[2]) for x in logged], \
        "replayed arm order does not match the log"

    out = {}
    for a, (t0, _, _) in zip(arms, logged):
        cells = [(k, t) for k in [K] for t in range(TRIALS)]
        rng.shuffle(cells)
        sel = {int(r["trial"]): r for r in rows
               if r["strategy"] == a[0] and int(r["limit"]) == a[2]}
        if a[0] not in ONE_STEP:
            continue
        anomalous = [t for t, r in sel.items() if int(r["provider_sends"]) > a[2]]
        for t in anomalous:
            order = [tt for _, tt in cells]
            pos = order.index(t)
            before = sum(float(sel[tt]["elapsed_s"]) for tt in order[:pos])
            h, m, s = (int(x) for x in t0.split(":"))
            arm_start = h * 3600 + m * 60 + s
            burst = float(sel[t]["elapsed_s"])
            # server start-up and per-trial overhead are not recorded; bound them
            # from the arm's total wall-clock span in the log
            total_measured = sum(float(r["elapsed_s"]) for r in sel.values())
            out[f"{a[0]}|L={a[2]}|trial={t}"] = dict(
                strategy=a[0], limit=a[2], trial=t, provider_sends=int(sel[t]["provider_sends"]),
                execution_position=pos + 1, trials_in_arm=TRIALS,
                arm_start_utc=t0, measured_burst_seconds_before=round(before, 2),
                own_burst_seconds=burst, arm_total_measured_seconds=round(total_measured, 2),
                earliest_start_utc=hms(arm_start + before),
                latest_start_utc_if_overhead_3s=hms(arm_start + before + 3.0),
                next_window_boundary_utc=hms(((arm_start // WINDOW_S) + 1) * WINDOW_S),
                straddles_boundary_for_overhead_between_s=[
                    round(max(0.0, ((arm_start // WINDOW_S) + 1) * WINDOW_S - arm_start - before - burst), 2),
                    round(((arm_start // WINDOW_S) + 1) * WINDOW_S - arm_start - before, 2)])
    if verbose:
        for k, v in out.items():
            print(k)
            for kk, vv in v.items():
                print(f"   {kk}: {vv}")
    return out


def hms(sec):
    sec = sec % 86400
    return f"{int(sec // 3600):02d}:{int(sec % 3600 // 60):02d}:{sec % 60:05.2f}"


if __name__ == "__main__":
    main()
