# Send-side OTP quota enforcement: research artifact

Reproducibility materials for **Send-Side Quota Enforcement in One-Time-Password Software: A Package Survey and a Measurement Under Concurrency**, by Naveed Ahmad. This is a prepublication research artifact; the manuscript has not been represented here as an accepted or published IEEE Access article.

The study surveys OTP delivery packages and measures six quota-enforcement patterns under concurrent requests. It reports admissions against declared limits, not real SMS charges. Experiments use a local provider stub and do not contact a production OTP provider or send messages to recipients.

## Repository map

| Path | Contents |
| --- | --- |
| [`artifact/README.md`](artifact/README.md) | Full methodology, results, limitations, and reproduction instructions |
| [`artifact/notebooks/otp_quota_reproduction_executed.ipynb`](artifact/notebooks/otp_quota_reproduction_executed.ipynb) | Executed notebook and playbook |
| [`artifact/svc/`](artifact/svc/) | Versioned OTP service and archived source used for the reported runs |
| [`artifact/study/`](artifact/study/) | Experiment drivers, survey scripts, policy oracle, event analysis, and tests |
| [`artifact/results/`](artifact/results/) | Raw trial and request records, survey audit, and derived outputs |
| [`artifact/paper/`](artifact/paper/) | Manuscript source and preview PDF |
| [`artifact/review/`](artifact/review/) | Review trackers, rebuttals, and verification logs |

The `artifact/` directory preserves the supplied **v3.4-r6 snapshot** with its own `MANIFEST.sha256.json`. Run artifact commands from that directory so repository metadata above it does not affect verification.

## Quick verification

```bash
cd artifact
python3 study/manifest.py verify
python3 study/test_manifest.py
python3 regenerate.py
python3 study/manifest.py verify
```

The first check validates the supplied files. The second runs nine verifier tests. Regeneration recomputes the derived numbers from archived event records and the frozen package audit; the final check requires byte-identical derived outputs. Install the environment and run the complete suite using [`artifact/README.md`](artifact/README.md). A full rerun writes to `artifact/results/repro/` without overwriting the shipped trials.

The notebook reruns the SQLite main sweep and examines archived analyses. It does **not** independently rerun every arm or recollect the package survey. For the complete protocol, use `artifact/reproduce.sh` and the survey commands in the artifact README.

## Scope

The package survey is a sample of one language ecosystem; its end-to-end recall is unknown. The concurrency study uses one host, two datastores, local traffic, and a provider stub. It does not establish the exposure or bill of any deployed application. The review history and prepublication manuscript are included for auditability, not as evidence of journal acceptance.

The artifact identifies concurrency behavior in a named third-party package. Its responsible-disclosure section records that maintainers had **not** been notified as of 23 September 2026. Coordinate public disclosure of that finding with the maintainers. Do not direct tests at third-party systems without authorization.

## Citation and license

Cite this as a **research artifact, version v3.4-r6** until a final publication record exists; see [`CITATION.cff`](CITATION.cff). Code is MIT licensed under [`LICENSE`](LICENSE). Package metadata and third-party dependencies retain their respective licenses.
