# Round 18 tracker: Computers & Security, Reviewer 2 (Major Revision) on manuscript v5.0

Manuscript v5.1, artifact v5.1-r18, response letter `review/rebuttal_round18.pdf`.

| Review item | Action | Where |
|---|---|---|
| 1 Datastore clock vs authorization time (PG statement_timestamp fixed before lock wait) | τ defined as the datastore's reading under the serializing lock; service 2.2.1 (lock first, then the granting statement, both datastores; 2.2.0 archived and runnable); `study/clock_semantics.py` measures the datastores; new deterministic lock wait arm (6 designs × 2 datastores × 30 trials); oracle reports τ under issue and return bounds; time arm rerun for the db designs | Sec. 3.1, 4.1, 4.3, 5.9, 5.10 (new), App. A; `results/r7/lockwait_*`, `timing_*_db221.*`, `clock_semantics.json` |
| 2 Formal C2 attributed only | `C2tau` added and checked for every fault row | `AdmissionTimed.tla`, Table timed, Sec. 5.11 |
| 3 Sliding window endpoints | `CountFrom` and sliding properties closed `[t-W, t]`; every sliding design run redone; round 7 verdicts kept for fixed designs | `run_tlc_timed.py`, `results_timed_r7.json`, App. A |
| 4 Load ordering / interpretation / records | per request records; metrics recomputed; beyond-L reported as C1 violations; refused-below-L in arrival and completion order | Sec. 5.12, Table load, `load_*.requests.jsonl` |
| 5 Delivery evidence | per delivery records; counts derived from them with assertion against the harness count; all six packages rerun | Sec. 5.5, `packages_*.deliveries.jsonl` |
| 6 Independent coding | still pending (author's action); stated plainly in paper and letter | Sec. 4.2, 6.5 |
| 6.2 per worker | atomic per process counter (≤ K·L) distinguished from racy local dictionary (django-otp-auth, k of k) | Sec. 6.2 |
| Abstract/highlights sequential | narrowed to one at a time on one connection | abstract, highlights, conclusion |
| SMS subgroup | django-otp-auth channel SMS+hosted, fastapi-otp-auth email; corrections file applied on top of the frozen audit; subgroup 21 / 4 labeled | Sec. 5.1, Table survey, `audit_corrections.csv` |
| Family totals | fourth category: helper not wired (django-otp-admin) → 20+7+3+1 = 31 | Sec. 5.1 |
| Public artifact wording | "is public" | Sec. data availability, letter |
| Disclosure | status dated; author to notify | Sec. 5.5, 6.4 |
| Layout | Table 3 reset to fit; "Appendix Appendix B" fixed | |

Round 8 results in brief: lock wait arm: sampled clock designs attribute all 90 waiting grants to the old window and reach 6 grants with τ in one window (C1 by τ violated 30/30), 2.2.1 designs 0 on both datastores; the 2.2.1 time arm rows give the same verdicts as 2.2.0 (no wait inside the statement in that arm). Package rerun: django-mfa up to 25 (SQLite) / 27 (PG) against 3; django-otp 14 / 7 against 1; others unchanged in verdict. Load rerun: two step designs grant beyond L (e.g. increment after send 1/3/11 on SQLite, 24 on PG at 100/s), one step 0.

Incident: django_mfa on PostgreSQL failed on the first pass (tables left by the round 7 run); `pg_reset` now drops every table of the packages' apps; rerun at the end of the queue.
