# Round 19 tracker: Computers & Security, Reviewer 2 closure assessment (Major revision) on manuscript v5.1

Manuscript v5.2, artifact v5.2-r19, response letter `review/rebuttal_round19.pdf`.

| Review item | Action | Where |
|---|---|---|
| 1 Algorithm 2 shows the 2.2.0 procedure | `GrantOnDatastoreClock` rewritten to the 2.2.1/2.2.2 sequence: transaction + recipient lock (the wait point), row init with window 0, one granting UPDATE reading the clock inside, RETURNING (start, used, reading), commit, release under the same lock on the reserved row; 2.2.0 kept in the note as superseded comparison | `float_alg_onestep.tex`; Sec. 4.1; App. A mapping row (2.2.1, 2.2.2) |
| 2 Waiting requests vs granting statements | arm description and results name the instants (arrival, lock call return, statement issue, reading, commit); "waited" defined as arrival before release and statement return after it; record says in which call the wait fell and whether the clock reading precedes the release; arm rerun on 2.2.2 (360 trials), round 8 run archived under prefix `r8:` | Sec. 4.3 (vi), Sec. 5.10, Table lockwait; `lockwait_*_r9.*` |
| 3 Sequential conclusion | restricted to configurations with a declared send bound; django-two-factor-auth and django-otp-twilio stated as unbounded one at a time | Sec. 7, abstract, highlights |
| 4 Independent coding | still pending (author's action); consequence spelled out in threats; letter separates completed corrections from pending validation | Sec. 4.2, 6.5; letter "Status at a glance" |
| 5 Client errors under load | load arm rerun with one record per number from the server's datastore (provider calls recorded); errors reconciled (errors with send / without send); beyond-L reported client confirmed and server recorded; "does not change the column" sentence removed | Sec. 4.3, 5.12, Table load; `load_*.server.jsonl` |
| 6 Timing interval verdicts | `_tau_bounds`: exact may/must verdict over the issue to return intervals (fixed: exact assignment; sliding: exact upper, sufficient lower); definitive vs ambiguous reported per row; service 2.2.2 returns the clock reading (`tau_db`), time arm db rows and lock wait arm rerun, verdict by recorded instant beside interval verdict | Sec. 3.1, 5.9, 5.10, Tables timing and lockwait; `timing_*_db222.*`, `svc/CHANGELOG.md` |
| Abstract 25 vs 27 | overall maximum 27 (PostgreSQL) in abstract | abstract |
| "C2 holds" means attributed | two readings defined and named in Sec. 3.1 (in the attributed window / by τ); Sec. 5.11 names the time base in every verdict; "unqualified" sentence removed | Sec. 3.1, 5.11 |
| Conclusion guidance | authorization time rule added (clock read under the serializing lock, in the granting statement, never a pre wait reading) | Sec. 7 |
| Maintainer notification | still outstanding; dated October 11, 2026 | Sec. 5.5, 6.4 |
| Table 3 | no change needed | |

Round 9 in brief (service 2.2.2; see `results/paper_numbers.json`, key `r7`): lock wait arm 360 trials; time arm datastore clock rows 240 trials; load arm 36 runs with server side reconciliation. Superseded round 8 rows are archived (`lockwait_<b>.*` → prefix `r8:`; `timing_*_db221.*` → prefix `r8_db221:`; 2.2.0 rows → `r7_db220:`).
