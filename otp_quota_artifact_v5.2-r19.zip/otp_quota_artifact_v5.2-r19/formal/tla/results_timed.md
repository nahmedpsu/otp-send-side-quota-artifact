| group | design | N | L | T | K | faults | release rule | release scope | db clock | call delay D | property | verdict | distinct states | trace states |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 1063 | 10 |
| A | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 3470 | 10 |
| A | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | violated | 51225 | 14 |
| A | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 1071 | 9 |
| A | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 3631 | 9 |
| A | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | violated | 65409 | 13 |
| A | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 2717 | 11 |
| A | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 16128 | 11 |
| A | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 321225 | 17 |
| A | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 7239 |  |
| A | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | violated | 213101 | 16 |
| A | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 1116242 |  |
| A | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 7239 |  |
| A | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 416339 |  |
| A | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 1116242 |  |
| A | CountThenInsert | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 29 | 5 |
| A | CountThenInsert | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 856 | 9 |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 1174 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 4569 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | violated | 57064 |  |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 1117 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 3782 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | violated | 65360 |  |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 2971 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 12255 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 298172 |  |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 7967 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | violated | 220823 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 1174400 |  |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 7967 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 505061 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 1174400 |  |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 7967 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 505061 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 1174400 |  |
| A | ReadModifyWrite | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 37 |  |
| A | ReadModifyWrite | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 848 |  |
| A | IncrementAfterSend | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 316 | 7 |
| A | IncrementAfterSend | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 832 | 8 |
| A | IncrementAfterSend | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | violated | 10785 | 10 |
| A | IncrementAfterSend | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 467 | 7 |
| A | IncrementAfterSend | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 833 | 7 |
| A | IncrementAfterSend | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | violated | 11390 | 10 |
| A | IncrementAfterSend | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 1817 | 9 |
| A | IncrementAfterSend | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 4485 | 9 |
| A | IncrementAfterSend | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 128177 | 13 |
| A | IncrementAfterSend | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 25452 |  |
| A | IncrementAfterSend | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | violated | 125604 | 13 |
| A | IncrementAfterSend | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 5200019 |  |
| A | IncrementAfterSend | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 25452 |  |
| A | IncrementAfterSend | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 3063860 |  |
| A | IncrementAfterSend | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 5200019 |  |
| A | IncrementAfterSend | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 19 | 4 |
| A | IncrementAfterSend | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 581 | 7 |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 5670 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 212621 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | holds | 430298 |  |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 2001 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 10316 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | violated | 72605 |  |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 3750 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 34647 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 273914 |  |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 5670 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | violated | 210841 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 430298 |  |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 5670 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 212621 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 430298 |  |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 5670 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 212621 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 430298 |  |
| A | ConditionalUpdate | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 35 |  |
| A | ConditionalUpdate | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 1154 |  |
| A | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 4296 |  |
| A | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 100763 |  |
| A | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | holds | 331517 |  |
| A | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 2629 | 13 |
| A | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 14529 | 13 |
| A | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | violated | 129177 | 16 |
| A | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 3507 | 15 |
| A | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 34975 | 15 |
| A | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 292269 | 19 |
| A | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 4296 |  |
| A | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 100763 |  |
| A | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 331517 |  |
| A | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 4296 |  |
| A | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 100763 |  |
| A | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 331517 |  |
| A | GuardedTransaction | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 39 | 5 |
| A | GuardedTransaction | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 777 | 9 |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | C1 | holds | 5670 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | C1 | holds | 212621 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | C1 | holds | 430298 |  |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | C1tau | violated | 2033 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | C1tau | violated | 10934 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | C1tau | violated | 57615 |  |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | ProvL | violated | 3839 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | ProvL | violated | 30842 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | ProvL | violated | 226546 |  |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | Prov2L | holds | 5670 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | Prov2L | violated | 210841 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | Prov2L | holds | 430298 |  |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | C3 | holds | 5670 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | C3 | holds | 212621 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | C3 | holds | 430298 |  |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | NonNegative | holds | 5670 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | NonNegative | holds | 212621 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | NonNegative | holds | 430298 |  |
| A | ReserveBeforeSend | 1 | 1 | 4 | 1 | False | anyError | current | False |  | BelowLimit | violated | 37 |  |
| A | ReserveBeforeSend | 2 | 2 | 4 | 1 | False | anyError | current | False |  | BelowLimit | violated | 1140 |  |
| B | ConditionalUpdate | 2 | 1 | 4 | 1 | True |  |  | False |  | C1 | holds | 23880 |  |
| B | ConditionalUpdate | 3 | 1 | 4 | 1 | True |  |  | False |  | C1 | holds | 1310864 |  |
| B | ConditionalUpdate | 3 | 2 | 4 | 1 | True |  |  | False |  | C1 | holds | 5866973 |  |
| B | ConditionalUpdate | 2 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 23880 |  |
| B | ConditionalUpdate | 3 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 1310864 |  |
| B | ConditionalUpdate | 3 | 2 | 4 | 1 | True |  |  | False |  | C2 | holds | 5866973 |  |
| B | ConditionalUpdate | 2 | 1 | 4 | 1 | True |  |  | False |  | C4 | violated | 2660 |  |
| B | ConditionalUpdate | 3 | 1 | 4 | 1 | True |  |  | False |  | C4 | violated | 181761 |  |
| B | ConditionalUpdate | 3 | 2 | 4 | 1 | True |  |  | False |  | C4 | violated | 406466 |  |
| B | GuardedTransaction | 2 | 1 | 4 | 1 | True |  |  | False |  | C1 | holds | 14352 |  |
| B | GuardedTransaction | 3 | 1 | 4 | 1 | True |  |  | False |  | C1 | holds | 449621 |  |
| B | GuardedTransaction | 3 | 2 | 4 | 1 | True |  |  | False |  | C1 | holds | 3618119 |  |
| B | GuardedTransaction | 2 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 14352 |  |
| B | GuardedTransaction | 3 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 449621 |  |
| B | GuardedTransaction | 3 | 2 | 4 | 1 | True |  |  | False |  | C2 | holds | 3618119 |  |
| B | GuardedTransaction | 2 | 1 | 4 | 1 | True |  |  | False |  | C4 | holds | 14352 |  |
| B | GuardedTransaction | 3 | 1 | 4 | 1 | True |  |  | False |  | C4 | holds | 449621 |  |
| B | GuardedTransaction | 3 | 2 | 4 | 1 | True |  |  | False |  | C4 | holds | 3618119 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | current | False |  | C1 | violated | 5964 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | current | False |  | C1 | violated | 30406 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | current | False |  | C1 | violated | 460816 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | current | False |  | C2 | violated | 10759 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | current | False |  | C2 | violated | 64219 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | current | False |  | C2 | violated | 2346428 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | current | False |  | NonNegative | violated | 5592 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | current | False |  | NonNegative | violated | 38073 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | current | False |  | NonNegative | violated | 51255 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | current | False |  | C4 | holds | 87219 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | current | False |  | C4 | holds | 15399932 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | current | False |  | C4 | holds | 37545425 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | reserved | False |  | C1 | violated | 5736 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | reserved | False |  | C1 | violated | 27104 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | reserved | False |  | C1 | violated | 611104 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | reserved | False |  | C2 | violated | 11411 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | reserved | False |  | C2 | violated | 63767 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | reserved | False |  | C2 | violated | 2369488 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | reserved | False |  | NonNegative | holds | 75591 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | reserved | False |  | NonNegative | holds | 10868558 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | reserved | False |  | NonNegative | holds | 28808171 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | reserved | False |  | C4 | holds | 75591 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | reserved | False |  | C4 | holds | 10868558 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | reserved | False |  | C4 | holds | 28808171 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | current | False |  | C1 | violated | 6053 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | current | False |  | C1 | violated | 28045 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | current | False |  | C1 | violated | 608889 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | current | False |  | C2 | holds | 64591 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | current | False |  | C2 | violated | 1920043 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | current | False |  | C2 | holds | 28044133 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | current | False |  | NonNegative | violated | 7737 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | current | False |  | NonNegative | violated | 41312 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | current | False |  | NonNegative | violated | 42165 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | current | False |  | C4 | holds | 64591 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | current | False |  | C4 | holds | 7242472 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | current | False |  | C4 | holds | 28044133 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C1 | violated | 6600 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C1 | violated | 30957 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | False |  | C1 | violated | 429249 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C2 | holds | 60715 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C2 | holds | 5826274 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | False |  | C2 | holds | 25131715 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | NonNegative | holds | 60715 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | NonNegative | holds | 5826274 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | False |  | NonNegative | holds | 25131715 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C4 | holds | 60715 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C4 | holds | 5826274 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | False |  | C4 | holds | 25131715 |  |
| B | ConditionalUpdate | 2 | 1 | 4 | 1 | True |  |  | False |  | C2tau | violated | 7958 | 13 |
| B | ConditionalUpdate | 3 | 1 | 4 | 1 | True |  |  | False |  | C2tau | violated | 72603 | 13 |
| B | ConditionalUpdate | 3 | 2 | 4 | 1 | True |  |  | False |  | C2tau | violated | 1723414 | 18 |
| B | GuardedTransaction | 2 | 1 | 4 | 1 | True |  |  | False |  | C2tau | violated | 10810 | 14 |
| B | GuardedTransaction | 3 | 1 | 4 | 1 | True |  |  | False |  | C2tau | violated | 115088 | 14 |
| B | GuardedTransaction | 3 | 2 | 4 | 1 | True |  |  | False |  | C2tau | violated | 2356857 | 19 |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | current | False |  | C2tau | violated | 9814 | 12 |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | current | False |  | C2tau | violated | 45313 | 12 |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | current | False |  | C2tau | violated | 1578703 | 18 |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | reserved | False |  | C2tau | violated | 11197 | 12 |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | reserved | False |  | C2tau | violated | 48535 | 13 |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | reserved | False |  | C2tau | violated | 2098895 | 18 |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | current | False |  | C2tau | violated | 6739 | 13 |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | current | False |  | C2tau | violated | 94255 | 13 |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | current | False |  | C2tau | violated | 3265599 | 18 |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C2tau | violated | 12580 | 13 |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C2tau | violated | 63213 | 13 |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | False |  | C2tau | violated | 3142815 | 18 |
| C | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | True |  | C1 | holds | 10566 |  |
| C | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | True |  | C1 | holds | 481309 |  |
| C | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | True |  | C1 | holds | 882352 |  |
| C | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | True |  | C1tau | violated | 2613 |  |
| C | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | True |  | C1tau | violated | 13726 |  |
| C | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | True |  | C1tau | violated | 86579 |  |
| C | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | True |  | ProvL | violated | 4519 |  |
| C | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | True |  | ProvL | violated | 30062 |  |
| C | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | True |  | ProvL | violated | 309268 |  |
| C | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | True |  | Prov2L | holds | 10566 |  |
| C | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | True |  | Prov2L | violated | 423756 |  |
| C | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | True |  | Prov2L | holds | 882352 |  |
| C | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | True |  | C2 | holds | 10566 |  |
| C | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | True |  | C2 | holds | 481309 |  |
| C | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | True |  | C2 | holds | 882352 |  |
| C | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C1 | violated | 8206 |  |
| C | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C1 | violated | 36894 |  |
| C | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | True |  | C1 | violated | 875249 |  |
| C | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C1tau | violated | 5884 |  |
| C | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C1tau | violated | 24224 |  |
| C | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | True |  | C1tau | violated | 595523 |  |
| C | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | ProvL | violated | 13275 |  |
| C | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | ProvL | violated | 90839 |  |
| C | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | True |  | ProvL | violated | 3909592 |  |
| C | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | Prov2L | holds | 134963 |  |
| C | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | Prov2L | violated | 7241666 |  |
| C | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | True |  | Prov2L | holds | 56143477 |  |
| C | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C2 | holds | 134963 |  |
| C | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C2 | holds | 17602348 |  |
| C | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C2tau | violated | 17750 | 13 |
| C | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C2tau | violated | 131059 | 13 |
| D | ConditionalUpdate | 2 | 1 | 4 | 2 | False |  |  | False |  | C1 | violated | 3348 |  |
| D | ConditionalUpdate | 3 | 1 | 4 | 2 | False |  |  | False |  | C1 | violated | 19010 |  |
| D | ConditionalUpdate | 2 | 1 | 4 | 2 | False |  |  | False |  | C1K | holds | 24951 |  |
| D | ConditionalUpdate | 3 | 1 | 4 | 2 | False |  |  | False |  | C1K | holds | 2182679 |  |
| D | GuardedTransaction | 2 | 1 | 4 | 2 | False |  |  | False |  | C1 | violated | 2910 | 10 |
| D | GuardedTransaction | 3 | 1 | 4 | 2 | False |  |  | False |  | C1 | violated | 16367 | 9 |
| D | GuardedTransaction | 2 | 1 | 4 | 2 | False |  |  | False |  | C1K | holds | 22203 |  |
| D | GuardedTransaction | 3 | 1 | 4 | 2 | False |  |  | False |  | C1K | holds | 1499771 |  |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | False |  | C1 | holds | 1725199 |  |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | False |  | C1tau | violated | 9950 |  |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | False |  | Prov2L | violated | 1274125 |  |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | True |  | C1 | holds | 6095805 |  |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | True |  | C1tau | violated | 22836 |  |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | True |  | Prov2L | violated | 3103979 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 1046 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 3740 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 71509 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | violated | 103231 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | C2 | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | C2 | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | C2 | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | C4 | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | C4 | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | C4 | holds | 215618 |  |
| G | ConditionalUpdateDb | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 13 |  |
| G | ConditionalUpdateDb | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 114 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | C1 | violated | 988 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | C1 | violated | 2534 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | C1tau | violated | 1309 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | C1tau | violated | 1713 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | ProvL | violated | 3744 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | ProvL | violated | 13621 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | Prov2L | holds | 68095 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | Prov2L | violated | 654593 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 68095 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 6226156 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | C3 | holds | 68095 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | C3 | holds | 6226156 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | NonNegative | holds | 68095 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | NonNegative | holds | 6226156 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | C4 | holds | 68095 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | C4 | holds | 6226156 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | C2tau | holds | 68095 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | C2tau | holds | 6226156 |  |
| G | ReserveBeforeSendDb | 1 | 1 | 4 | 1 | True |  |  | False |  | BelowLimit | violated | 11 |  |
| G | ReserveBeforeSendDb | 2 | 2 | 4 | 1 | True |  |  | False |  | BelowLimit | violated | 179 |  |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | C1 | holds | 3564 |  |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | C1 | holds | 64265 |  |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | C1 | holds | 168893 |  |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | C1tau | violated | 2437 | 12 |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | C1tau | violated | 16570 | 12 |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | C1tau | violated | 87736 | 16 |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | ProvL | violated | 3024 | 15 |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | ProvL | violated | 35576 | 15 |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | ProvL | violated | 151437 | 19 |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | Prov2L | holds | 3564 |  |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | Prov2L | holds | 64265 |  |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | Prov2L | holds | 168893 |  |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | C2 | holds | 3564 |  |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | C2 | holds | 64265 |  |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | C2 | holds | 168893 |  |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | C3 | holds | 3564 |  |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | C3 | holds | 64265 |  |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | C3 | holds | 168893 |  |
| G | GuardedTransaction | 1 | 1 | 4 | 1 | False |  |  | True |  | BelowLimit | violated | 47 | 7 |
| G | GuardedTransaction | 2 | 2 | 4 | 1 | False |  |  | True |  | BelowLimit | violated | 739 | 9 |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 646 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 3186 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 15327 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 1264 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 23153 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 28292 |  |
| G | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 1764 |  |
| G | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 22182 |  |
| G | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 81761 |  |
| G | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 2700 |  |
| G | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | violated | 75457 |  |
| G | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 101420 |  |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True | 0 | ProvL | violated | 1572 | 14 |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True | 0 | ProvL | violated | 15861 | 14 |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True | 0 | ProvL | violated | 31302 | 19 |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True | 0 | Prov2L | holds | 1638 |  |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True | 0 | Prov2L | holds | 23264 |  |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True | 0 | Prov2L | holds | 32489 |  |
| G | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 1824 | 12 |
| G | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 11612 | 11 |
| G | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 115842 | 16 |
| G | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 3046 |  |
| G | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | violated | 74533 | 17 |
| G | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 225226 |  |
| G | ConditionalUpdateDb | 3 | 1 | 6 | 1 | False |  |  | False |  | C1 | holds | 1262219 |  |
| G | ConditionalUpdateDb | 3 | 1 | 6 | 1 | False |  |  | False |  | C1tau | holds | 1262219 |  |
| G | ConditionalUpdateDb | 3 | 1 | 6 | 1 | False |  |  | False |  | Prov2L | violated | 484803 |  |
| F | CountThenInsert | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 1004 |  |
| F | ReadModifyWrite | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 1044 |  |
| F | IncrementAfterSend | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 1925 |  |
| F | ConditionalUpdate | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 787 |  |
| F | GuardedTransaction | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 671 |  |
| F | ReserveBeforeSend | 2 | 1 | 2 | 1 | False | anyError | current | False |  | Termination | holds | 787 |  |
| F | ReserveBeforeSend | 2 | 1 | 2 | 1 | True | anyError | current | False |  | Termination | holds | 6619 |  |
| F | ConditionalUpdateDb | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 435 |  |
| F | ReserveBeforeSendDb | 2 | 1 | 2 | 1 | True |  |  | False |  | Termination | holds | 4425 |  |
