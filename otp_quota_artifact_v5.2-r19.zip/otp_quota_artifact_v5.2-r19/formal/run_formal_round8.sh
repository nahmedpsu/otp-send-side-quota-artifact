#!/bin/bash
# Round 8 formal runs: the timed TLA+ suite with C2tau and the closed sliding
# window interval (the fixed window verdicts of round 7 are kept, every
# sliding window run is redone). Waits for the round 8 measurements.
set -u
cd "$(dirname "$0")"
export PATH=/home/claude/tools:/home/claude/tools/maude35:$PATH LANG=C.UTF-8 LC_ALL=C.UTF-8
LOG=formal_round8.log
until grep -q "done (django_mfa postgres rerun)" ../results/r7/round8.log 2>/dev/null; do sleep 60; done
echo "=== $(date -u +%FT%TZ) TLC timed (round 8)" >> $LOG
(cd tla && python3 run_tlc_timed.py /home/claude/tools/tla2tools.jar) >> $LOG 2>&1 || echo "FAILED: TLC timed" >> $LOG
echo "=== $(date -u +%FT%TZ) formal done" >> $LOG
