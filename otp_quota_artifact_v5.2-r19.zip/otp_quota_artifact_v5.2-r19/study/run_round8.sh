#!/usr/bin/env bash
# Round 8 measurements (service 2.2.1), in response to the second Computers &
# Security review: the deterministic lock wait arm; the time and fault arm
# rerun for the two datastore clock designs, whose grant now reads the clock
# under the serializing lock; every package execution rerun with one record
# per delivery; the sustained load arm rerun with one record per request.
# Every other round 7 record is unchanged.
set -u
cd "$(dirname "$0")/.."
LOG=results/r7/round8.log
run() { echo "=== $(date -u +%FT%TZ) $*" | tee -a "$LOG"; "$@" >> "$LOG" 2>&1 || echo "FAILED: $*" | tee -a "$LOG"; }
run python3 study/clock_semantics.py
run python3 study/run_round7.py lockwait --backend sqlite
run python3 study/run_round7.py lockwait --backend postgres
run python3 study/run_round7.py timing --backend sqlite --strategies atomic_update_db reserve_commit_db --tag db221
run python3 study/run_round7.py timing --backend postgres --strategies atomic_update_db reserve_commit_db --tag db221
for b in sqlite postgres; do
  for n in otp_email two_factor otp_twilio django_mfa otp_auth; do
    run python3 study/run_packages7.py $n --backend $b
  done
done
run python3 study/run_packages7.py fastapi_otp --backend sqlite
run python3 study/run_round7.py load --backend sqlite
run python3 study/run_round7.py load --backend postgres
echo "=== $(date -u +%FT%TZ) done" | tee -a "$LOG"
# django_mfa on PostgreSQL failed in the first pass (tables of a previous run
# left in the schema); pg_reset now drops every table of the packages' apps
run python3 study/run_packages7.py django_mfa --backend postgres
echo "=== $(date -u +%FT%TZ) done (django_mfa postgres rerun)" | tee -a "$LOG"
