"""When does a datastore read its clock for a statement that waits on a lock?

Round 8. A blocker holds the lock that a granting statement needs for one
second; the statement is issued 0.2 s into the hold. Reported, relative to
the instant the blocker took the lock: when the statement was issued, the
clock reading the statement used, when the lock was released, and when the
statement returned. PostgreSQL's statement_timestamp() is fixed when the
statement starts, before the wait; clock_timestamp() is read when evaluated;
SQLite's unixepoch() inside an UPDATE is read after the write lock, because
SQLite opens the write transaction at the start of the statement. The 2.2.1
pattern (take the number's advisory lock in the transaction, then issue the
UPDATE) reads statement_timestamp() after the lock.

    python3 study/clock_semantics.py      # writes results/r7/clock_semantics.json
"""
import json
import os
import sqlite3
import tempfile
import threading
import time

import psycopg

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DSN = os.environ.get("OTP_PG_DSN", "dbname=otp user=otp password=otp host=127.0.0.1")
HOLD, ISSUE_AT = 1.0, 0.2


def pg_case(pattern):
    res = {}
    with psycopg.connect(DSN, autocommit=True) as c:
        c.execute("DROP TABLE IF EXISTS clock_probe; CREATE TABLE clock_probe(phone TEXT PRIMARY KEY, used INT, ws DOUBLE PRECISION)")
        c.execute("INSERT INTO clock_probe VALUES ('x', 0, 0)")

    def holder():
        with psycopg.connect(DSN) as c:
            c.execute("SELECT pg_advisory_xact_lock(hashtext('x'))")
            c.execute("SELECT * FROM clock_probe WHERE phone='x' FOR UPDATE")
            res["lock"] = time.time()
            time.sleep(HOLD)
            c.commit()
            res["release"] = time.time()

    def waiter():
        time.sleep(ISSUE_AT)
        res["issue"] = time.time()
        if pattern == "autocommit":          # 2.2.0: the UPDATE itself waits on the row lock
            with psycopg.connect(DSN, autocommit=True) as c:
                r = c.execute("UPDATE clock_probe SET used=used+1, ws=extract(epoch from statement_timestamp()) "
                              "WHERE phone='x' RETURNING ws, extract(epoch from clock_timestamp())").fetchone()
                res["reading"], res["clock_timestamp_at_return"] = float(r[0]), float(r[1])
        else:                                # 2.2.1: advisory lock first, then the UPDATE
            with psycopg.connect(DSN) as c:
                c.execute("SELECT pg_advisory_xact_lock(hashtext('x'))")
                res["lock_acquired"] = time.time()
                r = c.execute("UPDATE clock_probe SET used=used+1, ws=extract(epoch from statement_timestamp()) "
                              "WHERE phone='x' RETURNING ws").fetchone()
                res["reading"] = float(r[0])
                c.commit()
        res["return"] = time.time()
    run(holder, waiter)
    return rel(res)


def sqlite_case():
    res = {}
    p = os.path.join(tempfile.mkdtemp(prefix="clk-"), "probe.db")
    c = sqlite3.connect(p, isolation_level=None)
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("CREATE TABLE clock_probe(phone TEXT PRIMARY KEY, used INT, ws REAL)")
    c.execute("INSERT INTO clock_probe VALUES ('x',0,0)")
    c.close()

    def holder():
        c = sqlite3.connect(p, isolation_level=None)
        c.execute("PRAGMA busy_timeout=30000")
        c.execute("BEGIN IMMEDIATE")
        res["lock"] = time.time()
        time.sleep(HOLD)
        c.execute("COMMIT")
        res["release"] = time.time()
        c.close()

    def waiter():
        time.sleep(ISSUE_AT)
        c = sqlite3.connect(p, isolation_level=None)
        c.execute("PRAGMA busy_timeout=30000")
        res["issue"] = time.time()
        r = c.execute("UPDATE clock_probe SET used=used+1, ws=unixepoch('subsec') WHERE phone='x' RETURNING ws").fetchone()
        res["reading"] = float(r[0])
        res["return"] = time.time()
        c.close()
    run(holder, waiter)
    return rel(res)


def run(h, w):
    a, b = threading.Thread(target=h), threading.Thread(target=w)
    a.start(); b.start(); a.join(); b.join()


def rel(res):
    t0 = res["lock"]
    return {k: round(v - t0, 3) for k, v in res.items() if k != "lock"}


if __name__ == "__main__":
    out = {"hold_s": HOLD, "issue_at_s": ISSUE_AT,
           "postgresql_autocommit_statement_timestamp (2.2.0)": pg_case("autocommit"),
           "postgresql_advisory_lock_then_statement (2.2.1)": pg_case("locked"),
           "sqlite_unixepoch_in_update": sqlite_case()}
    os.makedirs(os.path.join(ROOT, "results", "r7"), exist_ok=True)
    json.dump(out, open(os.path.join(ROOT, "results", "r7", "clock_semantics.json"), "w"), indent=1)
    for k, v in out.items():
        print(k, v)
