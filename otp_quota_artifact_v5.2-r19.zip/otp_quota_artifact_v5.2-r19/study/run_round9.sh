#!/usr/bin/env bash
# Round 9 measurements (service 2.2.2), in response to the closure assessment
# of v5.1: the granting statement of the two datastore clock designs now
# returns the clock reading it used, so the lock wait arm and the time and
# fault arm's rows for those designs are rerun with the authorization instant
# recorded directly (tau_db) beside the issue and return instants; the
# sustained load arm is rerun with one record per number from the server's
# datastore (the provider calls it recorded), so that a request the client
# saw fail can be reconciled with what the server did. Every other round 7
# and round 8 record is unchanged.
set -u
cd "$(dirname "$0")/.."
LOG=results/r7/round9.log
run() { echo "=== $(date -u +%FT%TZ) $*" | tee -a "$LOG"; "$@" >> "$LOG" 2>&1 || echo "FAILED: $*" | tee -a "$LOG"; }
run python3 study/run_round7.py lockwait --backend sqlite --tag r9
run python3 study/run_round7.py lockwait --backend postgres --tag r9
run python3 study/run_round7.py timing --backend sqlite --strategies atomic_update_db reserve_commit_db --tag db222
run python3 study/run_round7.py timing --backend postgres --strategies atomic_update_db reserve_commit_db --tag db222
run python3 study/run_round7.py load --backend sqlite
run python3 study/run_round7.py load --backend postgres
echo "=== $(date -u +%FT%TZ) done" | tee -a "$LOG"
