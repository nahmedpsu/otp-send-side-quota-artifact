"""Every number of the round 7 arms (artifact v5.0-r17), from their records
in results/r7/ and formal/; imported by regenerate.py, which writes the
result under the key "r7" of results/paper_numbers.json.

Nothing here is typed in: each value is computed from a CSV or JSONL file
that a script in study/ or formal/ wrote, or from a hand label file in
results/r7/survey/ that records its own evidence.
"""
import csv
import json
import math
import os
import re
import statistics as st
from collections import Counter, defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _rows(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def _wilson(x, n, z=1.96):
    if n == 0:
        return None
    p = x / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return [round(100 * max(0.0, c - h), 1), round(100 * min(1.0, c + h), 1)]


def _q(v):
    v = sorted(v)
    if len(v) < 2:
        return v[0], v[0], v[0]
    q = st.quantiles(v, n=4)
    return q[0], st.median(v), q[2]


def _cell(v, lim=None):
    v = sorted(v)
    d = {"n": len(v), "median": st.median(v), "min": v[0], "max": v[-1]}
    if lim is not None:
        d["over"] = sum(1 for x in v if x > lim)
        d["over_ci_pct"] = _wilson(d["over"], len(v))
    return d


# ------------------------------------------------------------ executed packages
PKG = [("otp_email", "django-otp", "1.7.3"), ("django_mfa", "django-mfa", "4.6.0"),
       ("otp_auth", "django-otp-auth", "2.3.0"), ("fastapi_otp", "fastapi-otp-auth", "0.1.4"),
       ("two_factor", "django-two-factor-auth", "1.18.1"), ("otp_twilio", "django-otp-twilio", "1.0.5")]


def packages(R):
    """Per package results. The delivery count of every trial is derived from
    the individual delivery records (one line per message the counting mail
    backend, the provider stub or the SMTP sink received, round 8:
    packages_<name>_<backend>.deliveries.jsonl) and must equal the count the
    harness wrote to the CSV at the time."""
    out = {}
    for key, pkg, ver in PKG:
        for b in ("sqlite", "postgres"):
            f = os.path.join(R, "r7", f"packages_{key}_{b}.csv")
            if not os.path.exists(f):
                continue
            rs = _rows(f)
            dpath = os.path.join(R, "r7", f"packages_{key}_{b}.deliveries.jsonl")
            if os.path.exists(dpath):
                dcount = Counter()
                for line in open(dpath):
                    d = json.loads(line)
                    dcount[(d["mode"], int(d["concurrency"]), int(d["trial"]))] += 1
                for r in rs:
                    n = dcount.get((r["mode"], int(r["concurrency"]), int(r["trial"])), 0)
                    assert n == int(r["deliveries"]), ("delivery records disagree with the CSV", key, b, r, n)
                    r["deliveries"] = str(n)
                delivery_records = sum(dcount.values())
            else:
                delivery_records = None
            backend = rs[0]["backend"]
            lim = int(rs[0]["declared_limit"]) if rs[0]["declared_limit"] else None
            by = defaultdict(list)
            for r in rs:
                by[(r["mode"], int(r["concurrency"]))].append(int(r["deliveries"]))
            cells = {f"{m}|{k}": _cell(v, lim) for (m, k), v in sorted(by.items())}
            conc = [x for (m, k), v in by.items() if m == "concurrent" for x in v]
            conc_gt = [x for (m, k), v in by.items() if m == "concurrent" and (lim is None or k > lim) for x in v]
            d = {"package": pkg, "version": ver, "backend": backend, "declared_limit": lim, "trials": len(rs),
                 "errors": sum(int(r["errors"]) for r in rs), "cells": cells,
                 "delivery_records": delivery_records,
                 "concurrent_trials": len(conc), "concurrent_max": max(conc),
                 "deliveries_equal_k_every_trial": all(int(r["deliveries"]) == int(r["concurrency"]) for r in rs
                                                        if r["mode"] in ("concurrent", "sequential")) if lim is None else None}
            if lim is not None:
                d["concurrent_over"] = sum(1 for x in conc if x > lim)
                d["concurrent_trials_k_gt_L"] = len(conc_gt)
                d["worst_amplification"] = round(max(conc) / lim, 1)
                seq = [x for (m, k), v in by.items() if m.startswith("sequential") for x in v]
                d["sequential_over"] = sum(1 for x in seq if x > lim)
                for m in ("sequential", "sequential_new_conn"):
                    v = [x for (mm, k), vv in by.items() if mm == m for x in vv]
                    if v:
                        d[m + "_max"] = max(v)
                        d[m + "_over"] = sum(1 for x in v if x > lim)
            out[f"{key}|{backend}"] = d
    return out


# ------------------------------------------------------------ libraries
SUPPORTED = {  # what each library's documentation and checks say
    "slowapi_memory": "per process store, four workers (documented default; not shared)",
    "slowapi_redis": "supported shared store",
    "djrl_locmem": "rejected by the system check (E003)",
    "djrl_db_sqlite": "rejected by the system check (E003)",
    "djrl_db_postgres": "rejected by the system check (E003)",
    "djrl_redis": "warning only (W001), shared atomic store",
    "slowapi_memcached": "supported shared store",
    "slowapi_redis_moving": "supported shared store, moving window",
    "slowapi_redis_sliding": "supported shared store, sliding window counter",
    "slowapi_memory_1w": "per process store, one worker",
    "slowapi_memory_moving_1w": "per process store, moving window, one worker",
    "djrl_memcached": "supported (no system check issue)",
    "djrl_locmem_1w": "rejected by the system check (E003), one worker",
}


def libraries7(R):
    base = os.path.join(R, "r7", "libraries7")
    if not os.path.exists(base + ".csv"):
        return None
    rs = _rows(base + ".csv")
    meta = json.load(open(base + ".meta.json"))
    lim = meta["limit"]
    by, seq = defaultdict(list), defaultdict(list)
    for r in rs:
        a = int(r["admits"])
        assert int(r["provider_sends"]) == a, "provider calls differ from admissions"
        if r["mode"] == "concurrent":
            by[(r["config"], int(r["concurrency"]))].append(a)
        else:
            seq[(r["config"], r["mode"])].append(a)
    out = {"meta": {k: meta[k] for k in ("versions", "seed", "limit", "workers", "trials", "levels")},
           "django_system_checks": {c: {"exit": v["exit"], "ids": sorted(set(re.findall(r"django_ratelimit\.[EW]\d+", v["output"])))}
                                    for c, v in meta.get("django_system_checks", {}).items()},
           "cells": {}, "sequential": {}, "summary": {}, "errors": sum(int(r["errors"]) for r in rs), "trials": len(rs)}
    cfgs = sorted({c for c, _ in by})
    for (c, k), v in sorted(by.items()):
        out["cells"][f"{c}|{k}"] = _cell(v, lim)
    for c in cfgs:
        cv = [x for (cc, k), v in by.items() if cc == c for x in v]
        out["summary"][c] = {"trials": len(cv), "over": sum(1 for x in cv if x > lim), "max": max(cv),
                             "worst_amplification": round(max(cv) / lim, 1), "support": SUPPORTED.get(c, ""),
                             "workers": meta["workers"].get(c)}
        for m in ("sequential", "sequential_new_conn"):
            v = seq.get((c, m), [])
            if v:
                out["sequential"][f"{c}|{m}"] = {"n": len(v), "max": max(v), "over": sum(1 for x in v if x > lim)}
    return out


def worker_assignment(R):
    """Round 6 process local configurations: admissions per worker process
    in every trial, from the pid in each event record."""
    path = os.path.join(R, "r6", "libraries.events.jsonl")
    if not os.path.exists(path):
        return None
    trials = defaultdict(list)
    for line in open(path):
        e = json.loads(line)
        if e["config"] in ("slowapi_memory", "djrl_locmem"):
            trials[(e["config"], e["mode"], e["concurrency"], e["trial"])].append(e)
    out = {}
    for cfg in ("slowapi_memory", "djrl_locmem"):
        per_worker_max, workers_seen, admits_eq = 0, Counter(), 0
        n = 0
        for (c, mode, k, t), evs in trials.items():
            if c != cfg:
                continue
            n += 1
            adm = Counter(e["pid"] for e in evs if e["decision"] == "admit")
            per_worker_max = max(per_worker_max, max(adm.values()) if adm else 0)
            pids = {e["pid"] for e in evs}
            workers_seen[len(pids)] += 1
            admits_eq += int(sum(adm.values()) == sum(min(3, sum(1 for e in evs if e["pid"] == p)) for p in pids))
        out[cfg] = {"trials": n, "max_admissions_by_one_worker": per_worker_max,
                    "trials_admissions_equal_sum_over_workers_of_min_requests_L": admits_eq,
                    "distinct_workers_per_trial": dict(sorted(workers_seen.items()))}
    return out


# ------------------------------------------------------------ round 7 arms
ORDER = ["naive_count", "cache_get_set", "after_send", "atomic_update", "immediate_txn", "reserve_commit"]


def indep(R, s2):
    out = {"runs": {}, "between_run": {}}
    runs = defaultdict(lambda: defaultdict(list))
    for b in ("sqlite", "postgres"):
        # run 1 is the round 4 main sweep (the same cells)
        r4 = s2.get(f"main_{b}")
        for f in sorted(os.listdir(os.path.join(R, "r7"))):
            m = re.match(rf"indep_{b}_run(\d+)\.csv$", f)
            if not m:
                continue
            rr = int(m.group(1))
            for r in _rows(os.path.join(R, "r7", f)):
                runs[(b, rr)][(r["strategy"], int(r["concurrency"]))].append((int(r["admits"]), int(r["policy_overrun"]) > 0))
        for s in ORDER:
            for k in (4, 8, 32):
                per = {}
                if r4 and f"{s}|{k}" in r4:
                    c = r4[f"{s}|{k}"]
                    per[1] = {"median": c["median"], "max": c["max"], "violations": c["policy_violations"], "n": c["n"]}
                for (bb, rr), cells in runs.items():
                    if bb != b or (s, k) not in cells:
                        continue
                    v = cells[(s, k)]
                    per[rr] = {"median": st.median(a for a, _ in v), "max": max(a for a, _ in v),
                               "violations": sum(1 for _, p in v if p), "n": len(v)}
                if per:
                    out["runs"][f"{b}|{s}|{k}"] = per
                    vio = [p["violations"] for p in per.values()]
                    med = [p["median"] for p in per.values()]
                    out["between_run"][f"{b}|{s}|{k}"] = {"runs": len(per), "violations_min": min(vio),
                                                          "violations_max": max(vio), "median_min": min(med),
                                                          "median_max": max(med)}
    one_step_viol = sum(p["violations"] for key, per in out["runs"].items() for rr, p in per.items()
                        if rr > 1 and key.split("|")[1] in ORDER[3:])
    one_step_trials = sum(p["n"] for key, per in out["runs"].items() for rr, p in per.items()
                          if rr > 1 and key.split("|")[1] in ORDER[3:])
    out["new_runs_one_step_violations"] = one_step_viol
    out["new_runs_one_step_trials"] = one_step_trials
    out["new_runs_trials"] = sum(p["n"] for per in out["runs"].values() for rr, p in per.items() if rr > 1)
    return out


def interfere(R):
    f = os.path.join(R, "r7", "interfere_sqlite.csv")
    if not os.path.exists(f):
        return None
    by = defaultdict(list)
    for r in _rows(f):
        by[(r["strategy"], r["logging"], int(r["concurrency"]))].append(int(r["provider_sends"]))
    out = {}
    for (s, m, k), v in sorted(by.items()):
        out[f"{s}|{m}|{k}"] = _cell(v, 3)
    return out


def provider(R):
    out = {}
    for b in ("sqlite", "postgres"):
        f = os.path.join(R, "r7", f"provider_{b}.csv")
        if not os.path.exists(f):
            continue
        rs = _rows(f)
        out[b] = {"trials": len(rs),
                  "requests_logged_equal_k": all(int(r["requests_logged"]) == int(r["concurrency"]) for r in rs),
                  "provider_log_equals_admissions": all(int(r["provider_log_calls"]) == int(r["admits"]) for r in rs),
                  "db_provider_rows_equal_admissions": all(int(r["db_provider_rows"]) == int(r["admits"]) for r in rs),
                  "request_ids_match": all(r["rids_match"] == "1" for r in rs),
                  "message_ids_match": all(r["mids_match"] == "1" for r in rs),
                  "verdict_agrees": all((int(r["policy_overrun"]) > 0) == (r["provider_over"] == "1") for r in rs),
                  "by_strategy": {s: {"trials": sum(1 for r in rs if r["strategy"] == s),
                                      "provider_over": sum(1 for r in rs if r["strategy"] == s and r["provider_over"] == "1")}
                                  for s in ORDER}}
    return out


def sync(R):
    f = os.path.join(R, "r7", "sync_sqlite.csv")
    if not os.path.exists(f):
        return None
    by = defaultdict(list)
    for r in _rows(f):
        by[(r["strategy"], r["release"], int(r["concurrency"]))].append(r)
    out = {}
    for (s, m, k), rs in sorted(by.items()):
        a = [int(r["admits"]) for r in rs]
        out[f"{s}|{m}|{k}"] = dict(_cell(a, 3), violations=sum(1 for r in rs if int(r["policy_overrun"]) > 0),
                                   arrival_spread_ms_median=st.median(float(r["arrival_spread_ms"]) for r in rs),
                                   read_spread_ms_median=st.median(float(r["read_spread_ms"]) for r in rs),
                                   errors=sum(int(r["errors"]) for r in rs))
    return out


def _tau_bounds(es, pol, W, L, issue=lambda e: e["t_read"], ret=lambda e: e["t_write"]):
    """Verdict of a limit L over a set of grants whose authorization instant
    tau is known only to lie in [issue, return] of the granting statement
    (round 9). Returns (may, must, exact): `may` is the largest count one
    window can reach for some choice of the instants inside their intervals,
    `must` the smallest count the fullest window reaches whatever the
    choice; a verdict is definitive when both sides of L agree, that is
    when must > L (violated under every choice) or may <= L (held under
    every choice). For aligned windows both bounds are exact: `may` is the
    number of grants whose interval touches the fullest window, `must` is
    found by assigning each grant to one of the windows its interval
    touches so as to minimize the fullest window (earliest deadline first
    with a capacity, searched). For the closed trailing window [t-W, t],
    `may` is the largest set of grants whose intervals can all meet one
    interval of length W (exact), and `must` counts grants whose whole
    interval lies inside one interval of length W (a sufficient condition,
    so a sliding verdict reported as ambiguous may still be definitive).
    `exact` is the count by the recorded instant tau_db when every grant
    has one, else None."""
    if not es:
        return 0, 0, 0
    a = [issue(e) for e in es]
    b = [ret(e) for e in es]
    if pol == "fixed":
        rng = [(math.floor(x / W), math.floor(y / W)) for x, y in zip(a, b)]
        ws = sorted({w for lo, hi in rng for w in range(lo, hi + 1)})
        may = max(sum(1 for lo, hi in rng if lo <= w <= hi) for w in ws)

        def feasible(c):
            pending = sorted(rng, key=lambda r: r[1])
            for w in ws:
                avail = sorted([r for r in pending if r[0] <= w], key=lambda r: r[1])
                take = avail[:c]
                for r in take:
                    pending.remove(r)
                if any(r[1] == w for r in pending if r[0] <= w):
                    return False
            return not pending
        must = next(c for c in range(1, len(rng) + 1) if feasible(c))
    else:
        cand = sorted(set(b) | {x - W for x in a})
        may = max(sum(1 for x, y in zip(a, b) if x <= t + W and y >= t) for t in cand)
        must = max(sum(1 for x, y in zip(a, b) if x >= t and y <= t + W) for t in a)
    exact = None
    if all(e.get("tau_db") is not None for e in es):
        ts = [e["tau_db"] for e in es]
        if pol == "fixed":
            exact = max(Counter(math.floor(t / W) for t in ts).values())
        else:
            ts.sort()
            exact = max(sum(1 for y in ts if x <= y <= x + W) for x in ts)
    return may, must, exact


def _timing_rows(R, b, suffix=".csv"):
    """The time and fault arm's rows for one datastore: the round 7 run, with
    the rows of the two datastore clock designs replaced by the latest rerun
    (round 9, service 2.2.2, timing_<b>_db222.*, whose granting statement
    returns the clock reading it used; before it round 8, service 2.2.1,
    timing_<b>_db221.*). The superseded rows of those designs stay in the
    archive and are reported separately under the prefixes r7_db220 and
    r8_db221. Returns (rows, {prefix: superseded rows})."""
    base = os.path.join(R, "r7", f"timing_{b}{suffix}")
    if not os.path.exists(base):
        return [], {}
    load = (lambda p: _rows(p)) if suffix == ".csv" else (lambda p: [json.loads(l) for l in open(p)])
    r7 = load(base)
    keep = [r for r in r7 if not r["strategy"].endswith("_db")]
    old = {"r7_db220:": [r for r in r7 if r["strategy"].endswith("_db")]}
    main = None
    for tag, prefix in (("db221", "r8_db221:"), ("db222", None)):
        f = os.path.join(R, "r7", f"timing_{b}_{tag}{suffix}")
        if not os.path.exists(f):
            continue
        rows_ = load(f)
        if main is not None:
            old[prev_prefix] = main
        main, prev_prefix = rows_, prefix
    if main is None:
        return r7, {}
    return keep + main, old


def timing(R):
    out = {}
    for b in ("sqlite", "postgres"):
        rows_, _old = _timing_rows(R, b)
        if not rows_:
            continue
        by = defaultdict(list)
        for r in rows_:
            by[(r["strategy"], r["release"], int(r["delay_ms_max"]))].append(r)
        for (s, rel, d), rs in sorted(by.items()):
            n = len(rs)
            c2 = [int(r["c2_billed_per_window"]) for r in rs if r["c2_billed_per_window"] != ""]
            out[f"{b}|{s}|{rel}|{d}"] = {
                "trials": n, "faults": rs[0]["faults"] == "1",
                "c1_violated": sum(int(r["c1_violated"]) for r in rs),
                "c1_tau_violated": sum(int(r["c1_tau_violated"]) for r in rs),
                "c2_violated": sum(int(r["c2_violated"]) for r in rs),
                "c2_max": max(c2) if c2 else None,
                "negative_counter": sum(int(r["negative_counter"]) for r in rs),
                "late_grants": sum(int(r["late_grants"]) for r in rs),
                "trials_with_late_grant": sum(1 for r in rs if int(r["late_grants"]) > 0),
                "provider_any_interval_max": max(int(r["provider_any_interval"]) for r in rs),
                "provider_any_interval_over_L": sum(1 for r in rs if int(r["provider_any_interval"]) > 3),
                "admits_median": st.median(int(r["admits"]) for r in rs),
                "released": sum(int(r["released"]) for r in rs),
                "errors": sum(int(r["errors"]) for r in rs)}
    return out


def timing_events(R):
    """The time and fault arms recomputed from their event records, request by
    request. A call counts toward C1 whether or not its reservation was later
    returned, and a call is billed when its outcome is ok or a timeout that
    billed (unkB), also whether or not it was returned. (The arm's own c1 and
    c2 columns counted only the requests whose final decision was "admit", so
    they omit returned calls; these columns supersede them.) The authorization
    instant tau is the application's instant at the return of the granting
    statement (t_write)."""
    out = {}
    for b in ("sqlite", "postgres"):
        evs_all, old = _timing_rows(R, b, ".events.jsonl")
        if not evs_all:
            continue
        for label, evs_src in [("", evs_all)] + sorted(old.items()):
            out.update(_timing_events_for(b, evs_src, label))
    return out


def _timing_events_for(b, evs_src, label):
    if True:
        trials = defaultdict(list)
        for e in evs_src:
            trials[(e["strategy"], e.get("release", ""), int(e["delay_ms_max"]), e["trial"])].append(e)
        agg = defaultdict(lambda: defaultdict(int))
        for (st_, rel, dl, t), evs in trials.items():
            W, L = evs[0]["window_s"], evs[0]["limit"]
            calls = [e for e in evs if e["decision"] in ("admit", "released") and e.get("message_id")]
            billed = [e for e in calls if e.get("provider_outcome") in (None, "unkB")]
            pol = evs[0]["policy"]

            def mx(es, tau):
                """tau: None = the implementation's attribution; "return" = the
                instant the granting statement returned (an upper bound on the
                authorization instant); "issue" = the instant it was issued
                (a lower bound; for the 2.2.1 datastore clock designs, after
                the serializing lock)."""
                if not es:
                    return 0
                key = {None: (lambda e: e["window_id"] if pol == "fixed" else e["policy_ts"]),
                       "return": (lambda e: e["t_write"]), "issue": (lambda e: e["t_read"])}[tau]
                if pol == "fixed":
                    ws = Counter(math.floor(key(e) / W) if tau else key(e) for e in es)
                    return max(ws.values())
                ts = sorted(key(e) for e in es)
                return max(sum(1 for y in ts if x <= y <= x + W) for x in ts)
            a = agg[f"{label}{b}|{st_}|{rel}|{dl}"]
            a["trials"] += 1
            a["faults"] = int(evs[0].get("faults", 0))
            a["c1_calls_violated"] += int(mx(calls, None) > L)
            a["c1_calls_tau_violated"] += int(mx(calls, "return") > L)
            a["c1_calls_tau_issue_violated"] += int(mx(calls, "issue") > L)
            a["c2_violated"] += int(mx(billed, None) > L)
            a["c2_tau_violated"] += int(mx(billed, "return") > L)
            a["c2_tau_issue_violated"] += int(mx(billed, "issue") > L)
            for nm, es in (("c1_calls", calls), ("c2", billed)):
                may, must, exact = _tau_bounds(es, pol, W, L)
                a[f"{nm}_tau_may_violated"] += int(may > L)        # violated for some tau in the intervals
                a[f"{nm}_tau_must_violated"] += int(must > L)      # violated for every tau in the intervals
                a[f"{nm}_tau_ambiguous"] += int(may > L and not must > L)
                if exact is not None:
                    a[f"{nm}_tau_db_violated"] += int(exact > L)   # by the recorded reading (2.2.2 designs)
                    a[f"{nm}_tau_db_trials"] += 1
            a["c2_max"] = max(a["c2_max"], mx(billed, None))
            a["straddling_grants"] += sum(1 for e in calls if math.floor(e["t_read"] / W) != math.floor(e["t_write"] / W))
            a["released"] += sum(1 for e in evs if e["decision"] == "released" and e.get("released_rows", 1))
            a["release_no_row"] += sum(1 for e in evs if e["decision"] == "released" and e.get("released_rows", 1) == 0)
            a["cross_window_releases"] += sum(1 for e in evs if e["decision"] == "released" and e.get("released_rows", 1)
                                              and rel != "certain_reserved" and not st_.endswith("_db")
                                              and math.floor(e["t_done"] / W) * W != e["window_id"])
            a["calls"] += len(calls)
            a["billed"] += len(billed)
            a["unkU"] += sum(1 for e in calls if e.get("provider_outcome") == "unkU")
        return {k: dict(v) for k, v in agg.items()}


def lockwait(R):
    """The deterministic lock wait arm, recomputed from its event records:
    L requests that arrive while a blocker holds the serializing lock across
    an aligned boundary and are granted after its release, then L more after
    it. The main rows are the round 9 run on service 2.2.2
    (lockwait_<b>_r9.*), whose datastore clock designs record the reading
    tau_db the granting statement used; the round 8 run (service 2.2.1) is
    reported under the prefix r8:. A grant "waited" when its request arrived
    before the blocker released the lock and its granting statement returned
    after the release (t_recv < t_release <= t_write). Where the wait fell is
    reported too: before the statement was issued (t_read >= t_release; the
    2.2.x designs wait in the lock acquisition call, so the statement and
    its clock reading come after the release) or inside the statement
    (t_read < t_release <= t_write; the sampled clock designs wait on the
    row lock inside their granting statement, after their clock was read).
    For a fixed window design, "waited attributed old" counts waited grants
    attributed to the window before the boundary. The C1 verdicts by
    authorization instant use the design's own family (aligned windows for
    the fixed designs, the closed trailing interval for the sliding ones):
    by the issue and the return bound, by the interval bounds (may, must),
    and by the recorded reading where there is one."""
    out = {}
    for b in ("sqlite", "postgres"):
        runs = [("", f"lockwait_{b}_r9.events.jsonl"), ("r8:", f"lockwait_{b}.events.jsonl")]
        if not os.path.exists(os.path.join(R, "r7", runs[0][1])):
            runs = [("", runs[1][1])]
        for label, fn in runs:
            f = os.path.join(R, "r7", fn)
            if not os.path.exists(f):
                continue
            trials = defaultdict(list)
            for line in open(f):
                e = json.loads(line)
                trials[(e["strategy"], e["trial"])].append(e)
            agg = defaultdict(lambda: defaultdict(int))
            for (st_, t), evs in sorted(trials.items()):
                W, L, pol = evs[0]["window_s"], evs[0]["limit"], evs[0]["policy"]
                B, rel = evs[0]["boundary"], evs[0]["t_release"]
                adm = [e for e in evs if e["decision"] == "admit"]
                waited = [e for e in adm if e["t_recv"] < rel <= e["t_write"]]

                def worst(key):
                    if not adm:
                        return 0
                    if pol == "fixed":
                        return max(Counter(math.floor(key(e) / W) for e in adm).values())
                    ts = sorted(key(e) for e in adm)
                    return max(sum(1 for y in ts if x <= y <= x + W) for x in ts)
                a = agg[f"{label}{b}|{st_}"]
                a["trials"] += 1
                a["grants"] += len(adm)
                a["waited_grants_total"] += len(waited)
                a["trials_with_L_waited"] += int(len(waited) == L)
                a["waited_before_issue"] += sum(1 for e in waited if e["t_read"] >= rel)
                a["waited_inside_statement"] += sum(1 for e in waited if e["t_read"] < rel)
                # the design's own clock reading: the recorded datastore reading for the
                # 2.2.2 designs, the request's sample at arrival (t_recv) for the others
                reading = lambda e: e["tau_db"] if e.get("tau_db") is not None else e["t_recv"]
                a["waited_clock_before_release"] += sum(1 for e in waited if reading(e) < rel)
                a["waited_clock_after_release"] += sum(1 for e in waited if reading(e) >= rel)
                if pol == "fixed":
                    a["waited_attributed_old"] += sum(1 for e in waited if e["window_id"] < B)
                    a["waited_attributed_new"] += sum(1 for e in waited if e["window_id"] >= B)
                    a["c1_attributed_violated"] += int(max(Counter(e["window_id"] for e in adm).values()) > L if adm else 0)
                else:
                    a["waited_attributed_old"] = a["waited_attributed_new"] = None
                    a["c1_attributed_violated"] += int(worst(lambda e: e["policy_ts"]) > L)
                a["c1_tau_return_violated"] += int(worst(lambda e: e["t_write"]) > L)
                a["c1_tau_issue_violated"] += int(worst(lambda e: e["t_read"]) > L)
                may, must, exact = _tau_bounds(adm, pol, W, L)
                a["c1_tau_may_violated"] += int(may > L)
                a["c1_tau_must_violated"] += int(must > L)
                a["c1_tau_ambiguous"] += int(may > L and not must > L)
                if exact is not None:
                    a["c1_tau_db_violated"] += int(exact > L)
                    a["c1_tau_db_trials"] += 1
                    a["waited_tau_db_old"] += sum(1 for e in waited if e["tau_db"] < B)
                    a["waited_tau_db_new"] += sum(1 for e in waited if e["tau_db"] >= B)
                    a["tau_db_in_bounds"] += sum(1 for e in adm if e["t_read"] <= e["tau_db"] + 0.001 and e["tau_db"] <= e["t_write"] + 0.001)
                    a["tau_db_after_lock"] += sum(1 for e in adm if e.get("t_lock") is not None and e["tau_db"] + 0.001 >= e["t_lock"])
                a["grants_max"] = max(a["grants_max"], len(adm))
                a["errors"] += sum(1 for e in evs if e["decision"] == "error")
            out.update({k: dict(v) for k, v in agg.items()})
    p = os.path.join(R, "r7", "clock_semantics.json")
    if os.path.exists(p):
        out["clock_semantics"] = json.load(open(p))
    return out


def load(R):
    """The sustained load arm, recomputed from the per request records
    (round 8: load_<b>.requests.jsonl, one line per request with its
    scheduled arrival, actual start and completion on the client's clock,
    recipient, status and latency). The harness's own CSV is checked
    against them. Per number, grants beyond L is max(0, grants - L), which
    does not depend on any ordering; refusals of a number below L are
    counted in two orders, by scheduled arrival and by completion, since the
    server's order of grants is not observed."""
    L = 3
    out = {}
    # main rows: the round 9 run (load_<b>.*, with the server's records); the round 8 run on the
    # earlier host (load_<b>_r8.*, client records only) is reported under the prefix r8:
    for b, tag, label in (("sqlite", "", ""), ("postgres", "", ""), ("sqlite", "_r8", "r8:"), ("postgres", "_r8", "r8:")):
        f = os.path.join(R, "r7", f"load_{b}{tag}.csv")
        rq = os.path.join(R, "r7", f"load_{b}{tag}.requests.jsonl")
        if not os.path.exists(f):
            continue
        csv_rows = {(r["strategy"], int(float(r["rate"]))): r for r in _rows(f)}
        if not os.path.exists(rq):
            for (s_, rate), r in csv_rows.items():
                out[f"{label}{b}|{s_}|{rate}"] = {k: (float(v) if re.fullmatch(r"-?\d+(\.\d+)?", v or "") else v)
                                          for k, v in r.items() if k not in ("arm", "backend", "strategy")}
            continue
        runs = defaultdict(list)
        for line in open(rq):
            e = json.loads(line)
            runs[(e["strategy"], int(e["rate"]))].append(e)
        srv = defaultdict(list)                     # round 9: the server's record per number
        sv = os.path.join(R, "r7", f"load_{b}{tag}.server.jsonl")
        if os.path.exists(sv):
            for line in open(sv):
                e = json.loads(line)
                srv[(e["strategy"], int(e["rate"]))].append(e)
        q = lambda v, f_: round(sorted(v)[min(len(v) - 1, int(f_ * len(v)))], 2) if v else None
        for (s_, rate), es in sorted(runs.items()):
            es.sort(key=lambda e: e["t_sched"])
            granted = [e for e in es if e["status"] == "sent"]
            refused = [e for e in es if e["status"] == "rejected"]
            errors = [e for e in es if e["status"] not in ("sent", "rejected")]
            per = Counter(e["phone"] for e in granted)
            beyond = sum(max(0, n - L) for n in per.values())

            def below(order):
                seen, n = Counter(), 0
                for e in sorted(es, key=order):
                    if e["status"] == "sent":
                        seen[e["phone"]] += 1
                    elif e["status"] == "rejected" and seen[e["phone"]] < L:
                        n += 1
                return n
            dur = max(e["t_sched"] for e in es)
            d = {"requests": len(es), "admitted": len(granted), "refused": len(refused), "errors": len(errors),
                 "numbers": len({e["phone"] for e in es}), "numbers_at_limit": sum(1 for n in per.values() if n >= L),
                 "admitted_beyond_limit": beyond, "numbers_beyond_limit": sum(1 for n in per.values() if n > L),
                 "max_grants_one_number": max(per.values()) if per else 0,
                 "refused_below_limit_arrival_order": below(lambda e: e["t_sched"]),
                 "refused_below_limit_completion_order": below(lambda e: e["t_end"]),
                 "admitted_per_s": round(len(granted) / dur, 2),
                 "adm_p50_ms": q([e["latency_ms"] for e in granted], .5), "adm_p95_ms": q([e["latency_ms"] for e in granted], .95),
                 "adm_p99_ms": q([e["latency_ms"] for e in granted], .99),
                 "ref_p50_ms": q([e["latency_ms"] for e in refused], .5), "ref_p95_ms": q([e["latency_ms"] for e in refused], .95),
                 "ref_p99_ms": q([e["latency_ms"] for e in refused], .99),
                 "start_lag_p95_ms": q([1000 * (e["t_start"] - e["t_sched"]) for e in es], .95),
                 "seconds": 30, "rate": rate}
            if srv.get((s_, rate)):
                rows_ = srv[(s_, rate)]
                sends = {r["phone"]: r["server_sends"] for r in rows_}
                assert all(sends[ph] >= n for ph, n in per.items()), ("server recorded fewer sends than the client saw", b, s_, rate)
                # the run must lie within one aligned window of 3600 s, else "beyond L" is not defined
                spanned = len({math.floor(t / 3600) for r in rows_ for t in r["server_send_ts"]})
                assert spanned == 1, ("load run crossed a window boundary", b, s_, rate, spanned)
                errs_by = Counter(e["phone"] for e in errors)
                d.update({
                    "server_sends": sum(sends.values()),
                    "server_beyond_limit": sum(max(0, n - L) for n in sends.values()),
                    "server_numbers_beyond_limit": sum(1 for n in sends.values() if n > L),
                    "server_max_sends_one_number": max(sends.values()) if sends else 0,
                    # sends the server recorded that no client "sent" reply accounts for:
                    # requests that errored at the client after the server had sent
                    "sends_unconfirmed": sum(max(0, sends[ph] - per.get(ph, 0)) for ph in sends),
                    "errors_with_send": sum(min(errs_by[ph], max(0, sends[ph] - per.get(ph, 0))) for ph in errs_by),
                    "errors_without_send": sum(max(0, errs_by[ph] - max(0, sends[ph] - per.get(ph, 0))) for ph in errs_by),
                    "numbers_recorded": len(rows_), "windows_spanned": spanned,
                    "run_span_s": round(max(t for r in rows_ for t in r["server_send_ts"]) -
                                        min(t for r in rows_ for t in r["server_send_ts"]), 1)})
            c = csv_rows.get((s_, rate))
            if c:
                for k in ("admitted", "refused", "errors", "admitted_beyond_limit"):
                    assert int(float(c[k])) == d[k], ("load CSV disagrees with the request records", b, s_, rate, k, c[k], d[k])
                d["csv_agrees"] = True
            out[f"{label}{b}|{s_}|{rate}"] = d
    return out


def overlap(R):
    """Offered concurrency against observed overlap at the decision, round 4
    SQLite main sweep: per trial, the number of requests whose read of the
    quota state came before the L-th granting write (application observed
    instants)."""
    path = os.path.join(R, "r4", "main_sqlite.events.jsonl")
    trials = defaultdict(list)
    for line in open(path):
        e = json.loads(line)
        trials[(e["strategy"], e["concurrency"], e["trial"])].append(e)
    by = defaultdict(list)
    per_trial = []
    for (s, k, t), evs in sorted(trials.items()):
        writes = sorted(e["t_write"] for e in evs if e.get("decision") == "admit" and e.get("t_write"))
        if len(writes) < 3:
            continue
        cut = writes[2]
        ov = sum(1 for e in evs if e.get("t_read") and e["t_read"] < cut)
        by[(s, k)].append(ov)
        recv = [e["t_recv"] for e in evs if e.get("t_recv")]
        reads = [e["t_read"] for e in evs if e.get("t_read")]
        per_trial.append({"strategy": s, "concurrency": k, "trial": t,
                          "arrival_spread_ms": round(1000 * (max(recv) - min(recv)), 3) if recv else "",
                          "read_spread_ms": round(1000 * (max(reads) - min(reads)), 3) if reads else "",
                          "third_grant_after_first_arrival_ms": round(1000 * (cut - min(recv)), 3) if recv else "",
                          "reads_before_third_grant": ov,
                          "grants": sum(1 for e in evs if e.get("decision") == "admit")})
    with open(os.path.join(R, "r7", "overlap_per_trial.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(per_trial[0]))
        w.writeheader()
        w.writerows(per_trial)
    return {f"{s}|{k}": dict(zip(("q1", "median", "q3"), _q(v)), n=len(v), max=max(v))
            for (s, k), v in sorted(by.items())}


# ------------------------------------------------------------ formal (round 7)
def formal7():
    out = {}
    p = os.path.join(ROOT, "formal", "tla", "results_timed.json")
    if os.path.exists(p):
        runs = json.load(open(p))
        agg = defaultdict(list)
        for r in runs:
            var = []
            if r["K"] > 1:
                var.append(f"K{r['K']}")
            if r["faults"]:
                var.append("faults")
            if r["design"] == "ReserveBeforeSend":
                var.append(f"{r['rule']}/{r['scope']}")
            if r["dbclock"]:
                var.append("dbclock")
            if r.get("D") is not None:
                var.append(f"D{r['D']}")
            if r["T"] != 4:
                var.append(f"T{r['T']}")
            agg[(r["group"], r["design"], r["prop"], ",".join(var))].append(r)
        out["tlc_timed_runs"] = len(runs)
        out["tlc_timed_max_states"] = max(r["distinct"] for r in runs if r["distinct"])
        out["tlc_timed"] = {"|".join(k): {"verdicts": {f"N{r['N']}L{r['L']}": r["verdict"] for r in v},
                                          "holds_all": all(r["verdict"] == "holds" for r in v),
                                          "violated_any": any(r["verdict"] == "violated" for r in v)}
                            for k, v in sorted(agg.items())}
    sw = os.path.join(ROOT, "formal", "tamarin", "results", "sweep.json")
    if os.path.exists(sw):
        recs = json.load(open(sw))
        out["tamarin_sweep"] = {f"{r['design']}|L{r['L']}": {k: v["verdict"] for k, v in r["lemmas"].items()}
                                for r in recs}
        out["tamarin_sweep_all_verified"] = all(v["verdict"] == "verified" for r in recs for v in r["lemmas"].values())
        out["tamarin_sweep_limits"] = sorted({r["L"] for r in recs})
    pp = os.path.join(ROOT, "formal", "tamarin", "results", "param")
    if os.path.isdir(pp):
        par = {}
        for f in sorted(os.listdir(pp)):
            m = re.match(r"log_(\w+)\.txt$", f)
            if m:
                log = open(os.path.join(pp, f)).read()
                par[m.group(1)] = {x.group(1): {"verdict": x.group(3), "steps": int(x.group(4))}
                                   for x in re.finditer(r"^  (\w+) \((all-traces|exists-trace)\): (verified|falsified|analysis incomplete) \((\d+) steps\)", log, re.M)}
        out["tamarin_param"] = par
    return out


# ------------------------------------------------------------ survey (round 7)
def survey7(R, s1):
    d = os.path.join(R, "r7", "survey")
    out = {}
    sv = _rows(os.path.join(d, "stage_validation.csv"))
    meta = [r for r in sv if r["stage"] == "metadata"]
    name = [r for r in sv if r["stage"] == "name"]
    ns = json.load(open(os.path.join(d, "name_stage_sample.json")))
    rel_n = sum(int(r["relevant"]) for r in name)
    out["metadata_stage"] = {"reviewed": len(meta), "relevant": sum(int(r["relevant"]) for r in meta),
                             "relevant_send_bound": dict(Counter(r["send_bound"] for r in meta if r["relevant"] == "1")),
                             "code_inspected": sum(int(r["code_inspected"]) for r in meta)}
    out["name_stage"] = {"index_size_now": ns["index_size"], "broad_token_names_outside": ns["broad_outside"],
                         "sample": len(name), "relevant": rel_n, "relevant_ci_pct": _wilson(rel_n, len(name)),
                         "est_relevant_outside": round(ns["broad_outside"] * rel_n / len(name)),
                         "est_relevant_outside_ci": [round(ns["broad_outside"] * x / 100) for x in _wilson(rel_n, len(name))],
                         "relevant_send_bound": dict(Counter(r["send_bound"] for r in name if r["relevant"] == "1")),
                         "seed": ns["seed"], "fetched_utc": ns["fetched_utc"]}
    vw = _rows(os.path.join(d, "validation_whole_package.csv"))
    miss = sum(1 for r in vw if r["whole_package_label"] == "miss")
    rej = 695
    out["validation_whole_package"] = {"sample": len(vw), "misses": miss,
                                       "missed_packages": [r["package"] for r in vw if r["whole_package_label"] == "miss"],
                                       "miss_rate_pct": round(100 * miss / len(vw), 1),
                                       "miss_rate_ci_pct": _wilson(miss, len(vw)),
                                       "est_missed_in_screened_set": round(rej * miss / len(vw), 1),
                                       "est_missed_ci": [round(rej * x / 100, 1) for x in _wilson(miss, len(vw))],
                                       "est_relevant_in_screened_set": round(s1["retained"] + rej * miss / len(vw)),
                                       "detector_recall_pct": round(100 * s1["retained"] / (s1["retained"] + rej * miss / len(vw)), 1),
                                       "detector_recall_ci_pct": [round(100 * s1["retained"] / (s1["retained"] + rej * x / 100), 1)
                                                                  for x in reversed(_wilson(miss, len(vw)))]}
    fam = _rows(os.path.join(d, "families.csv"))
    fams = defaultdict(list)
    for r in fam:
        fams[r["family"]].append(r)
    lvl = lambda rs: {r["send_control_evidence_level"] for r in rs}
    out["families"] = {"packages": len(fam), "families": len(fams),
                       "multi_member": sorted([len(v) for v in fams.values() if len(v) > 1], reverse=True),
                       "families_all_none": sum(1 for v in fams.values() if lvl(v) == {"none_in_package"}),
                       "families_any_in_package": sum(1 for v in fams.values()
                                                      if lvl(v) & {"in_package_delivery_path", "in_package_framework_throttle"}),
                       "families_delegated_only": sum(1 for v in fams.values() if lvl(v) == {"delegated_provider"}),
                       "families_helper_not_wired_only": sum(1 for v in fams.values() if lvl(v) == {"helper_not_wired"}),
                       "families_by_levels": dict(Counter("+".join(sorted(lvl(v))) for v in fams.values()))}
    gc = _rows(os.path.join(d, "guard_contracts.csv"))
    out["guard_contracts"] = {"rows": len(gc),
                              "per_recipient_effective": [r["package"] for r in gc if r["constrains_send_only_attacker_per_recipient"].startswith("yes")],
                              "per_recipient_effective_one_worker_only": [r["package"] for r in gc if r["constrains_send_only_attacker_per_recipient"].startswith("only")],
                              "not_per_recipient": [r["package"] for r in gc if r["constrains_send_only_attacker_per_recipient"].startswith("no")],
                              "provider": [r["package"] for r in gc if r["constrains_send_only_attacker_per_recipient"].startswith("depends")],
                              "one_step": [r["package"] for r in gc if r["decision_shape"].startswith("one step")],
                              "two_step": [r["package"] for r in gc if r["decision_shape"].startswith("two step")],
                              "executed": [r["package"] for r in gc if r["executed_round7"].startswith("yes")]}
    return out


def round7(R, s1, s2):
    if not os.path.isdir(os.path.join(R, "r7")):
        return None
    return {"packages": packages(R), "libraries7": libraries7(R), "worker_assignment": worker_assignment(R),
            "indep": indep(R, s2), "interfere": interfere(R), "provider": provider(R), "sync": sync(R),
            "timing": timing(R), "timing_events": timing_events(R), "lockwait": lockwait(R), "load": load(R), "overlap": overlap(R), "formal": formal7(),
            "survey": survey7(R, s1)}
