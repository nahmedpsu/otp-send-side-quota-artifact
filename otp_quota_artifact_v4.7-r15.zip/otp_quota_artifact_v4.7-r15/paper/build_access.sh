#!/bin/bash
# Build the IEEE Access PDF of manuscript v4.2 with the official template class.
# ieeeaccess.cls is not on CTAN and is not redistributed here: download
#   https://ieeeaccess.ieee.org/wp-content/uploads/2026/05/ACCESS_latex_template_20260513-1-1.zip
# unzip it, and copy ieeeaccess.cls and the image files it uses into this folder.
set -u
cd "$(dirname "$0")"
if [ ! -f ieeeaccess.cls ]; then
  echo "ieeeaccess.cls not found in $(pwd)."
  echo "Copy it (and the logo/bullet images from the same zip) here, then rerun."
  exit 1
fi
pdflatex -interaction=nonstopmode otp_ieee_access.tex > build.log 2>&1
bibtex otp_ieee_access >> build.log 2>&1
pdflatex -interaction=nonstopmode otp_ieee_access.tex >> build.log 2>&1
pdflatex -interaction=nonstopmode otp_ieee_access.tex >> build.log 2>&1
status=0
grep -n '^!' otp_ieee_access.log && status=1
grep -n 'undefined' otp_ieee_access.log | grep -v 'Font shape' && status=1
if [ $status -eq 0 ]; then echo "BUILD OK: otp_ieee_access.pdf"; else echo "BUILD PROBLEMS: see otp_ieee_access.log"; fi
exit $status
