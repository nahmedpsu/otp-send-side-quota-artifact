#!/bin/bash
# Round 6: off-the-shelf limiters under the burst protocol (library arm).
# Needs Redis 7 on 127.0.0.1:6379 and PostgreSQL 16 with the otp database
# (as for round 4). Writes results/r6/.
set -euo pipefail
cd "$(dirname "$0")/.."
echo "=== libraries ($(date -u +%FT%TZ)) ==="
python3 study/run_libraries.py --trials 30 --seed 20261008 --out results/r6/libraries.csv
