"""Generate the admission figures (one per datastore), the package execution figure, and the pgfplots coordinates of the
line and bar figures from the round-4 trial files (admissions per trial)."""
import csv, os, random
from collections import defaultdict
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LAB = {"naive_count": "Count then\ninsert", "cache_get_set": "Read modify\nwrite",
       "after_send": "Increment\nafter send", "atomic_update": "Conditional\natomic update",
       "immediate_txn": "Guarded write\ntransaction", "reserve_commit": "Reserve\nbefore send"}
ORDER = list(LAB)


def load(fn, k="concurrency", v="admits"):
    d = defaultdict(list)
    for r in csv.DictReader(open(fn)):
        d[(r["strategy"], int(r[k]))].append(int(r[v]))
    return d


# Typeset to match the IEEE body text: Liberation Serif (metrically Times),
# a TrueType font, so the PDF embeds cleanly.
RC = ({"font.family": "serif",
                     "font.serif": ["Liberation Serif", "Times New Roman", "DejaVu Serif"],
                     "mathtext.fontset": "stix", "font.size": 8,
                     "axes.linewidth": 0.6, "xtick.direction": "in", "ytick.direction": "in",
                     "xtick.major.width": 0.6, "ytick.major.width": 0.6,
                     "xtick.top": True, "ytick.right": True, "pdf.fonttype": 42})
# applied only to the admission figures (rc_context below); the package
# execution figure keeps the defaults it was drawn with

# The three two step implementations get the first three categorical slots
# (checked for colour vision deficiency) and their own marker and line style;
# the three one step implementations admitted min(k, L) in every trial on both
# datastores, so they share one grey series (asserted below, not assumed).
TWO_STEP = [("naive_count", "Count then insert", "#2a78d6", "o", "-"),
            ("cache_get_set", "Read modify write counter", "#eb6834", "s", "--"),
            ("after_send", "Increment after send", "#1baf7a", "^", "-.")]
ONE_STEP = ("atomic_update", "immediate_txn", "reserve_commit")


def quart(v):
    import statistics as st
    v = sorted(v)
    q = st.quantiles(v, n=4)        # exclusive, as regenerate.py and the supplement
    return st.median(v), q[0], q[2], v[0], v[-1]


def admissions_figure(data, ks, limit, out):
    """Admissions per trial against k: the median of the 30 trials (marker),
    the interquartile range (thick bar; exclusive quartiles, as in
    regenerate.py) and the range (thin bar). The series are offset sideways
    so that coincident markers stay visible."""
    import math
    with plt.rc_context(RC):
        _admissions_figure(data, ks, limit, out, math)


def _admissions_figure(data, ks, limit, out, math):
    for s in ONE_STEP:
        for k in ks:
            assert all(v == min(k, limit) for v in data[(s, k)]), (s, k)
    fig, ax = plt.subplots(figsize=(3.45, 2.55))
    x = [math.log2(k) for k in ks]
    ax.plot(x, ks, color="0.55", lw=0.7, ls=":", zorder=1)
    ax.text(math.log2(16) - 0.12, 17.0, "all $k$ admitted", ha="right", va="bottom",
            fontsize=6.5, color="0.35")
    ax.axhline(limit, color="black", lw=0.8, ls=(0, (4, 2)), zorder=1)
    ax.text(-0.2, limit + 0.5, f"declared limit $L={limit}$", fontsize=6.5,
            va="bottom", ha="left")
    ax.plot([xi - 0.21 for xi in x], [min(k, limit) for k in ks], color="0.45", lw=1.0, marker="o",
            ms=3.6, mfc="white", mec="0.35", mew=0.8, zorder=2,
            label="One step implementations (all three)")
    for j, (s, lab, col, mk, ls) in enumerate(TWO_STEP):
        dx = -0.07 + j * 0.14
        xs = [xi + dx for xi in x]
        q = [quart(data[(s, k)]) for k in ks]
        ax.vlines(xs, [r[3] for r in q], [r[4] for r in q], color=col, lw=0.6, zorder=3)
        ax.vlines(xs, [r[1] for r in q], [r[2] for r in q], color=col, lw=1.9, zorder=3)
        ax.plot(xs, [r[0] for r in q], color=col, lw=1.0, ls=ls, marker=mk, ms=3.8,
                mec="white", mew=0.5, zorder=4, label=lab)
    ax.set_xticks(x)
    ax.set_xticklabels([str(k) for k in ks])
    ax.set_xlim(-0.45, x[-1] + 0.45)
    ax.set_ylim(0, 34)
    ax.set_yticks([0, 3, 8, 16, 24, 32])
    ax.set_xlabel("Simultaneous requests $k$")
    ax.set_ylabel("Admissions per trial")
    ax.grid(axis="y", color="0.88", lw=0.5)
    ax.set_axisbelow(True)
    ax.legend(loc="upper left", fontsize=6.5, frameon=True, framealpha=1.0,
              edgecolor="0.7", fancybox=False, handlelength=2.6, borderpad=0.4)
    fig.tight_layout(pad=0.2)
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print("wrote", out)


def main():
    sq = load(f"{ROOT}/results/r4/main_sqlite.csv")
    pg = load(f"{ROOT}/results/r4/main_postgres.csv")
    ks = [1, 2, 4, 8, 16, 32]
    admissions_figure(sq, ks, 3, f"{ROOT}/paper/fig_admissions_sqlite.pdf")
    admissions_figure(pg, ks, 3, f"{ROOT}/paper/fig_admissions_postgres.pdf")

    pkgexec_figure(ks, f"{ROOT}/paper/fig_pkgexec.pdf")


def pkgexec_figure(ks, out):
    """django-otp 1.7.3 executed as shipped: tokens delivered per trial against
    the number of calls released. Every simultaneous trial is one dot (dots
    with the same count are spread sideways so each stays visible), the line
    joins the medians, and the sequential trials (all exactly one, asserted
    below) are one grey series."""
    import math
    from collections import Counter
    d = defaultdict(list)
    for r in csv.DictReader(open(f"{ROOT}/results/r4/pkg_exec.csv")):
        d[(r["mode"], int(r["concurrency"]))].append(int(r["deliveries"]))
    for k in ks:
        assert all(v == 1 for v in d[("sequential", k)]), k
    with plt.rc_context(RC):
        import statistics as st
        fig, ax = plt.subplots(figsize=(3.45, 2.45))
        x = [math.log2(k) for k in ks]
        ax.plot(x, ks, color="0.55", lw=0.7, ls=":", zorder=1)
        ax.text(math.log2(8) - 0.15, 8.6, "all $k$ delivered", ha="right", va="bottom",
                fontsize=6.5, color="0.35")
        ax.axhline(1, color="black", lw=0.8, ls=(0, (4, 2)), zorder=1)
        ax.text(x[-1] + 0.55, -0.55, "dashed: declared limit of one token", fontsize=6.5, va="bottom", ha="right")
        for xi, k in zip(x, ks):
            cnt = Counter(d[("concurrent", k)])
            for v, c in sorted(cnt.items()):
                step = min(0.024, 0.62 / max(c - 1, 1))
                offs = [(i - (c - 1) / 2) * step for i in range(c)]
                ax.scatter([xi + 0.12 + o for o in offs], [v] * c, s=7, color="#2a78d6",
                           alpha=0.75, linewidths=0, zorder=3)
        med = [st.median(d[("concurrent", k)]) for k in ks]
        ax.plot([xi + 0.12 for xi in x], med, color="#1b4f8f", lw=1.1, marker="D", ms=3.4,
                mec="white", mew=0.5, zorder=4, label="Released simultaneously (median)")
        ax.plot([xi - 0.3 for xi in x], [1] * len(ks), color="0.45", lw=1.0, marker="s", ms=3.4,
                mfc="white", mec="0.35", mew=0.8, zorder=4, label="Released one at a time (all trials)")
        ax.scatter([], [], s=7, color="#2a78d6", alpha=0.75, label="One simultaneous trial")
        ax.set_xticks(x)
        ax.set_xticklabels([str(k) for k in ks])
        ax.set_xlim(-0.6, x[-1] + 0.6)
        ax.set_ylim(-0.8, 17.5)
        ax.set_yticks([1, 4, 8, 12, 16])
        ax.set_xlabel("Calls released $k$")
        ax.set_ylabel("Tokens delivered per trial")
        ax.grid(axis="y", color="0.88", lw=0.5)
        ax.set_axisbelow(True)
        ax.legend(loc="upper left", fontsize=6.5, frameon=True, framealpha=1.0,
                  edgecolor="0.7", fancybox=False, handlelength=2.2, borderpad=0.4)
        fig.tight_layout(pad=0.2)
        fig.savefig(out, bbox_inches="tight")
        plt.close(fig)
    print("wrote", out)


def pgf_coords():
    """Write the coordinates of Fig. S4 (medians against k) and Fig. S5 (k=32,
    simultaneous against sequential) for pgfplots, from the round-4 files."""
    import statistics as st
    G = f"{ROOT}/paper/gen"
    os.makedirs(G, exist_ok=True)
    sq = load(f"{ROOT}/results/r4/main_sqlite.csv")
    seq = load(f"{ROOT}/results/r4/sequential.csv")
    ks = [1, 2, 4, 8, 16, 32]
    med = {s: [st.median(sq[(s, k)]) for k in ks] for s in ORDER}
    styles = {
        "after_send": ("blue!65!black, thick, mark=*, mark size=1.7pt", "Increment after send"),
        "cache_get_set": ("orange!80!black, thick, dashdotted, mark=square*, mark size=1.7pt", "Read modify write"),
        "naive_count": ("teal!70!black, thick, densely dotted, mark=triangle*, mark size=2.2pt", "Count then insert"),
        "immediate_txn": ("black!60, thick, mark=o, mark size=3.6pt, mark options={line width=0.9pt}", "Guarded write transaction"),
        "atomic_update": ("black!72, thick, mark=diamond*, mark size=2.2pt", "Conditional atomic update"),
        "reserve_commit": ("red!60!black, thick, densely dashdotted, mark=x, mark size=2.4pt, mark options={line width=0.9pt}", "Reserve before send"),
    }
    with open(f"{G}/fig_concurrency.tex", "w") as f:
        f.write("% generated by study/make_figs.py from results/r4/main_sqlite.csv; do not edit\n")
        for s in ("after_send", "cache_get_set", "naive_count", "immediate_txn", "atomic_update", "reserve_commit"):
            pts = "".join(f"({k},{m:g})" for k, m in zip(ks, med[s]))
            f.write(f"\\addplot[{styles[s][0]}]\n  coordinates {{{pts}}};\n\\addlegendentry{{{styles[s][1]}}}\n")
    short = {"naive_count": "Count insert", "cache_get_set": "Read mod write", "after_send": "After send",
             "atomic_update": "Atomic update", "immediate_txn": "Guarded txn", "reserve_commit": "Reserve"}
    with open(f"{G}/fig_seqvscon.tex", "w") as f:
        f.write("% generated by study/make_figs.py from results/r4/{main_sqlite,sequential}.csv; do not edit\n")
        con = " ".join(f"({st.median(sq[(s, 32)]):g},{short[s]})" for s in ORDER)
        sq32 = " ".join(f"({st.median(seq[(s, 32)]):g},{short[s]})" for s in ORDER)
        f.write("\\addplot[fill=blue!25, draw=blue!60!black, postaction={pattern=north east lines,\n"
                "         pattern color=blue!55!black}] coordinates {\n  " + con + "};\n"
                "\\addlegendentry{Released simultaneously}\n")
        f.write("\\addplot[fill=black!12, draw=black!55] coordinates {\n  " + sq32 + "};\n"
                "\\addlegendentry{Released one at a time}\n")
    print("wrote", f"{G}/fig_concurrency.tex", f"{G}/fig_seqvscon.tex")


if __name__ == "__main__":
    main()
    pgf_coords()
