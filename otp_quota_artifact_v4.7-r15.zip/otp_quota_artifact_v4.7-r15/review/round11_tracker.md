# Round 11 tracker: author's four requests (Sep 25, 2026) → manuscript v4.3, artifact v4.3-r11

| # | Request | Status | What was done |
|---|---|---|---|
| 1 | Check the manuscript is complete; no reference without a citation | DONE | 47 printed references, all cited; every citation and cross-reference resolves; all 7 tables and 3 figures referred to in the text; no unresolved marker or author note in the PDF. 3 uncited entries removed from `references.bib` (never printed) |
| 2 | Merge Sections VI and VII and shorten, or delete them | DONE (merged) | "VI. Discussion and Limitations", about 1,000 words (was about 1,520). Not deleted: Sections III and IV point to its recommendations, and the limitations hold the qualifications earlier reviews required |
| 3 | Shorten the conclusion to the given structure | DONE | 2 paragraphs, about 240 words (was about 450): objective, synthesis, significance, limitations and future work; no new data or citations; heading "Conclusion" |
| 4 | Rewrite the abstract (150 to 300 words; background, gap, methods, results, implication) | DONE | 244 words (within IEEE Access's 250); one paragraph in the requested order |

No reported number changed. Every number in the new abstract and conclusion already appears in the body. The IEEEtran proof is 15 pages and passes the gate. The IEEE Access source compiles against a stand-in class with no errors or undefined references.

An independent accuracy check of the new text against the Results and `paper_numbers.json` found wording that claimed more than the body does; the text now says "in their own code", "the worst by 10.7 times", "the email device" and "showed no policy violation". It also found qualifications the merge had dropped (claim scope, PostgreSQL timing, unknown provider outcome, abuse path 1). All were fixed.
