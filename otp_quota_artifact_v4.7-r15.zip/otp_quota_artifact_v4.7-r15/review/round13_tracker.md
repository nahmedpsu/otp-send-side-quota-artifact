# Round 13 tracker: author's five requests on v4.4 (Oct 8, 2026) → manuscript v4.5, artifact v4.5-r13

| # | Request | Status | What was done |
|---|---|---|---|
| 1 | A diagram of the methodology | DONE | New Fig. 3 (full width, start of Section IV): Study 1 and Study 2 as two lanes with the count at each stage; introduced in a new opening paragraph |
| 2 | Extract the algorithms behind the implementation from GitHub and add them in academic format | DONE | Repository visited: it holds a README and the v3.4-r6 archive, which this session could not download (repository access not enabled). Algorithms 1 to 4 taken from the same code in the artifact (`svc/app.py`, `svc/app_pg.py`, `study/run_experiments.py`, `study/policy.py`, `study/survey_discover.py`, `study/survey_scope2.py`), set with `algorithm` and `algpseudocode`, each in the section that describes it |
| 3 | Make Fig. 2 less machine looking; may split it in two | DONE | Replaced by Figs. 4 (SQLite) and 5 (PostgreSQL): conventional line and range plots, Times type, colorblind checked colors plus markers and line styles; statistics equal to `paper_numbers.json` |
| 4 | A visual for the threat model | DONE | New Fig. 2: bow tie from the five abuse paths, through the requirement that blocks each (R1 to R4, now labeled in the text), to one unintended provider call and its three outcomes; adversary, limits and trust below |
| 5 | Cite every reference, figure, table and algorithm in the main text | DONE | 45 references, 6 figures, 7 tables, 4 algorithms, all cited in running text, each before or on its page; the 2 bibliography entries left uncited by the v4.4 removal of the Acknowledgment deleted; the supplement's Fig. 3 pointer now Fig. 6 |

Correction found while extracting Algorithm 3: the Study 1 text described a name filter the code does not use (it would have missed 8 of the 991 names). The paragraph now gives the code's eleven patterns, the 27 names with no metadata, and the exact summary filter. The detector name test, the validation sample, a Table III row label and the `window_source` sentence were made exact as well. No count changed.

No reported number changed: `paper_numbers.json` is identical to v4.3-r11 apart from the version, and `overrun_classification.csv` is byte identical. The IEEEtran proof is 16 pages and passes the gate. The IEEE Access source builds against the stand-in class (17 pages there). An independent check of the algorithms against the code, the plots against the trial files, and the new wording found a quartile method mismatch in the first plots and several inexact phrasings; all were fixed and rechecked.

Unchanged from v4.4 as the author wrote it: the funding line (typos flagged), the shortened captions, and the removal of the Acknowledgment (AI disclosure, which IEEE requires, is now only in the cover letter).
