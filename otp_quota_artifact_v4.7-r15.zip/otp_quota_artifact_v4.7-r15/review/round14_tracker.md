# Round 14 tracker: Fig. 6 and short captions (Oct 8, 2026) → manuscript v4.6, artifact v4.6-r14

| # | Request | Status | What was done |
|---|---|---|---|
| 1 | Make Fig. 6 look less machine generated | DONE | Redrawn like Figs. 4 and 5: every simultaneous trial as a dot, medians joined, sequential trials (all one token, asserted) as a grey series, limit dashed, k dotted; the supplement's Table S10 keeps every trial |
| 2 | Short, concise captions for all figures, tables and algorithms | DONE | All 17 captions in the paper and 18 in the supplement are now short titles; Fig. 1 keeps the author's caption; typos fixed ("verficiation", "send-side"). What the long captions explained (table notation, column meanings, plot encoding) now sits in the sentence that first cites each float |

No reported number changed. Proof 16 pages, supplement 7 pages, both gates passed.
