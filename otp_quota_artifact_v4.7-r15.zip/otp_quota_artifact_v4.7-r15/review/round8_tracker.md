# Round 8 tracker: language edit report (Paperpal, 25 September 2026) and length → manuscript v4.0, artifact v4.0-r8

Page numbers refer to `manuscript_v4.0.pdf` (15 pages), compiled by `paper/build.sh` (exit 0, `manuscript_v4.0.gate.txt`).
No reported number changed. The service (2.1.0) and every record in `results/` are unchanged; `paper_numbers.json` differs from v3.5-r7 only in its version string.

| # | Item in the report | Status | What was done |
|---|---|---|---|
| L | Manuscript too long (27,605 words; the author asks for the usual 15 double column pages) | DONE | condensed from 30 to **15 pages**: body prose 21,000 → about 10,800 words; 20 tables and 8 figures → 7 tables and 3 figures. Everything removed is in a new **supplementary document** (`paper/supplement.tex`, 7 pages, Tables S1–S13, Figs. S1–S5, the complete artifact description), shipped with the artifact and cited from the main paper. The long form is kept as `paper/body_v3.5_full.tex` |
| 2 | Abstract too long (should be ≤ 200 words) | DONE | 267 → 207 words; OTP defined at first use (P8) |
| 3 | Abstract not structured | not applicable | IEEE Access uses an unstructured abstract; left unstructured |
| 4 | Missing word count | noted | not an IEEE Access element; the count is reported here: main text ≈ 10,800 words excluding references, tables and captions |
| 5 | Missing funding statement | OPEN (author) | a TODO comment marks the place in the Acknowledgment; the author must state the funding source (or none) in the first page footnote of the submission file |
| 6 | Missing ethics statement | DONE | Acknowledgment and Disclosures p.14: no human participants, personal data or animals, so no ethics approval; no real message sent, no provider or maintainer contacted |
| P1 | "results" vs "re-sults" | not an issue | a line break hyphenation in the PDF, not in the source |
| P7 | Month style ("Aug." vs "February") | not an issue | "Aug. 2023" is inside a reference formatted by the IEEEtran bibliography style; the text spells months out |
| P8 | Define OTP at first use in the abstract | DONE | "one time password (OTP)" |
| F | Figure legends out of order | DONE | the condensed paper's figures print in order (Fig. 1 p.4, Fig. 2 p.9, Fig. 3 p.10) and its tables I–VII in order; checked on the compiled PDF |
| R | References with no citations | not an issue | all 45 reference list entries are cited (checked against the .bbl and every \cite); the report's parser mis-read bracketed citations |
| PL | Missing plain language summary | not applicable | not an IEEE Access element |
| E | Tracked language edits (grammar, American spelling: organizations, analogs, defenses, 30 seconds, …) | DONE in spirit | the condensed text was rewritten in American spelling throughout (checked by word list); the grammar edits were absorbed in the rewrite. **The report also re-inserts hyphens in compounds ("one-time", "send-side", "end-to-end"); this conflicts with the author's round 7 instruction to remove hyphens between words, so hyphens were kept out.** Reversing this is mechanical if the author prefers Paperpal's form |

## What the condensed paper keeps and where the rest went
- Main paper: Introduction; Background and Related Work (prose only); System and Threat Model (Fig. 1); Methodology (Table I provenance, Table II arms); Results (Table III funnel+evidence, Table IV crosstab, Table V SQLite sweep, Fig. 2 all trials, Table VI PostgreSQL, Fig. 3 executed package, Table VII interleaving); Discussion; Threats; Conclusion; Data and Code Availability.
- Supplement: terms (S1), guidance (S2), prior work comparison (S3), vantage figure (S1), study design figure (S2), patterns (S4), every arm incl. historical (S5), race diagram (S3), channel (S6), benchmark (S7), quartiles (S8), medians figure (S4), sequential vs concurrent (S5), latency (S9), executed package table (S10), timing (S11), interleaving in full (S12), boundary tests (S13), the provenance check arm, the historical anomaly, the artifact in full.

## Independent check after condensation
An agent compared every number in v4.0 with `paper_numbers.json` and every claim with the long form. One error introduced by the condensation was found and fixed (the latency control had been generalized to "30 of 30 at every latency"; count then insert exceeded the limit in 27, 28 and 29 of 30 at 10, 50 and 200 ms, as Table S9 shows); fourteen qualifications the long form treated as essential and the condensation had dropped were restored (framework throttles not measured; architecture not neutral; remedies proposed not observed; the fastapi-otp-auth difference in Table I; single threaded deployments outside the model; four latency settings cannot exclude every provider behavior; one factor sweeps; the limit arm's window; deployment caveats for the executed package; the operator question not studied; regenerate.py cannot check the service; server shared within an arm).

## Author actions still open
Funding statement; biography; confirm the AI use sentence; django-otp notification date (§V-E); upload the v4.0-r8 archive to the GitHub repository.
