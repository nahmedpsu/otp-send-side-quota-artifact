# Round 9 tracker: second language edit report (Paperpal, September 25, 2026, on manuscript v4.0) → manuscript v4.1, artifact v4.1-r9

Page numbers refer to `manuscript_v4.1.pdf` (15 pages), compiled by `paper/build.sh` (exit 0, `manuscript_v4.1.gate.txt`); the supplement is 7 pages (`supplement_v4.1.gate.txt`). Every table and figure prints on the same page as in v4.0.
No reported number changed. The service (2.1.0) and every record in `results/` are unchanged; `paper_numbers.json` differs from v4.0-r8 only in its version string, and `overrun_classification.csv` is byte for byte identical.

## The report's comments

| # | Item | Status | What was done |
|---|---|---|---|
| 1 | Abstract longer than 200 words | DONE | 207 → 196 words (at most 200 even if hyphenated names and version numbers are split); same claims; now names both datastores (p.1) |
| 2 | Abstract not structured | not applicable | IEEE Access prints one unstructured paragraph |
| 3 | No word count | noted | not an IEEE Access element; the inserted line was not kept. Main text ≈ 11,100 words excluding references, tables and captions (the report's 13,579 includes tables and captions) |
| 4 | Missing funding statement | **OPEN (author)** | the report inserted a template with placeholder grants ("grant NN from the Foundation of Basic Research"), not kept. `otp_ieee_access.tex` now has two ready `\tfootnote` lines (funder and grant, or no specific grant); uncomment one |
| P5 | Define OTP at first use in the main text | already done | OTP is defined in the abstract and again at first use in Section I (p.1); the comment sits on a later use in Section II. Also defined at first use: CI, NIST, OWASP, CWE, WAL (pp.1, 6); ASGI/WSGI and NAT replaced with plain words; "2FA" in Table III spelled out |
| S | Manuscript too long (2,500–4,000 words) | not applicable | the tool's generic default; the author's 15 page target is met |
| S | IMRaD | already met | Introduction; IV Methodology; V Results; VI Discussion, plus the customary IEEE sections |
| S | Plain language summary | not applicable | not an IEEE Access element |
| S | References with no citations | not an issue | BibTeX prints only cited entries; all 45 are cited |

## Tracked language edits

| Class | Status | Examples |
|---|---|---|
| Serial (Oxford) commas | ADOPTED, main text and supplement | "file, and function"; "worker count, and declared limit"; "1, 5, and 10" |
| Past tense for reported results (Section V) | ADOPTED | held, failed, matched, produced, was correct |
| "that" before relative clauses; "; therefore," | ADOPTED | "resources that the operator already owns"; "irreversible; therefore, any decision …" |
| "This study" for self reference | ADOPTED | Sections II and III |
| American dates | ADOPTED | September 22, 2026 in text; Sep. 22, 2026 in reference notes (IEEE style) |
| Small word fixes | ADOPTED | not money; as follows; requires; sufficient; the results; These 61; This cut |
| Edits that changed meaning | ADAPTED | "the case in ordinary testing" → "the case that ordinary testing misses"; "were used" → "held"; "For count, then insert" → "For count then insert, the window"; "Count then inserts admits" → "The count then insert pattern admits"; "and implementation permits" → "that an implementation permits"; guidance sentence rewritten as "Published guidance leaves open what the application itself should do." |
| Hyphens re-inserted in compounds (one-time, send-side, two-step, per-worker, …) | NOT ADOPTED | the author's round 7 instruction; hyphens remain only in names, identifiers, standard numbers, reference titles and verbatim quotations |
| Past tense for survey counts (Section V-A) | NOT ADOPTED | they describe code as shipped, in the present tense as in the abstract, Introduction and Conclusion |
| Edits caused by the tool's own text conversion (sentences split around tables; small capitals read as capital letters) | NOT APPLICABLE | nothing in the source |
| Single author | FIXED | "The authors will report" → "The author will report" (p.10); "Nobody outside the author group" → "Nobody other than the author" (p.13) |

## Found while rechecking (not in the report)

- **Wording error corrected:** Section V-D said the pooled PostgreSQL arm ran "at the two highest levels"; it ran at k = 8 and k = 32 (Table II, Table S12), the levels the same sentence reports. Numbers unchanged (p.9). The phrase came from the long form.
- **File names hyphenated at line breaks in v4.0** (`re-generate.py`, `overrun_classi-fication.csv`, `otp_quota_artifact_-v4.0-r8.zip`): identifiers are no longer hyphenated; lines may break after an underscore with no hyphen added (`\ident` in all three preambles).
- **Django REST Framework quotation** now starts at "The built-in throttle implementations …", checked against the live page; the hyphen is inside the quotation (p.3).
- **AI use statement** names the tools (Claude, Anthropic; Paperpal for language checks); author to confirm completeness (p.14).
- Build note removed from the preview's first page footnote; Elle reference's internal year note removed; `\markboth` running heads added to `otp_ieee_access.tex`.

## Verification

- Number by number comparison of the sources with v4.0. The only differences: "8" → "eight" (twice); "seventeen/ten" → "17/10" (Conclusion); "One thousand and eighty" → "1 080"; "k=8 and k=32" in the pooled sentence; the artifact version.
- An independent reviewer read every changed sentence against v4.0 and `paper_numbers.json`. It raised about a dozen wording and punctuation points and found the pooled arm error; all were fixed before the final compile.
- `regenerate.py` output identical apart from the version; notebook re-executed at the paper's trial counts (`notebooks/notebook_exec_round9.log`); manifest verify --strict, negative cases and compile gates on the unpacked archive.

## Author actions still open
Funding statement (uncomment one line in `otp_ieee_access.tex`); confirm the AI tools named; biography and ORCID; django-otp notification (§V-E states "As of September 23, 2026 … not notified"); upload the v4.1-r9 archive to the GitHub repository.
