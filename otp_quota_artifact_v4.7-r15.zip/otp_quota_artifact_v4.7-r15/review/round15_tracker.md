# Round 15 tracker: formal validation, related work, benchmark (Oct 8, 2026) → manuscript v4.7, artifact v4.7-r15

| # | Request | Status | What was done |
|---|---|---|---|
| 1 | Formal modeling with TLA+ and Tamarin | DONE | `formal/`: PlusCal model of the six designs checked with TLC (156 runs, L = 1..3, N up to L + 2): two step designs violate R1 iff N > L, one step designs never; shipped reserve before send violates R3 when a billed call raises, fixed by keeping the claim on unknown outcomes. Tamarin (any number of requests, L = 3): R1 proved for the one step designs, violating traces for the two step designs. Paper: IV-C, V-H, Tables IX and X |
| 2 | Introduction to formal modeling in the manuscript | DONE | Section II paragraph: TLA+, PlusCal, TLC, industrial use, ProVerif, Tamarin, ACIDRain |
| 3 | References for both tools | DONE | 11 new references (TLA+ book, TLC, AWS, Tamarin, Tamarin manual, ProVerif, ACIDRain, Django cache, django-ratelimit, SlowAPI, limits), checked against publisher or author pages |
| 2a | Comparison with related work | DONE | Table I |
| 2b | Benchmark of the six designs | DONE | Table XII, in Section VI |
| 2c | Benchmark of off-the-shelf limiters | DONE | Round 6 arm, 1,200 trials: SlowAPI and django-ratelimit in six configurations; Section V-I, Table XI |

No earlier number changed (all v4.6 keys of `paper_numbers.json` identical). Proof 19 pages, supplement 7 pages, both gates passed. An independent check of the models against the code and of every new number against the data led to a guarded transaction R3 model with faults, TLC sanity runs, a rerun of the library arm with the django-ratelimit app installed and a second sequential control, and several wording fixes.
