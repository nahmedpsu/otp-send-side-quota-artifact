# Round 7 tracker: author's corrections on manuscript v3.4 → manuscript v3.5, artifact v3.5-r7

Page numbers refer to `manuscript_v3.5.pdf` (30 pages), compiled by `paper/build.sh` (exit 0, `manuscript_v3.5.gate.txt`).
No reported number changed; the service (2.1.0) and the round 4 and round 5 records are unchanged.

| # | Item | Status | Where in v3.5 | Evidence |
|---|---|---|---|---|
| 1 | Abstract still said the historical runs "are retained but used for no number" | DONE | Abstract p.1 | now "Runs from earlier revisions, which kept no such records, are retained for comparison but do not replace or contribute to the reported results" (the requested sentence, with "the reported results" in place of "the Round 4 results" because rounds are not defined in the abstract) |
| 2 | Verifier accepted an unlisted symbolic link at the archive root | DONE (links rejected) | App. A p.27; README "Verification is strict" | `study/manifest.py`: `walk()` collects every symbolic link (file, directory, dangling, or in place of a listed file) without following it; `check()` fails on any; `write` refuses a tree containing one; five new negative tests (14 in all) in `study/test_manifest.py`, log `review/manifest_selftest_round7.txt`; the user's case (an unlisted link at the root of the unpacked v3.4-r6 archive) now prints `SYMLINK link-at-root`, `MANIFEST MISMATCH`, exit 1 |
| 3 | Abstract too long | DONE | Abstract p.1 | 524 words → 267 words; every retained number checked against `paper_numbers.json` |
| 4 | Table and figure captions too long | DONE | all 28 captions | longest now 62 words (Table XIX), most under 40; definitions the text still needs moved into the prose (Wilson intervals §V-B, the three extra SMS packages §V-B, quantile method §V-D, the "sent by email" consistency §V-H, Table XIX columns §V-J, the five abuse paths §III-C, the k=32 column reading of Fig. 8 §V-H) |
| 5 | No hyphens between words | DONE | whole manuscript | 380 mechanical replacements plus manual repairs; title, keywords, abstract, body, threat section, generated table labels and figure labels; kept only in package names, identifiers, labels, cite keys, URLs, the two search tokens listed in §IV-A (p.8), standards identifiers (CWE-367, SP 800-63B-4), bibliography titles, and two verbatim quotations ("built-in", "back-off") whose sources use them |
| 6 | Public repository link | DONE | §I contributions p.3; App. A p.27; README | https://github.com/nahmedpsu/otp-send-side-quota-artifact |

## Repairs made after the mechanical hyphen pass (independent check)
Two verbatim quotations restored (DRF "built-in", django-otp "back-off"); CWE-367 named "Time of check to time of use (TOCTOU)";
"producer and consumer" dependencies; "a counter held inside one process"; the django-otp-admin comment quoted as `nx=True`
("set-if-not-exists"); "Of these, 61 packages"; "anomaly investigation" (Table VI); "the round 4 audit moved"; the
one identity per trial limitation reworded; "deployments spread over several hosts"; Tables XVIII/XX header "Trials over".

## Author actions still open
Complete the biography; confirm the AI use sentence names the tools used; file the django-otp notification and record its date (§V-H).
