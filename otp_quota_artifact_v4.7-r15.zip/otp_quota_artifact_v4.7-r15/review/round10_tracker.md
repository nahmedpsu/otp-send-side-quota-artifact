# Round 10 tracker: author's Paperpal-revised Word file (Sep 25, 2026) → manuscript v4.2, artifact v4.2-r10, IEEE Access package

No reported number changed. An independent check of every changed sentence led to about fifteen further fixes, one of them a meaning fix in the Table VII caption. A token-by-token number comparison of the sources with v4.1 shows none. `paper_numbers.json` is identical apart from the version, and `overrun_classification.csv` is byte for byte identical.
The IEEEtran proof is 15 pages and passes the compile gate. The IEEE Access source compiles without errors against a stand-in class.

## The revised Word file (about 330 differences from v4.1)

| Class | Count | Decision |
|---|---|---|
| Grammar and wording edits (joins, commas, articles, "This study", "request ID", heading wording, captions, Acknowledgment) | about 100 | ADOPTED |
| Hyphens between ordinary words | about 90 | NOT ADOPTED: author's decision, Sep 25 |
| Thousands separators turned into ", " ("896, 086", "5, 220", "3, 157", "2, 430", "1, 080", "2, 088", "1, 858") | 12 | NOT ADOPTED: number corruption; thin space kept |
| Broken identifiers ("models. py", "&lt;arm&gt;. events.jsonl", "Fig.1", "Fig.3") | 4 | NOT ADOPTED |
| "authors" for a single author | 3 | NOT ADOPTED |
| Run-in headings turned into sentences ("This does not establish", "... include the following:", "... were as follows:", "Every overrun is classified", "The operations take") | 5 | NOT ADOPTED |
| Meaning changes ("42 were sampled", "not representative of the population", "window that starts", "call is raised", "has been researched", "were held", "increment after sending", "to defeat the latter", "pipeline, and audit", "Second, we built") | 10 | NOT ADOPTED |
| Duplicated sentence replacing "The nonmonotonic median ..." | 1 | NOT ADOPTED |
| Survey counts in past tense (11 still pending in the file, 1 accepted) | 12 | NOT ADOPTED: present tense as in abstract, Introduction and Conclusion |
| Kept intent, new wording ("reported that 67% of those endpoints lacked", "can tell them apart", "support a narrow conclusion", "requires new research", asymmetry sentence, "dynamic tests that teams write ... do not", "raises an exception", one tense in the abstract) | 8 | ADAPTED |
| Paperpal comments: define NIST, OWASP, OTP, CI | 4 | already defined at first use (Section I) |

## IEEE Access requirements (guidelines read Sep 25, 2026)

| Item | Done |
|---|---|
| `otp_ieee_access.tex`: missing `\begin{document}` | FIXED; the file would not have compiled with the official class |
| Funding footnote | "This research received no specific grant ..." (author confirmed) |
| Biography | affiliation and a line on what the author works on (inferred from this paper; to confirm); degrees for the author (TODO in the source) |
| AI disclosure with citation to the AI system | Claude [46], Paperpal [47] in the Acknowledgment |
| Graphical abstract, 660x295 JPEG, under 45 KB | `graphical_abstract.jpg`, 42 KB |
| Cover letter | one page, Word and PDF |
| Separate figure files | Fig. 1 (PDF and PNG), Figs. 2 and 3 (PDF) |
| Submission checklist | `SUBMISSION_CHECKLIST.md` |
| Official class | not downloadable here (host blocked); `build_access.sh` and the checklist give the steps |

## Author actions
- Compile with the official class and upload the matching PDF.
- Add an ORCID and your degrees to the biography.
- Confirm the cover letter's declarations and that the AI tools named are complete.
- Notify the django-otp maintainers, then update Section V-E.
- Upload v4.2-r10 to GitHub.
- If this is a resubmission, prepare the list of updates.
