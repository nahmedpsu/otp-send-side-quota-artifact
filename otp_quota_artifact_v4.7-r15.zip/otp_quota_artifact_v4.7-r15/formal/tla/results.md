| design | N | L | faults | spent on unknown | invariant | verdict | distinct states | counterexample states |
|---|---|---|---|---|---|---|---|---|
| CountThenInsert | 1 | 1 | False | False | R1 | holds | 6 |  |
| CountThenInsert | 2 | 1 | False | False | R1 | violated | 44 | 11 |
| CountThenInsert | 3 | 1 | False | False | R1 | violated | 248 | 11 |
| CountThenInsert | 2 | 1 | False | False | NotAllAdmitted | violated | 44 | 11 |
| CountThenInsert | 3 | 1 | False | False | NotAllAdmitted | violated | 384 | 16 |
| CountThenInsert | 1 | 1 | False | False | BelowLimit | violated | 6 | 6 |
| CountThenInsert | 1 | 2 | False | False | R1 | holds | 6 |  |
| CountThenInsert | 2 | 2 | False | False | R1 | holds | 52 |  |
| CountThenInsert | 3 | 2 | False | False | R1 | violated | 618 | 16 |
| CountThenInsert | 4 | 2 | False | False | R1 | violated | 6206 | 16 |
| CountThenInsert | 3 | 2 | False | False | NotAllAdmitted | violated | 618 | 16 |
| CountThenInsert | 4 | 2 | False | False | NotAllAdmitted | violated | 9058 | 21 |
| CountThenInsert | 2 | 2 | False | False | BelowLimit | violated | 50 | 11 |
| CountThenInsert | 1 | 3 | False | False | R1 | holds | 6 |  |
| CountThenInsert | 2 | 3 | False | False | R1 | holds | 52 |  |
| CountThenInsert | 3 | 3 | False | False | R1 | holds | 696 |  |
| CountThenInsert | 4 | 3 | False | False | R1 | violated | 12628 | 21 |
| CountThenInsert | 5 | 3 | False | False | R1 | violated | 205148 | 21 |
| CountThenInsert | 4 | 3 | False | False | NotAllAdmitted | violated | 12628 | 21 |
| CountThenInsert | 5 | 3 | False | False | NotAllAdmitted | violated | 268371 | 26 |
| CountThenInsert | 3 | 3 | False | False | BelowLimit | violated | 681 | 16 |
| ReadModifyWrite | 1 | 1 | False | False | R1 | holds | 6 |  |
| ReadModifyWrite | 2 | 1 | False | False | R1 | violated | 44 | 11 |
| ReadModifyWrite | 3 | 1 | False | False | R1 | violated | 248 | 11 |
| ReadModifyWrite | 2 | 1 | False | False | NotAllAdmitted | violated | 44 | 11 |
| ReadModifyWrite | 3 | 1 | False | False | NotAllAdmitted | violated | 360 | 16 |
| ReadModifyWrite | 1 | 1 | False | False | BelowLimit | violated | 6 | 6 |
| ReadModifyWrite | 1 | 2 | False | False | R1 | holds | 6 |  |
| ReadModifyWrite | 2 | 2 | False | False | R1 | holds | 52 |  |
| ReadModifyWrite | 3 | 2 | False | False | R1 | violated | 615 | 16 |
| ReadModifyWrite | 4 | 2 | False | False | R1 | violated | 5820 | 16 |
| ReadModifyWrite | 3 | 2 | False | False | NotAllAdmitted | violated | 615 | 16 |
| ReadModifyWrite | 4 | 2 | False | False | NotAllAdmitted | violated | 8792 | 21 |
| ReadModifyWrite | 2 | 2 | False | False | BelowLimit | violated | 50 | 11 |
| ReadModifyWrite | 1 | 3 | False | False | R1 | holds | 6 |  |
| ReadModifyWrite | 2 | 3 | False | False | R1 | holds | 52 |  |
| ReadModifyWrite | 3 | 3 | False | False | R1 | holds | 672 |  |
| ReadModifyWrite | 4 | 3 | False | False | R1 | violated | 11612 | 21 |
| ReadModifyWrite | 5 | 3 | False | False | R1 | violated | 170158 | 21 |
| ReadModifyWrite | 4 | 3 | False | False | NotAllAdmitted | violated | 11612 | 21 |
| ReadModifyWrite | 5 | 3 | False | False | NotAllAdmitted | violated | 235731 | 26 |
| ReadModifyWrite | 3 | 3 | False | False | BelowLimit | violated | 657 | 16 |
| IncrementAfterSend | 1 | 1 | False | False | R1 | holds | 6 |  |
| IncrementAfterSend | 2 | 1 | False | False | R1 | violated | 35 | 9 |
| IncrementAfterSend | 3 | 1 | False | False | R1 | violated | 121 | 9 |
| IncrementAfterSend | 2 | 1 | False | False | NotAllAdmitted | violated | 35 | 9 |
| IncrementAfterSend | 3 | 1 | False | False | NotAllAdmitted | violated | 270 | 13 |
| IncrementAfterSend | 1 | 1 | False | False | BelowLimit | violated | 5 | 5 |
| IncrementAfterSend | 1 | 2 | False | False | R1 | holds | 6 |  |
| IncrementAfterSend | 2 | 2 | False | False | R1 | holds | 44 |  |
| IncrementAfterSend | 3 | 2 | False | False | R1 | violated | 314 | 13 |
| IncrementAfterSend | 4 | 2 | False | False | R1 | violated | 1456 | 13 |
| IncrementAfterSend | 3 | 2 | False | False | NotAllAdmitted | violated | 314 | 13 |
| IncrementAfterSend | 4 | 2 | False | False | NotAllAdmitted | violated | 3789 | 17 |
| IncrementAfterSend | 2 | 2 | False | False | BelowLimit | violated | 35 | 9 |
| IncrementAfterSend | 1 | 3 | False | False | R1 | holds | 6 |  |
| IncrementAfterSend | 2 | 3 | False | False | R1 | holds | 44 |  |
| IncrementAfterSend | 3 | 3 | False | False | R1 | holds | 432 |  |
| IncrementAfterSend | 4 | 3 | False | False | R1 | violated | 3924 | 17 |
| IncrementAfterSend | 5 | 3 | False | False | R1 | violated | 23271 | 17 |
| IncrementAfterSend | 4 | 3 | False | False | NotAllAdmitted | violated | 3924 | 17 |
| IncrementAfterSend | 5 | 3 | False | False | NotAllAdmitted | violated | 65515 | 21 |
| IncrementAfterSend | 3 | 3 | False | False | BelowLimit | violated | 314 | 13 |
| ConditionalUpdate | 1 | 1 | False | False | R1 | holds | 5 |  |
| ConditionalUpdate | 2 | 1 | False | False | R1 | holds | 28 |  |
| ConditionalUpdate | 3 | 1 | False | False | R1 | holds | 152 |  |
| ConditionalUpdate | 1 | 1 | False | False | BelowLimit | violated | 4 | 4 |
| ConditionalUpdate | 1 | 2 | False | False | R1 | holds | 5 |  |
| ConditionalUpdate | 2 | 2 | False | False | R1 | holds | 25 |  |
| ConditionalUpdate | 3 | 2 | False | False | R1 | holds | 152 |  |
| ConditionalUpdate | 4 | 2 | False | False | R1 | holds | 976 |  |
| ConditionalUpdate | 2 | 2 | False | False | BelowLimit | violated | 21 | 7 |
| ConditionalUpdate | 1 | 3 | False | False | R1 | holds | 5 |  |
| ConditionalUpdate | 2 | 3 | False | False | R1 | holds | 25 |  |
| ConditionalUpdate | 3 | 3 | False | False | R1 | holds | 125 |  |
| ConditionalUpdate | 4 | 3 | False | False | R1 | holds | 760 |  |
| ConditionalUpdate | 5 | 3 | False | False | R1 | holds | 5312 |  |
| ConditionalUpdate | 3 | 3 | False | False | BelowLimit | violated | 111 | 10 |
| GuardedTransaction | 1 | 1 | False | False | R1 | holds | 7 |  |
| GuardedTransaction | 2 | 1 | False | False | R1 | holds | 44 |  |
| GuardedTransaction | 3 | 1 | False | False | R1 | holds | 284 |  |
| GuardedTransaction | 1 | 1 | False | False | BelowLimit | violated | 7 | 7 |
| GuardedTransaction | 1 | 2 | False | False | R1 | holds | 7 |  |
| GuardedTransaction | 2 | 2 | False | False | R1 | holds | 44 |  |
| GuardedTransaction | 3 | 2 | False | False | R1 | holds | 308 |  |
| GuardedTransaction | 4 | 2 | False | False | R1 | holds | 2384 |  |
| GuardedTransaction | 2 | 2 | False | False | BelowLimit | violated | 43 | 13 |
| GuardedTransaction | 1 | 3 | False | False | R1 | holds | 7 |  |
| GuardedTransaction | 2 | 3 | False | False | R1 | holds | 44 |  |
| GuardedTransaction | 3 | 3 | False | False | R1 | holds | 308 |  |
| GuardedTransaction | 4 | 3 | False | False | R1 | holds | 2576 |  |
| GuardedTransaction | 5 | 3 | False | False | R1 | holds | 24112 |  |
| GuardedTransaction | 3 | 3 | False | False | BelowLimit | violated | 303 | 19 |
| ReserveBeforeSend | 1 | 1 | False | False | R1 | holds | 5 |  |
| ReserveBeforeSend | 2 | 1 | False | False | R1 | holds | 28 |  |
| ReserveBeforeSend | 3 | 1 | False | False | R1 | holds | 152 |  |
| ReserveBeforeSend | 1 | 1 | False | False | BelowLimit | violated | 4 | 4 |
| ReserveBeforeSend | 1 | 2 | False | False | R1 | holds | 5 |  |
| ReserveBeforeSend | 2 | 2 | False | False | R1 | holds | 25 |  |
| ReserveBeforeSend | 3 | 2 | False | False | R1 | holds | 152 |  |
| ReserveBeforeSend | 4 | 2 | False | False | R1 | holds | 976 |  |
| ReserveBeforeSend | 2 | 2 | False | False | BelowLimit | violated | 21 | 7 |
| ReserveBeforeSend | 1 | 3 | False | False | R1 | holds | 5 |  |
| ReserveBeforeSend | 2 | 3 | False | False | R1 | holds | 25 |  |
| ReserveBeforeSend | 3 | 3 | False | False | R1 | holds | 125 |  |
| ReserveBeforeSend | 4 | 3 | False | False | R1 | holds | 760 |  |
| ReserveBeforeSend | 5 | 3 | False | False | R1 | holds | 5312 |  |
| ReserveBeforeSend | 3 | 3 | False | False | BelowLimit | violated | 111 | 10 |
| ConditionalUpdate | 1 | 1 | True | False | R3 | holds | 9 |  |
| ConditionalUpdate | 2 | 1 | True | False | R3 | holds | 60 |  |
| ConditionalUpdate | 3 | 1 | True | False | R3 | holds | 344 |  |
| ConditionalUpdate | 1 | 2 | True | False | R3 | holds | 9 |  |
| ConditionalUpdate | 2 | 2 | True | False | R3 | holds | 81 |  |
| ConditionalUpdate | 3 | 2 | True | False | R3 | holds | 680 |  |
| ConditionalUpdate | 4 | 2 | True | False | R3 | holds | 4944 |  |
| ConditionalUpdate | 1 | 3 | True | False | R3 | holds | 9 |  |
| ConditionalUpdate | 2 | 3 | True | False | R3 | holds | 81 |  |
| ConditionalUpdate | 3 | 3 | True | False | R3 | holds | 729 |  |
| ConditionalUpdate | 4 | 3 | True | False | R3 | holds | 6904 |  |
| ConditionalUpdate | 5 | 3 | True | False | R3 | holds | 59392 |  |
| GuardedTransaction | 1 | 1 | True | False | R3 | holds | 9 |  |
| GuardedTransaction | 2 | 1 | True | False | R3 | holds | 72 |  |
| GuardedTransaction | 3 | 1 | True | False | R3 | holds | 524 |  |
| GuardedTransaction | 1 | 2 | True | False | R3 | holds | 9 |  |
| GuardedTransaction | 2 | 2 | True | False | R3 | holds | 88 |  |
| GuardedTransaction | 3 | 2 | True | False | R3 | holds | 908 |  |
| GuardedTransaction | 4 | 2 | True | False | R3 | holds | 8496 |  |
| GuardedTransaction | 1 | 3 | True | False | R3 | holds | 9 |  |
| GuardedTransaction | 2 | 3 | True | False | R3 | holds | 88 |  |
| GuardedTransaction | 3 | 3 | True | False | R3 | holds | 1100 |  |
| GuardedTransaction | 4 | 3 | True | False | R3 | holds | 14640 |  |
| GuardedTransaction | 5 | 3 | True | False | R3 | holds | 170192 |  |
| ReserveBeforeSend | 1 | 1 | True | False | R3 | holds | 9 |  |
| ReserveBeforeSend | 2 | 1 | True | False | R3 | violated | 64 | 8 |
| ReserveBeforeSend | 3 | 1 | True | False | R3 | violated | 226 | 8 |
| ReserveBeforeSend | 1 | 2 | True | False | R3 | holds | 9 |  |
| ReserveBeforeSend | 2 | 2 | True | False | R3 | holds | 81 |  |
| ReserveBeforeSend | 3 | 2 | True | False | R3 | violated | 636 | 11 |
| ReserveBeforeSend | 4 | 2 | True | False | R3 | violated | 2807 | 11 |
| ReserveBeforeSend | 1 | 3 | True | False | R3 | holds | 9 |  |
| ReserveBeforeSend | 2 | 3 | True | False | R3 | holds | 81 |  |
| ReserveBeforeSend | 3 | 3 | True | False | R3 | holds | 729 |  |
| ReserveBeforeSend | 4 | 3 | True | False | R3 | violated | 6028 | 14 |
| ReserveBeforeSend | 5 | 3 | True | False | R3 | violated | 31329 | 14 |
| ReserveBeforeSend | 1 | 1 | True | True | R3 | holds | 9 |  |
| ReserveBeforeSend | 2 | 1 | True | True | R3 | holds | 73 |  |
| ReserveBeforeSend | 3 | 1 | True | True | R3 | holds | 519 |  |
| ReserveBeforeSend | 1 | 2 | True | True | R3 | holds | 9 |  |
| ReserveBeforeSend | 2 | 2 | True | True | R3 | holds | 81 |  |
| ReserveBeforeSend | 3 | 2 | True | True | R3 | holds | 807 |  |
| ReserveBeforeSend | 4 | 2 | True | True | R3 | holds | 7217 |  |
| ReserveBeforeSend | 1 | 3 | True | True | R3 | holds | 9 |  |
| ReserveBeforeSend | 2 | 3 | True | True | R3 | holds | 81 |  |
| ReserveBeforeSend | 3 | 3 | True | True | R3 | holds | 729 |  |
| ReserveBeforeSend | 4 | 3 | True | True | R3 | holds | 8009 |  |
| ReserveBeforeSend | 5 | 3 | True | True | R3 | holds | 84043 |  |
