"""Run TLC on Admission.tla for every design and bound in the paper's table.

For each (design, N, L, provider faults, release rule, invariant) it writes a
TLC configuration, runs the model checker with breadth first search (so a
reported counterexample is a shortest one), and records the verdict, the
number of distinct states, and the length of any counterexample. Output:
results.json and results.md beside this script; the first counterexample of
each design is kept in traces/.

    python3 formal/tla/run_tlc.py [path/to/tla2tools.jar]
"""
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
JAR = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("TLA2TOOLS", "tla2tools.jar")
TWO = ["CountThenInsert", "ReadModifyWrite", "IncrementAfterSend"]
ONE = ["ConditionalUpdate", "GuardedTransaction", "ReserveBeforeSend"]

runs = []
for design in TWO + ONE:
    for L in (1, 2, 3):
        for N in range(1, L + 3):              # up to two more requests than the limit
            runs.append(dict(design=design, N=N, L=L, faults=False, spent=False, inv="R1"))
        if design in TWO:
            # can every one of N > L requests be admitted?
            for N in (L + 1, L + 2):
                runs.append(dict(design=design, N=N, L=L, faults=False, spent=False, inv="NotAllAdmitted"))
        # sanity: the limit itself is reachable, so a verdict of no violation is not vacuous
        runs.append(dict(design=design, N=L, L=L, faults=False, spent=False, inv="BelowLimit"))
for design in ONE:                              # R3: the provider may fail or time out
    for spent in ((False, True) if design == "ReserveBeforeSend" else (False,)):
        for L in (1, 2, 3):
            for N in range(1, L + 3):
                runs.append(dict(design=design, N=N, L=L, faults=True, spent=spent, inv="R3"))


def run(r):
    name = f"{r['design']}_N{r['N']}_L{r['L']}_{r['inv']}{'_faults' if r['faults'] else ''}{'_spent' if r['spent'] else ''}"
    cfg = os.path.join(HERE, "cfg", name + ".cfg")
    os.makedirs(os.path.dirname(cfg), exist_ok=True)
    open(cfg, "w").write(
        "SPECIFICATION Spec\n"
        f"CONSTANTS N = {r['N']}\n          L = {r['L']}\n          Design = \"{r['design']}\"\n"
        f"          Faults = {str(r['faults']).upper()}\n          SpentOnUnknown = {str(r['spent']).upper()}\n"
        f"INVARIANT {r['inv']}\n")
    meta = os.path.join(HERE, "states", name)
    p = subprocess.run(["java", "-XX:+UseParallelGC", "-cp", JAR, "tlc2.TLC", "-noGenerateSpecTE", "-config", cfg,
                        "-workers", "1", "-metadir", meta, "-cleanup", "Admission.tla"],
                       cwd=HERE, capture_output=True, text=True)
    out = p.stdout
    import shutil
    shutil.rmtree(meta, ignore_errors=True)
    m = re.search(r"(\d+) states generated, (\d+) distinct states found", out)
    r = dict(r, name=name, generated=int(m.group(1)) if m else None,
             distinct=int(m.group(2)) if m else None)
    if "No error has been found" in out:
        r["verdict"] = "holds"
    elif re.search(r"Invariant \w+ is violated", out):
        r["verdict"] = "violated"
        states = re.findall(r"^State (\d+):", out, re.M)
        r["trace_states"] = int(states[-1]) if states else None
        os.makedirs(os.path.join(HERE, "traces"), exist_ok=True)
        open(os.path.join(HERE, "traces", name + ".txt"), "w").write(out[out.index("Error:"):])
    else:
        r["verdict"] = "error"
        r["log"] = out[-2000:]
    return r


import shutil
for d in ("cfg", "traces"):
    shutil.rmtree(os.path.join(HERE, d), ignore_errors=True)
results = [run(r) for r in runs]
json.dump(results, open(os.path.join(HERE, "results.json"), "w"), indent=1)
with open(os.path.join(HERE, "results.md"), "w") as f:
    f.write("| design | N | L | faults | spent on unknown | invariant | verdict | distinct states | counterexample states |\n|---|---|---|---|---|---|---|---|---|\n")
    for r in results:
        f.write(f"| {r['design']} | {r['N']} | {r['L']} | {r['faults']} | {r['spent']} | {r['inv']} | {r['verdict']} | {r['distinct']} | {r.get('trace_states', '')} |\n")
bad = [r for r in results if r["verdict"] == "error"]
print(f"{len(results)} runs; errors: {len(bad)}")
for r in bad[:3]:
    print(r["name"], r["log"][-800:])
