------------------------------ MODULE Admission ------------------------------
(***************************************************************************)
(* The six admission designs of the paper as concurrent processes over an  *)
(* abstract datastore. One process is one request for the same number;      *)
(* N requests run with any interleaving. Each labeled step is atomic: one  *)
(* SQL statement, or one serialized transaction, of the implementation in   *)
(* svc/app.py (Algorithms 1 and 2 of the paper). One policy window.         *)
(*                                                                         *)
(*   count    the quota state: rows in the window, or the counter value     *)
(*   calls    provider calls made (what the operator is billed for when    *)
(*            every call succeeds)                                          *)
(*   billed   messages the aggregator billed (differs from calls only when  *)
(*            the provider can fail: Faults = TRUE)                         *)
(*                                                                         *)
(* Design is one of "CountThenInsert", "ReadModifyWrite",                   *)
(* "IncrementAfterSend", "ConditionalUpdate", "GuardedTransaction",         *)
(* "ReserveBeforeSend". For ReserveBeforeSend, SpentOnUnknown selects the   *)
(* release rule: FALSE releases the claim on any provider exception (the    *)
(* shipped fixture), TRUE releases it only when the call certainly failed.  *)
(***************************************************************************)
EXTENDS Naturals

CONSTANTS N, L, Design, Faults, SpentOnUnknown

ASSUME N \in Nat \ {0} /\ L \in Nat \ {0}
ASSUME Design \in {"CountThenInsert", "ReadModifyWrite", "IncrementAfterSend",
                   "ConditionalUpdate", "GuardedTransaction", "ReserveBeforeSend"}
ASSUME Faults \in BOOLEAN /\ SpentOnUnknown \in BOOLEAN

Outcomes == IF Faults THEN {"ok", "failed", "unknown"} ELSE {"ok"}

(* --algorithm admission
variables count = 0, calls = 0, billed = 0, lock = 0;

define
    \* R1, bounded consumption: provider calls never exceed the declared limit
    R1 == calls <= L
    \* R3 (billing form): messages billed never exceed the declared limit
    R3 == billed <= L
    \* used to ask whether every one of the N requests can be admitted
    NotAllAdmitted == calls < N
    \* used to show that the limit itself is reachable (not a vacuous verdict)
    BelowLimit == calls < L
end define;

process Req \in 1..N
variables v = 0, ok = FALSE, outcome = "ok";
begin
Start:
    if Design = "ConditionalUpdate" \/ Design = "ReserveBeforeSend" then
        \* one UPDATE ... SET used = used + 1 WHERE used < L: decide and write
        Claim:
            if count < L then count := count + 1; ok := TRUE;
            else ok := FALSE; end if;
        Send1:
            if ok then
                with o \in Outcomes do outcome := o; end with;
                calls := calls + 1;
                if outcome # "failed" then billed := billed + 1; end if;
                Release:
                    if Design = "ReserveBeforeSend" /\ outcome # "ok"
                       /\ (outcome = "failed" \/ ~SpentOnUnknown) then
                        count := count - 1;    \* compensating decrement
                    end if;
            end if;
    elsif Design = "GuardedTransaction" then
        \* BEGIN IMMEDIATE (SQLite) or an advisory lock on the number (PostgreSQL)
        Lock:   await lock = 0; lock := self;
        Read2:  v := count;
        Write2: if v < L then count := count + 1; ok := TRUE;
                else ok := FALSE; end if;
        Commit: lock := 0;
        Send2:  if ok then
                    with o \in Outcomes do outcome := o; end with;
                    calls := calls + 1;
                    if outcome # "failed" then billed := billed + 1; end if;
                end if;
    else
        \* the two step designs: read, decide on the value read, write
        Read:   v := count;
        Decide: if v < L then
                    if Design = "IncrementAfterSend" then
                        SendA:  calls := calls + 1; billed := billed + 1;
                        WriteA: count := count + 1;
                    else
                        Write:  if Design = "CountThenInsert" then count := count + 1;
                                else count := v + 1; end if;   \* ReadModifyWrite
                        SendB:  calls := calls + 1; billed := billed + 1;
                    end if;
                end if;
    end if;
end process;
end algorithm; *)
\* BEGIN TRANSLATION (chksum(pcal) = "b9d6b200" /\ chksum(tla) = "87333ad4")
VARIABLES pc, count, calls, billed, lock

(* define statement *)
R1 == calls <= L

R3 == billed <= L

NotAllAdmitted == calls < N

BelowLimit == calls < L

VARIABLES v, ok, outcome

vars == << pc, count, calls, billed, lock, v, ok, outcome >>

ProcSet == (1..N)

Init == (* Global variables *)
        /\ count = 0
        /\ calls = 0
        /\ billed = 0
        /\ lock = 0
        (* Process Req *)
        /\ v = [self \in 1..N |-> 0]
        /\ ok = [self \in 1..N |-> FALSE]
        /\ outcome = [self \in 1..N |-> "ok"]
        /\ pc = [self \in ProcSet |-> "Start"]

Start(self) == /\ pc[self] = "Start"
               /\ IF Design = "ConditionalUpdate" \/ Design = "ReserveBeforeSend"
                     THEN /\ pc' = [pc EXCEPT ![self] = "Claim"]
                     ELSE /\ IF Design = "GuardedTransaction"
                                THEN /\ pc' = [pc EXCEPT ![self] = "Lock"]
                                ELSE /\ pc' = [pc EXCEPT ![self] = "Read"]
               /\ UNCHANGED << count, calls, billed, lock, v, ok, outcome >>

Claim(self) == /\ pc[self] = "Claim"
               /\ IF count < L
                     THEN /\ count' = count + 1
                          /\ ok' = [ok EXCEPT ![self] = TRUE]
                     ELSE /\ ok' = [ok EXCEPT ![self] = FALSE]
                          /\ count' = count
               /\ pc' = [pc EXCEPT ![self] = "Send1"]
               /\ UNCHANGED << calls, billed, lock, v, outcome >>

Send1(self) == /\ pc[self] = "Send1"
               /\ IF ok[self]
                     THEN /\ \E o \in Outcomes:
                               outcome' = [outcome EXCEPT ![self] = o]
                          /\ calls' = calls + 1
                          /\ IF outcome'[self] # "failed"
                                THEN /\ billed' = billed + 1
                                ELSE /\ TRUE
                                     /\ UNCHANGED billed
                          /\ pc' = [pc EXCEPT ![self] = "Release"]
                     ELSE /\ pc' = [pc EXCEPT ![self] = "Done"]
                          /\ UNCHANGED << calls, billed, outcome >>
               /\ UNCHANGED << count, lock, v, ok >>

Release(self) == /\ pc[self] = "Release"
                 /\ IF Design = "ReserveBeforeSend" /\ outcome[self] # "ok"
                       /\ (outcome[self] = "failed" \/ ~SpentOnUnknown)
                       THEN /\ count' = count - 1
                       ELSE /\ TRUE
                            /\ count' = count
                 /\ pc' = [pc EXCEPT ![self] = "Done"]
                 /\ UNCHANGED << calls, billed, lock, v, ok, outcome >>

Lock(self) == /\ pc[self] = "Lock"
              /\ lock = 0
              /\ lock' = self
              /\ pc' = [pc EXCEPT ![self] = "Read2"]
              /\ UNCHANGED << count, calls, billed, v, ok, outcome >>

Read2(self) == /\ pc[self] = "Read2"
               /\ v' = [v EXCEPT ![self] = count]
               /\ pc' = [pc EXCEPT ![self] = "Write2"]
               /\ UNCHANGED << count, calls, billed, lock, ok, outcome >>

Write2(self) == /\ pc[self] = "Write2"
                /\ IF v[self] < L
                      THEN /\ count' = count + 1
                           /\ ok' = [ok EXCEPT ![self] = TRUE]
                      ELSE /\ ok' = [ok EXCEPT ![self] = FALSE]
                           /\ count' = count
                /\ pc' = [pc EXCEPT ![self] = "Commit"]
                /\ UNCHANGED << calls, billed, lock, v, outcome >>

Commit(self) == /\ pc[self] = "Commit"
                /\ lock' = 0
                /\ pc' = [pc EXCEPT ![self] = "Send2"]
                /\ UNCHANGED << count, calls, billed, v, ok, outcome >>

Send2(self) == /\ pc[self] = "Send2"
               /\ IF ok[self]
                     THEN /\ \E o \in Outcomes:
                               outcome' = [outcome EXCEPT ![self] = o]
                          /\ calls' = calls + 1
                          /\ IF outcome'[self] # "failed"
                                THEN /\ billed' = billed + 1
                                ELSE /\ TRUE
                                     /\ UNCHANGED billed
                     ELSE /\ TRUE
                          /\ UNCHANGED << calls, billed, outcome >>
               /\ pc' = [pc EXCEPT ![self] = "Done"]
               /\ UNCHANGED << count, lock, v, ok >>

Read(self) == /\ pc[self] = "Read"
              /\ v' = [v EXCEPT ![self] = count]
              /\ pc' = [pc EXCEPT ![self] = "Decide"]
              /\ UNCHANGED << count, calls, billed, lock, ok, outcome >>

Decide(self) == /\ pc[self] = "Decide"
                /\ IF v[self] < L
                      THEN /\ IF Design = "IncrementAfterSend"
                                 THEN /\ pc' = [pc EXCEPT ![self] = "SendA"]
                                 ELSE /\ pc' = [pc EXCEPT ![self] = "Write"]
                      ELSE /\ pc' = [pc EXCEPT ![self] = "Done"]
                /\ UNCHANGED << count, calls, billed, lock, v, ok, outcome >>

SendA(self) == /\ pc[self] = "SendA"
               /\ calls' = calls + 1
               /\ billed' = billed + 1
               /\ pc' = [pc EXCEPT ![self] = "WriteA"]
               /\ UNCHANGED << count, lock, v, ok, outcome >>

WriteA(self) == /\ pc[self] = "WriteA"
                /\ count' = count + 1
                /\ pc' = [pc EXCEPT ![self] = "Done"]
                /\ UNCHANGED << calls, billed, lock, v, ok, outcome >>

Write(self) == /\ pc[self] = "Write"
               /\ IF Design = "CountThenInsert"
                     THEN /\ count' = count + 1
                     ELSE /\ count' = v[self] + 1
               /\ pc' = [pc EXCEPT ![self] = "SendB"]
               /\ UNCHANGED << calls, billed, lock, v, ok, outcome >>

SendB(self) == /\ pc[self] = "SendB"
               /\ calls' = calls + 1
               /\ billed' = billed + 1
               /\ pc' = [pc EXCEPT ![self] = "Done"]
               /\ UNCHANGED << count, lock, v, ok, outcome >>

Req(self) == Start(self) \/ Claim(self) \/ Send1(self) \/ Release(self)
                \/ Lock(self) \/ Read2(self) \/ Write2(self)
                \/ Commit(self) \/ Send2(self) \/ Read(self)
                \/ Decide(self) \/ SendA(self) \/ WriteA(self)
                \/ Write(self) \/ SendB(self)

(* Allow infinite stuttering to prevent deadlock on termination. *)
Terminating == /\ \A self \in ProcSet: pc[self] = "Done"
               /\ UNCHANGED vars

Next == (\E self \in 1..N: Req(self))
           \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(\A self \in ProcSet: pc[self] = "Done")

\* END TRANSLATION 
=============================================================================
