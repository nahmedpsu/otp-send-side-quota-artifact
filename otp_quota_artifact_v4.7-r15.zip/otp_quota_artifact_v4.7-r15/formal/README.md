# Formal models of the six admission designs

Two independent models of the admission designs in `svc/app.py` and
`svc/app_pg.py` (Algorithms 1 and 2 of the paper), checked against the
enforcement requirements of the paper's Section III:

* **R1, bounded consumption:** for any arrival pattern, the provider calls
  accepted for one number in one window never exceed the declared limit L.
* **R3, account exactly once:** the messages the aggregator bills never exceed
  L, even when a provider call fails or its outcome is unknown.

| Folder | Tool | What it shows |
|---|---|---|
| `tla/` | TLA+ (PlusCal 1.12), TLC2 build 2026.10.06 (rev. 94d0c50), from the `tla2tools.jar` of release v1.8.0 | 156 runs. Every interleaving of N concurrent requests, for L = 1, 2, 3 and N up to L + 2; R1 for all six designs, R3 for the three one step designs with a provider that may fail or time out after billing; whether every one of N > L requests can be admitted (two step designs); and, as a sanity check, that the limit itself is reachable (all designs). Breadth first search, so each counterexample is a shortest one, and a run stops at its first counterexample. |
| `tamarin/` | Tamarin prover 1.10.0 with Maude 3.5 | An unbounded number of concurrent requests (and of numbers), L = 3: R1 proved for the three one step designs; for the three two step designs a trace with four admissions is found. |

## What the models abstract

* One policy window and one number per model run; the window roll of the
  fixed window designs is not modeled (the boundary behavior is measured, not
  modeled: paper Section V-G).
* Every labeled step (TLA+) or rule (Tamarin) is atomic: one SQL statement, or
  one serialized transaction. That is the datastore guarantee the designs rely
  on (a single `UPDATE ... WHERE used < L`; `BEGIN IMMEDIATE` on SQLite; a
  transaction scoped advisory lock on PostgreSQL). Weaker isolation than the
  datastore provides is not modeled.
* A count of rows and a counter are the same abstract quantity `count`;
  count then insert increments the current value, the read modify write
  counter writes back the value it read plus one.
* The provider is a single step; with `Faults = TRUE` (TLA+ only) its outcome
  is `ok` (billed), `failed` (not billed, an exception) or `unknown` (billed,
  but the call raises, as after a timeout).
* The models check the designs, not the Python code; the measurement
  (paper Section V) checks the code.

## Tool versions used for the reported results

| File | SHA-256 |
|---|---|
| `tla2tools.jar` (release v1.8.0, downloaded October 8, 2026) | `7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d` |
| `tamarin-prover-1.10.0-linux64-ubuntu.tar.gz` | `538fe055b65f419aac4710015948f0e6a2253d2f61958c136e2d2bd67981028c` |
| `Maude-3.5-linux-x86_64.zip` | `e74cb8cf91b2d8b45440b54ef037180b581279358facf49f656e5b126eb7d1d3` |

The v1.8.0 release of the TLA+ tools is updated in place by its maintainers,
so a later download may report a later TLC build; the verdicts should not
change with the build, although state counts could.

## Running

```bash
# TLA+: Java 11 or later and tla2tools.jar v1.8.0
#   https://github.com/tlaplus/tlaplus/releases/download/v1.8.0/tla2tools.jar
java -cp tla2tools.jar pcal.trans -nocfg formal/tla/Admission.tla   # only after editing the PlusCal
python3 formal/tla/run_tlc.py /path/to/tla2tools.jar                 # about 2 minutes; writes results.json, results.md, traces/

# Tamarin 1.10.0 and Maude 3.5 on the PATH
#   https://github.com/tamarin-prover/tamarin-prover/releases/download/1.10.0/tamarin-prover-1.10.0-linux64-ubuntu.tar.gz
#   https://github.com/maude-lang/Maude/releases/download/Maude3.5/Maude-3.5-linux-x86_64.zip
bash formal/tamarin/run_tamarin.sh                                    # under a minute; writes results/
```

`regenerate.py` reads `tla/results.json` and `tamarin/results/log_*.txt`
into `results/paper_numbers.json` (key `formal`), from which the paper's
verification table is generated.
