#!/bin/bash
# Prove every lemma of OTPAdmission.spthy for each of the six designs.
# Needs tamarin-prover 1.10 and Maude 3.5 on the PATH (README in this folder).
# Writes one log and one proof file per design into results/.
set -u
cd "$(dirname "$0")"
export LANG=C.UTF-8 LC_ALL=C.UTF-8
mkdir -p results
for D in CONDITIONAL GUARDED RESERVE COUNTINSERT RMW AFTERSEND; do
  timeout 600 tamarin-prover --prove -D=$D --output=results/proof_$D.spthy OTPAdmission.spthy > results/log_$D.txt 2>&1
  echo "== $D"; grep -E "^  [a-zA-Z0-9_]+ \((all-traces|exists-trace)\)|processing time|WARNING" results/log_$D.txt
done
