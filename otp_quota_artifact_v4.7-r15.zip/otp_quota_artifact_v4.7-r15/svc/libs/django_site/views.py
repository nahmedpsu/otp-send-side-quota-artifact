"""django-ratelimit guarding the OTP send endpoint: "3/h" per phone number
(the key is the phone number from the query string), block=False so that a
limited request is answered and recorded as a refusal."""
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django_ratelimit.decorators import ratelimit

from svc.libs import common

common.init()


@csrf_exempt
@ratelimit(key="get:phone", rate=f"{common.LIMIT}/h", method="POST", block=False)
def otp_request(request):
    phone = request.GET["phone"]
    ev = common.new_event(phone)
    if getattr(request, "limited", False):
        return JsonResponse(common.finish(ev, "refuse"))
    common.provider_send(phone, ev)
    return JsonResponse(common.finish(ev, "admit"))


def stats(request):
    return JsonResponse(common.stats(request.GET["phone"]))


def events(request):
    return JsonResponse(common.events(request.GET["phone"]))
