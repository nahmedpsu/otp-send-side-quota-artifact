from django.urls import path

from svc.libs.django_site import views

urlpatterns = [
    path("otp/request", views.otp_request),
    path("otp/stats", views.stats),
    path("otp/events", views.events),
]
