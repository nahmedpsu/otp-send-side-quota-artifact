import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "svc.libs.django_site.settings")
from django.core.asgi import get_asgi_application  # noqa: E402

application = get_asgi_application()
