"""Minimal Django project for the django-ratelimit arms.

    OTP_DJ_CACHE   locmem (Django's default cache: one per worker process),
                   db-sqlite, db-postgres (DatabaseCache), or redis (RedisCache)
"""
import os

SECRET_KEY = "experiment-only"
DEBUG = False
ALLOWED_HOSTS = ["*"]
ROOT_URLCONF = "svc.libs.django_site.urls"
INSTALLED_APPS = ["django_ratelimit"]   # registers its system checks (manage.py check)
MIDDLEWARE = []
USE_TZ = True
_cache = os.environ.get("OTP_DJ_CACHE", "locmem")
_db = os.environ.get("OTP_DJ_DB", "/tmp/otp_lib_django.db")
DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": _db,
                         "OPTIONS": {"timeout": 30}}}
if _cache == "db-postgres":
    DATABASES = {"default": {"ENGINE": "django.db.backends.postgresql", "NAME": "otp",
                             "USER": "otp", "PASSWORD": "otp", "HOST": "127.0.0.1"}}
CACHES = {
    "locmem": {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}},
    "db-sqlite": {"default": {"BACKEND": "django.core.cache.backends.db.DatabaseCache",
                              "LOCATION": "otp_ratelimit_cache"}},
    "db-postgres": {"default": {"BACKEND": "django.core.cache.backends.db.DatabaseCache",
                                "LOCATION": "otp_ratelimit_cache"}},
    "redis": {"default": {"BACKEND": "django.core.cache.backends.redis.RedisCache",
                          "LOCATION": "redis://127.0.0.1:6379/1"}},
}[_cache]
