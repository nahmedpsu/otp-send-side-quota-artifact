"""Shared pieces of the off-the-shelf limiter services (Study 2, library arm).

The provider stub and the event log are the same as in svc/app.py: the stub
sleeps OTP_PROVIDER_MS and writes one row per call to a SQLite file of its
own (so it never shares a database with the limiter under test), and every
request appends one event record to a per worker file after it finishes.
The library decides admission; the service only records the outcome, so the
record carries the receive and provider call instants but no read or write
instants of the library's own state.
"""
import glob
import json
import os
import sqlite3
import time
import uuid

PROVIDER_MS = float(os.environ.get("OTP_PROVIDER_MS", "50"))
PROVIDER_DB = os.environ.get("OTP_PROVIDER_DB", "/tmp/otp_lib_provider.db")
EVENT_DIR = os.environ.get("OTP_EVENT_DIR", PROVIDER_DB + ".events")
CONFIG = os.environ.get("OTP_LIB_CONFIG", "unnamed")
LIMIT = int(os.environ.get("OTP_LIMIT", "3"))
_event_file = None


def _conn():
    c = sqlite3.connect(PROVIDER_DB, timeout=30.0, isolation_level=None)
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA busy_timeout=30000")
    return c


def init():
    c = _conn()
    c.execute("CREATE TABLE IF NOT EXISTS provider_sends (id INTEGER PRIMARY KEY AUTOINCREMENT,"
              " phone TEXT NOT NULL, message_id TEXT NOT NULL, ts REAL NOT NULL)")
    c.close()
    os.makedirs(EVENT_DIR, exist_ok=True)


def new_event(phone):
    return {"rid": uuid.uuid4().hex, "phone": phone, "t_recv": time.time()}


def provider_send(phone, ev):
    ev["t_provider_start"] = time.time()
    if PROVIDER_MS > 0:
        time.sleep(PROVIDER_MS / 1000.0)
    mid = uuid.uuid4().hex
    c = _conn()
    c.execute("INSERT INTO provider_sends(phone, message_id, ts) VALUES (?,?,?)", (phone, mid, time.time()))
    c.close()
    ev["t_provider_end"] = time.time()
    ev["message_id"] = mid


def finish(ev, decision):
    global _event_file
    ev["decision"] = decision
    ev["t_done"] = time.time()
    ev["pid"] = os.getpid()
    ev["config"] = CONFIG
    ev["limit"] = LIMIT
    if _event_file is None:
        os.makedirs(EVENT_DIR, exist_ok=True)
        _event_file = open(os.path.join(EVENT_DIR, f"events-{os.getpid()}.jsonl"), "a")
    _event_file.write(json.dumps(ev) + "\n")
    _event_file.flush()
    return {"status": "sent" if decision == "admit" else "rejected"}


def stats(phone):
    c = _conn()
    n = c.execute("SELECT COUNT(*) FROM provider_sends WHERE phone=?", (phone,)).fetchone()[0]
    c.close()
    return {"phone": phone, "provider_sends": n, "limit": LIMIT, "config": CONFIG}


def events(phone):
    out = []
    for fn in glob.glob(os.path.join(EVENT_DIR, "events-*.jsonl")):
        with open(fn) as f:
            for line in f:
                if line.strip():
                    e = json.loads(line)
                    if e.get("phone") == phone:
                        out.append(e)
    out.sort(key=lambda e: e["t_recv"])
    return {"phone": phone, "limit": LIMIT, "config": CONFIG, "events": out}
