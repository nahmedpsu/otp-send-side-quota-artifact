# Literature search record (round 17, Computers & Security revision)

Date: October 9, 2026. Searches run by the author with a general web search
tool (US results); this record answers the reviewer's question of how the
related work was found. Earlier rounds' search streams are described in the
round 1 to round 6 trackers; this file lists only the round 17 additions.

## Queries and what was kept

| Query | Kept | Not kept, and why |
|---|---|---|
| SMS OTP rate limiting race condition concurrency send quota | CVE-2026-43930 (parse-server, MFA SMS code accepted twice under concurrent login; verification side race) | practitioner blog posts on resend races and SMS pumping (dev.to, undercodetesting): not peer reviewed, no data; Stytch platform rate limit page: vendor limits on its own API, not a send side contract |
| SMS pumping toll fraud OTP endpoint defense research paper 2025 | none new beyond the threat intelligence and carrier sources already cited (CRIL 2026; Huh et al. 2025) | vendor marketing pages; Okta threat intelligence post on SMS pumping against sign up pages (consistent with the cited CRIL report; not cited to avoid duplicating the threat evidence) |
| formal verification rate limiter TLA+ model checking | none: no peer reviewed formal model of a send quota or rate limiter was found | course exercises and curated lists |
| Twilio Verify service rate limits; SMS 2FA retry best practices | Twilio Docs, "Protect Your Verify Application with Service Rate Limits" (checked before a send; HTTP 429, error 60203); Robinson, Twilio Blog, July 27, 2021 | |
| concurrency timing attacks remote connections HTTP/2 | Van Goethem et al., USENIX Security 2020 | |

Earlier round sources kept for the race condition line: CWE-367; Kettle
(PortSwigger, 2023); Loi et al. (2026); Warszawski and Bailis (ACIDRain, 2017).

## Inclusion rule

A source is cited if it (a) is peer reviewed, a standard, an official
advisory or CVE record, or a provider's own documentation of its controls, and
(b) bears on one of: send side abuse of OTP endpoints, admission races in web
applications, provider side enforcement, or formal checking of admission
logic. Practitioner blog posts are not cited unless they are the primary
source of a technique (Kettle).
