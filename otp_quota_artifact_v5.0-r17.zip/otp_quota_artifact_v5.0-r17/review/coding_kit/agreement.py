"""Agreement between the second coder's form and the author's labels.

    python3 review/coding_kit/agreement.py review/coding_kit/coding_form_<coder>.csv

Reads the author's labels from results/r4/classification_audit.csv (which the
second coder must not open before finishing) and reports, for each field,
the observed agreement and Cohen's kappa over the subjects both coded, and
lists every disagreement for adjudication."""
import csv
import sys
from collections import Counter

FIELDS = {"in_scope (yes/no)": None,
          "send_bound (none/in_package_delivery_path/in_package_framework_throttle/delegated_provider/helper_not_wired)":
              "send_control_evidence_level",
          "verify_control (yes/no)": "verify_control"}


def kappa(pairs):
    n = len(pairs)
    if n == 0:
        return None, None
    po = sum(a == b for a, b in pairs) / n
    ca, cb = Counter(a for a, _ in pairs), Counter(b for _, b in pairs)
    pe = sum(ca[k] * cb[k] for k in set(ca) | set(cb)) / (n * n)
    return po, (None if pe == 1 else (po - pe) / (1 - pe))


def main(path):
    author = {r["package"]: r for r in csv.DictReader(open("results/r4/classification_audit.csv"))}
    misses = {"bach-sms-verify3", "django-otp-sms", "yaz-pyotp"}
    coder = list(csv.DictReader(open(path)))
    for field, akey in FIELDS.items():
        pairs, diffs = [], []
        for r in coder:
            p, v = r["package"], r[field].strip().lower()
            if not v:
                continue
            if akey is None:
                a = "yes" if (p in author or p in misses) else "no"
            elif p in author:
                a = author[p][akey].strip().lower()
            else:
                continue
            pairs.append((v, a))
            if v != a:
                diffs.append((r["subject_id"], p, v, a))
        po, k = kappa(pairs)
        print(f"{field.split(' (')[0]}: n={len(pairs)} agreement={po if po is None else round(po, 3)} kappa={k if k is None else round(k, 3)}")
        for d in diffs:
            print("   disagree", d)


if __name__ == "__main__":
    main(sys.argv[1])
