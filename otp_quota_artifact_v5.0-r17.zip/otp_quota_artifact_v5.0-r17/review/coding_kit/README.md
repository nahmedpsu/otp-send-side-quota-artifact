# Blinded second adjudication: protocol (round 7)

This kit lets a second coder label every package in the cohort without seeing
the author's labels, so that agreement can be measured and every disagreement
adjudicated. Until a second coder's labels are returned, the manuscript states
that every label was assigned by one coder.

## Subjects

`coding_form.csv` lists 45 subjects in a random order (seed 20261009): the 42
retained packages and the three packages that the detector missed in its
validation sample (`bach-sms-verify3`, `django-otp-sms`, `yaz-pyotp`). Each row
points to the package source in `pkgs/src/`, the exact version that was
surveyed. Do not open `results/`, `paper/`, or `review/` (other than this
folder) before the form is complete.

## Codebook

1. **In scope**: the package's own code delivers a one time or verification
   code to a person (SMS, voice, e-mail, push, or through a hosted provider's
   API that it calls). Generating or verifying codes without delivering them is
   out of scope; so is an activation link.
2. **Send bound** (choose one): `none` (nothing in the package's code bounds
   how often a code is delivered); `in_package_delivery_path` (a check in the
   package's own delivery path refuses a send); `in_package_framework_throttle`
   (a framework throttle class is attached to the view that sends);
   `delegated_provider` (the package calls a hosted service that does the
   bounding); `helper_not_wired` (a bounding helper exists but the delivery path
   never calls it).
3. For a bound, record what it **counts** (sends, requests, failed
   verifications), its **key** (recipient, user, device, session, client
   address, provider), where its **state** lives (database, cache, process
   memory, session, provider), whether it **constrains a send only attacker**
   per recipient (one who never submits a code and may discard cookies and
   change client address), and its **decision shape**: `one_step` when one
   atomic operation both decides and records, `two_step` when a read or check
   is followed by a separate write.
4. **Verify control**: any attempt limit, lockout or throttle on the
   verification path.
5. **Evidence**: the file, function and line span that justify each label.

## After coding

Run `python3 review/coding_kit/agreement.py <your form>`; it reports agreement
and Cohen's kappa per field and lists every disagreement. Disagreements are
resolved by discussion, and the paper reports the agreement before resolution
and the labels after it.
