# Send-side quota enforcement in one-time-password software

Artifact **v5.0-r17** for *Send Side Quota Enforcement in One Time Password Software: A
Package Survey and a Measurement Under Concurrency* (Computers & Security, manuscript v5.0).
Public repository: https://github.com/nahmedpsu/otp-send-side-quota-artifact

An SMS one-time-password endpoint spends money every time it accepts a request. An attacker
who never guesses a code can still run up the bill. This repository holds the survey, the
measurements, the formal models, the code that produced them, every raw event record, and one
script (`regenerate.py`) that recomputes every reported number into
`results/paper_numbers.json`, from which every table, figure, and number of the paper is
generated.

**What v5.0-r17 adds** (round 7, in response to the Computers & Security review; the round 4
and round 6 records are unchanged):

- One operational contract (C1 send bound per window of a named policy family, C2 billing
  bound under faults, C3 no duplicate call, C4 availability), stated in the paper's Section 3.
- **Service 2.2.0** (`svc/app.py`, `svc/app_pg.py`, `svc/opt.py`): opt-in switches for request
  delays, provider faults, the reservation's release rule, an independent provider process
  (`svc/provider.py`), and minimal logging; two designs whose grant takes its window from the
  datastore's clock. With every switch off it issues the statements of 2.1.0.
- **Round 7 arms** (`study/run_round7.py`, `study/run_round7.sh`, `study/run_round7_resume.sh`,
  `results/r7/`): independent runs, instrumentation, independent provider, last byte
  synchronization, time and faults, sustained load.
- **Six surveyed packages executed** on their own delivery paths with local adapters
  (`study/run_packages7.py`, `study/gw.py`, `study/smtp_sink.py`, `svc/pkgs/`).
- **Seven more library configurations** (`study/run_libraries.py`, `results/r7/libraries7.*`).
- **Survey validation** (`results/r7/survey/`): every filter stage, whole package re-reading of
  the detector sample, families, and the contract of every guard; a blinded second coder kit
  (`review/coding_kit/`).
- **Formal**: a timed TLA+ model with rollover, delays, faults, release rules, the datastore's
  clock, and per worker stores (`formal/tla/AdmissionTimed.tla`, `run_tlc_timed.py`), a
  parameterized Tamarin model (`formal/tamarin/OTPAdmissionParam.spthy`) and a limit sweep
  (`sweep_limits.py`); `formal/run_formal_round7.sh` runs all three.
- **Generated paper inputs**: `study/round7_numbers.py` (the "r7" key of paper_numbers.json),
  `study/paper_macros.py` (paper/gen/r7.tex, one macro per quoted number),
  `study/paper_tables7.py`, `study/make_figs7.py`, `study/comparison7.py`.
- The manuscript is `paper/otp_cose.tex` with sections in `paper/cose/`
  (`bash paper/build.sh paper/otp_cose.tex`); the response letter is
  `review/rebuttal_round17.tex`. The IEEE Access sources of v4.8 are kept for reference.

The container in which round 7 ran restarted once, at 01:59 UTC on October 9, 2026, during
the independent provider arm on SQLite; that arm's partial records were deleted and the arm
was rerun whole (`study/run_round7_resume.sh`, `results/r7/round7.log`).

**Start here.**

```bash
python3 study/manifest.py verify # the whole tree against its SHA-256 manifest; exit 1 on any difference
python3 regenerate.py            # every reported number, from the event records, under a minute
python3 study/paper_tables.py    # the LaTeX bodies of the result tables, from the same file
```

## The round 4 reviewer's decisive question, and the answer

The fourth-round reviewer asked: *for every reported policy violation and legitimate
cross-window total, what exact event is being counted, and can the artifact independently
prove that event's window assignment for every request?*

**The event is the admission**: the completion of the implementation's own granting state
update. Where the recorded window comes from differs between implementations, and each record
says which (`window_source`):

- `atomic_update`, `reserve_commit` (one-step, fixed window): the `window_start` the counter
  row held when the conditional `UPDATE` was applied, **returned by the database in that
  statement** (`RETURNING window_start, used`). The application never computes it.
- `cache_get_set` (read-modify-write counter, fixed window): the `window_start` the request
  itself computed and wrote in its upsert (the row's window if still current, else its own
  clock's aligned window). That pattern decides in the application, so its recorded window is
  an **application-computed value**; a `RETURNING` clause on the upsert (added in service
  2.1.0) echoes it and cannot certify the row's state before the write, whose loss under
  concurrency is the defect being measured. For all 6,762 admissions this implementation made
  in round 4 the recorded window is aligned, current at the request's own read, and equal to
  the aligned window of that read (`window_provenance_check` in `results/paper_numbers.json`).
- the three sliding-window implementations: the admission timestamp the implementation used
  in its own check.

The provider call happens after the admission and its instant is never used to assign a
window (the round-3 oracle did that, and the reviewer's two-request counterexample against
the shipped fixture is exactly the failure it produces).

**Every request in every round-4 trial has one event record** (`results/r4/<arm>.events.jsonl`,
one JSON line per request: request id, worker, the instants of receipt, read, decision, write,
provider-call start and end and completion, the state value observed, the decision, the window
identifier or admission timestamp, the counter value after the update, the message id).
`regenerate.py` reads those records, evaluates the policy on the admission events with
`study/policy.py`, derives every per-trial summary, checks it against the harness's own CSV
(and stops if they disagree), and writes `results/overrun_classification.csv` with the
per-window admission counts of every overrun and the file they came from. The only
quantities it takes from the CSV rather than the records are the two the client measured
(client-side burst time and client-side error count). Part D of the notebook recomputes one
row's window assignment by hand from its records.

The round-4 records were produced by service **2.0.0**, archived verbatim in `svc/archive/`.
The shipped service is **2.1.0** (`svc/CHANGELOG.md`): the read-modify-write counter's upsert
carries `RETURNING`, every fixed-window record carries `window_source`, and each admission
field is assigned in one helper. The round-5 check arms in `results/r5/` (that implementation
only: the main sweep on both datastores and both boundary tests) were produced by 2.1.0. They
are not used to replace or recompute any round-4 result; their results are reported separately,
only as a provenance check: in every one of their admissions the returned window and counter
equal the submitted ones (`round5_check` in `paper_numbers.json`).

The round-1 to round-3 runs kept no event records. They are retained under `results/`,
`results/r2/` and `results/r3/`, summarised by `regenerate.py` under a separate "historical"
heading, and reported in the paper only where it compares them with round 4; they replace or
contribute to no round-4 result. The one round-2 trial in which a one-step
implementation exceeded its limit in total is classified **indeterminate**: the records that
would assign its six admissions to windows do not exist. The earlier claim that "the error
was in the oracle, not in the implementation" is withdrawn for that trial.

## What the round 4 studies found (v4.x; see the paper for v5.0)

**Study 1, the package survey.** Starting from the Python Package Index snapshot of
September 22, 2026 (896,086 projects), 42 packages were read by hand. The round-4 audit
records the evidence level and location behind every send-side and verification-side label
(`results/r4/classification_audit.csv`):

| Send-side evidence level | Packages |
|---|---|
| Bound checked in the package's own delivery code | 7 |
| Framework throttle class declared on the sending view | 3 |
| Delegated: thin client for a hosted provider that enforces the bound | 3 |
| Helper defined and tested but never called on the delivery path | 1 |
| No bound in the package | 28 |

So 10 bound sending in their own code, 3 delegate it, and 29 have no send-side bound
(69%). Cross-tabulated with verification-side controls: 7 bound both operations,
6 send only, 10 verification only, 19 neither. Twenty can deliver by SMS and 3 of those carry a
send-side bound. Two labels changed in this round after a reviewer checked one against the
source: `maykin-django-two-factor-auth` 2.0.5 (its `generate_challenge` sends without consulting
`verify_is_allowed`, unlike upstream 1.18.1) and `django-otp-admin` 1.0.2 (its cooldown helper
is defined and tested but never called by the login flow that sends).

This is a **sample, not a census**: detector recall is estimated at 64.5% (95% CI 34.7 to 86.8%)
within the 756 downloaded candidates only; end-to-end recall is unknown.

**Study 2, the measurement.** One declared policy (three admissions per number per window)
implemented six ways on an ordinary stack (FastAPI, SQLite in WAL mode, four worker
processes; and PostgreSQL 16). Released simultaneously, round-4 SQLite sweep:

| Pattern | k=2 | k=4 | k=8 | k=16 | k=32 | Over / PV |
|---|---|---|---|---|---|---|
| Count-then-insert | 2/2 | 4/4 | 8/8 | 10/16 | 6.5/27 | 113 / 113 |
| Read-modify-write counter | 2/2 | 4/4 | 8/8 | 16/16 | 18.5/32 | 118 / 118 |
| Increment after send | 2/2 | 4/4 | 8/8 | 16/16 | 32/32 | 120 / 120 |
| Conditional atomic update | 2/2 | 3/3 | 3/3 | 3/3 | 3/3 | 0 / 0 |
| Guarded write transaction | 2/2 | 3/3 | 3/3 | 3/3 | 3/3 | 0 / 0 |
| Reserve before send | 2/2 | 3/3 | 3/3 | 3/3 | 3/3 | 0 / 0 |

Median / maximum admissions per cell, 30 trials each; "Over" is trials of 180 over the limit
in total, "PV" the trials whose policy was violated per window. Provider calls equalled
admissions in every trial. Across every round-4 arm, the three one-step implementations
violated their declared policy in 0 of
2430 trials, including the boundary tests that straddle a
window on purpose (120 legitimate cross-window
totals, five admissions in each window by the database's own window identifier).

**Why, request by request** (`study/events.py`, Table VIII of the paper, Table S12 of the supplement). Primary evidence is
database-visible state: every excess admission by count-then-insert had read a count below
the limit, the value its own read returned; the read-modify-write counter's written values
bound its lost updates from below (172 across 30 trials at k = 8, and at k = 2, where the outcome is
still correct, 27 of 30 trials lost one). Application-observed instants are reported as
proxies for the database's order and labelled as such.

## Layout

```
VERSION, MANIFEST.sha256.json      artifact version; SHA-256 of every file in the archive except the manifest
study/manifest.py                  writes (last, at packaging) and verifies the manifest: strict, whole tree
study/test_manifest.py             negative tests: missing, changed, unlisted files and symbolic links all fail verification
regenerate.py                      every reported number, from the event records; overrun classifier; audits
svc/app.py, svc/app_pg.py          the OTP service 2.2.0 (SQLite / PostgreSQL), eight designs, event log
svc/opt.py, svc/provider.py        2.2.0 opt-in switches; the independent provider process
svc/archive/, svc/CHANGELOG.md     the 2.0.0 and 2.1.0 sources, and what changed since
study/policy.py                    the policy oracle, evaluated on admission events
study/events.py                    per-trial quantities derived from the event records
study/run_experiments.py           the burst harness: keeps one event record per request
study/boundary_test.py             deterministic window-boundary test, both datastores
study/run_package_exec.py          executes django-otp 1.7.3 with per-call event records
study/mailcount.py                 the counting e-mail backend it uses (opens no connection)
study/paper_tables.py, make_figs.py  the LaTeX table bodies and figures, from paper_numbers.json
study/run_round4.sh, run_round4b.sh  exact invocation and UTC start of every round-4 arm
study/run_round5.sh                the round-5 check arms (service 2.1.0, read-modify-write counter only)
study/run_libraries.py, run_round6.sh  the round-6 arm: SlowAPI and django-ratelimit under the burst protocol
study/run_round7.py, run_round7.sh   the round-7 arms (service 2.2.0); run_round7_resume.sh after the restart
study/run_packages7.py, gw.py, smtp_sink.py   six surveyed packages executed (svc/pkgs/ holds their sites)
study/round7_numbers.py            every round-7 number, read by regenerate.py into paper_numbers.json["r7"]
study/paper_macros.py, paper_tables7.py, make_figs7.py, comparison7.py   generated inputs of the v5.0 paper
results/r7/                        round-7 records; results/r7/survey/ the survey validation files
review/coding_kit/                 blinded second coder kit (codebook, form, agreement.py)
svc/libs/                          the services that wrap the two libraries (same provider stub and event log)
formal/                            TLA+ (TLC, untimed and timed) and Tamarin models, with runners and results
study/locate_anomaly.py            replays the round-2 seed (historical; the trial stays indeterminate)
study/survey_*.py, validate_detector.py, population_profile.py, map_patterns.py   Study 1
study/compare_repro.py             prints a fresh run beside the shipped one
results/r4/                        round-4 event records (*.events.jsonl), trial CSVs, logs, audit
results/r6/                        round-6 library arm: libraries.csv, libraries.events.jsonl, libraries.meta.json, log
results/r5/                        round-5 check arms (service 2.1.0): a provenance check, reported separately; replace no round-4 result
results/, results/r2/, results/r3/ historical runs (rounds 1 to 3), reaggregated only
results/paper_numbers.{json,md}    written by regenerate.py
results/overrun_classification.csv written by regenerate.py
paper/                             manuscript source (body.tex) and supplementary material (supplement.tex);
                                   paper/gen/ holds the generated table bodies; paper/build.sh compiles and
                                   fails on any unresolved reference; body_v3.5_full.tex is the long form
notebooks/                         the reproduction notebook and an executed copy
review/                            rebuttal letters, reviewer reports, trackers
reproduce.sh, Dockerfile, requirements-lock.txt
```

## Reproducing

```bash
pip install -r requirements-lock.txt
python3 study/manifest.py verify          # the archive as shipped: exit 1 if anything is missing, changed or unlisted
python3 study/test_manifest.py            # the verifier's own negative tests (on a temporary tree)
python3 regenerate.py                     # recompute every reported number from the shipped event records
python3 study/manifest.py verify          # still passes: the derived files are byte-for-byte reproducible
bash reproduce.sh                         # verify, then re-run every round-4 arm into results/repro/ (about two hours)
python3 study/compare_repro.py            # your cells beside the shipped cells
bash paper/build.sh paper/otp_cose.tex   # compile the manuscript; exits 1 on any "??" or unknown number key
```

**Verification is strict.** `study/manifest.py verify` walks the whole tree under the artifact
root, not a list of expected directories, and exits 1 if any listed file is missing, any listed
file has changed, or any regular file is present that the manifest does not list, at the root or
anywhere below it. Symbolic links are never hashed and never accepted: a link to a file or a
directory, anywhere under the root, dangling or in place of a listed file, is reported as
`SYMLINK` and fails verification, and `write` refuses a tree that contains one. The only files it does not count as unlisted are the ones the artifact's own
commands create after unpacking (Python bytecode caches, LaTeX build products under `paper/`
and `review/`, and `results/repro/`), and it prints each of those by name; `verify --strict`
counts them too. `inspect` prints the same report but always exits 0, for diagnosis only.
`reproduce.sh` runs `verify` first and aborts on any difference; `reproduce.sh --no-verify` is
the diagnostic mode for a tree you have changed on purpose, and it says so when it runs.

The notebook (`notebooks/`) re-runs the SQLite main sweep, regenerates the reported analyses
from the archived request-level records, reads the survey's frozen results, and gives the
commands for re-running the survey and the complete round-4 suite; it does not itself
re-run those.

`reproduce.sh` re-runs every arm the paper reports at the paper's exact trial counts (30 per
cell; 10 for the sequential control; 20 for the worker and declared-limit arms), never
overwrites the shipped run, and re-runs nothing from rounds 1 to 3. `--quick` runs a reduced
design in about ten minutes; `--no-verify` skips the manifest gate (diagnostic runs only).

Study 1 re-downloads packages from the index, so its counts drift as the index changes; the
snapshot and the per-package adjudication ship so the published numbers can be checked
without re-collecting (`study/survey_*.py` in order, then `regenerate.py`).

## Scope and honesty notes

- **No real messages, no real billing.** The provider is a local stub that sleeps and records
  the attempt. No telephone number here is real; no external API, package maintainer,
  provider or production system is contacted. The paper reports admission counts, not money.
- **One ecosystem**, and the cohort is the packages one search discovers; every filter stage is
  validated against what it rejected (`results/r7/survey/`). **One coder**; the audit ships with the
  evidence for every label, and `review/coding_kit/` is ready for a blinded second coder.
- **Two datastores, one host.** The sensitivity arms are separate one-factor sweeps.
- **Fixtures are structural analogues** of surveyed code, not copies; six surveyed packages are also executed as shipped (round 7).
- **Application-observed instants, not database commit order.** The claims that rest on
  ordering use values from the records that do not depend on clocks (the state each read
  returned, the counter values written, the window identifiers); instant comparisons are
  proxies and are labelled as such.
- **The oracle has been wrong twice and the harness once**, and the paper says where
  (Threats to Validity). Rounds 1 to 3 are historical for that reason.
- **That a check followed by a write can be raced was already known**; Django REST
  Framework's throttling documentation says so. What is measured here is how much it costs
  for the shapes these packages use, against the policy each declares, on the event it
  constrains.

## Responsible disclosure

`results/r4/pkg_exec.*` and `results/r7/packages_*` record behavior in currently published
packages (races in send side cooldowns or counts in django-otp 1.7.3 and django-mfa 4.6.0, and
per process state in django-otp-auth 2.3.0); none is a verification bypass. As of October 9,
2026, the maintainers had not been notified. The author will report each behavior through the
project's published security contact, and the paper will state the dates. Public release of
this artifact, maintainer notification, and journal publication are separate events. Nothing in
this repository contacts anyone.

## Citation

```bibtex
@article{ahmad2026otpsend,
  author  = {Ahmad, Naveed},
  title   = {Send Side Quota Enforcement in One Time Password Software:
             A Package Survey and a Measurement Under Concurrency},
  journal = {Computers \& Security},
  year    = {2026},
  note    = {Under review; artifact v5.0-r17}
}
```

`CITATION.cff` gives the same record in the Citation File Format, which GitHub reads.

## License

MIT for the code in this repository. The package metadata in `results/` was collected from
the public package index and remains subject to the licenses of the projects it describes.
