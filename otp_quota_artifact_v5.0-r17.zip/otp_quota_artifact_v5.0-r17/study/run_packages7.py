"""Round 7: execute more surveyed packages on their own delivery paths, with
local adapters in place of the provider and nothing sent off the host.

In process (the package's own device method, called from k threads, each on
its own database connection, as in study/run_package_exec.py):
  otp_email   django-otp 1.7.3, EmailDevice.generate_challenge (the round 4
              package), here also on PostgreSQL
  two_factor  django-two-factor-auth 1.18.1, PhoneDevice.generate_challenge
              with method "sms" through a gateway that posts to the local
              provider stub
  otp_twilio  django-otp-twilio 1.0.5, TwilioSMSDevice.generate_challenge,
              with OTP_TWILIO_URL pointing at the local provider stub's
              Twilio Messages route
  django_mfa  django-mfa 4.6.0, the e-mail adapter's _ensure_code (the send
              path of begin_verify), with its database rate limit backend
              (the package default, "3/5m" per user)

Over HTTP (the package's own view or router, four Uvicorn workers):
  otp_auth    django-otp-auth 2.3.0, otp_auth.api_send_otp, sessions in
              SQLite or PostgreSQL, OTP_API_BASE pointing at the local stub
  fastapi_otp fastapi-otp-auth 0.1.4, POST /auth/request-otp, Redis, mail to
              a local SMTP sink

Deliveries are counted where the package sends them: the provider stub's log
(an independent process) or the SMTP sink's log, per number or address.
Writes results/r7/packages_<name>_<backend>.csv and .events.jsonl.

    python3 study/run_packages7.py <name> --backend sqlite|postgres
"""
import argparse
import csv
import json
import os
import random
import secrets
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import uuid

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
OUT = os.path.join(ROOT, "results", "r7")
PPORT, APORT, SMTP_PORT = 8098, 8099, 1025
PBASE = f"http://127.0.0.1:{PPORT}"
ABASE = f"http://127.0.0.1:{APORT}"
TMP = tempfile.mkdtemp(prefix="pk7-")
PLOG = os.path.join(TMP, "provider.jsonl")
SLOG = os.path.join(TMP, "smtp.jsonl")
LEVELS = [1, 2, 4, 8, 16, 32]


def spawn(args, env):
    return subprocess.Popen(args, env=dict(os.environ, PYTHONPATH=ROOT, **env), cwd=env.get("CWD", ROOT),
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, preexec_fn=os.setsid)


def wait_http(url, tries=300):
    for _ in range(tries):
        try:
            httpx.get(url, timeout=1.0)
            return
        except Exception:
            time.sleep(0.15)
    raise RuntimeError("did not start: " + url)


def stop(p):
    try:
        os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        p.wait(timeout=15)
    except Exception:
        try:
            os.killpg(os.getpgid(p.pid), signal.SIGKILL)
        except Exception:
            pass


def start_provider():
    p = spawn([sys.executable, "-m", "uvicorn", "svc.provider:app", "--host", "127.0.0.1", "--port", str(PPORT),
               "--workers", "1", "--log-level", "error"], dict(PROVIDER_LOG=PLOG, PROVIDER_SLEEP_MS="50"))
    wait_http(f"{PBASE}/log?phone=warm")
    return p


def provider_count(number):
    n = 0
    if os.path.exists(PLOG):
        for line in open(PLOG):
            if line.strip() and json.loads(line)["phone"] == number:
                n += 1
    return n


def smtp_count(addr):
    n = 0
    if os.path.exists(SLOG):
        for line in open(SLOG):
            if line.strip() and json.loads(line)["to"] == addr.lower():
                n += 1
    return n


def pg_reset(tables):
    import psycopg
    with psycopg.connect("dbname=otp user=otp password=otp host=127.0.0.1", autocommit=True) as c:
        for t in tables:
            c.execute(f"DROP TABLE IF EXISTS {t} CASCADE")


# ====================================================================== in process
def configure(name, backend, db):
    import django
    from django.conf import settings
    if backend == "postgres":
        DB = {"ENGINE": "django.db.backends.postgresql", "NAME": "otp", "USER": "otp",
              "PASSWORD": "otp", "HOST": "127.0.0.1"}
    else:
        DB = {"ENGINE": "django.db.backends.sqlite3", "NAME": db, "OPTIONS": {"timeout": 30}}
    apps = ["django.contrib.contenttypes", "django.contrib.auth", "django_otp"]
    extra = {}
    if name == "otp_email":
        apps += ["django_otp.plugins.otp_email"]
        extra = dict(EMAIL_BACKEND="study.mailcount.CountingEmailBackend",
                     OTP_EMAIL_BODY_TEMPLATE="Your code is {{ token }}.", OTP_EMAIL_COOLDOWN_DURATION=3600,
                     OTP_EMAIL_TOKEN_VALIDITY=300, OTP_EMAIL_THROTTLE_FACTOR=1)
    elif name == "two_factor":
        apps += ["django_otp.plugins.otp_static", "django_otp.plugins.otp_totp", "two_factor",
                 "two_factor.plugins.phonenumber", "phonenumber_field"]
        extra = dict(TWO_FACTOR_SMS_GATEWAY="study.gw.ProviderGateway", PHONENUMBER_DEFAULT_REGION="US")
    elif name == "django_mfa":
        apps = ["django.contrib.contenttypes", "django.contrib.auth", "django.contrib.sessions", "django_mfa"]
        extra = dict(EMAIL_BACKEND="study.mailcount.CountingEmailBackend", DEFAULT_FROM_EMAIL="h@harness.invalid",
                     MFA_RATE_LIMIT_BACKEND="database", MFA_EMAIL_SEND_RATE_LIMIT="3/5m")
    elif name == "otp_twilio":
        apps += ["otp_twilio"]
        extra = dict(OTP_TWILIO_URL=PBASE, OTP_TWILIO_ACCOUNT="ACharness", OTP_TWILIO_AUTH="harness",
                     OTP_TWILIO_FROM="+15550000000")
    settings.configure(DEBUG=False, SECRET_KEY="harness-only", DATABASES={"default": DB}, INSTALLED_APPS=apps,
                       USE_TZ=True, PASSWORD_HASHERS=["django.contrib.auth.hashers.MD5PasswordHasher"],
                       TEMPLATES=[{"BACKEND": "django.template.backends.django.DjangoTemplates",
                                   "DIRS": [], "APP_DIRS": True, "OPTIONS": {}}], **extra)
    django.setup()
    from django.core.management import call_command
    call_command("migrate", run_syncdb=True, verbosity=0, interactive=False)


def make_device(name, i):
    from django.contrib.auth.models import User
    u = User.objects.create(username=f"s{i}-{uuid.uuid4().hex[:8]}", email=f"s{i}@harness.invalid")
    number = "+1555" + str(random.randint(0, 9999999)).zfill(7)
    if name == "otp_email":
        from django_otp.plugins.otp_email.models import EmailDevice
        return EmailDevice.objects.create(user=u, name="default", confirmed=True), u.email
    if name == "django_mfa":
        return u, u.email
    if name == "two_factor":
        from two_factor.plugins.phonenumber.models import PhoneDevice
        return PhoneDevice.objects.create(user=u, name="default", confirmed=True, number=number,
                                          method="sms"), number
    if name == "otp_twilio":
        from otp_twilio.models import TwilioSMSDevice
        return TwilioSMSDevice.objects.create(user=u, name="default", confirmed=True, number=number), number


def device_model(name):
    if name == "otp_email":
        from django_otp.plugins.otp_email.models import EmailDevice as M
    elif name == "two_factor":
        from two_factor.plugins.phonenumber.models import PhoneDevice as M
    else:
        from otp_twilio.models import TwilioSMSDevice as M
    return M


class _Req:
    def __init__(self):
        self.session = {}


def call_once(name, pk, ev):
    if name == "django_mfa":
        from django.contrib.auth.models import User
        from django_mfa.adapters.email import EmailAdapter
        ev["t_load"] = time.time()
        u = User.objects.get(pk=pk)
        ev["t_call_start"] = time.time()
        EmailAdapter()._ensure_code(_Req(), u, u.email, "mfa_email_verify")
        ev["t_call_end"] = time.time()
        return None
    M = device_model(name)
    ev["t_load"] = time.time()
    d = M.objects.get(pk=pk)
    ev["t_call_start"] = time.time()
    r = d.generate_challenge()
    ev["t_call_end"] = time.time()
    ev["returned"] = str(r)[:60]
    return r


def run_inprocess(a):
    from django.db import connections
    db = os.path.join(TMP, "pk.sqlite3")
    if a.backend == "postgres":
        pg_reset(["django_migrations", "django_content_type", "auth_permission", "auth_group",
                  "auth_group_permissions", "auth_user", "auth_user_groups", "auth_user_user_permissions",
                  "otp_email_emaildevice", "otp_static_staticdevice", "otp_static_statictoken",
                  "otp_totp_totpdevice", "two_factor_phonedevice", "otp_twilio_twiliosmsdevice",
                  "django_session", "django_mfa_authenticator", "django_mfa_ratelimitcounter",
                  "django_mfa_recoverycode", "django_mfa_webauthncredential", "django_mfa_trusteddevice"])
    configure(a.name, a.backend, db)
    from study import mailcount
    import importlib.metadata as md
    pkg = {"otp_email": "django-otp", "two_factor": "django-two-factor-auth", "otp_twilio": "django-otp-twilio",
           "django_mfa": "django-mfa"}[a.name]
    ver = md.version(pkg)
    declared = {"otp_email": 1, "two_factor": None, "otp_twilio": None, "django_mfa": 3}[a.name]
    prov = start_provider() if a.name not in ("otp_email", "django_mfa") else None
    rng = random.Random(a.seed)
    tag = f"packages_{a.name}_{a.backend}"
    os.makedirs(OUT, exist_ok=True)
    ef = open(os.path.join(OUT, tag + ".events.jsonl"), "w")
    rows = []
    cells = [("concurrent", k, t) for k in LEVELS for t in range(a.trials)]
    cells += [("sequential", k, t) for k in LEVELS for t in range(a.seq_trials)]
    rng.shuffle(cells)
    try:
        for i, (mode, k, t) in enumerate(cells):
            dev, target = make_device(a.name, i)
            mailcount.reset()
            evs, errs = [], []

            def one(j, gate=None):
                ev = {"call": j}
                if gate:
                    gate.wait()
                try:
                    call_once(a.name, dev.pk, ev)
                    ev["decision"] = "called"
                except Exception as e:
                    ev["error"] = type(e).__name__
                    errs.append(type(e).__name__)
                finally:
                    if gate:
                        connections.close_all()
                    evs.append(ev)
            if mode == "concurrent":
                gate = threading.Barrier(k)
                ts = [threading.Thread(target=one, args=(j, gate)) for j in range(k)]
                [x.start() for x in ts]
                [x.join() for x in ts]
            else:
                for j in range(k):
                    one(j)
            time.sleep(0.05)
            delivered = len(mailcount.sends()) if a.name in ("otp_email", "django_mfa") else provider_count(target)
            for ev in evs:
                ef.write(json.dumps(dict(ev, package=pkg, version=ver, backend=a.backend, mode=mode,
                                         concurrency=k, trial=t)) + "\n")
            rows.append(dict(package=pkg, version=ver, backend=a.backend, mode=mode, concurrency=k, trial=t,
                             declared_limit=declared if declared is not None else "", deliveries=delivered,
                             over=int(declared is not None and delivered > declared),
                             errors=len(errs), error_types=";".join(sorted(set(errs)))))
    finally:
        if prov:
            stop(prov)
        ef.close()
    write(tag, rows)


# ====================================================================== over HTTP
def burst(url, payloads, k, form=False):
    gate = threading.Barrier(k)
    out = [None] * k

    def w(i):
        with httpx.Client(timeout=120.0) as c:
            gate.wait()
            try:
                r = c.post(url, data=payloads[i]) if form else c.post(url, json=payloads[i])
                out[i] = r.status_code
            except Exception as e:
                out[i] = f"error:{type(e).__name__}"
    ts = [threading.Thread(target=w, args=(i,)) for i in range(k)]
    [x.start() for x in ts]
    [x.join() for x in ts]
    return out


def sequential(url, payloads, new_conn, form=False):
    out = []
    c = httpx.Client(timeout=120.0)
    for p in payloads:
        if new_conn:
            c.close()
            c = httpx.Client(timeout=120.0)
        try:
            r = c.post(url, data=p) if form else c.post(url, json=p)
            out.append(r.status_code)
        except Exception as e:
            out.append(f"error:{type(e).__name__}")
    c.close()
    return out


def run_http(a):
    rng = random.Random(a.seed)
    tag = f"packages_{a.name}_{a.backend}"
    import importlib.metadata as md
    procs = [start_provider()]
    env = {}
    if a.name == "otp_auth":
        pkg, declared = "django-otp-auth", 1
        cwd = os.path.join(TMP, "otpauth")
        os.makedirs(cwd, exist_ok=True)
        json.dump({"OTP_API_BASE": PBASE, "OTP_API_KEY": "harness"}, open(os.path.join(cwd, "otp_config.json"), "w"))
        env = dict(DJANGO_SETTINGS_MODULE="svc.pkgs.otpauth_site.settings", OTP_PKG_DB=a.backend,
                   OTP_PKG_SQLITE=os.path.join(TMP, "otpauth.sqlite3"), CWD=cwd)
        if a.backend == "postgres":
            pg_reset(["django_session", "django_migrations"])
        subprocess.run([sys.executable, "-m", "django", "migrate", "--run-syncdb", "-v", "0"],
                       env=dict(os.environ, PYTHONPATH=ROOT, **{k: v for k, v in env.items() if k != "CWD"}),
                       cwd=cwd, check=True)
        module, url, form = "svc.pkgs.otpauth_site.asgi:application", f"{ABASE}/send/", True
        payload = lambda target: {"mobile": target}
        count = provider_count
    else:
        pkg, declared = "fastapi-otp-auth", 5
        env = dict(FASTAPI_OTP_AUTH_REDIS_URL="redis://127.0.0.1:6379/2", FASTAPI_OTP_AUTH_SMTP_SERVER="127.0.0.1",
                   FASTAPI_OTP_AUTH_SMTP_PORT=str(SMTP_PORT))
        subprocess.run(["redis-cli", "-n", "2", "FLUSHDB"], check=True, capture_output=True)
        procs.append(spawn([sys.executable, os.path.join(ROOT, "study", "smtp_sink.py")], dict(SMTP_LOG=SLOG)))
        time.sleep(1.0)
        module, url, form = "svc.pkgs.fastapi_otp_app:app", f"{ABASE}/auth/request-otp", False
        payload = lambda target: {"email": target}
        count = smtp_count
    ver = md.version(pkg)
    app = spawn([sys.executable, "-m", "uvicorn", module, "--host", "127.0.0.1", "--port", str(APORT),
                 "--workers", "4", "--log-level", "error"], env)
    procs.append(app)
    wait_http(f"{ABASE}/docs" if a.name == "fastapi_otp" else f"{ABASE}/send/")
    os.makedirs(OUT, exist_ok=True)
    rows = []
    cells = [("concurrent", k, t) for k in LEVELS for t in range(a.trials)]
    cells += [(m, 8, t) for m in ("sequential", "sequential_new_conn") for t in range(a.seq_trials)]
    rng.shuffle(cells)
    try:
        for mode, k, t in cells:
            if a.name == "otp_auth":
                target = "+1555" + str(rng.randint(0, 9999999)).zfill(7)
            else:
                target = f"u{uuid.uuid4().hex[:12]}@example.com"
            pl = [payload(target)] * k
            rep = (burst(url, pl, k, form) if mode == "concurrent"
                   else sequential(url, pl, mode == "sequential_new_conn", form))
            time.sleep(0.15)
            d = count(target)
            rows.append(dict(package=pkg, version=ver, backend=a.backend if a.name == "otp_auth" else "redis",
                             mode=mode, concurrency=k, trial=t, declared_limit=declared, deliveries=d,
                             over=int(d > declared),
                             errors=sum(1 for r in rep if str(r).startswith("error") or r == 500)))
    finally:
        for p in procs:
            stop(p)
    write(tag, rows)


def write(tag, rows):
    with open(os.path.join(OUT, tag + ".csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {len(rows)} rows to results/r7/{tag}.csv", flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("name", choices=["otp_email", "two_factor", "otp_twilio", "django_mfa", "otp_auth", "fastapi_otp"])
    ap.add_argument("--backend", default="sqlite", choices=["sqlite", "postgres"])
    ap.add_argument("--trials", type=int, default=30)
    ap.add_argument("--seq-trials", type=int, default=10)
    ap.add_argument("--seed", type=int, default=20261009)
    a = ap.parse_args()
    random.seed(a.seed)
    (run_http if a.name in ("otp_auth", "fastapi_otp") else run_inprocess)(a)
    shutil.rmtree(TMP, ignore_errors=True)
