"""Every enforcement measured under the burst protocol, on two scales, for the
v5.0 comparison figure and the macros that quote it.

For each subject and datastore: the worst trial's grants divided by the
subject's declared limit, and the share of its simultaneous trials with more
requests than the limit (k > L) that exceeded the limit, with that
denominator. Read from results/paper_numbers.json only. Trials with k <= L
cannot exceed the limit; that none did is asserted, not assumed.
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KS = (1, 2, 4, 8, 16, 32)

DESIGNS = [("naive_count", "Count then insert", "two"), ("cache_get_set", "Read modify write counter", "two"),
           ("after_send", "Increment after send", "two"), ("atomic_update", "Conditional atomic update", "one"),
           ("immediate_txn", "Guarded write transaction", "one"), ("reserve_commit", "Reserve before send", "one")]
PACKAGES = [("otp_email", "django-otp 1.7.3", "two"), ("django_mfa", "django-mfa 4.6.0", "two"),
            ("otp_auth", "django-otp-auth 2.3.0", "process"), ("fastapi_otp", "fastapi-otp-auth 0.1.4", "one")]
LIBS = [("slowapi_memory", "SlowAPI, memory, 4 workers", "process", "default"),
        ("djrl_locmem", "django-ratelimit, local memory, 4 workers", "process", "rejected"),
        ("slowapi_memory_1w", "SlowAPI, memory, 1 worker", "one", "default"),
        ("slowapi_memory_moving_1w", "SlowAPI, memory, moving, 1 worker", "one", "per process"),
        ("djrl_locmem_1w", "django-ratelimit, local memory, 1 worker", "one", "rejected"),
        ("djrl_db_sqlite", "django-ratelimit, DB cache, SQLite", "two", "rejected"),
        ("djrl_db_postgres", "django-ratelimit, DB cache, PostgreSQL", "two", "rejected"),
        ("slowapi_redis", "SlowAPI, Redis, fixed", "one", "supported"),
        ("slowapi_redis_moving", "SlowAPI, Redis, moving", "one", "supported"),
        ("slowapi_redis_sliding", "SlowAPI, Redis, sliding counter", "one", "supported"),
        ("slowapi_memcached", "SlowAPI, Memcached", "one", "supported"),
        ("djrl_redis", "django-ratelimit, Redis", "one", "warning"),
        ("djrl_memcached", "django-ratelimit, Memcached", "one", "supported")]


def rows(P=None):
    """[(group, label, shape, datastore, amplification, over, eligible)]"""
    P = P or json.load(open(os.path.join(ROOT, "results", "paper_numbers.json")))
    S2, R7 = P["study2"], P["r7"]
    out = []
    for s, lab, shape in DESIGNS:
        for b, key in (("SQLite", "main_sqlite"), ("PostgreSQL", "main_postgres")):
            cells = [S2[key][f"{s}|{k}"] for k in KS]
            assert all(c["policy_violations"] == 0 for c, k in zip(cells, KS) if k <= 3)
            over = sum(c["policy_violations"] for c, k in zip(cells, KS) if k > 3)
            n = sum(c["n"] for c, k in zip(cells, KS) if k > 3)
            out.append(("This study's designs (round 4)", lab, shape, b,
                        S2[key + "_summary"][s]["worst_amplification"], over, n))
    for key, lab, shape in PACKAGES:
        for b in ("sqlite", "postgres", "redis"):
            d = R7["packages"].get(f"{key}|{b}")
            if d is None:
                continue
            lim = d["declared_limit"]
            assert all(c["over"] == 0 for kk, c in d["cells"].items()
                       if kk.startswith("concurrent|") and int(kk.split("|")[1]) <= lim)
            out.append(("Surveyed packages (round 7)", f"{lab} ($L={lim}$)", shape,
                        {"sqlite": "SQLite", "postgres": "PostgreSQL", "redis": "Redis"}[b],
                        d["worst_amplification"], d["concurrent_over"], d["concurrent_trials_k_gt_L"]))
    for cfg, lab, shape, sup in LIBS:
        src = R7["libraries7"] if cfg in R7["libraries7"]["summary"] else P["libraries"]
        cells = [src["cells"][f"{cfg}|{k}"] for k in KS]
        ov = [c.get("over", c.get("policy_violations")) for c in cells]
        assert all(o == 0 for o, k in zip(ov, KS) if k <= 3)
        out.append(("Rate limiting libraries (rounds 6 and 7)", lab, shape, sup,
                    src["summary"][cfg]["worst_amplification"],
                    sum(o for o, k in zip(ov, KS) if k > 3), sum(c["n"] for c, k in zip(cells, KS) if k > 3)))
    return out


def two_step_share_range(P=None):
    """Smallest and largest share over the limit among the enforcements whose
    decision is a check followed by a separate write."""
    sh = [100 * o / n for g, l, shape, b, a, o, n in rows(P) if shape == "two"]
    return round(min(sh)), round(max(sh))


def one_step_violations(P=None):
    return sum(o for g, l, shape, b, a, o, n in rows(P) if shape == "one"), \
        sum(n for g, l, shape, b, a, o, n in rows(P) if shape == "one")


if __name__ == "__main__":
    for r in rows():
        print(r)
    print(two_step_share_range(), one_step_violations())
