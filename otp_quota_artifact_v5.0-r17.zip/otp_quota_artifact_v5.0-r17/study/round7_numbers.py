"""Every number of the round 7 arms (artifact v5.0-r17), from their records
in results/r7/ and formal/; imported by regenerate.py, which writes the
result under the key "r7" of results/paper_numbers.json.

Nothing here is typed in: each value is computed from a CSV or JSONL file
that a script in study/ or formal/ wrote, or from a hand label file in
results/r7/survey/ that records its own evidence.
"""
import csv
import json
import math
import os
import re
import statistics as st
from collections import Counter, defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _rows(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def _wilson(x, n, z=1.96):
    if n == 0:
        return None
    p = x / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return [round(100 * max(0.0, c - h), 1), round(100 * min(1.0, c + h), 1)]


def _q(v):
    v = sorted(v)
    if len(v) < 2:
        return v[0], v[0], v[0]
    q = st.quantiles(v, n=4)
    return q[0], st.median(v), q[2]


def _cell(v, lim=None):
    v = sorted(v)
    d = {"n": len(v), "median": st.median(v), "min": v[0], "max": v[-1]}
    if lim is not None:
        d["over"] = sum(1 for x in v if x > lim)
        d["over_ci_pct"] = _wilson(d["over"], len(v))
    return d


# ------------------------------------------------------------ executed packages
PKG = [("otp_email", "django-otp", "1.7.3"), ("django_mfa", "django-mfa", "4.6.0"),
       ("otp_auth", "django-otp-auth", "2.3.0"), ("fastapi_otp", "fastapi-otp-auth", "0.1.4"),
       ("two_factor", "django-two-factor-auth", "1.18.1"), ("otp_twilio", "django-otp-twilio", "1.0.5")]


def packages(R):
    out = {}
    for key, pkg, ver in PKG:
        for b in ("sqlite", "postgres"):
            f = os.path.join(R, "r7", f"packages_{key}_{b}.csv")
            if not os.path.exists(f):
                continue
            rs = _rows(f)
            backend = rs[0]["backend"]
            lim = int(rs[0]["declared_limit"]) if rs[0]["declared_limit"] else None
            by = defaultdict(list)
            for r in rs:
                by[(r["mode"], int(r["concurrency"]))].append(int(r["deliveries"]))
            cells = {f"{m}|{k}": _cell(v, lim) for (m, k), v in sorted(by.items())}
            conc = [x for (m, k), v in by.items() if m == "concurrent" for x in v]
            conc_gt = [x for (m, k), v in by.items() if m == "concurrent" and (lim is None or k > lim) for x in v]
            d = {"package": pkg, "version": ver, "backend": backend, "declared_limit": lim, "trials": len(rs),
                 "errors": sum(int(r["errors"]) for r in rs), "cells": cells,
                 "concurrent_trials": len(conc), "concurrent_max": max(conc),
                 "deliveries_equal_k_every_trial": all(int(r["deliveries"]) == int(r["concurrency"]) for r in rs
                                                        if r["mode"] in ("concurrent", "sequential")) if lim is None else None}
            if lim is not None:
                d["concurrent_over"] = sum(1 for x in conc if x > lim)
                d["concurrent_trials_k_gt_L"] = len(conc_gt)
                d["worst_amplification"] = round(max(conc) / lim, 1)
                seq = [x for (m, k), v in by.items() if m.startswith("sequential") for x in v]
                d["sequential_over"] = sum(1 for x in seq if x > lim)
                for m in ("sequential", "sequential_new_conn"):
                    v = [x for (mm, k), vv in by.items() if mm == m for x in vv]
                    if v:
                        d[m + "_max"] = max(v)
                        d[m + "_over"] = sum(1 for x in v if x > lim)
            out[f"{key}|{backend}"] = d
    return out


# ------------------------------------------------------------ libraries
SUPPORTED = {  # what each library's documentation and checks say
    "slowapi_memory": "per process store, four workers (documented default; not shared)",
    "slowapi_redis": "supported shared store",
    "djrl_locmem": "rejected by the system check (E003)",
    "djrl_db_sqlite": "rejected by the system check (E003)",
    "djrl_db_postgres": "rejected by the system check (E003)",
    "djrl_redis": "warning only (W001), shared atomic store",
    "slowapi_memcached": "supported shared store",
    "slowapi_redis_moving": "supported shared store, moving window",
    "slowapi_redis_sliding": "supported shared store, sliding window counter",
    "slowapi_memory_1w": "per process store, one worker",
    "slowapi_memory_moving_1w": "per process store, moving window, one worker",
    "djrl_memcached": "supported (no system check issue)",
    "djrl_locmem_1w": "rejected by the system check (E003), one worker",
}


def libraries7(R):
    base = os.path.join(R, "r7", "libraries7")
    if not os.path.exists(base + ".csv"):
        return None
    rs = _rows(base + ".csv")
    meta = json.load(open(base + ".meta.json"))
    lim = meta["limit"]
    by, seq = defaultdict(list), defaultdict(list)
    for r in rs:
        a = int(r["admits"])
        assert int(r["provider_sends"]) == a, "provider calls differ from admissions"
        if r["mode"] == "concurrent":
            by[(r["config"], int(r["concurrency"]))].append(a)
        else:
            seq[(r["config"], r["mode"])].append(a)
    out = {"meta": {k: meta[k] for k in ("versions", "seed", "limit", "workers", "trials", "levels")},
           "django_system_checks": {c: {"exit": v["exit"], "ids": sorted(set(re.findall(r"django_ratelimit\.[EW]\d+", v["output"])))}
                                    for c, v in meta.get("django_system_checks", {}).items()},
           "cells": {}, "sequential": {}, "summary": {}, "errors": sum(int(r["errors"]) for r in rs), "trials": len(rs)}
    cfgs = sorted({c for c, _ in by})
    for (c, k), v in sorted(by.items()):
        out["cells"][f"{c}|{k}"] = _cell(v, lim)
    for c in cfgs:
        cv = [x for (cc, k), v in by.items() if cc == c for x in v]
        out["summary"][c] = {"trials": len(cv), "over": sum(1 for x in cv if x > lim), "max": max(cv),
                             "worst_amplification": round(max(cv) / lim, 1), "support": SUPPORTED.get(c, ""),
                             "workers": meta["workers"].get(c)}
        for m in ("sequential", "sequential_new_conn"):
            v = seq.get((c, m), [])
            if v:
                out["sequential"][f"{c}|{m}"] = {"n": len(v), "max": max(v), "over": sum(1 for x in v if x > lim)}
    return out


def worker_assignment(R):
    """Round 6 process local configurations: admissions per worker process
    in every trial, from the pid in each event record."""
    path = os.path.join(R, "r6", "libraries.events.jsonl")
    if not os.path.exists(path):
        return None
    trials = defaultdict(list)
    for line in open(path):
        e = json.loads(line)
        if e["config"] in ("slowapi_memory", "djrl_locmem"):
            trials[(e["config"], e["mode"], e["concurrency"], e["trial"])].append(e)
    out = {}
    for cfg in ("slowapi_memory", "djrl_locmem"):
        per_worker_max, workers_seen, admits_eq = 0, Counter(), 0
        n = 0
        for (c, mode, k, t), evs in trials.items():
            if c != cfg:
                continue
            n += 1
            adm = Counter(e["pid"] for e in evs if e["decision"] == "admit")
            per_worker_max = max(per_worker_max, max(adm.values()) if adm else 0)
            pids = {e["pid"] for e in evs}
            workers_seen[len(pids)] += 1
            admits_eq += int(sum(adm.values()) == sum(min(3, sum(1 for e in evs if e["pid"] == p)) for p in pids))
        out[cfg] = {"trials": n, "max_admissions_by_one_worker": per_worker_max,
                    "trials_admissions_equal_sum_over_workers_of_min_requests_L": admits_eq,
                    "distinct_workers_per_trial": dict(sorted(workers_seen.items()))}
    return out


# ------------------------------------------------------------ round 7 arms
ORDER = ["naive_count", "cache_get_set", "after_send", "atomic_update", "immediate_txn", "reserve_commit"]


def indep(R, s2):
    out = {"runs": {}, "between_run": {}}
    runs = defaultdict(lambda: defaultdict(list))
    for b in ("sqlite", "postgres"):
        # run 1 is the round 4 main sweep (the same cells)
        r4 = s2.get(f"main_{b}")
        for f in sorted(os.listdir(os.path.join(R, "r7"))):
            m = re.match(rf"indep_{b}_run(\d+)\.csv$", f)
            if not m:
                continue
            rr = int(m.group(1))
            for r in _rows(os.path.join(R, "r7", f)):
                runs[(b, rr)][(r["strategy"], int(r["concurrency"]))].append((int(r["admits"]), int(r["policy_overrun"]) > 0))
        for s in ORDER:
            for k in (4, 8, 32):
                per = {}
                if r4 and f"{s}|{k}" in r4:
                    c = r4[f"{s}|{k}"]
                    per[1] = {"median": c["median"], "max": c["max"], "violations": c["policy_violations"], "n": c["n"]}
                for (bb, rr), cells in runs.items():
                    if bb != b or (s, k) not in cells:
                        continue
                    v = cells[(s, k)]
                    per[rr] = {"median": st.median(a for a, _ in v), "max": max(a for a, _ in v),
                               "violations": sum(1 for _, p in v if p), "n": len(v)}
                if per:
                    out["runs"][f"{b}|{s}|{k}"] = per
                    vio = [p["violations"] for p in per.values()]
                    med = [p["median"] for p in per.values()]
                    out["between_run"][f"{b}|{s}|{k}"] = {"runs": len(per), "violations_min": min(vio),
                                                          "violations_max": max(vio), "median_min": min(med),
                                                          "median_max": max(med)}
    one_step_viol = sum(p["violations"] for key, per in out["runs"].items() for rr, p in per.items()
                        if rr > 1 and key.split("|")[1] in ORDER[3:])
    one_step_trials = sum(p["n"] for key, per in out["runs"].items() for rr, p in per.items()
                          if rr > 1 and key.split("|")[1] in ORDER[3:])
    out["new_runs_one_step_violations"] = one_step_viol
    out["new_runs_one_step_trials"] = one_step_trials
    out["new_runs_trials"] = sum(p["n"] for per in out["runs"].values() for rr, p in per.items() if rr > 1)
    return out


def interfere(R):
    f = os.path.join(R, "r7", "interfere_sqlite.csv")
    if not os.path.exists(f):
        return None
    by = defaultdict(list)
    for r in _rows(f):
        by[(r["strategy"], r["logging"], int(r["concurrency"]))].append(int(r["provider_sends"]))
    out = {}
    for (s, m, k), v in sorted(by.items()):
        out[f"{s}|{m}|{k}"] = _cell(v, 3)
    return out


def provider(R):
    out = {}
    for b in ("sqlite", "postgres"):
        f = os.path.join(R, "r7", f"provider_{b}.csv")
        if not os.path.exists(f):
            continue
        rs = _rows(f)
        out[b] = {"trials": len(rs),
                  "requests_logged_equal_k": all(int(r["requests_logged"]) == int(r["concurrency"]) for r in rs),
                  "provider_log_equals_admissions": all(int(r["provider_log_calls"]) == int(r["admits"]) for r in rs),
                  "db_provider_rows_equal_admissions": all(int(r["db_provider_rows"]) == int(r["admits"]) for r in rs),
                  "request_ids_match": all(r["rids_match"] == "1" for r in rs),
                  "message_ids_match": all(r["mids_match"] == "1" for r in rs),
                  "verdict_agrees": all((int(r["policy_overrun"]) > 0) == (r["provider_over"] == "1") for r in rs),
                  "by_strategy": {s: {"trials": sum(1 for r in rs if r["strategy"] == s),
                                      "provider_over": sum(1 for r in rs if r["strategy"] == s and r["provider_over"] == "1")}
                                  for s in ORDER}}
    return out


def sync(R):
    f = os.path.join(R, "r7", "sync_sqlite.csv")
    if not os.path.exists(f):
        return None
    by = defaultdict(list)
    for r in _rows(f):
        by[(r["strategy"], r["release"], int(r["concurrency"]))].append(r)
    out = {}
    for (s, m, k), rs in sorted(by.items()):
        a = [int(r["admits"]) for r in rs]
        out[f"{s}|{m}|{k}"] = dict(_cell(a, 3), violations=sum(1 for r in rs if int(r["policy_overrun"]) > 0),
                                   arrival_spread_ms_median=st.median(float(r["arrival_spread_ms"]) for r in rs),
                                   read_spread_ms_median=st.median(float(r["read_spread_ms"]) for r in rs),
                                   errors=sum(int(r["errors"]) for r in rs))
    return out


def timing(R):
    out = {}
    for b in ("sqlite", "postgres"):
        f = os.path.join(R, "r7", f"timing_{b}.csv")
        if not os.path.exists(f):
            continue
        by = defaultdict(list)
        for r in _rows(f):
            by[(r["strategy"], r["release"], int(r["delay_ms_max"]))].append(r)
        for (s, rel, d), rs in sorted(by.items()):
            n = len(rs)
            c2 = [int(r["c2_billed_per_window"]) for r in rs if r["c2_billed_per_window"] != ""]
            out[f"{b}|{s}|{rel}|{d}"] = {
                "trials": n, "faults": rs[0]["faults"] == "1",
                "c1_violated": sum(int(r["c1_violated"]) for r in rs),
                "c1_tau_violated": sum(int(r["c1_tau_violated"]) for r in rs),
                "c2_violated": sum(int(r["c2_violated"]) for r in rs),
                "c2_max": max(c2) if c2 else None,
                "negative_counter": sum(int(r["negative_counter"]) for r in rs),
                "late_grants": sum(int(r["late_grants"]) for r in rs),
                "trials_with_late_grant": sum(1 for r in rs if int(r["late_grants"]) > 0),
                "provider_any_interval_max": max(int(r["provider_any_interval"]) for r in rs),
                "provider_any_interval_over_L": sum(1 for r in rs if int(r["provider_any_interval"]) > 3),
                "admits_median": st.median(int(r["admits"]) for r in rs),
                "released": sum(int(r["released"]) for r in rs),
                "errors": sum(int(r["errors"]) for r in rs)}
    return out


def timing_events(R):
    """The time and fault arms recomputed from their event records, request by
    request. A call counts toward C1 whether or not its reservation was later
    returned, and a call is billed when its outcome is ok or a timeout that
    billed (unkB), also whether or not it was returned. (The arm's own c1 and
    c2 columns counted only the requests whose final decision was "admit", so
    they omit returned calls; these columns supersede them.) The authorization
    instant tau is the application's instant at the return of the granting
    statement (t_write)."""
    out = {}
    for b in ("sqlite", "postgres"):
        f = os.path.join(R, "r7", f"timing_{b}.events.jsonl")
        if not os.path.exists(f):
            continue
        trials = defaultdict(list)
        for line in open(f):
            e = json.loads(line)
            trials[(e["strategy"], e.get("release", ""), int(e["delay_ms_max"]), e["trial"])].append(e)
        agg = defaultdict(lambda: defaultdict(int))
        for (st_, rel, dl, t), evs in trials.items():
            W, L = evs[0]["window_s"], evs[0]["limit"]
            calls = [e for e in evs if e["decision"] in ("admit", "released") and e.get("message_id")]
            billed = [e for e in calls if e.get("provider_outcome") in (None, "unkB")]
            pol = evs[0]["policy"]

            def mx(es, tau):
                if not es:
                    return 0
                if pol == "fixed":
                    ws = Counter(math.floor(e["t_write"] / W) if tau else e["window_id"] for e in es)
                    return max(ws.values())
                ts = sorted(e["t_write"] if tau else e["policy_ts"] for e in es)
                return max(sum(1 for y in ts if x <= y < x + W) for x in ts)
            a = agg[f"{b}|{st_}|{rel}|{dl}"]
            a["trials"] += 1
            a["faults"] = int(evs[0].get("faults", 0))
            a["c1_calls_violated"] += int(mx(calls, False) > L)
            a["c1_calls_tau_violated"] += int(mx(calls, True) > L)
            a["c2_violated"] += int(mx(billed, False) > L)
            a["c2_tau_violated"] += int(mx(billed, True) > L)
            a["c2_max"] = max(a["c2_max"], mx(billed, False))
            a["released"] += sum(1 for e in evs if e["decision"] == "released" and e.get("released_rows", 1))
            a["release_no_row"] += sum(1 for e in evs if e["decision"] == "released" and e.get("released_rows", 1) == 0)
            a["cross_window_releases"] += sum(1 for e in evs if e["decision"] == "released" and e.get("released_rows", 1)
                                              and rel != "certain_reserved" and not st_.endswith("_db")
                                              and math.floor(e["t_done"] / W) * W != e["window_id"])
            a["calls"] += len(calls)
            a["billed"] += len(billed)
            a["unkU"] += sum(1 for e in calls if e.get("provider_outcome") == "unkU")
        out.update({k: dict(v) for k, v in agg.items()})
    return out


def load(R):
    out = {}
    for b in ("sqlite", "postgres"):
        f = os.path.join(R, "r7", f"load_{b}.csv")
        if os.path.exists(f):
            for r in _rows(f):
                out[f"{b}|{r['strategy']}|{r['rate']}"] = {k: (float(v) if re.fullmatch(r"-?\d+(\.\d+)?", v or "") else v)
                                                          for k, v in r.items() if k not in ("arm", "backend", "strategy")}
    return out


def overlap(R):
    """Offered concurrency against observed overlap at the decision, round 4
    SQLite main sweep: per trial, the number of requests whose read of the
    quota state came before the L-th granting write (application observed
    instants)."""
    path = os.path.join(R, "r4", "main_sqlite.events.jsonl")
    trials = defaultdict(list)
    for line in open(path):
        e = json.loads(line)
        trials[(e["strategy"], e["concurrency"], e["trial"])].append(e)
    by = defaultdict(list)
    per_trial = []
    for (s, k, t), evs in sorted(trials.items()):
        writes = sorted(e["t_write"] for e in evs if e.get("decision") == "admit" and e.get("t_write"))
        if len(writes) < 3:
            continue
        cut = writes[2]
        ov = sum(1 for e in evs if e.get("t_read") and e["t_read"] < cut)
        by[(s, k)].append(ov)
        recv = [e["t_recv"] for e in evs if e.get("t_recv")]
        reads = [e["t_read"] for e in evs if e.get("t_read")]
        per_trial.append({"strategy": s, "concurrency": k, "trial": t,
                          "arrival_spread_ms": round(1000 * (max(recv) - min(recv)), 3) if recv else "",
                          "read_spread_ms": round(1000 * (max(reads) - min(reads)), 3) if reads else "",
                          "third_grant_after_first_arrival_ms": round(1000 * (cut - min(recv)), 3) if recv else "",
                          "reads_before_third_grant": ov,
                          "grants": sum(1 for e in evs if e.get("decision") == "admit")})
    with open(os.path.join(R, "r7", "overlap_per_trial.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(per_trial[0]))
        w.writeheader()
        w.writerows(per_trial)
    return {f"{s}|{k}": dict(zip(("q1", "median", "q3"), _q(v)), n=len(v), max=max(v))
            for (s, k), v in sorted(by.items())}


# ------------------------------------------------------------ formal (round 7)
def formal7():
    out = {}
    p = os.path.join(ROOT, "formal", "tla", "results_timed.json")
    if os.path.exists(p):
        runs = json.load(open(p))
        agg = defaultdict(list)
        for r in runs:
            var = []
            if r["K"] > 1:
                var.append(f"K{r['K']}")
            if r["faults"]:
                var.append("faults")
            if r["design"] == "ReserveBeforeSend":
                var.append(f"{r['rule']}/{r['scope']}")
            if r["dbclock"]:
                var.append("dbclock")
            if r.get("D") is not None:
                var.append(f"D{r['D']}")
            if r["T"] != 4:
                var.append(f"T{r['T']}")
            agg[(r["group"], r["design"], r["prop"], ",".join(var))].append(r)
        out["tlc_timed_runs"] = len(runs)
        out["tlc_timed_max_states"] = max(r["distinct"] for r in runs if r["distinct"])
        out["tlc_timed"] = {"|".join(k): {"verdicts": {f"N{r['N']}L{r['L']}": r["verdict"] for r in v},
                                          "holds_all": all(r["verdict"] == "holds" for r in v),
                                          "violated_any": any(r["verdict"] == "violated" for r in v)}
                            for k, v in sorted(agg.items())}
    sw = os.path.join(ROOT, "formal", "tamarin", "results", "sweep.json")
    if os.path.exists(sw):
        recs = json.load(open(sw))
        out["tamarin_sweep"] = {f"{r['design']}|L{r['L']}": {k: v["verdict"] for k, v in r["lemmas"].items()}
                                for r in recs}
        out["tamarin_sweep_all_verified"] = all(v["verdict"] == "verified" for r in recs for v in r["lemmas"].values())
        out["tamarin_sweep_limits"] = sorted({r["L"] for r in recs})
    pp = os.path.join(ROOT, "formal", "tamarin", "results", "param")
    if os.path.isdir(pp):
        par = {}
        for f in sorted(os.listdir(pp)):
            m = re.match(r"log_(\w+)\.txt$", f)
            if m:
                log = open(os.path.join(pp, f)).read()
                par[m.group(1)] = {x.group(1): {"verdict": x.group(3), "steps": int(x.group(4))}
                                   for x in re.finditer(r"^  (\w+) \((all-traces|exists-trace)\): (verified|falsified|analysis incomplete) \((\d+) steps\)", log, re.M)}
        out["tamarin_param"] = par
    return out


# ------------------------------------------------------------ survey (round 7)
def survey7(R, s1):
    d = os.path.join(R, "r7", "survey")
    out = {}
    sv = _rows(os.path.join(d, "stage_validation.csv"))
    meta = [r for r in sv if r["stage"] == "metadata"]
    name = [r for r in sv if r["stage"] == "name"]
    ns = json.load(open(os.path.join(d, "name_stage_sample.json")))
    rel_n = sum(int(r["relevant"]) for r in name)
    out["metadata_stage"] = {"reviewed": len(meta), "relevant": sum(int(r["relevant"]) for r in meta),
                             "relevant_send_bound": dict(Counter(r["send_bound"] for r in meta if r["relevant"] == "1")),
                             "code_inspected": sum(int(r["code_inspected"]) for r in meta)}
    out["name_stage"] = {"index_size_now": ns["index_size"], "broad_token_names_outside": ns["broad_outside"],
                         "sample": len(name), "relevant": rel_n, "relevant_ci_pct": _wilson(rel_n, len(name)),
                         "est_relevant_outside": round(ns["broad_outside"] * rel_n / len(name)),
                         "est_relevant_outside_ci": [round(ns["broad_outside"] * x / 100) for x in _wilson(rel_n, len(name))],
                         "relevant_send_bound": dict(Counter(r["send_bound"] for r in name if r["relevant"] == "1")),
                         "seed": ns["seed"], "fetched_utc": ns["fetched_utc"]}
    vw = _rows(os.path.join(d, "validation_whole_package.csv"))
    miss = sum(1 for r in vw if r["whole_package_label"] == "miss")
    rej = 695
    out["validation_whole_package"] = {"sample": len(vw), "misses": miss,
                                       "missed_packages": [r["package"] for r in vw if r["whole_package_label"] == "miss"],
                                       "miss_rate_pct": round(100 * miss / len(vw), 1),
                                       "miss_rate_ci_pct": _wilson(miss, len(vw)),
                                       "est_missed_in_screened_set": round(rej * miss / len(vw), 1),
                                       "est_missed_ci": [round(rej * x / 100, 1) for x in _wilson(miss, len(vw))],
                                       "est_relevant_in_screened_set": round(s1["retained"] + rej * miss / len(vw)),
                                       "detector_recall_pct": round(100 * s1["retained"] / (s1["retained"] + rej * miss / len(vw)), 1),
                                       "detector_recall_ci_pct": [round(100 * s1["retained"] / (s1["retained"] + rej * x / 100), 1)
                                                                  for x in reversed(_wilson(miss, len(vw)))]}
    fam = _rows(os.path.join(d, "families.csv"))
    fams = defaultdict(list)
    for r in fam:
        fams[r["family"]].append(r)
    lvl = lambda rs: {r["send_control_evidence_level"] for r in rs}
    out["families"] = {"packages": len(fam), "families": len(fams),
                       "multi_member": sorted([len(v) for v in fams.values() if len(v) > 1], reverse=True),
                       "families_all_none": sum(1 for v in fams.values() if lvl(v) == {"none_in_package"}),
                       "families_any_in_package": sum(1 for v in fams.values()
                                                      if lvl(v) & {"in_package_delivery_path", "in_package_framework_throttle"}),
                       "families_delegated_only": sum(1 for v in fams.values() if lvl(v) == {"delegated_provider"})}
    gc = _rows(os.path.join(d, "guard_contracts.csv"))
    out["guard_contracts"] = {"rows": len(gc),
                              "per_recipient_effective": [r["package"] for r in gc if r["constrains_send_only_attacker_per_recipient"].startswith("yes")],
                              "per_recipient_effective_one_worker_only": [r["package"] for r in gc if r["constrains_send_only_attacker_per_recipient"].startswith("only")],
                              "not_per_recipient": [r["package"] for r in gc if r["constrains_send_only_attacker_per_recipient"].startswith("no")],
                              "provider": [r["package"] for r in gc if r["constrains_send_only_attacker_per_recipient"].startswith("depends")],
                              "one_step": [r["package"] for r in gc if r["decision_shape"].startswith("one step")],
                              "two_step": [r["package"] for r in gc if r["decision_shape"].startswith("two step")],
                              "executed": [r["package"] for r in gc if r["executed_round7"].startswith("yes")]}
    return out


def round7(R, s1, s2):
    if not os.path.isdir(os.path.join(R, "r7")):
        return None
    return {"packages": packages(R), "libraries7": libraries7(R), "worker_assignment": worker_assignment(R),
            "indep": indep(R, s2), "interfere": interfere(R), "provider": provider(R), "sync": sync(R),
            "timing": timing(R), "timing_events": timing_events(R), "load": load(R), "overlap": overlap(R), "formal": formal7(),
            "survey": survey7(R, s1)}
