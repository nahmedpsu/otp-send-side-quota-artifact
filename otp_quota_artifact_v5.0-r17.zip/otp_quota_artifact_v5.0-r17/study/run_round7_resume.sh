#!/usr/bin/env bash
# Resume of study/run_round7.sh after the container restart of 2026-10-09
# 01:59Z, which interrupted the provider arm on SQLite (its partial records
# were deleted; the arm is rerun whole). Every earlier arm had completed.
set -u
cd "$(dirname "$0")/.."
LOG=results/r7/round7.log
run() { echo "=== $(date -u +%FT%TZ) $*" | tee -a "$LOG"; "$@" >> "$LOG" 2>&1 || echo "FAILED: $*" | tee -a "$LOG"; }
echo "=== $(date -u +%FT%TZ) resume after container restart (provider sqlite interrupted, rerun whole)" >> "$LOG"
run python3 study/run_round7.py provider --backend sqlite
run python3 study/run_round7.py provider --backend postgres
run python3 study/run_round7.py sync --backend sqlite
run python3 study/run_round7.py timing --backend sqlite
run python3 study/run_round7.py timing --backend postgres
run python3 study/run_round7.py load --backend sqlite
run python3 study/run_round7.py load --backend postgres
echo "=== $(date -u +%FT%TZ) done" | tee -a "$LOG"
