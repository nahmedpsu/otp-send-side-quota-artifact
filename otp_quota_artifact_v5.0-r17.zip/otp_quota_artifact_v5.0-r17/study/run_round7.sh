#!/bin/bash
# Round 7 (service 2.2.0, artifact v5.0-r17): every new empirical arm, one
# after another, so no two arms share the host's two cores.
# Needs Redis, Memcached and PostgreSQL 16 running (see README). Writes
# results/r7/ and results/r7/round7.log.
set -u
cd "$(dirname "$0")/.."
mkdir -p results/r7
LOG=results/r7/round7.log
run() { echo "=== $(date -u +%FT%TZ) $*" | tee -a "$LOG"; "$@" >> "$LOG" 2>&1 || echo "FAILED: $*" | tee -a "$LOG"; }

# executed packages (local adapters; nothing leaves the host)
for b in sqlite postgres; do
  for n in otp_email two_factor otp_twilio django_mfa otp_auth; do
    run python3 study/run_packages7.py $n --backend $b
  done
done
run python3 study/run_packages7.py fastapi_otp --backend sqlite

# library arm: supported configurations, other strategies, one worker
run python3 study/run_libraries.py --configs slowapi_memcached slowapi_redis_moving slowapi_redis_sliding \
    slowapi_memory_1w slowapi_memory_moving_1w djrl_memcached djrl_locmem_1w \
    --seed 20261009 --out results/r7/libraries7.csv

# independent repeated runs of the main sweep cells k = 4, 8, 32
for r in 2 3 4; do
  run python3 study/run_round7.py indep --backend sqlite --run $r --seed $((20261009 + r))
  run python3 study/run_round7.py indep --backend postgres --run $r --seed $((20261109 + r))
done

run python3 study/run_round7.py interfere --backend sqlite
run python3 study/run_round7.py provider --backend sqlite
run python3 study/run_round7.py provider --backend postgres
run python3 study/run_round7.py sync --backend sqlite
run python3 study/run_round7.py timing --backend sqlite
run python3 study/run_round7.py timing --backend postgres
run python3 study/run_round7.py load --backend sqlite
run python3 study/run_round7.py load --backend postgres
echo "=== $(date -u +%FT%TZ) done" | tee -a "$LOG"
