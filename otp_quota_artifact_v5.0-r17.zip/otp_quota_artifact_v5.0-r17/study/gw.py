"""A django-two-factor-auth SMS gateway for the harness (round 7): it posts
each message to the local provider stub (svc/provider.py, route /sms), which
logs it. Configured with TWO_FACTOR_SMS_GATEWAY = "study.gw.ProviderGateway".
Nothing leaves the host."""
import os

import httpx

URL = os.environ.get("PROVIDER_BASE", "http://127.0.0.1:8098")


class ProviderGateway:
    @staticmethod
    def send_sms(device, token):
        httpx.post(URL + "/sms", json={"to": device.number.as_e164, "rid": str(device.pk)}, timeout=60)

    @staticmethod
    def make_call(device, token):
        httpx.post(URL + "/sms", json={"to": device.number.as_e164, "rid": "call"}, timeout=60)
