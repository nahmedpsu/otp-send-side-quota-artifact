#!/usr/bin/env bash
# Stage artifact v5.0-r17: the files of v4.8-r16 that still exist, plus every
# round 7 addition, into a clean tree; write and verify its manifest; zip it.
#
#     bash study/package_v5.sh <v4.8 file list> <staging dir>
set -eu
cd "$(dirname "$0")/.."
LIST=$1
STAGE=$2
NAME=otp_quota_artifact_$(cat VERSION)
DST="$STAGE/$NAME"
rm -rf "$DST"
mkdir -p "$DST"
copy() { for f in "$@"; do [ -e "$f" ] || { echo "missing: $f"; exit 1; }; mkdir -p "$DST/$(dirname "$f")"; cp -p "$f" "$DST/$f"; done; }
# 1. everything v4.8-r16 shipped that still exists (MANIFEST is rewritten below)
while read -r f; do
  [ -z "$f" ] && continue
  [ "$f" = "MANIFEST.sha256.json" ] && continue
  [ -e "$f" ] && copy "$f"
done < "$LIST"
# 2. round 7 additions
copy svc/opt.py svc/provider.py svc/archive/app_v2.1.0.py svc/archive/app_pg_v2.1.0.py
for f in $(find svc/pkgs -type f ! -name '*.pyc' ! -path '*__pycache__*'); do copy "$f"; done
copy study/run_round7.py study/run_round7.sh study/run_round7_resume.sh study/run_packages7.py study/gw.py \
     study/smtp_sink.py study/round7_numbers.py study/paper_macros.py study/paper_tables7.py study/make_figs7.py \
     study/comparison7.py study/package_v5.sh
for f in $(find results/r7 -type f); do copy "$f"; done
copy formal/run_formal_round7.sh formal/formal_round7.log formal/formal_round7_part1.log formal/tla/AdmissionTimed.tla formal/tla/run_tlc_timed.py \
     formal/tla/results_timed.json formal/tla/results_timed.md \
     formal/tamarin/OTPAdmissionParam.spthy formal/tamarin/sweep_limits.py
for d in formal/tla/traces_timed formal/tamarin/results/param formal/tamarin/results/sweep; do
  for f in $(find "$d" -type f); do copy "$f"; done
done
[ -e formal/tamarin/results/sweep.json ] && copy formal/tamarin/results/sweep.json
for f in $(find review/coding_kit -type f); do copy "$f"; done
copy review/literature_search.md review/reviewer2_cose_round17_report.txt review/rebuttal_round17.tex \
     review/rebuttal_round17_body.tex review/rebuttal_round17.pdf review/cover_letter_cose_v5_0.txt
copy paper/otp_cose.tex paper/otp_cose.pdf paper/otp_cose.gate.txt paper/make_docx.py paper/references.bib
for f in $(find paper/cose -type f -name '*.tex' ! -name '_old*'); do copy "$f"; done
for f in paper/gen/*.tex paper/fig_*.pdf; do copy "$f"; done
copy README.md VERSION CITATION.cff svc/CHANGELOG.md svc/app.py svc/app_pg.py regenerate.py build_notebook.py \
     notebooks/otp_quota_reproduction.ipynb notebooks/otp_quota_reproduction_executed.ipynb formal/README.md
# 3. manifest, verified in the staged tree
( cd "$DST" && python3 study/manifest.py write && python3 study/manifest.py verify )
( cd "$STAGE" && rm -f "$NAME.zip" && zip -qr "$NAME.zip" "$NAME" )
echo "staged $DST and $STAGE/$NAME.zip ($(du -h "$STAGE/$NAME.zip" | cut -f1))"
