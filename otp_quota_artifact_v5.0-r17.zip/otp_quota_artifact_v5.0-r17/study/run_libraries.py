"""
Off-the-shelf limiters under the burst protocol (round 6, library arm).

The same barrier protocol as study/run_experiments.py, applied to two widely
used Python rate limiting libraries guarding the same OTP send endpoint and
the same provider stub, with the same declared policy: three admissions per
number per hour. The library alone decides admission; the service records
one event per request (svc/libs/common.py).

  SlowAPI 0.1.10 on limits 5.8.0, fixed window, storage in process memory
      (the library's default) or in Redis 7
  django-ratelimit 4.1.0 on Django 5.1.15, with Django's default local
      memory cache, the database cache on SQLite or PostgreSQL 16, or the
      Redis cache

Every configuration runs four Uvicorn worker processes, the main sweep's
levels k in {1, 2, 4, 8, 16, 32} and 30 trials per cell, in an order
randomized under a recorded seed. Each trial uses a fresh phone number, so
no trial inherits another's limiter state. Writes results/r6/libraries.csv
(one row per trial) and results/r6/libraries.events.jsonl (one record per
request). Two sequential controls send 8 requests one after another, 10 trials each
per configuration, in the same randomized order: on one keep-alive connection
(as a test client does) and on a new connection per request. For the
django-ratelimit configurations the output of Django's system check is kept in
the meta file. The script checks in every trial that the provider calls the stub
recorded equal the admissions in the event records.

    python3 study/run_libraries.py [--trials 30] [--seed 20261008]
"""
import argparse
import csv
import json
import os
import random
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import zlib

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = int(os.environ.get("EXP_PORT", "8098"))
BASE = f"http://127.0.0.1:{PORT}"
TMP = tempfile.gettempdir()
PROVIDER_DB = os.path.join(TMP, "otp_lib_provider.db")
EVENT_DIR = PROVIDER_DB + ".events"
DJ_DB = os.path.join(TMP, "otp_lib_django.db")
LIMIT = 3
WINDOW_S = 3600
CHECKS = {}

CONFIGS = {
    # name: (library, backend, module, extra environment)
    "slowapi_memory": ("SlowAPI", "process memory", "svc.libs.slowapi_app:app",
                       {"OTP_LIMITS_STORAGE": "memory://"}),
    "slowapi_redis": ("SlowAPI", "Redis", "svc.libs.slowapi_app:app",
                      {"OTP_LIMITS_STORAGE": "redis://127.0.0.1:6379/0"}),
    "djrl_locmem": ("django-ratelimit", "local memory cache", "svc.libs.django_site.asgi:application",
                    {"OTP_DJ_CACHE": "locmem"}),
    "djrl_db_sqlite": ("django-ratelimit", "database cache, SQLite", "svc.libs.django_site.asgi:application",
                       {"OTP_DJ_CACHE": "db-sqlite"}),
    "djrl_db_postgres": ("django-ratelimit", "database cache, PostgreSQL", "svc.libs.django_site.asgi:application",
                         {"OTP_DJ_CACHE": "db-postgres"}),
    "djrl_redis": ("django-ratelimit", "Redis cache", "svc.libs.django_site.asgi:application",
                   {"OTP_DJ_CACHE": "redis"}),
    # round 7: the configurations each library documents as supported, the
    # other two strategies of the limits library, and one worker process
    "slowapi_memcached": ("SlowAPI", "Memcached", "svc.libs.slowapi_app:app",
                          {"OTP_LIMITS_STORAGE": "memcached://127.0.0.1:11211"}),
    "slowapi_redis_moving": ("SlowAPI", "Redis, moving window", "svc.libs.slowapi_app:app",
                             {"OTP_LIMITS_STORAGE": "redis://127.0.0.1:6379/0",
                              "OTP_LIMITS_STRATEGY": "moving-window"}),
    "slowapi_redis_sliding": ("SlowAPI", "Redis, sliding window counter", "svc.libs.slowapi_app:app",
                              {"OTP_LIMITS_STORAGE": "redis://127.0.0.1:6379/0",
                               "OTP_LIMITS_STRATEGY": "sliding-window-counter"}),
    "slowapi_memory_1w": ("SlowAPI", "process memory, one worker", "svc.libs.slowapi_app:app",
                          {"OTP_LIMITS_STORAGE": "memory://", "OTP_WORKERS": "1"}),
    "slowapi_memory_moving_1w": ("SlowAPI", "process memory, moving window, one worker", "svc.libs.slowapi_app:app",
                                 {"OTP_LIMITS_STORAGE": "memory://", "OTP_LIMITS_STRATEGY": "moving-window",
                                  "OTP_WORKERS": "1"}),
    "djrl_memcached": ("django-ratelimit", "Memcached cache", "svc.libs.django_site.asgi:application",
                       {"OTP_DJ_CACHE": "memcached"}),
    "djrl_locmem_1w": ("django-ratelimit", "local memory cache, one worker", "svc.libs.django_site.asgi:application",
                       {"OTP_DJ_CACHE": "locmem", "OTP_WORKERS": "1"}),
}
ROUND6 = ["slowapi_memory", "slowapi_redis", "djrl_locmem", "djrl_db_sqlite", "djrl_db_postgres", "djrl_redis"]


def versions():
    import importlib.metadata as md
    out = {}
    for pkg in ("slowapi", "limits", "django-ratelimit", "Django", "redis", "pymemcache", "uvicorn", "fastapi"):
        try:
            out[pkg] = md.version(pkg)
        except md.PackageNotFoundError:
            out[pkg] = None
    try:
        out["memcached"] = subprocess.run(["memcached", "-V"], capture_output=True, text=True).stdout.split()[1]
    except Exception:
        out["memcached"] = None
    try:
        out["redis-server"] = subprocess.run(["redis-server", "--version"], capture_output=True,
                                             text=True).stdout.split()[2].split("=")[1]
    except Exception:
        out["redis-server"] = None
    return out


def prepare(name, env):
    for f in (PROVIDER_DB, PROVIDER_DB + "-wal", PROVIDER_DB + "-shm", DJ_DB, DJ_DB + "-wal", DJ_DB + "-shm"):
        try:
            os.remove(f)
        except FileNotFoundError:
            pass
    shutil.rmtree(EVENT_DIR, ignore_errors=True)
    if "redis" in name:
        subprocess.run(["redis-cli", "FLUSHALL"], check=True, capture_output=True)
    if "memcached" in name:
        from pymemcache.client.base import Client
        Client(("127.0.0.1", 11211)).flush_all()
    if name.startswith("djrl_db"):
        if name.endswith("postgres"):
            subprocess.run(["psql", "-h", "127.0.0.1", "-U", "otp", "-d", "otp", "-c",
                            "DROP TABLE IF EXISTS otp_ratelimit_cache"],
                           env=dict(env, PGPASSWORD="otp"), check=True, capture_output=True)
        subprocess.run([sys.executable, "-m", "django", "createcachetable"],
                       env=env, cwd=ROOT, check=True, capture_output=True)


def system_check(name, env):
    """What Django's system check framework (manage.py check) reports for a
    django-ratelimit configuration; the checks run at check, migrate and
    runserver time, not when an ASGI server imports the application."""
    p = subprocess.run([sys.executable, "-m", "django", "check"], env=env, cwd=ROOT,
                       capture_output=True, text=True)
    return {"exit": p.returncode, "output": (p.stdout + p.stderr).strip()}


def start(name):
    lib, backend, module, extra = CONFIGS[name]
    env = dict(os.environ, PYTHONPATH=ROOT, OTP_PROVIDER_DB=PROVIDER_DB, OTP_EVENT_DIR=EVENT_DIR,
               OTP_LIMIT=str(LIMIT), OTP_PROVIDER_MS="50", OTP_LIB_CONFIG=name,
               OTP_DJ_DB=DJ_DB, DJANGO_SETTINGS_MODULE="svc.libs.django_site.settings", **extra)
    prepare(name, env)
    if name.startswith("djrl"):
        CHECKS[name] = system_check(name, env)
    p = subprocess.Popen([sys.executable, "-m", "uvicorn", module, "--host", "127.0.0.1",
                          "--port", str(PORT), "--workers", extra.get("OTP_WORKERS", "4"),
                          "--log-level", "error"],
                         env=env, cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         preexec_fn=os.setsid)
    for _ in range(300):
        try:
            if httpx.get(f"{BASE}/otp/stats", params={"phone": "warm"}, timeout=1.0).status_code == 200:
                return p
        except Exception:
            pass
        time.sleep(0.15)
    stop(p)
    raise RuntimeError(f"server did not start: {name}")


def stop(p):
    try:
        os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        p.wait(timeout=15)
    except Exception:
        try:
            os.killpg(os.getpgid(p.pid), signal.SIGKILL)
        except Exception:
            pass


def burst(phone, k, timeout=120.0):
    barrier = threading.Barrier(k)
    out = [None] * k

    def worker(i):
        with httpx.Client(timeout=timeout) as c:
            barrier.wait()
            try:
                r = c.post(f"{BASE}/otp/request", params={"phone": phone}, json={"phone": phone})
                out[i] = r.json().get("status", f"http_{r.status_code}")
            except Exception as e:            # recorded, never swallowed
                out[i] = f"error:{type(e).__name__}"

    ts = [threading.Thread(target=worker, args=(i,)) for i in range(k)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    return out


def sequential(phone, k, new_connection, timeout=120.0):
    """k requests one after another: on one keep-alive connection, as a test
    client sends them (and as one worker then serves them), or each on a new
    connection, so that the server may hand them to different workers, as a
    load balancer would."""
    out = []

    def one(c):
        try:
            r = c.post(f"{BASE}/otp/request", params={"phone": phone}, json={"phone": phone})
            out.append(r.json().get("status", f"http_{r.status_code}"))
        except Exception as e:
            out.append(f"error:{type(e).__name__}")

    if new_connection:
        for _ in range(k):
            with httpx.Client(timeout=timeout) as c:
                one(c)
    else:
        with httpx.Client(timeout=timeout) as c:
            for _ in range(k):
                one(c)
    return out


def djrl_window(phone, ts):
    """The end of the django-ratelimit window an instant falls in
    (django_ratelimit.core._get_window, period 3600)."""
    t = int(ts)
    w = t - (t % WINDOW_S) + (zlib.crc32(phone.encode()) % WINDOW_S)
    return w + WINDOW_S if w < t else w


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", nargs="+", default=ROUND6)
    ap.add_argument("--concurrency", nargs="+", type=int, default=[1, 2, 4, 8, 16, 32])
    ap.add_argument("--trials", type=int, default=30)
    ap.add_argument("--seed", type=int, default=20261008)
    ap.add_argument("--seq-k", type=int, default=8, help="requests per sequential control trial")
    ap.add_argument("--seq-trials", type=int, default=10)
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "r6", "libraries.csv"))
    args = ap.parse_args()
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    events_path = os.path.splitext(args.out)[0] + ".events.jsonl"
    rng = random.Random(args.seed)
    configs = list(args.configs)
    rng.shuffle(configs)
    meta = dict(seed=args.seed, versions=versions(), configs=configs, limit=LIMIT, window_s=WINDOW_S,
                workers={n: CONFIGS[n][3].get('OTP_WORKERS', '4') for n in configs}, provider_ms=50, trials=args.trials, levels=args.concurrency,
                sequential_k=args.seq_k, sequential_trials=args.seq_trials,
                start_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    rows = []
    ef = open(events_path, "w")
    for name in configs:
        lib, backend, module, extra = CONFIGS[name]
        print(f"[{time.strftime('%H:%M:%S')}] {name}", flush=True)
        p = start(name)
        try:
            cells = [("concurrent", k, t) for k in args.concurrency for t in range(args.trials)]
            cells += [("sequential", args.seq_k, t) for t in range(args.seq_trials)]
            cells += [("sequential_new_conn", args.seq_k, t) for t in range(args.seq_trials)]
            rng.shuffle(cells)
            for mode, k, trial in cells:
                phone = f"+2{configs.index(name)}{dict(concurrent='c', sequential='s', sequential_new_conn='n')[mode]}{k:02d}{trial:03d}"
                t0 = time.time()
                replies = (burst(phone, k) if mode == "concurrent"
                           else sequential(phone, k, new_connection=(mode == "sequential_new_conn")))
                elapsed = time.time() - t0
                n_provider = httpx.get(f"{BASE}/otp/stats", params={"phone": phone}, timeout=60).json()["provider_sends"]
                evs = httpx.get(f"{BASE}/otp/events", params={"phone": phone}, timeout=60).json()["events"]
                admits = [e for e in evs if e["decision"] == "admit"]
                windows = ({djrl_window(phone, e["t_recv"]) for e in admits} if name.startswith("djrl") else set())
                for e in evs:
                    ef.write(json.dumps(dict(e, config=name, library=lib, backend=backend,
                                             mode=mode, concurrency=k, trial=trial)) + "\n")
                ef.flush()
                errs = [r for r in replies if str(r).startswith("error")]
                rows.append(dict(config=name, library=lib, backend=backend, mode=mode, concurrency=k, trial=trial,
                                 limit=LIMIT, requests_logged=len(evs), admits=len(admits),
                                 provider_sends=n_provider,
                                 admits_equal_provider_calls=int(n_provider == len(admits)),
                                 over=int(len(admits) > LIMIT),
                                 windows_touched=(len(windows) if windows else 1),
                                 accepted_replies=sum(1 for r in replies if r == "sent"),
                                 rejected_replies=sum(1 for r in replies if r == "rejected"),
                                 errors=len(errs), error_types=";".join(sorted(set(errs))),
                                 elapsed_s=round(elapsed, 4)))
            done = [r for r in rows if r["config"] == name]
            for k in args.concurrency:
                v = sorted(r["admits"] for r in done if r["concurrency"] == k and r["mode"] == "concurrent")
                print(f"   k={k:>3} admits {v}", flush=True)
            for m in ("sequential", "sequential_new_conn"):
                v = sorted(r["admits"] for r in done if r["mode"] == m)
                print(f"   {m} k={args.seq_k} admits {v}", flush=True)
        finally:
            stop(p)
    ef.close()
    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    json.dump(dict(meta, django_system_checks=CHECKS,
                   end_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())),
              open(os.path.splitext(args.out)[0] + ".meta.json", "w"), indent=1)
    print(f"wrote {len(rows)} rows to {args.out}")


if __name__ == "__main__":
    main()
