"""Round 7 figures of the v5.0 manuscript, drawn from the round 7 trial files
in results/r7/ (never from typed numbers).

Usage: python3 study/make_figs7.py [packages] [libraries] [timing] [timed]

fig_packages7.pdf: deliveries per simultaneous trial for the six executed
packages, one panel per package; marker = median of the 30 trials at each k,
thick bar = interquartile range, thin bar = range; dashed line = the
package's declared limit, dotted line = k. The two datastores are offset.
"""
import csv
import math
import os
import statistics as st
import sys
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R7 = os.path.join(ROOT, "results", "r7")
OUT = os.path.join(ROOT, "paper")
RC = {"font.family": "serif", "font.serif": ["Liberation Serif", "Times New Roman", "DejaVu Serif"],
      "mathtext.fontset": "stix", "font.size": 8, "axes.linewidth": 0.6, "xtick.direction": "in",
      "ytick.direction": "in", "xtick.major.width": 0.6, "ytick.major.width": 0.6, "pdf.fonttype": 42}
KS = [1, 2, 4, 8, 16, 32]
COL = {"sqlite": "#2a78d6", "postgres": "#eb6834", "redis": "#1baf7a"}
DSN = {"sqlite": "SQLite", "postgres": "PostgreSQL", "redis": "Redis"}
PK = [("otp_email", "django-otp 1.7.3\ncooldown, $L=1$"), ("django_mfa", "django-mfa 4.6.0\ncount, $L=3$"),
      ("otp_auth", "django-otp-auth 2.3.0\ncooldown per worker, $L=1$"),
      ("fastapi_otp", "fastapi-otp-auth 0.1.4\natomic INCR, $L=5$"),
      ("two_factor", "django-two-factor-auth 1.18.1\nno bound for this attacker"),
      ("otp_twilio", "django-otp-twilio 1.0.5\nno bound")]


def quart(v):
    v = sorted(v)
    if len(v) < 2:
        return v[0], v[0], v[0], v[0], v[0]
    q = st.quantiles(v, n=4)
    return st.median(v), q[0], q[2], v[0], v[-1]


def packages():
    with plt.rc_context(RC):
        fig, axes = plt.subplots(2, 3, figsize=(7.0, 4.2), sharex=True)
        for ax, (key, title) in zip(axes.flat, PK):
            lim = None
            series = []
            for b in ("sqlite", "postgres", "redis"):
                f = os.path.join(R7, f"packages_{key}_{b if b != 'redis' else 'sqlite'}.csv")
                if not os.path.exists(f):
                    continue
                rows = [r for r in csv.DictReader(open(f)) if r["backend"] == b and r["mode"] == "concurrent"]
                if not rows:
                    continue
                lim = int(rows[0]["declared_limit"]) if rows[0]["declared_limit"] else None
                d = defaultdict(list)
                for r in rows:
                    d[int(r["concurrency"])].append(int(r["deliveries"]))
                series.append((b, d))
            off = {0: [0.0], 1: [0.0], 2: [-0.06, 0.06]}[len(series)]
            for (b, d), o in zip(series, off):
                xs, med = [], []
                for k in KS:
                    if k not in d:
                        continue
                    m, q1, q3, lo, hi = quart(d[k])
                    x = math.log2(k) + o
                    ax.plot([x, x], [lo, hi], color=COL[b], lw=0.7)
                    ax.plot([x, x], [q1, q3], color=COL[b], lw=2.4, solid_capstyle="butt")
                    xs.append(x)
                    med.append(m)
                ax.plot(xs, med, color=COL[b], lw=0.8, marker="o", ms=3, label=DSN[b])
            ax.plot([math.log2(k) for k in KS], KS, ls=":", color="0.4", lw=0.8)
            if lim:
                ax.axhline(lim, ls="--", color="0.2", lw=0.8)
            ax.set_title(title, fontsize=7.5)
            ax.set_xticks([math.log2(k) for k in KS])
            ax.set_xticklabels([str(k) for k in KS])
            ax.set_ylim(0, 34)
            ax.legend(fontsize=6.5, frameon=False, loc="upper left")
        for ax in axes[1]:
            ax.set_xlabel("simultaneous requests $k$")
        for ax in axes[:, 0]:
            ax.set_ylabel("deliveries per trial")
        fig.tight_layout()
        fig.savefig(os.path.join(OUT, "fig_packages7.pdf"))
        print("wrote paper/fig_packages7.pdf")


LIBGROUPS = [
    ("(a) per process store, four workers",
     [("slowapi_memory", "SlowAPI, memory"), ("djrl_locmem", "django-ratelimit, local memory")]),
    ("(b) per process store, one worker",
     [("slowapi_memory_1w", "three configurations")]),
    ("(c) database cache (read then write)",
     [("djrl_db_sqlite", "SQLite"), ("djrl_db_postgres", "PostgreSQL")]),
    ("(d) shared store with atomic increment",
     [("slowapi_redis", "six configurations")]),
]
IDENTICAL = {"slowapi_memory_1w": ["slowapi_memory_moving_1w", "djrl_locmem_1w"],
             "slowapi_redis": ["slowapi_redis_moving", "slowapi_redis_sliding", "slowapi_memcached",
                               "djrl_redis", "djrl_memcached"]}


def _librows():
    d = defaultdict(lambda: defaultdict(list))
    for f in (os.path.join(ROOT, "results", "r6", "libraries.csv"), os.path.join(R7, "libraries7.csv")):
        for r in csv.DictReader(open(f)):
            if r["mode"] == "concurrent":
                d[r["config"]][int(r["concurrency"])].append(int(r["admits"]))
    return d


def libraries():
    d = _librows()
    for base, others in IDENTICAL.items():   # a merged series must really be identical
        for o in others:
            assert {k: sorted(v) for k, v in d[o].items()} == {k: sorted(v) for k, v in d[base].items()}, o
    cols = ["#2a78d6", "#eb6834"]
    with plt.rc_context(RC):
        fig, axes = plt.subplots(1, 4, figsize=(7.0, 2.3), sharey=True)
        for ax, (title, series) in zip(axes, LIBGROUPS):
            off = [0.0] if len(series) == 1 else [-0.07, 0.07]
            for (cfg, lab), o, col in zip(series, off, cols):
                xs, med = [], []
                for k in KS:
                    m, q1, q3, lo, hi = quart(d[cfg][k])
                    x = math.log2(k) + o
                    ax.plot([x, x], [lo, hi], color=col, lw=0.7)
                    ax.plot([x, x], [q1, q3], color=col, lw=2.4, solid_capstyle="butt")
                    xs.append(x)
                    med.append(m)
                ax.plot(xs, med, color=col, lw=0.8, marker="o", ms=3, label=lab)
            ax.plot([math.log2(k) for k in KS], KS, ls=":", color="0.4", lw=0.8)
            ax.axhline(3, ls="--", color="0.2", lw=0.8)
            ax.set_title(title, fontsize=7)
            ax.set_xticks([math.log2(k) for k in KS])
            ax.set_xticklabels([str(k) for k in KS])
            ax.set_xlabel("$k$")
            ax.set_ylim(0, 33)
            ax.legend(fontsize=6, frameon=False, loc="upper left")
        axes[0].set_ylabel("admissions per trial")
        fig.tight_layout()
        fig.savefig(os.path.join(OUT, "fig_libraries7.pdf"))
        print("wrote paper/fig_libraries7.pdf")


def comparison():
    sys.path.insert(0, os.path.join(ROOT, "study"))
    import comparison7
    rows = comparison7.rows()
    shapecol = {"two": "#eb6834", "process": "#2a78d6", "one": "0.45"}
    mk = {"SQLite": "o", "PostgreSQL": "s", "Redis": "D", "default": "D", "supported": "D",
          "per process": "D", "rejected": "X", "warning": "D"}
    labels, groups = [], []
    for g, l, shape, b, a, o, n in rows:
        lab = l if g.startswith("Rate") else f"{l}, {b}"
        labels.append(lab)
        groups.append(g)
    with plt.rc_context(RC):
        fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 6.4), sharey=True,
                                     gridspec_kw={"width_ratios": [1, 1]})
        y, ys, prev, heads = 0.0, [], None, []
        for g in groups:
            if g != prev:
                if prev is not None:
                    y += 0.8
                heads.append((y, g))
                y += 0.9
                prev = g
            ys.append(y)
            y += 1.0
        for yy, (g, l, shape, b, a, o, n) in zip(ys, rows):
            kw = dict(marker=mk[b], ms=4.2, color=shapecol[shape], ls="none",
                      mfc="white" if b in ("PostgreSQL", "rejected") else shapecol[shape], mec=shapecol[shape])
            a1.plot([a], [yy], **kw)
            a2.plot([100 * o / n], [yy], **kw)
            a2.text(108, yy, f"{o}/{n}", va="center", fontsize=6)
        for yy, g in heads:
            a1.text(0.62, yy, g, fontsize=7, fontweight="bold", va="center")
        a1.set_xscale("log", base=2)
        a1.set_xticks([1, 2, 4, 8, 16, 32])
        a1.set_xticklabels(["1", "2", "4", "8", "16", "32"])
        a1.set_xlim(0.6, 40)
        a1.axvline(1, color="0.7", lw=0.6)
        a1.set_xlabel("(a) worst trial: grants / declared limit")
        a2.set_xlim(-4, 132)
        a2.set_xticks([0, 25, 50, 75, 100])
        a2.set_xlabel("(b) trials with $k>L$ over the limit (%)")
        a1.set_yticks(ys)
        a1.set_yticklabels(labels, fontsize=6.5)
        a1.invert_yaxis()
        from matplotlib.lines import Line2D
        h = [Line2D([], [], color=shapecol["two"], marker="o", ls="none", label="check, then a separate write"),
             Line2D([], [], color=shapecol["process"], marker="o", ls="none", label="one counter per worker process"),
             Line2D([], [], color=shapecol["one"], marker="o", ls="none", label="one atomic operation, one store"),
             Line2D([], [], color="0.2", marker="s", mfc="white", ls="none", label="PostgreSQL (packages, designs)"),
             Line2D([], [], color="0.2", marker="X", mfc="white", ls="none", label="rejected by the library's check")]
        fig.legend(handles=h, fontsize=6.5, frameon=False, loc="lower center", ncol=3,
                   bbox_to_anchor=(0.62, 0.0))
        fig.subplots_adjust(left=0.33, right=0.92, top=0.99, bottom=0.12, wspace=0.06)
        fig.savefig(os.path.join(OUT, "fig_comparison7.pdf"))
        print("wrote paper/fig_comparison7.pdf")


if __name__ == "__main__":
    which = sys.argv[1:] or ["packages"]
    for w in which:
        globals()[w]()
