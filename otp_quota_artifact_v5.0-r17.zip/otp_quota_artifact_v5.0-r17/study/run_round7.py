"""Round 7 arms (service 2.2.0), run in response to the Computers & Security
review. Each subcommand writes results/r7/<arm>.csv (one row per trial),
results/r7/<arm>.events.jsonl (every event record, with the trial identity)
and, where an independent provider process is used, the provider's own log.

  indep      the main sweep cells k = 4, 8, 32, repeated as independent runs
             (fresh server, fresh database, new seed) on SQLite and PostgreSQL
  interfere  the two step designs with full and with minimal instrumentation,
             in alternating blocks; evaluated on the provider rows alone
  provider   all designs with an independent provider process; every trial is
             cross-checked: event records, the provider's own log, and the
             database's final state
  sync       the same bursts released by the threaded barrier and by last byte
             synchronization over k connections (HTTP/1.1, after Kettle)
  timing     a two second window, bursts placed around a boundary, with and
             without a decision delay of up to 1.5 s, with and without
             provider faults, for the fixed window designs, the guarded
             transaction, and the variants on the datastore's clock
  load       sustained open loop arrivals over many numbers at three rates:
             throughput, latency of admitted and refused requests, refusals
             below the limit, and errors

    python3 study/run_round7.py <arm> [--backend sqlite|postgres] [...]
"""
import argparse
import csv
import json
import math
import os
import random
import shutil
import signal
import socket
import statistics as st
import subprocess
import sys
import tempfile
import threading
import time
import uuid

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from study import policy as P  # noqa: E402

PORT = int(os.environ.get("EXP_PORT", "8099"))
PPORT = PORT - 1
BASE = f"http://127.0.0.1:{PORT}"
PBASE = f"http://127.0.0.1:{PPORT}"
TMP = tempfile.mkdtemp(prefix="r7-")
SQLITE_DB = os.path.join(TMP, "otp.db")
EVENT_DIR = os.path.join(TMP, "events")
PG_DSN = os.environ.get("OTP_PG_DSN", "dbname=otp user=otp password=otp host=127.0.0.1")
OUT = os.path.join(ROOT, "results", "r7")
TWO = ["naive_count", "cache_get_set", "after_send"]
ONE = ["atomic_update", "immediate_txn", "reserve_commit"]
POLICY = {"naive_count": "sliding", "after_send": "sliding", "immediate_txn": "sliding",
          "cache_get_set": "fixed", "atomic_update": "fixed", "reserve_commit": "fixed",
          "atomic_update_db": "fixed", "reserve_commit_db": "fixed"}


# ------------------------------------------------------------------ servers
def start(strategy, backend="sqlite", limit=3, window_s=3600, provider_ms=50, workers=4, extra=None):
    env = dict(os.environ)
    env.update(OTP_STRATEGY=strategy, OTP_LIMIT=str(limit), OTP_WINDOW_S=str(window_s),
               OTP_PROVIDER_MS=str(provider_ms), OTP_EVENT_DIR=EVENT_DIR, PYTHONPATH=ROOT)
    env.update(extra or {})
    shutil.rmtree(EVENT_DIR, ignore_errors=True)
    if backend == "sqlite":
        env["OTP_DB"] = SQLITE_DB
        module = "svc.app:app"
        for f in (SQLITE_DB, SQLITE_DB + "-wal", SQLITE_DB + "-shm"):
            if os.path.exists(f):
                os.remove(f)
    else:
        env["OTP_PG_DSN"] = PG_DSN
        module = "svc.app_pg:app"
    p = subprocess.Popen([sys.executable, "-m", "uvicorn", module, "--host", "127.0.0.1",
                          "--port", str(PORT), "--workers", str(workers), "--log-level", "error"],
                         env=env, cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         preexec_fn=os.setsid)
    for _ in range(300):
        try:
            httpx.get(f"{BASE}/otp/stats", params={"phone": "warm"}, timeout=1.0)
            return p
        except Exception:
            time.sleep(0.15)
    raise RuntimeError(f"server did not start: {strategy}/{backend}")


def start_provider(log):
    env = dict(os.environ, PROVIDER_LOG=log, PYTHONPATH=ROOT)
    p = subprocess.Popen([sys.executable, "-m", "uvicorn", "svc.provider:app", "--host", "127.0.0.1",
                          "--port", str(PPORT), "--workers", "1", "--log-level", "error"],
                         env=env, cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         preexec_fn=os.setsid)
    for _ in range(300):
        try:
            httpx.get(f"{PBASE}/log", params={"phone": "warm"}, timeout=1.0)
            return p
        except Exception:
            time.sleep(0.15)
    raise RuntimeError("provider did not start")


def stop(p):
    try:
        os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        p.wait(timeout=15)
    except Exception:
        try:
            os.killpg(os.getpgid(p.pid), signal.SIGKILL)
        except Exception:
            pass


def reset():
    httpx.post(f"{BASE}/admin/reset", timeout=60.0)


def phone():
    return "+1" + str(uuid.uuid4().int % 10**9).zfill(9)


def events_for(ph):
    r = httpx.get(f"{BASE}/otp/events", params={"phone": ph}, timeout=60.0).json()
    return r["events"], int(r["limit"]), int(r["window_s"]), r["policy"]


def sends_for(ph):
    return httpx.get(f"{BASE}/otp/sends", params={"phone": ph}, timeout=60.0).json()


# ------------------------------------------------------------------ clients
def burst(ph, k, timeout=120.0):
    barrier = threading.Barrier(k)
    out = [None] * k

    def w(i):
        with httpx.Client(timeout=timeout) as c:
            barrier.wait()
            try:
                out[i] = c.post(f"{BASE}/otp/request", json={"phone": ph}).json().get("status")
            except Exception as e:
                out[i] = f"error:{type(e).__name__}"
    ts = [threading.Thread(target=w, args=(i,)) for i in range(k)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    return out


def lastbyte(ph, k, timeout=120.0):
    """Last byte synchronization: open k connections, send every request but
    its final byte, then send the k final bytes back to back."""
    body = json.dumps({"phone": ph}).encode()
    req = (b"POST /otp/request HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Type: application/json\r\n"
           b"Connection: close\r\nContent-Length: " + str(len(body)).encode() + b"\r\n\r\n" + body)
    socks = []
    for _ in range(k):
        s = socket.create_connection(("127.0.0.1", PORT), timeout=timeout)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        s.sendall(req[:-1])
        socks.append(s)
    time.sleep(0.05)
    for s in socks:
        s.send(req[-1:])
    out = []
    for s in socks:
        data = b""
        try:
            while True:
                chunk = s.recv(65536)
                if not chunk:
                    break
                data += chunk
            txt = data.decode(errors="replace")
            out.append("sent" if '"sent"' in txt else ("rejected" if '"rejected"' in txt else "other"))
        except Exception as e:
            out.append(f"error:{type(e).__name__}")
        finally:
            s.close()
    return out


def writer(name):
    os.makedirs(OUT, exist_ok=True)
    return open(os.path.join(OUT, name + ".events.jsonl"), "w")


def write_rows(name, rows):
    with open(os.path.join(OUT, name + ".csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {len(rows)} rows to results/r7/{name}.csv", flush=True)


def spread(evs, key):
    v = [e[key] for e in evs if e.get(key)]
    return round(1000 * (max(v) - min(v)), 3) if len(v) > 1 else 0.0


# ------------------------------------------------------------------ arms
def arm_indep(a):
    rng = random.Random(a.seed)
    name = f"indep_{a.backend}_run{a.run}"
    ef, rows = writer(name), []
    strategies = TWO + ONE
    rng.shuffle(strategies)
    for s in strategies:
        print(f"[{time.strftime('%H:%M:%S')}] {name} {s}", flush=True)
        p = start(s, a.backend)
        try:
            cells = [(k, t) for k in (4, 8, 32) for t in range(a.trials)]
            rng.shuffle(cells)
            for k, t in cells:
                ph = phone(); reset()
                rep = burst(ph, k)
                evs, lim, win, pol = events_for(ph)
                ev = P.evaluate(evs, lim, win, pol)
                n = len(sends_for(ph)["ts"])
                meta = dict(arm=name, run=a.run, backend=a.backend, strategy=s, concurrency=k, trial=t)
                for e in evs:
                    ef.write(json.dumps({**e, **meta}) + "\n")
                rows.append(dict(meta, admits=ev["admits"], provider_sends=n,
                                 policy_overrun=ev["policy_overrun"], windows_touched=ev["windows_touched"],
                                 errors=sum(1 for r in rep if str(r).startswith("error")),
                                 arrival_spread_ms=spread(evs, "t_recv"), read_spread_ms=spread(evs, "t_read")))
        finally:
            stop(p)
    ef.close()
    write_rows(name, rows)


def arm_interfere(a):
    rng = random.Random(a.seed)
    name = f"interfere_{a.backend}"
    rows = []
    blocks = [("full", 0), ("minimal", 0), ("minimal", 1), ("full", 1)]
    for s in TWO:
        for mode, blk in blocks:
            print(f"[{time.strftime('%H:%M:%S')}] {name} {s} {mode} block {blk}", flush=True)
            p = start(s, a.backend, extra=dict(OTP_LOG=mode))
            try:
                cells = [(k, t) for k in (8, 32) for t in range(a.trials // 2)]
                rng.shuffle(cells)
                for k, t in cells:
                    ph = phone(); reset()
                    rep = burst(ph, k)
                    n = len(sends_for(ph)["ts"])
                    rows.append(dict(arm=name, backend=a.backend, strategy=s, logging=mode, block=blk,
                                     concurrency=k, trial=t, provider_sends=n, over=int(n > 3),
                                     errors=sum(1 for r in rep if str(r).startswith("error"))))
            finally:
                stop(p)
    write_rows(name, rows)


def db_state(ph, backend):
    """The database's own final state for one number, read directly."""
    if backend == "sqlite":
        import sqlite3
        c = sqlite3.connect(SQLITE_DB)
        att = c.execute("SELECT COUNT(*) FROM attempts WHERE phone=?", (ph,)).fetchone()[0]
        row = c.execute("SELECT used FROM counters WHERE phone=?", (ph,)).fetchone()
        sends = c.execute("SELECT COUNT(*) FROM provider_sends WHERE phone=?", (ph,)).fetchone()[0]
        c.close()
    else:
        import psycopg
        with psycopg.connect(PG_DSN, autocommit=True) as c:
            att = c.execute("SELECT COUNT(*) FROM attempts WHERE phone=%s", (ph,)).fetchone()[0]
            row = c.execute("SELECT used FROM counters WHERE phone=%s", (ph,)).fetchone()
            sends = c.execute("SELECT COUNT(*) FROM provider_sends WHERE phone=%s", (ph,)).fetchone()[0]
    return att, (row[0] if row else None), sends


def arm_provider(a):
    rng = random.Random(a.seed)
    name = f"provider_{a.backend}"
    plog = os.path.join(OUT, name + ".provider.jsonl")
    os.makedirs(OUT, exist_ok=True)
    if os.path.exists(plog):
        os.remove(plog)
    pp = start_provider(plog)
    ef, rows = writer(name), []
    try:
        for s in TWO + ONE:
            print(f"[{time.strftime('%H:%M:%S')}] {name} {s}", flush=True)
            p = start(s, a.backend, extra=dict(OTP_PROVIDER_URL=PBASE))
            try:
                cells = [(k, t) for k in (8, 32) for t in range(a.trials)]
                rng.shuffle(cells)
                for k, t in cells:
                    ph = phone(); reset()
                    burst(ph, k)
                    evs, lim, win, pol = events_for(ph)
                    ev = P.evaluate(evs, lim, win, pol)
                    calls = httpx.get(f"{PBASE}/log", params={"phone": ph}, timeout=60).json()["calls"]
                    att, used, sends = db_state(ph, a.backend)
                    adm = [e for e in evs if e.get("decision") == "admit"]
                    adm_rids = {e["rid"] for e in adm}
                    call_rids = [c["rid"] for c in calls]
                    meta = dict(arm=name, backend=a.backend, strategy=s, concurrency=k, trial=t)
                    for e in evs:
                        ef.write(json.dumps({**e, **meta}) + "\n")
                    rows.append(dict(meta, requests_logged=len(evs), admits=len(adm),
                                     provider_log_calls=len(calls), db_provider_rows=sends,
                                     db_attempt_rows=att, db_counter=used if used is not None else "",
                                     rids_match=int(set(call_rids) == adm_rids and len(call_rids) == len(set(call_rids))),
                                     mids_match=int({c["message_id"] for c in calls} == {e.get("message_id") for e in adm}),
                                     policy_overrun=ev["policy_overrun"],
                                     provider_over=int(len(calls) > lim)))
            finally:
                stop(p)
    finally:
        stop(pp)
        ef.close()
    write_rows(name, rows)


def arm_sync(a):
    rng = random.Random(a.seed)
    name = f"sync_{a.backend}"
    ef, rows = writer(name), []
    for s in TWO + ["atomic_update"]:
        print(f"[{time.strftime('%H:%M:%S')}] {name} {s}", flush=True)
        p = start(s, a.backend)
        try:
            cells = [(m, k, t) for m in ("barrier", "lastbyte") for k in (8, 32) for t in range(a.trials)]
            rng.shuffle(cells)
            for m, k, t in cells:
                ph = phone(); reset()
                rep = burst(ph, k) if m == "barrier" else lastbyte(ph, k)
                evs, lim, win, pol = events_for(ph)
                ev = P.evaluate(evs, lim, win, pol)
                meta = dict(arm=name, backend=a.backend, strategy=s, release=m, concurrency=k, trial=t)
                for e in evs:
                    ef.write(json.dumps({**e, **meta}) + "\n")
                rows.append(dict(meta, requests_logged=len(evs), admits=ev["admits"],
                                 provider_sends=len(sends_for(ph)["ts"]), policy_overrun=ev["policy_overrun"],
                                 arrival_spread_ms=spread(evs, "t_recv"), read_spread_ms=spread(evs, "t_read"),
                                 errors=sum(1 for r in rep if str(r).startswith("error"))))
        finally:
            stop(p)
    ef.close()
    write_rows(name, rows)


TIMING = [  # (strategy, extra env, faults)
    ("cache_get_set", {}, False),
    ("atomic_update", {}, False),
    ("atomic_update_db", {}, False),
    ("immediate_txn", {}, False),
    ("reserve_commit", dict(OTP_RELEASE="any_current"), True),
    ("reserve_commit", dict(OTP_RELEASE="certain_reserved"), True),
    ("reserve_commit_db", {}, True),
]


def timed_requests(ph, offsets, boundary):
    """One thread per request, each released at boundary + offset."""
    out = [None] * len(offsets)

    def w(i, off):
        with httpx.Client(timeout=120.0) as c:
            d = boundary + off - time.time()
            if d > 0:
                time.sleep(d)
            try:
                out[i] = c.post(f"{BASE}/otp/request", json={"phone": ph}).json().get("status")
            except Exception as e:
                out[i] = f"error:{type(e).__name__}"
    ts = [threading.Thread(target=w, args=(i, o)) for i, o in enumerate(offsets)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    return out


def window_counts(times, W):
    from collections import Counter
    return Counter(math.floor(t / W) for t in times)


def max_in_any(times, W):
    times = sorted(times)
    best, j = 0, 0
    for i, t in enumerate(times):
        while times[j] <= t - W:
            j += 1
        best = max(best, i - j + 1)
    return best


def arm_timing(a):
    rng = random.Random(a.seed)
    W, L = 2, 3
    name = f"timing_{a.backend}"
    ef, rows = writer(name), []
    offsets = [-0.40] * 4 + [0.10] * 4 + [0.60] * 4
    configs = [(s, ex, f, d) for s, ex, f in TIMING for d in (0, 1500)]
    if a.backend == "postgres":
        configs = [c for c in configs if c[0].endswith("_db") or c[0] == "reserve_commit"]
    for s, ex, faults, delay in configs:
        extra = dict(ex, OTP_DELAY_MS_MAX=str(delay), OTP_SEED=str(a.seed))
        if faults:
            extra["OTP_FAULTS"] = "0.2,0.2,0.2"
        print(f"[{time.strftime('%H:%M:%S')}] {name} {s} {ex} faults={faults} delay={delay}", flush=True)
        p = start(s, a.backend, limit=L, window_s=W, extra=extra)
        try:
            for t in range(a.trials):
                ph = phone(); reset()
                now = time.time()
                boundary = (math.floor(now / W) + 2) * W        # at least one full window ahead
                rep = timed_requests(ph, offsets, boundary)
                time.sleep(0.2)
                evs, lim, win, pol = events_for(ph)
                adm = [e for e in evs if e.get("decision") == "admit"]
                rel = [e for e in evs if e.get("decision") == "released"]
                billed_mids = set(sends_for(ph)["message_ids"])
                billed_ts = sends_for(ph)["ts"]
                # C1 in the implementation's own attribution
                ev = P.evaluate(evs, lim, win, pol)
                # C1 by authorization instant: the granting statement's instant
                tau = [e["t_write"] for e in adm if e.get("t_write")]
                c1tau = max(window_counts(tau, W).values()) if tau else 0
                # C2: billed admissions per attributed window (fixed designs)
                from collections import Counter
                if pol == "fixed":
                    bw = Counter(e["window_id"] for e in adm if e.get("message_id") in billed_mids)
                    c2 = max(bw.values()) if bw else 0
                else:
                    c2 = ""
                # provider observed: billed calls in any interval of length W, and per aligned window
                prov_any = max_in_any(billed_ts, W) if billed_ts else 0
                prov_aligned = max(window_counts(billed_ts, W).values()) if billed_ts else 0
                late = sum(1 for e in adm if pol == "fixed" and e.get("t_write")
                           and math.floor(e["t_write"] / W) * W > e["window_id"] + 1e-9)
                att, used, _ = db_state(ph, a.backend)
                meta = dict(arm=name, backend=a.backend, strategy=s, release=ex.get("OTP_RELEASE", ""),
                            faults=int(faults), delay_ms_max=delay, trial=t)
                for e in evs:
                    ef.write(json.dumps({**e, **meta}) + "\n")
                rows.append(dict(meta, requests_logged=len(evs), admits=len(adm), released=len(rel),
                                 billed=len(billed_ts), c1_attributed=ev["max_per_policy"],
                                 c1_violated=int(ev["max_per_policy"] > L), c1_tau=c1tau,
                                 c1_tau_violated=int(c1tau > L), c2_billed_per_window=c2,
                                 c2_violated=int(c2 != "" and c2 > L),
                                 provider_any_interval=prov_any, provider_aligned=prov_aligned,
                                 late_grants=late, final_counter=used if used is not None else "",
                                 negative_counter=int(used is not None and used < 0),
                                 errors=sum(1 for r in rep if str(r).startswith("error"))))
        finally:
            stop(p)
    ef.close()
    write_rows(name, rows)


def arm_load(a):
    """Open loop arrivals at a fixed rate for a fixed time, each from a number
    chosen at random among `numbers`; every number's requests are its own."""
    import asyncio
    rng = random.Random(a.seed)
    name = f"load_{a.backend}"
    rows = []
    rates = [int(x) for x in a.rates.split(",")]
    strategies = TWO + ONE
    for s in strategies:
        for rate in rates:
            print(f"[{time.strftime('%H:%M:%S')}] {name} {s} rate={rate}", flush=True)
            p = start(s, a.backend, extra=dict(OTP_LOG="minimal"))
            try:
                reset()
                nums = [phone() for _ in range(a.numbers)]
                n_req = rate * a.seconds
                arr, t = [], 0.0
                for _ in range(n_req):
                    t += rng.expovariate(rate)
                    arr.append((t, rng.choice(nums)))
                res = asyncio.run(_open_loop(arr))
                counts = {}
                lat_a, lat_r, errs, below, beyond = [], [], 0, 0, 0
                for (t0, ph), (status, lat) in zip(arr, res):
                    seen = counts.get(ph, 0)
                    if status == "sent":
                        lat_a.append(lat); counts[ph] = seen + 1
                        if seen >= 3:
                            beyond += 1         # admitted although the number already had L
                    elif status == "rejected":
                        lat_r.append(lat)
                        if seen < 3:
                            below += 1          # refused while the number had fewer than L admissions
                    else:
                        errs += 1
                q = lambda v, f: round(1000 * sorted(v)[min(len(v) - 1, int(f * len(v)))], 2) if v else ""
                dur = max(t for t, _ in arr)
                rows.append(dict(arm=name, backend=a.backend, strategy=s, rate=rate, seconds=a.seconds,
                                 numbers=a.numbers, requests=n_req, admitted=len(lat_a), refused=len(lat_r),
                                 errors=errs, refused_below_limit=below, admitted_beyond_limit=beyond,
                                 admitted_per_s=round(len(lat_a) / dur, 2),
                                 adm_p50_ms=q(lat_a, .5), adm_p95_ms=q(lat_a, .95), adm_p99_ms=q(lat_a, .99),
                                 ref_p50_ms=q(lat_r, .5), ref_p95_ms=q(lat_r, .95), ref_p99_ms=q(lat_r, .99)))
                print("   ", rows[-1], flush=True)
            finally:
                stop(p)
    write_rows(name, rows)


async def _open_loop(arr):
    import asyncio
    lim = httpx.Limits(max_connections=400, max_keepalive_connections=400)
    async with httpx.AsyncClient(timeout=120.0, limits=lim) as c:
        t0 = time.perf_counter()

        async def one(t, ph):
            d = t - (time.perf_counter() - t0)
            if d > 0:
                await asyncio.sleep(d)
            s = time.perf_counter()
            try:
                r = await c.post(f"{BASE}/otp/request", json={"phone": ph})
                return r.json().get("status", "error"), time.perf_counter() - s
            except Exception:
                return "error", time.perf_counter() - s
        return await asyncio.gather(*(one(t, ph) for t, ph in arr))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("arm", choices=["indep", "interfere", "provider", "sync", "timing", "load"])
    ap.add_argument("--backend", default="sqlite", choices=["sqlite", "postgres"])
    ap.add_argument("--trials", type=int, default=30)
    ap.add_argument("--run", type=int, default=1)
    ap.add_argument("--seed", type=int, default=20261009)
    ap.add_argument("--rates", default="25,50,100")
    ap.add_argument("--seconds", type=int, default=30)
    ap.add_argument("--numbers", type=int, default=500)
    a = ap.parse_args()
    globals()["arm_" + a.arm](a)
    shutil.rmtree(TMP, ignore_errors=True)
