"""Write paper/gen/r7.tex: one LaTeX macro per number that the v5.0 text quotes.

Usage: python3 study/paper_macros.py [--strict]

Every value is read from results/paper_numbers.json (written by
regenerate.py); nothing is typed here. The text uses \\R{key}; an unknown key
stops the LaTeX run with an error, and --strict makes this script fail when
any key cannot be computed (the packaging script runs it with --strict).
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
N = json.load(open(os.path.join(ROOT, "results", "paper_numbers.json")))
R7 = N.get("r7") or {}
S1 = N["study1"]


def fmt(v):
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, float):
        if v.is_integer():
            v = int(v)
        else:
            s = f"{v:.2f}".rstrip("0")
            return s
    if isinstance(v, int):
        s = f"{v:,}".replace(",", "\\,")
        return s
    return str(v)


def pkg(key, backend="sqlite"):
    return R7["packages"][f"{key}|{backend}"]


def pkg_trials():
    return sum(d["trials"] for d in R7["packages"].values())


def lib_summary():
    return R7["libraries7"]["summary"]


def all_lib_configs():
    return sorted(set(N["libraries"]["summary"]) | set(lib_summary()))


def tl(group_design_prop_var):
    return R7["formal"]["tlc_timed"][group_design_prop_var]


def timing(b, s, rel, d):
    return R7["timing"][f"{b}|{s}|{rel}|{d}"]


def sum_n(cells, field="n"):
    return sum(c[field] for c in cells.values())


def gc(field):
    return R7["survey"]["guard_contracts"][field]


K = {
    # ---------------------------------------------------------- trial counts
    "r7.n.pkg": pkg_trials,
    "r7.n.lib": lambda: R7["libraries7"]["trials"],
    "r7.n.indep": lambda: R7["indep"]["new_runs_trials"],
    "r7.n.interfere": lambda: sum_n(R7["interfere"]),
    "r7.n.provider": lambda: sum(v["trials"] for v in R7["provider"].values()),
    "r7.n.sync": lambda: sum_n(R7["sync"]),
    "r7.n.timing": lambda: sum(v["trials"] for v in R7["timing"].values()),
    "r7.n.load": lambda: len(R7["load"]),
    "r7.trials": lambda: (pkg_trials() + R7["libraries7"]["trials"] + R7["indep"]["new_runs_trials"]
                          + sum_n(R7["interfere"]) + sum(v["trials"] for v in R7["provider"].values())
                          + sum_n(R7["sync"]) + sum(v["trials"] for v in R7["timing"].values())),
    # ---------------------------------------------------------- packages
    "pkg.n": lambda: len({d["package"] for d in R7["packages"].values()}),
    "pkg.mfa.sqlite.max": lambda: pkg("django_mfa")["concurrent_max"],
    "pkg.mfa.postgres.max": lambda: pkg("django_mfa", "postgres")["concurrent_max"],
    "pkg.mfa.sqlite.over": lambda: pkg("django_mfa")["concurrent_over"],
    "pkg.mfa.sqlite.ktrials": lambda: pkg("django_mfa")["concurrent_trials_k_gt_L"],
    "pkg.mfa.postgres.over": lambda: pkg("django_mfa", "postgres")["concurrent_over"],
    "pkg.mfa.postgres.ktrials": lambda: pkg("django_mfa", "postgres")["concurrent_trials_k_gt_L"],
    "pkg.mfa.seqover": lambda: pkg("django_mfa")["sequential_over"] + pkg("django_mfa", "postgres")["sequential_over"],
    "pkg.email.sqlite.max": lambda: pkg("otp_email")["concurrent_max"],
    "pkg.email.postgres.max": lambda: pkg("otp_email", "postgres")["concurrent_max"],
    "pkg.email.sqlite.over": lambda: pkg("otp_email")["concurrent_over"],
    "pkg.email.postgres.over": lambda: pkg("otp_email", "postgres")["concurrent_over"],
    "pkg.email.ktrials": lambda: pkg("otp_email")["concurrent_trials_k_gt_L"],
    "pkg.email.limit": lambda: pkg("otp_email")["declared_limit"],
    "pkg.otpauth.limit": lambda: pkg("otp_auth")["declared_limit"],
    "pkg.otpauth.sqlite.max": lambda: pkg("otp_auth")["concurrent_max"],
    "pkg.otpauth.postgres.max": lambda: pkg("otp_auth", "postgres")["concurrent_max"],
    "pkg.otpauth.sqlite.over": lambda: pkg("otp_auth")["concurrent_over"],
    "pkg.otpauth.ktrials": lambda: pkg("otp_auth")["concurrent_trials_k_gt_L"],
    "pkg.otpauth.seq.max": lambda: pkg("otp_auth")["sequential_max"],
    "pkg.otpauth.newconn.max": lambda: max(pkg("otp_auth")["sequential_new_conn_max"],
                                           pkg("otp_auth", "postgres")["sequential_new_conn_max"]),
    "pkg.fastapi.limit": lambda: pkg("fastapi_otp", "redis")["declared_limit"],
    "pkg.fastapi.max": lambda: pkg("fastapi_otp", "redis")["concurrent_max"],
    "pkg.fastapi.over": lambda: pkg("fastapi_otp", "redis")["concurrent_over"] + pkg("fastapi_otp", "redis")["sequential_over"],
    "pkg.fastapi.trials": lambda: pkg("fastapi_otp", "redis")["trials"],
    "pkg.errors": lambda: sum(d["errors"] for d in R7["packages"].values()),
    # ---------------------------------------------------------- libraries
    "lib.configs": lambda: len(all_lib_configs()),
    "lib.configs7": lambda: len(lib_summary()),
    "lib.errors7": lambda: R7["libraries7"]["errors"],
    "wa.mem.maxw": lambda: R7["worker_assignment"]["slowapi_memory"]["max_admissions_by_one_worker"],
    "wa.mem.trials": lambda: R7["worker_assignment"]["slowapi_memory"]["trials"],
    "wa.mem.eq": lambda: R7["worker_assignment"]["slowapi_memory"]["trials_admissions_equal_sum_over_workers_of_min_requests_L"],
    "wa.loc.maxw": lambda: R7["worker_assignment"]["djrl_locmem"]["max_admissions_by_one_worker"],
    "wa.loc.trials": lambda: R7["worker_assignment"]["djrl_locmem"]["trials"],
    "wa.loc.eq": lambda: R7["worker_assignment"]["djrl_locmem"]["trials_admissions_equal_sum_over_workers_of_min_requests_L"],
    # ---------------------------------------------------------- independent runs
    "indep.onestep.viol": lambda: R7["indep"]["new_runs_one_step_violations"],
    "indep.onestep.trials": lambda: R7["indep"]["new_runs_one_step_trials"],
    # ---------------------------------------------------------- survey
    "gc.rows": lambda: gc("rows"),
    "gc.perrecip.n": lambda: len(gc("per_recipient_effective")),
    "gc.oneworker.n": lambda: len(gc("per_recipient_effective_one_worker_only")),
    "gc.notper.n": lambda: len(gc("not_per_recipient")),
    "gc.provider.n": lambda: len(gc("provider")),
    "gc.onestep.n": lambda: len(gc("one_step")),
    "gc.twostep.n": lambda: len(gc("two_step")),
    "gc.shaped.n": lambda: len(gc("two_step")) + len(gc("one_step")),
    "sv.meta.reviewed": lambda: R7["survey"]["metadata_stage"]["reviewed"],
    "sv.meta.relevant": lambda: R7["survey"]["metadata_stage"]["relevant"],
    "sv.name.sample": lambda: R7["survey"]["name_stage"]["sample"],
    "sv.name.relevant": lambda: R7["survey"]["name_stage"]["relevant"],
    "sv.name.outside": lambda: R7["survey"]["name_stage"]["broad_token_names_outside"],
    "sv.name.index": lambda: R7["survey"]["name_stage"]["index_size_now"],
    "sv.name.est": lambda: R7["survey"]["name_stage"]["est_relevant_outside"],
    "sv.name.estlo": lambda: R7["survey"]["name_stage"]["est_relevant_outside_ci"][0],
    "sv.name.esthi": lambda: R7["survey"]["name_stage"]["est_relevant_outside_ci"][1],
    "sv.name.cilo": lambda: R7["survey"]["name_stage"]["relevant_ci_pct"][0],
    "sv.name.cihi": lambda: R7["survey"]["name_stage"]["relevant_ci_pct"][1],
    "vw.sample": lambda: R7["survey"]["validation_whole_package"]["sample"],
    "vw.misses": lambda: R7["survey"]["validation_whole_package"]["misses"],
    "vw.missrate": lambda: R7["survey"]["validation_whole_package"]["miss_rate_pct"],
    "vw.misslo": lambda: R7["survey"]["validation_whole_package"]["miss_rate_ci_pct"][0],
    "vw.misshi": lambda: R7["survey"]["validation_whole_package"]["miss_rate_ci_pct"][1],
    "vw.est": lambda: round(R7["survey"]["validation_whole_package"]["est_missed_in_screened_set"]),
    "vw.recall": lambda: R7["survey"]["validation_whole_package"]["detector_recall_pct"],
    "vw.recalllo": lambda: R7["survey"]["validation_whole_package"]["detector_recall_ci_pct"][0],
    "vw.recallhi": lambda: R7["survey"]["validation_whole_package"]["detector_recall_ci_pct"][1],
    "vw.estlo": lambda: round(R7["survey"]["validation_whole_package"]["est_missed_ci"][0]),
    "vw.esthi": lambda: round(R7["survey"]["validation_whole_package"]["est_missed_ci"][1]),
    "vw.estrel": lambda: R7["survey"]["validation_whole_package"]["est_relevant_in_screened_set"],
    "fam.n": lambda: R7["survey"]["families"]["families"],
    "fam.pkgs": lambda: R7["survey"]["families"]["packages"],
    "fam.none": lambda: R7["survey"]["families"]["families_all_none"],
    "fam.inpkg": lambda: R7["survey"]["families"]["families_any_in_package"],
    "fam.deleg": lambda: R7["survey"]["families"]["families_delegated_only"],
    "fam.multi": lambda: len(R7["survey"]["families"]["multi_member"]),
    # ---------------------------------------------------------- formal
    "tlc.timed.runs": lambda: R7["formal"]["tlc_timed_runs"],
    "tlc.timed.maxstates": lambda: R7["formal"]["tlc_timed_max_states"],
    "tam.sweep.maxL": lambda: max(R7["formal"]["tamarin_sweep_limits"]),
    "tam.sweep.maxLtwo": lambda: max(int(k.split("|L")[1]) for k, v in R7["formal"]["tamarin_sweep"].items()
                                     if "R1_violation_trace" in v and v["R1_violation_trace"] == "verified"),
    "tam.sweep.allverified": lambda: R7["formal"]["tamarin_sweep_all_verified"],
}

# offered against observed overlap (round 4 SQLite main sweep): ov.<design>.<k>.<q1|median|q3|max>
SHORT = {"naive_count": "cti", "cache_get_set": "rmw", "after_send": "ias", "atomic_update": "cau",
         "immediate_txn": "gwt", "reserve_commit": "rbs", "atomic_update_db": "caudb", "reserve_commit_db": "rbsdb"}
for _d, _s in list(SHORT.items())[:6]:
    for _k in (4, 8, 16, 32):
        for _f in ("q1", "median", "q3", "max"):
            K[f"ov.{_s}.{_k}.{_f}"] = (lambda d=_d, k=_k, f=_f: R7["overlap"][f"{d}|{k}"][f])

# provider cross check: every comparison true on both datastores
def _prov_ok():
    pr = R7["provider"]
    if set(pr) != {"sqlite", "postgres"}:
        raise KeyError("provider arm incomplete")
    keys = ("requests_logged_equal_k", "provider_log_equals_admissions", "db_provider_rows_equal_admissions",
            "request_ids_match", "message_ids_match", "verdict_agrees")
    return all(pr[b][k] for b in pr for k in keys)


K["prov.allok"] = _prov_ok
K["prov.n"] = lambda: sum(v["trials"] for v in R7["provider"].values())
for _d, _s in list(SHORT.items())[:6]:
    for _b in ("sqlite", "postgres"):
        K[f"prov.{_b}.{_s}.over"] = (lambda d=_d, b=_b: R7["provider"][b]["by_strategy"][d]["provider_over"])
        K[f"prov.{_b}.{_s}.n"] = (lambda d=_d, b=_b: R7["provider"][b]["by_strategy"][d]["trials"])
# synchronization: sync.<design>.<barrier|lastbyte>.<k>.<field>
for _d, _s in list(SHORT.items())[:4]:
    for _m in ("barrier", "lastbyte"):
        for _k in (8, 32):
            for _f, _src in (("viol", "violations"), ("med", "median"), ("max", "max"),
                             ("arr", "arrival_spread_ms_median"), ("read", "read_spread_ms_median"), ("err", "errors")):
                K[f"sync.{_s}.{_m}.{_k}.{_f}"] = (lambda d=_d, m=_m, k=_k, src=_src:
                                                   round(R7["sync"][f"{d}|{m}|{k}"][src], 1)
                                                   if isinstance(R7["sync"][f"{d}|{m}|{k}"][src], float)
                                                   else R7["sync"][f"{d}|{m}|{k}"][src])
# time and faults: tm.<b>.<design>.<rule>.<delay>.<field>
RSHORT = {"": "none", "any_current": "anycur", "certain_reserved": "certres"}
TMF = ("trials", "c1_violated", "c1_tau_violated", "c2_violated", "c2_max", "negative_counter",
       "trials_with_late_grant", "provider_any_interval_max", "provider_any_interval_over_L", "released", "errors")
for _key in list((R7.get("timing") or {}).keys()):
    _b, _d, _r, _dl = _key.split("|")
    for _f in TMF:
        K[f"tm.{_b}.{SHORT[_d]}.{RSHORT[_r]}.{_dl}.{_f}"] = (lambda key=_key, f=_f: R7["timing"][key][f])
TEF = ("trials", "c1_calls_violated", "c1_calls_tau_violated", "c2_violated", "c2_tau_violated", "c2_max",
       "released", "release_no_row", "cross_window_releases", "calls", "billed", "unkU")
for _key in list((R7.get("timing_events") or {}).keys()):
    _b, _d, _r, _dl = _key.split("|")
    for _f in TEF:
        K[f"te.{_b}.{SHORT[_d]}.{RSHORT[_r]}.{_dl}.{_f}"] = (lambda key=_key, f=_f: R7["timing_events"][key][f])
# timed TLC verdicts: tl.<group>.<Design>.<prop>.<variant> = holds | violated
for _key in list(((R7.get("formal") or {}).get("tlc_timed") or {}).keys()):
    _g, _d, _p, _v = _key.split("|")
    K[f"tl.{_g}.{_d}.{_p}.{_v}"] = (lambda key=_key: "holds" if R7["formal"]["tlc_timed"][key]["holds_all"]
                                    else "violated")
    K[f"tl.{_g}.{_d}.{_p}.{_v}.bad"] = (lambda key=_key: ", ".join(
        b.replace("N", "$N=").replace("L", "$, $L=") + "$" for b, x in R7["formal"]["tlc_timed"][key]["verdicts"].items()
        if x == "violated") or "none")
K["tm.errors"] = lambda: sum(v["errors"] for v in R7["timing"].values())
# sustained load: ld.<b>.<design>.<rate>.<field>
for _key in list((R7.get("load") or {}).keys()):
    _b, _d, _rt = _key.split("|")
    for _f in ("admitted", "refused", "errors", "refused_below_limit", "admitted_beyond_limit", "admitted_per_s",
               "adm_p50_ms", "adm_p95_ms", "adm_p99_ms", "ref_p50_ms", "ref_p95_ms", "requests"):
        K[f"ld.{_b}.{SHORT[_d]}.{int(float(_rt))}.{_f}"] = (lambda key=_key, f=_f: R7["load"][key][f])
K["ld.errors"] = lambda: sum(v["errors"] for v in R7["load"].values())
K["sync.errors"] = lambda: sum(v["errors"] for v in R7["sync"].values())

sys.path.insert(0, os.path.join(ROOT, "study"))
import comparison7  # noqa: E402
K["cmp.twostep.minpct"] = lambda: comparison7.two_step_share_range(N)[0]
K["cmp.twostep.maxpct"] = lambda: comparison7.two_step_share_range(N)[1]
K["cmp.onestep.viol"] = lambda: comparison7.one_step_violations(N)[0]
K["cmp.onestep.trials"] = lambda: comparison7.one_step_violations(N)[1]
K["cmp.rows"] = lambda: len(comparison7.rows(N))

EXTRA = os.path.join(ROOT, "study", "paper_macros_extra.json")  # optional key -> json path


def get_path(path):
    x = N
    for p in path:
        x = x[p]
    return x


def main():
    strict = "--strict" in sys.argv
    lines = ["% Generated by study/paper_macros.py from results/paper_numbers.json. Do not edit.",
             "\\makeatletter",
             "\\newcommand{\\R}[1]{\\@ifundefined{rseven@#1}{\\ifdefined\\Rdraft\\textbf{[\\detokenize{#1}]}\\else"
             "\\PackageError{r7}{Unknown number key #1}{}\\textbf{??}\\fi}{\\csname rseven@#1\\endcsname}}"]
    missing = []
    items = dict(K)
    if os.path.exists(EXTRA):
        for k, path in json.load(open(EXTRA)).items():
            items[k] = (lambda p=path: get_path(p))
    for k, f in sorted(items.items()):
        try:
            v = fmt(f())
        except (KeyError, TypeError, IndexError, ValueError, AttributeError, AssertionError):
            missing.append(k)
            continue
        lines.append(f"\\expandafter\\def\\csname rseven@{k}\\endcsname{{{v}}}")
    lines.append("\\makeatother")
    os.makedirs(os.path.join(ROOT, "paper", "gen"), exist_ok=True)
    open(os.path.join(ROOT, "paper", "gen", "r7.tex"), "w").write("\n".join(lines) + "\n")
    print(f"wrote {len(items) - len(missing)} macros to paper/gen/r7.tex")
    if missing:
        print("missing:", ", ".join(missing))
        if strict:
            sys.exit(1)


if __name__ == "__main__":
    main()
