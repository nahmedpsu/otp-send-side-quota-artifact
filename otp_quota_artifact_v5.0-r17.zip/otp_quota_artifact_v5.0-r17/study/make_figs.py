"""Generate the admission figures (one per datastore), the package execution figure, the TLC verdict map
(Fig. 7), the library figure (Fig. 9), the comparison figure (Fig. 10), and the pgfplots coordinates of the
line and bar figures, from the round-4 and round-6 trial files, formal/tla/results.json, and
results/paper_numbers.json."""
import csv, os, random
from collections import defaultdict
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LAB = {"naive_count": "Count then\ninsert", "cache_get_set": "Read modify\nwrite",
       "after_send": "Increment\nafter send", "atomic_update": "Conditional\natomic update",
       "immediate_txn": "Guarded write\ntransaction", "reserve_commit": "Reserve\nbefore send"}
ORDER = list(LAB)


def load(fn, k="concurrency", v="admits"):
    d = defaultdict(list)
    for r in csv.DictReader(open(fn)):
        d[(r["strategy"], int(r[k]))].append(int(r[v]))
    return d


# Typeset to match the IEEE body text: Liberation Serif (metrically Times),
# a TrueType font, so the PDF embeds cleanly.
RC = ({"font.family": "serif",
                     "font.serif": ["Liberation Serif", "Times New Roman", "DejaVu Serif"],
                     "mathtext.fontset": "stix", "font.size": 8,
                     "axes.linewidth": 0.6, "xtick.direction": "in", "ytick.direction": "in",
                     "xtick.major.width": 0.6, "ytick.major.width": 0.6,
                     "xtick.top": True, "ytick.right": True, "pdf.fonttype": 42})
# applied only to the admission figures (rc_context below); the package
# execution figure keeps the defaults it was drawn with

# The three two step implementations get the first three categorical slots
# (checked for colour vision deficiency) and their own marker and line style;
# the three one step implementations admitted min(k, L) in every trial on both
# datastores, so they share one grey series (asserted below, not assumed).
TWO_STEP = [("naive_count", "Count then insert", "#2a78d6", "o", "-"),
            ("cache_get_set", "Read modify write counter", "#eb6834", "s", "--"),
            ("after_send", "Increment after send", "#1baf7a", "^", "-.")]
ONE_STEP = ("atomic_update", "immediate_txn", "reserve_commit")


def quart(v):
    import statistics as st
    v = sorted(v)
    q = st.quantiles(v, n=4)        # exclusive, as regenerate.py and the supplement
    return st.median(v), q[0], q[2], v[0], v[-1]


def admissions_figure(data, ks, limit, out):
    """Admissions per trial against k: the median of the 30 trials (marker),
    the interquartile range (thick bar; exclusive quartiles, as in
    regenerate.py) and the range (thin bar). The series are offset sideways
    so that coincident markers stay visible."""
    import math
    with plt.rc_context(RC):
        _admissions_figure(data, ks, limit, out, math)


def _admissions_figure(data, ks, limit, out, math):
    for s in ONE_STEP:
        for k in ks:
            assert all(v == min(k, limit) for v in data[(s, k)]), (s, k)
    fig, ax = plt.subplots(figsize=(3.45, 2.55))
    x = [math.log2(k) for k in ks]
    ax.plot(x, ks, color="0.55", lw=0.7, ls=":", zorder=1)
    ax.text(math.log2(16) - 0.12, 17.0, "all $k$ admitted", ha="right", va="bottom",
            fontsize=6.5, color="0.35")
    ax.axhline(limit, color="black", lw=0.8, ls=(0, (4, 2)), zorder=1)
    ax.text(-0.2, limit + 0.5, f"declared limit $L={limit}$", fontsize=6.5,
            va="bottom", ha="left")
    ax.plot([xi - 0.21 for xi in x], [min(k, limit) for k in ks], color="0.45", lw=1.0, marker="o",
            ms=3.6, mfc="white", mec="0.35", mew=0.8, zorder=2,
            label="One step implementations (all three)")
    for j, (s, lab, col, mk, ls) in enumerate(TWO_STEP):
        dx = -0.07 + j * 0.14
        xs = [xi + dx for xi in x]
        q = [quart(data[(s, k)]) for k in ks]
        ax.vlines(xs, [r[3] for r in q], [r[4] for r in q], color=col, lw=0.6, zorder=3)
        ax.vlines(xs, [r[1] for r in q], [r[2] for r in q], color=col, lw=1.9, zorder=3)
        ax.plot(xs, [r[0] for r in q], color=col, lw=1.0, ls=ls, marker=mk, ms=3.8,
                mec="white", mew=0.5, zorder=4, label=lab)
    ax.set_xticks(x)
    ax.set_xticklabels([str(k) for k in ks])
    ax.set_xlim(-0.45, x[-1] + 0.45)
    ax.set_ylim(0, 34)
    ax.set_yticks([0, 3, 8, 16, 24, 32])
    ax.set_xlabel("Simultaneous requests $k$")
    ax.set_ylabel("Admissions per trial")
    ax.grid(axis="y", color="0.88", lw=0.5)
    ax.set_axisbelow(True)
    ax.legend(loc="upper left", fontsize=6.5, frameon=True, framealpha=1.0,
              edgecolor="0.7", fancybox=False, handlelength=2.6, borderpad=0.4)
    fig.tight_layout(pad=0.2)
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print("wrote", out)


def main():
    sq = load(f"{ROOT}/results/r4/main_sqlite.csv")
    pg = load(f"{ROOT}/results/r4/main_postgres.csv")
    ks = [1, 2, 4, 8, 16, 32]
    admissions_figure(sq, ks, 3, f"{ROOT}/paper/fig_admissions_sqlite.pdf")
    admissions_figure(pg, ks, 3, f"{ROOT}/paper/fig_admissions_postgres.pdf")

    pkgexec_figure(ks, f"{ROOT}/paper/fig_pkgexec.pdf")
    formal_figure(f"{ROOT}/paper/fig_formal.pdf")
    libraries_figure(f"{ROOT}/paper/fig_libraries.pdf")
    comparison_figure(f"{ROOT}/paper/fig_comparison.pdf")


def pkgexec_figure(ks, out):
    """django-otp 1.7.3 executed as shipped: tokens delivered per trial against
    the number of calls released. Every simultaneous trial is one dot (dots
    with the same count are spread sideways so each stays visible), the line
    joins the medians, and the sequential trials (all exactly one, asserted
    below) are one grey series."""
    import math
    from collections import Counter
    d = defaultdict(list)
    for r in csv.DictReader(open(f"{ROOT}/results/r4/pkg_exec.csv")):
        d[(r["mode"], int(r["concurrency"]))].append(int(r["deliveries"]))
    for k in ks:
        assert all(v == 1 for v in d[("sequential", k)]), k
    with plt.rc_context(RC):
        import statistics as st
        fig, ax = plt.subplots(figsize=(3.45, 2.45))
        x = [math.log2(k) for k in ks]
        ax.plot(x, ks, color="0.55", lw=0.7, ls=":", zorder=1)
        ax.text(math.log2(8) - 0.15, 8.6, "all $k$ delivered", ha="right", va="bottom",
                fontsize=6.5, color="0.35")
        ax.axhline(1, color="black", lw=0.8, ls=(0, (4, 2)), zorder=1)
        ax.text(x[-1] + 0.55, -0.55, "dashed: declared limit of one token", fontsize=6.5, va="bottom", ha="right")
        for xi, k in zip(x, ks):
            cnt = Counter(d[("concurrent", k)])
            for v, c in sorted(cnt.items()):
                step = min(0.024, 0.62 / max(c - 1, 1))
                offs = [(i - (c - 1) / 2) * step for i in range(c)]
                ax.scatter([xi + 0.12 + o for o in offs], [v] * c, s=7, color="#2a78d6",
                           alpha=0.75, linewidths=0, zorder=3)
        med = [st.median(d[("concurrent", k)]) for k in ks]
        ax.plot([xi + 0.12 for xi in x], med, color="#1b4f8f", lw=1.1, marker="D", ms=3.4,
                mec="white", mew=0.5, zorder=4, label="Released simultaneously (median)")
        ax.plot([xi - 0.3 for xi in x], [1] * len(ks), color="0.45", lw=1.0, marker="s", ms=3.4,
                mfc="white", mec="0.35", mew=0.8, zorder=4, label="Released one at a time (all trials)")
        ax.scatter([], [], s=7, color="#2a78d6", alpha=0.75, label="One simultaneous trial")
        ax.set_xticks(x)
        ax.set_xticklabels([str(k) for k in ks])
        ax.set_xlim(-0.6, x[-1] + 0.6)
        ax.set_ylim(-0.8, 17.5)
        ax.set_yticks([1, 4, 8, 12, 16])
        ax.set_xlabel("Calls released $k$")
        ax.set_ylabel("Tokens delivered per trial")
        ax.grid(axis="y", color="0.88", lw=0.5)
        ax.set_axisbelow(True)
        ax.legend(loc="upper left", fontsize=6.5, frameon=True, framealpha=1.0,
                  edgecolor="0.7", fancybox=False, handlelength=2.2, borderpad=0.4)
        fig.tight_layout(pad=0.2)
        fig.savefig(out, bbox_inches="tight")
        plt.close(fig)
    print("wrote", out)


def pgf_coords():
    """Write the coordinates of Fig. S4 (medians against k) and Fig. S5 (k=32,
    simultaneous against sequential) for pgfplots, from the round-4 files."""
    import statistics as st
    G = f"{ROOT}/paper/gen"
    os.makedirs(G, exist_ok=True)
    sq = load(f"{ROOT}/results/r4/main_sqlite.csv")
    seq = load(f"{ROOT}/results/r4/sequential.csv")
    ks = [1, 2, 4, 8, 16, 32]
    med = {s: [st.median(sq[(s, k)]) for k in ks] for s in ORDER}
    styles = {
        "after_send": ("blue!65!black, thick, mark=*, mark size=1.7pt", "Increment after send"),
        "cache_get_set": ("orange!80!black, thick, dashdotted, mark=square*, mark size=1.7pt", "Read modify write"),
        "naive_count": ("teal!70!black, thick, densely dotted, mark=triangle*, mark size=2.2pt", "Count then insert"),
        "immediate_txn": ("black!60, thick, mark=o, mark size=3.6pt, mark options={line width=0.9pt}", "Guarded write transaction"),
        "atomic_update": ("black!72, thick, mark=diamond*, mark size=2.2pt", "Conditional atomic update"),
        "reserve_commit": ("red!60!black, thick, densely dashdotted, mark=x, mark size=2.4pt, mark options={line width=0.9pt}", "Reserve before send"),
    }
    with open(f"{G}/fig_concurrency.tex", "w") as f:
        f.write("% generated by study/make_figs.py from results/r4/main_sqlite.csv; do not edit\n")
        for s in ("after_send", "cache_get_set", "naive_count", "immediate_txn", "atomic_update", "reserve_commit"):
            pts = "".join(f"({k},{m:g})" for k, m in zip(ks, med[s]))
            f.write(f"\\addplot[{styles[s][0]}]\n  coordinates {{{pts}}};\n\\addlegendentry{{{styles[s][1]}}}\n")
    short = {"naive_count": "Count insert", "cache_get_set": "Read mod write", "after_send": "After send",
             "atomic_update": "Atomic update", "immediate_txn": "Guarded txn", "reserve_commit": "Reserve"}
    with open(f"{G}/fig_seqvscon.tex", "w") as f:
        f.write("% generated by study/make_figs.py from results/r4/{main_sqlite,sequential}.csv; do not edit\n")
        con = " ".join(f"({st.median(sq[(s, 32)]):g},{short[s]})" for s in ORDER)
        sq32 = " ".join(f"({st.median(seq[(s, 32)]):g},{short[s]})" for s in ORDER)
        f.write("\\addplot[fill=blue!25, draw=blue!60!black, postaction={pattern=north east lines,\n"
                "         pattern color=blue!55!black}] coordinates {\n  " + con + "};\n"
                "\\addlegendentry{Released simultaneously}\n")
        f.write("\\addplot[fill=black!12, draw=black!55] coordinates {\n  " + sq32 + "};\n"
                "\\addlegendentry{Released one at a time}\n")
    print("wrote", f"{G}/fig_concurrency.tex", f"{G}/fig_seqvscon.tex")



# ---------------------------------------------------------------- round 16
# Colors: the first four categorical slots, checked with the palette validator
# (adjacent CVD separation passes; aqua and yellow fall below 3:1 against white,
# so every series also has its own marker and line style, and the numbers are
# in Table X).
SLOT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]
TLA_ROWS = [("CountThenInsert", "Count then insert"), ("ReadModifyWrite", "Read modify write"),
            ("IncrementAfterSend", "Increment after send"), ("ConditionalUpdate", "Conditional atomic update"),
            ("GuardedTransaction", "Guarded transaction"), ("ReserveBeforeSend", "Reserve before send")]


def formal_figure(out):
    """TLC verdicts at every bound: one column per (L, N), one row per design
    and requirement. An open circle is a run in which the invariant held over
    every reachable state; a cross is a run that stopped at a shortest
    counterexample. Read from formal/tla/results.json."""
    import json
    runs = json.load(open(f"{ROOT}/formal/tla/results.json"))
    V = {}
    for r in runs:
        if r["inv"] == "R1" and not r["faults"]:
            V[("R1", r["design"], False, r["L"], r["N"])] = r["verdict"]
        elif r["inv"] == "R3" and r["faults"]:
            V[("R3", r["design"], r["spent"], r["L"], r["N"])] = r["verdict"]
    rows = [("R1", d, False, lab) for d, lab in TLA_ROWS]
    rows += [("R3", "ConditionalUpdate", False, "Conditional atomic update"),
             ("R3", "GuardedTransaction", False, "Guarded transaction"),
             ("R3", "ReserveBeforeSend", False, "Reserve, release on any error"),
             ("R3", "ReserveBeforeSend", True, "Reserve, unknown kept as spent")]
    cols, x, xs = [], 0.0, {}
    for L in (1, 2, 3):
        for N in range(1, L + 3):
            cols.append((L, N)); xs[(L, N)] = x; x += 1.0
        x += 0.7
    with plt.rc_context(RC):
        fig, ax = plt.subplots(figsize=(3.45, 2.75))
        ys = {}
        y = 0.0
        for i, r in enumerate(rows):
            if i == 6:
                y += 1.1
            ys[i] = y; y += 1.0
        top, bot = -1.15, y - 0.25
        for (L, N), xx in xs.items():
            if N > L:
                ax.add_patch(plt.Rectangle((xx - 0.5, top), 1.0, bot - top, color="0.92", lw=0, zorder=0))
        for i, r in enumerate(rows):
            for (L, N), xx in xs.items():
                v = V[(r[0], r[1], r[2], L, N)]
                if v == "holds":
                    ax.plot(xx, ys[i], marker="o", ms=4.2, mfc="white", mec="0.35", mew=0.8, zorder=3)
                else:
                    assert v == "violated", v
                    ax.plot(xx, ys[i], marker="X", ms=5.6, color=SLOT[1], mec="white", mew=0.4, zorder=3)
        ax.set_yticks([ys[i] for i in range(len(rows))])
        ax.set_yticklabels([r[3] for r in rows], fontsize=6.6)
        ax.set_xticks([xs[c] for c in cols])
        ax.set_xticklabels([str(c[1]) for c in cols], fontsize=6.6)
        for L in (1, 2, 3):
            xm = (xs[(L, 1)] + xs[(L, L + 2)]) / 2
            ax.text(xm, top - 0.25, f"$L={L}$", ha="center", va="bottom", fontsize=7)
        for i, lab in ((0, "C1: calls never exceed $L$"), (6, "C2: billed never exceeds $L$, provider faults")):
            ax.text(-0.55, ys[i] - 0.68, lab, ha="left", va="bottom", fontsize=6.6, style="italic", color="0.25")
        ax.set_xlim(-0.6, x - 1.1)
        ax.set_ylim(bot + 0.1, top - 1.0)
        ax.set_xlabel("Concurrent requests $N$ (shaded: $N > L$)")
        ax.tick_params(axis="both", length=0)
        ax.xaxis.set_ticks_position("bottom"); ax.yaxis.set_ticks_position("left")
        for sp in ax.spines.values():
            sp.set_visible(False)
        ax.plot([], [], ls="", marker="o", ms=4.2, mfc="white", mec="0.35", mew=0.8,
                label="holds in every interleaving of the instance")
        ax.plot([], [], ls="", marker="X", ms=5.6, color=SLOT[1], mec="white", mew=0.4,
                label="violated (shortest trace found)")
        ax.legend(loc="upper center", bbox_to_anchor=(0.42, -0.17), ncol=2, fontsize=6.5, frameon=False,
                  handletextpad=0.3, columnspacing=1.2)
        fig.tight_layout(pad=0.2)
        fig.savefig(out, bbox_inches="tight")
        plt.close(fig)
    print("wrote", out)


LIB_SERIES = [("slowapi_memory", "SlowAPI, process memory", SLOT[0], "o", "-"),
              ("djrl_locmem", "django-ratelimit, local memory cache", SLOT[1], "s", "--"),
              ("djrl_db_sqlite", "django-ratelimit, database cache (SQLite)", SLOT[2], "^", "-."),
              ("djrl_db_postgres", "django-ratelimit, database cache (PostgreSQL)", SLOT[3], "D", ":")]
LIB_HOLD = ("slowapi_redis", "djrl_redis")


def libraries_figure(out):
    """Admissions per trial against k for the library configurations, in the
    style of Figs. 4 and 5: median (marker), interquartile range (thick bar)
    and range (thin bar). The two Redis configurations and the conditional
    atomic update of this study admitted min(k, L) in every trial (asserted),
    so they share one grey series."""
    import math
    ks = [1, 2, 4, 8, 16, 32]
    d = defaultdict(list)
    for r in csv.DictReader(open(f"{ROOT}/results/r6/libraries.csv")):
        if r["mode"] == "concurrent":
            d[(r["config"], int(r["concurrency"]))].append(int(r["admits"]))
    sq = load(f"{ROOT}/results/r4/main_sqlite.csv")
    for k in ks:
        for c in LIB_HOLD:
            assert len(d[(c, k)]) == 30 and all(v == min(k, 3) for v in d[(c, k)]), (c, k)
        assert all(v == min(k, 3) for v in sq[("atomic_update", k)]), k
    with plt.rc_context(RC):
        fig, ax = plt.subplots(figsize=(3.45, 2.7))
        x = [math.log2(k) for k in ks]
        ax.plot(x, ks, color="0.55", lw=0.7, ls=":", zorder=1)
        ax.text(math.log2(16) - 0.12, 17.0, "all $k$ admitted", ha="right", va="bottom", fontsize=6.5, color="0.35")
        ax.axhline(3, color="black", lw=0.8, ls=(0, (4, 2)), zorder=1)
        ax.text(x[-1] + 0.4, 0.6, "dashed: declared limit $L=3$", fontsize=6.5, va="bottom", ha="right")
        ax.axhline(12, color="0.45", lw=0.6, ls=(0, (1, 2)), zorder=1)
        ax.text(x[-1] + 0.4, 12.5, "four workers $\\times$ $L$", fontsize=6.5, va="bottom", ha="right", color="0.3")
        ax.plot([xi - 0.27 for xi in x], [min(k, 3) for k in ks], color="0.45", lw=1.0, marker="o", ms=3.6,
                mfc="white", mec="0.35", mew=0.8, zorder=2,
                label="Redis (both libraries); conditional atomic update")
        for j, (c, lab, col, mk, ls) in enumerate(LIB_SERIES):
            dx = -0.12 + j * 0.12
            xs = [xi + dx for xi in x]
            q = [quart(d[(c, k)]) for k in ks]
            ax.vlines(xs, [r[3] for r in q], [r[4] for r in q], color=col, lw=0.6, zorder=3)
            ax.vlines(xs, [r[1] for r in q], [r[2] for r in q], color=col, lw=1.9, zorder=3)
            ax.plot(xs, [r[0] for r in q], color=col, lw=1.0, ls=ls, marker=mk, ms=3.6,
                    mec="white", mew=0.5, zorder=4, label=lab)
        ax.set_xticks(x); ax.set_xticklabels([str(k) for k in ks])
        ax.set_xlim(-0.5, x[-1] + 0.5)
        ax.set_ylim(0, 34); ax.set_yticks([0, 3, 8, 12, 16, 24, 32])
        ax.set_xlabel("Simultaneous requests $k$")
        ax.set_ylabel("Admissions per trial")
        ax.grid(axis="y", color="0.88", lw=0.5); ax.set_axisbelow(True)
        ax.legend(loc="upper left", fontsize=6.2, frameon=True, framealpha=1.0, edgecolor="0.7",
                  fancybox=False, handlelength=2.4, borderpad=0.4)
        fig.tight_layout(pad=0.2)
        fig.savefig(out, bbox_inches="tight")
        plt.close(fig)
    print("wrote", out)


def comparison_figure(out):
    """Every enforcement measured under the same burst protocol: (a) the worst
    trial's admissions divided by the declared limit, (b) the share of the
    simultaneous trials with more requests than the limit (k > L) that exceeded
    the limit; a trial with k <= L cannot exceed it, and every such cell had no
    violation (asserted). Read from results/paper_numbers.json (the numbers of
    Tables VI, VII and X and Section V-E)."""
    import json
    P = json.load(open(f"{ROOT}/results/paper_numbers.json"))
    S2, LB = P["study2"], P["libraries"]
    KS = (1, 2, 4, 8, 16, 32)
    names = {"naive_count": "Count then insert", "cache_get_set": "Read modify write",
             "after_send": "Increment after send", "atomic_update": "Conditional atomic update",
             "immediate_txn": "Guarded transaction", "reserve_commit": "Reserve before send"}

    def share(cells, limit, key):
        over = [cells(k)[key] for k in KS]
        n = [cells(k).get("n", cells(k).get("trials")) for k in KS]
        assert all(o == 0 for o, k in zip(over, KS) if k <= limit), over
        return sum(o for o, k in zip(over, KS) if k > limit) / sum(m for m, k in zip(n, KS) if k > limit)

    rows = []   # (group, label, [(marker key, amplification, share)])
    for s in ORDER:
        a = S2["main_sqlite_summary"][s]; b = S2["main_postgres_summary"][s]
        sa = share(lambda k: S2["main_sqlite"][f"{s}|{k}"], 3, "policy_violations")
        sb = share(lambda k: S2["main_postgres"][f"{s}|{k}"], 3, "policy_violations")
        assert round(sa * 120) == a["policy_violations"] and round(sb * 120) == b["policy_violations"]
        rows.append(("This study's designs", names[s],
                     [("sqlite", a["worst_amplification"], sa), ("pg", b["worst_amplification"], sb)]))
    pe = S2["package_exec"]
    conc = [pe[f"concurrent|k={k}"] for k in KS]
    assert sum(c["over_limit"] for c in conc) == S2["package_exec_concurrent_over_all_k"]
    rows.append(("Surveyed package", "django-otp 1.7.3 (limit 1)",
                 [("sqlite", max(c["max"] for c in conc) / 1,
                   share(lambda k: pe[f"concurrent|k={k}"], 1, "over_limit"))]))
    lab = {"slowapi_memory": "SlowAPI, process memory", "slowapi_redis": "SlowAPI, Redis",
           "djrl_locmem": "django-ratelimit, local memory", "djrl_db_sqlite": "django-ratelimit, DB cache",
           "djrl_redis": "django-ratelimit, Redis"}
    for c in ("slowapi_memory", "djrl_locmem", "djrl_db_sqlite", "slowapi_redis", "djrl_redis"):
        def lib(cfg):
            x = LB["summary"][cfg]
            sh = share(lambda k: LB["cells"][f"{cfg}|{k}"], 3, "policy_violations")
            assert round(sh * 120) == x["over"], (cfg, sh, x)
            return x["worst_amplification"], sh
        if c == "djrl_db_sqlite":
            pts = [("sqlite",) + lib(c), ("pg",) + lib("djrl_db_postgres")]
        else:
            pts = [("one",) + lib(c)]
        rows.append(("Rate limiting libraries", lab[c], pts))
    sty = {"sqlite": dict(marker="o", ms=4.0, color=SLOT[0], mec="white", mew=0.4),
           "pg": dict(marker="s", ms=3.6, mfc="white", mec=SLOT[1], mew=1.0),
           "one": dict(marker="D", ms=3.4, color="0.3", mec="white", mew=0.4)}
    with plt.rc_context(RC):
        fig, (a1, a2) = plt.subplots(1, 2, figsize=(3.45, 3.05), sharey=True,
                                     gridspec_kw={"width_ratios": [1.15, 1.0], "wspace": 0.14})
        ys, y, prev = [], 0.0, None
        heads = []
        for g, l, pts in rows:
            if g != prev:
                if prev is not None:
                    y += 0.6
                heads.append((y - 0.05, g)); y += 0.85; prev = g
            ys.append(y); y += 1.0
        import math
        for (g, l, pts), yy in zip(rows, ys):
            for key, amp, share in pts:
                dy = {"sqlite": -0.16, "pg": 0.16, "one": 0.0}[key]
                a1.plot(math.log2(amp), yy + dy, ls="", zorder=3, **sty[key])
                a2.plot(100 * share, yy + dy, ls="", zorder=3, **sty[key])
            a1.plot([0, math.log2(max(p[1] for p in pts))], [yy, yy], color="0.85", lw=0.8, zorder=1)
        for ax in (a1, a2):
            ax.grid(axis="x", color="0.9", lw=0.5); ax.set_axisbelow(True)
            ax.tick_params(axis="y", length=0)
        a1.axvline(0, color="black", lw=0.8, ls=(0, (4, 2)), zorder=1)
        a1.set_xticks([0, 1, 2, 3, 4]); a1.set_xticklabels(["1", "2", "4", "8", "16"])
        a1.set_xlim(-0.35, 4.35)
        a1.set_xlabel("(a) Worst trial $\\div$ $L$")
        a2.set_xlim(-6, 106); a2.set_xticks([0, 50, 100])
        a2.set_xlabel("(b) % over, trials $k{>}L$")
        a1.set_yticks(ys); a1.set_yticklabels([r[1] for r in rows], fontsize=6.4)
        from matplotlib.transforms import blended_transform_factory
        tr = blended_transform_factory(fig.transFigure, a1.transData)
        for hy, g in heads:
            fig.text(0.012, hy, g, ha="left", va="center", fontsize=6.6, style="italic", color="0.25",
                     transform=tr)
        a1.set_ylim(y - 0.3, -0.7)
        a1.plot([], [], ls="", label="SQLite (designs, package, DB cache)", **sty["sqlite"])
        a1.plot([], [], ls="", label="PostgreSQL", **sty["pg"])
        a1.plot([], [], ls="", label="one datastore", **sty["one"])
        fig.legend(loc="lower center", bbox_to_anchor=(0.45, -0.035), ncol=3, fontsize=6.0, frameon=False,
                   handletextpad=0.2, columnspacing=0.8)
        fig.subplots_adjust(left=0.40, right=0.98, top=0.99, bottom=0.17)
        fig.savefig(out, bbox_inches="tight")
        plt.close(fig)
    print("wrote", out)

if __name__ == "__main__":
    main()
    pgf_coords()
