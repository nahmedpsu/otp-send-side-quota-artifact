"""A local SMTP sink (round 7): accepts every message on 127.0.0.1:1025 and
appends one line per recipient to SMTP_LOG; nothing is relayed.

    python3 study/smtp_sink.py
"""
import asyncio
import json
import os
import time

from aiosmtpd.controller import Controller

LOG = os.environ.get("SMTP_LOG", "/tmp/smtp_sink.jsonl")


class Sink:
    async def handle_DATA(self, server, session, envelope):
        with open(LOG, "a") as f:
            for rcpt in envelope.rcpt_tos:
                f.write(json.dumps({"to": rcpt.lower(), "t": time.time()}) + "\n")
        return "250 OK"


if __name__ == "__main__":
    c = Controller(Sink(), hostname="127.0.0.1", port=int(os.environ.get("SMTP_PORT", "1025")))
    c.start()
    try:
        asyncio.get_event_loop().run_forever()
    finally:
        c.stop()
