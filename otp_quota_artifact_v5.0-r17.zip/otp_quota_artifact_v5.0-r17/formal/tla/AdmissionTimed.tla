---------------------------- MODULE AdmissionTimed ----------------------------
(***************************************************************************)
(* The six admission designs of svc/app.py and svc/app_pg.py with time,     *)
(* window rollover, delayed requests, provider faults, the release rule of  *)
(* reserve before send, and per worker state. Written directly in TLA+.     *)
(*                                                                         *)
(* Time is a global tick counter `clock` (0..T) that advances by Tick.      *)
(* A request samples `now` from the clock when it starts (the Python        *)
(* `now = time.time()` at the top of each strategy) and then performs its   *)
(* statements one atomic step at a time; Tick steps may fall between any    *)
(* two of them, so a request can be delayed for any number of ticks after  *)
(* sampling `now`, across a window boundary. Every step below is one SQL    *)
(* statement in autocommit mode, or one serialized transaction, exactly as  *)
(* in the code; the mapping is in formal/README.md.                         *)
(*                                                                         *)
(* Fixed window designs keep one counter row [used, ws] per (worker) store; *)
(* sliding window designs keep a set of records [r, ts]. W is the window    *)
(* length in ticks and windows are aligned at multiples of W.               *)
(*                                                                         *)
(* Ghost state, for the properties only (the code never reads it):         *)
(*   adm    one record per admission: request r, tau = the clock at the     *)
(*          granting statement, w = the window or timestamp the             *)
(*          implementation attributes the admission to (returned window     *)
(*          start for the one step fixed designs, submitted window start    *)
(*          for the read modify write counter, the sampled `now` stored in  *)
(*          the record for the sliding designs)                             *)
(*   calls  one record per provider call: request r, t = clock at the call, *)
(*          o = outcome. "ok" billed; "failed" not billed and the service   *)
(*          knows it failed; "unkB" and "unkU" the call raised after a      *)
(*          timeout, billed or not billed, which the service cannot tell    *)
(*          apart.                                                         *)
(***************************************************************************)
EXTENDS Naturals, FiniteSets

CONSTANTS N,          \* requests for one number
          L,          \* declared limit per window
          W,          \* window length in ticks
          T,          \* last tick
          K,          \* stores: 1 = one store shared by every worker; K > 1 = one per worker
          Design,
          Faults,     \* the provider may fail or time out
          ReleaseRule,  \* reserve before send: "anyError" (shipped) or "certainOnly"
          ReleaseScope, \* reserve before send: "current" (shipped) or "reserved"
          D,          \* the provider call follows the granting statement within D
                      \* ticks (D >= T: no bound)
          DbClock     \* TRUE: the rollover statement uses the datastore's clock at
                      \* the statement instead of the request's sampled `now`

ASSUME Design \in {"CountThenInsert", "ReadModifyWrite", "IncrementAfterSend",
                   "ConditionalUpdate", "GuardedTransaction", "ReserveBeforeSend",
                   "ConditionalUpdateDb", "ReserveBeforeSendDb"}
\* ConditionalUpdateDb, ReserveBeforeSendDb (service 2.2.0, atomic_update_db and
\* reserve_commit_db): one statement starts a new window if the stored one has
\* ended, on the datastore's clock at that statement, and admits if the count is
\* below L; the reservation is released only on a certain failure, and only on
\* the row of the window it was claimed in.
ASSUME ReleaseRule \in {"anyError", "certainOnly"} /\ ReleaseScope \in {"current", "reserved"}

Req == 1..N
Stores == 1..K
Floor(t) == t - (t % W)
Fixed == Design \in {"ReadModifyWrite", "ConditionalUpdate", "ReserveBeforeSend",
                     "ConditionalUpdateDb", "ReserveBeforeSendDb"}
Reserve == Design \in {"ReserveBeforeSend", "ReserveBeforeSendDb"}
Outcomes == IF Faults THEN {"ok", "failed", "unkB", "unkU"} ELSE {"ok"}
Billed(o) == o \in {"ok", "unkB"}
None == [used |-> 0, ws |-> 0, present |-> FALSE]

VARIABLES clock, row, recs, lock, pc, now, val, wsv, st, resw, outc, adm, calls

vars == <<clock, row, recs, lock, pc, now, val, wsv, st, resw, outc, adm, calls>>

Init ==
    /\ clock = 0
    /\ row = [k \in Stores |-> None]
    /\ recs = [k \in Stores |-> {}]
    /\ lock = [k \in Stores |-> 0]
    /\ pc = [s \in Req |-> "start"]
    /\ now = [s \in Req |-> 0]
    /\ val = [s \in Req |-> 0]
    /\ wsv = [s \in Req |-> 0]
    /\ st = [s \in Req |-> 1]
    /\ resw = [s \in Req |-> 0]
    /\ outc = [s \in Req |-> "none"]
    /\ adm = {}
    /\ calls = {}

\* the clock at the request's granting statement (from the ghost record)
Grant(s) == CHOOSE t \in 0..T : \E a \in adm : a.r = s /\ a.tau = t

CallDue(s) == pc[s] = "send" /\ (\E a \in adm : a.r = s)

Tick ==
    /\ clock < T
    /\ \A s \in Req : CallDue(s) => ((clock + 1) - Grant(s) <= D)
    /\ clock' = clock + 1
    /\ UNCHANGED <<row, recs, lock, pc, now, val, wsv, st, resw, outc, adm, calls>>

Goto(s, l) == pc' = [pc EXCEPT ![s] = l]

\* rows of the sliding designs counted by `ts >= now - W`: every record whose
\* timestamp lies in the trailing window of length W that ends at `n` or later
CountFrom(k, n) == Cardinality({x \in recs[k] : x.ts + W > n})

Admit(s, w) == adm' = adm \cup {[r |-> s, tau |-> clock, w |-> w]}

\* ------------------------------------------------------------------ start
Start(s) ==
    /\ pc[s] = "start"
    /\ \E k \in Stores :
         /\ st' = [st EXCEPT ![s] = k]
         /\ now' = [now EXCEPT ![s] = clock]
    /\ Goto(s, CASE Design \in {"CountThenInsert", "IncrementAfterSend"} -> "read"
                 [] Design = "ReadModifyWrite"   -> "readrow"
                 [] Design = "GuardedTransaction" -> "lock"
                 [] Design \in {"ConditionalUpdateDb", "ReserveBeforeSendDb"} -> "grantdb"
                 [] OTHER                          -> "roll1")
    /\ UNCHANGED <<clock, row, recs, lock, val, wsv, resw, outc, adm, calls>>

\* ------------------------------------------------- sliding window designs
Read(s) ==             \* SELECT COUNT(*) ... WHERE ts >= now - W
    /\ pc[s] = "read"
    /\ val' = [val EXCEPT ![s] = CountFrom(st[s], now[s])]
    /\ Goto(s, "decide")
    /\ UNCHANGED <<clock, row, recs, lock, now, wsv, st, resw, outc, adm, calls>>

Decide(s) ==
    /\ pc[s] = "decide"
    /\ IF val[s] >= L
         THEN Goto(s, "done") /\ UNCHANGED adm
         ELSE IF Design = "IncrementAfterSend"
                THEN Admit(s, now[s]) /\ Goto(s, "send")      \* admitted at the decision
                ELSE Goto(s, "insert") /\ UNCHANGED adm
    /\ UNCHANGED <<clock, row, recs, lock, now, val, wsv, st, resw, outc, calls>>

Insert(s) ==           \* INSERT INTO attempts(phone, ts) VALUES (?, now)
    /\ pc[s] = "insert"
    /\ recs' = [recs EXCEPT ![st[s]] = @ \cup {[r |-> s, ts |-> now[s]]}]
    /\ Admit(s, now[s])
    /\ Goto(s, "send")
    /\ UNCHANGED <<clock, row, lock, now, val, wsv, st, resw, outc, calls>>

InsertAfterSend(s) ==  \* INSERT ... VALUES (?, time.time()) after the provider call
    /\ pc[s] = "insertlate"
    /\ recs' = [recs EXCEPT ![st[s]] = @ \cup {[r |-> s, ts |-> clock]}]
    /\ Goto(s, "done")
    /\ UNCHANGED <<clock, row, lock, now, val, wsv, st, resw, outc, adm, calls>>

\* BEGIN IMMEDIATE (SQLite) / pg_advisory_xact_lock (PostgreSQL), then the
\* count and the insert inside the transaction, then COMMIT. `now` was
\* sampled before the lock, as in the code.
Lock(s) ==
    /\ pc[s] = "lock" /\ lock[st[s]] = 0
    /\ lock' = [lock EXCEPT ![st[s]] = s]
    /\ Goto(s, "tread")
    /\ UNCHANGED <<clock, row, recs, now, val, wsv, st, resw, outc, adm, calls>>

TxNow(s) == IF DbClock THEN clock ELSE now[s]

TRead(s) ==
    /\ pc[s] = "tread"
    /\ now' = [now EXCEPT ![s] = TxNow(s)]      \* with DbClock, now() inside the transaction
    /\ val' = [val EXCEPT ![s] = CountFrom(st[s], TxNow(s))]
    /\ Goto(s, "tdecide")
    /\ UNCHANGED <<clock, row, recs, lock, wsv, st, resw, outc, adm, calls>>

TDecide(s) ==          \* refuse: ROLLBACK; admit: INSERT and COMMIT
    /\ pc[s] = "tdecide"
    /\ lock' = [lock EXCEPT ![st[s]] = 0]
    /\ IF val[s] >= L
         THEN Goto(s, "done") /\ UNCHANGED <<recs, adm>>
         ELSE /\ recs' = [recs EXCEPT ![st[s]] = @ \cup {[r |-> s, ts |-> now[s]]}]
              /\ Admit(s, now[s])
              /\ Goto(s, "send")
    /\ UNCHANGED <<clock, row, now, val, wsv, st, resw, outc, calls>>

\* ---------------------------------------------- read modify write counter
ReadRow(s) ==          \* SELECT used, window_start ...; keep or start a window
    /\ pc[s] = "readrow"
    /\ LET r == row[st[s]] IN
         IF ~r.present \/ now[s] - r.ws >= W
           THEN val' = [val EXCEPT ![s] = 0] /\ wsv' = [wsv EXCEPT ![s] = Floor(now[s])]
           ELSE val' = [val EXCEPT ![s] = r.used] /\ wsv' = [wsv EXCEPT ![s] = r.ws]
    /\ Goto(s, "decrow")
    /\ UNCHANGED <<clock, row, recs, lock, now, st, resw, outc, adm, calls>>

DecRow(s) ==
    /\ pc[s] = "decrow"
    /\ Goto(s, IF val[s] >= L THEN "done" ELSE "upsert")
    /\ UNCHANGED <<clock, row, recs, lock, now, val, wsv, st, resw, outc, adm, calls>>

Upsert(s) ==           \* INSERT ... ON CONFLICT DO UPDATE SET used=v+1, window_start=ws
    /\ pc[s] = "upsert"
    /\ row' = [row EXCEPT ![st[s]] = [used |-> val[s] + 1, ws |-> wsv[s], present |-> TRUE]]
    /\ Admit(s, wsv[s])
    /\ Goto(s, "send")
    /\ UNCHANGED <<clock, recs, lock, now, val, wsv, st, resw, outc, calls>>

\* ---------------------------------- conditional update, reserve before send
RollClock(s) == IF DbClock THEN clock ELSE now[s]

Roll1(s) ==            \* INSERT OR IGNORE INTO counters VALUES (phone, 0, floor(now))
    /\ pc[s] = "roll1"
    /\ IF row[st[s]].present THEN UNCHANGED row
       ELSE row' = [row EXCEPT ![st[s]] = [used |-> 0, ws |-> Floor(RollClock(s)), present |-> TRUE]]
    /\ Goto(s, "roll2")
    /\ UNCHANGED <<clock, recs, lock, now, val, wsv, st, resw, outc, adm, calls>>

Roll2(s) ==            \* UPDATE ... SET used=0, window_start=floor(now) WHERE now-window_start >= W
    /\ pc[s] = "roll2"
    /\ IF RollClock(s) - row[st[s]].ws >= W
         THEN row' = [row EXCEPT ![st[s]] = [used |-> 0, ws |-> Floor(RollClock(s)), present |-> TRUE]]
         ELSE UNCHANGED row
    /\ Goto(s, "inc")
    /\ UNCHANGED <<clock, recs, lock, now, val, wsv, st, resw, outc, adm, calls>>

Inc(s) ==              \* UPDATE ... SET used=used+1 WHERE used < L RETURNING window_start
    /\ pc[s] = "inc"
    /\ IF row[st[s]].used < L
         THEN /\ row' = [row EXCEPT ![st[s]].used = @ + 1]
              /\ resw' = [resw EXCEPT ![s] = row[st[s]].ws]
              /\ Admit(s, row[st[s]].ws)
              /\ Goto(s, "send")
         ELSE Goto(s, "done") /\ UNCHANGED <<row, resw, adm>>
    /\ UNCHANGED <<clock, recs, lock, now, val, wsv, st, outc, calls>>

GrantDb(s) ==          \* INSERT OR IGNORE; then one UPDATE that rolls (on the
    /\ pc[s] = "grantdb" \* datastore's clock) and admits
    /\ LET r0 == IF row[st[s]].present THEN row[st[s]]
                 ELSE [used |-> 0, ws |-> Floor(clock), present |-> TRUE]
           r  == IF clock - r0.ws >= W THEN [used |-> 0, ws |-> Floor(clock), present |-> TRUE] ELSE r0
       IN IF r.used < L
            THEN /\ row' = [row EXCEPT ![st[s]] = [r EXCEPT !.used = @ + 1]]
                 /\ resw' = [resw EXCEPT ![s] = r.ws]
                 /\ Admit(s, r.ws)
                 /\ Goto(s, "send")
            ELSE /\ row' = [row EXCEPT ![st[s]] = r0]
                 /\ Goto(s, "done") /\ UNCHANGED <<resw, adm>>
    /\ UNCHANGED <<clock, recs, lock, now, val, wsv, st, outc, calls>>

\* --------------------------------------------------------- provider call
Send(s) ==
    /\ pc[s] = "send"
    /\ \E o \in Outcomes :
         /\ outc' = [outc EXCEPT ![s] = o]
         /\ calls' = calls \cup {[r |-> s, t |-> clock, o |-> o]}
         /\ Goto(s, CASE Design = "IncrementAfterSend" -> "insertlate"
                      [] Reserve /\ o # "ok" -> "release"
                      [] OTHER -> "done")
    /\ UNCHANGED <<clock, row, recs, lock, now, val, wsv, st, resw, adm>>

\* UPDATE counters SET used=used-1 WHERE phone=? (shipped: any exception, the
\* current row); the variants release only a certain failure and/or only the
\* row of the window the claim was made in.
ReleaseApplies(s) ==
    IF Design = "ReserveBeforeSendDb"
      THEN outc[s] = "failed" /\ row[st[s]].ws = resw[s]
      ELSE /\ (ReleaseRule = "anyError" \/ outc[s] = "failed")
           /\ (ReleaseScope = "current" \/ row[st[s]].ws = resw[s])

Release(s) ==
    /\ pc[s] = "release"
    /\ IF ReleaseApplies(s)
         THEN row' = [row EXCEPT ![st[s]].used = @ - 1]
         ELSE UNCHANGED row
    /\ Goto(s, "done")
    /\ UNCHANGED <<clock, recs, lock, now, val, wsv, st, resw, outc, adm, calls>>

Step(s) == Start(s) \/ Read(s) \/ Decide(s) \/ Insert(s) \/ InsertAfterSend(s)
           \/ Lock(s) \/ TRead(s) \/ TDecide(s) \/ ReadRow(s) \/ DecRow(s) \/ Upsert(s)
           \/ Roll1(s) \/ Roll2(s) \/ Inc(s) \/ GrantDb(s) \/ Send(s) \/ Release(s)

AllDone == \A s \in Req : pc[s] = "done"
Terminated == AllDone /\ UNCHANGED vars

Next == Tick \/ (\E s \in Req : Step(s)) \/ Terminated

Spec == Init /\ [][Next]_vars
FairSpec == Spec /\ \A s \in Req : WF_vars(Step(s))

\* =================================================================== the contract
Windows == {w \in 0..T : w % W = 0}
Starts  == 0..T
AdmIn(w)  == {a \in adm : a.w = w}                       \* attributed to window w
CallOf(a) == {c \in calls : c.r = a.r}
BilledAdm(S) == {a \in S : \E c \in CallOf(a) : Billed(c.o)}

\* C1, send bound, in the implementation's own attribution:
\*   fixed: at most L admissions attributed to each aligned window;
\*   sliding: at most L admissions with timestamps in any interval of length W.
C1 == IF Fixed THEN \A w \in Windows : Cardinality(AdmIn(w)) <= L
               ELSE \A t0 \in Starts : Cardinality({a \in adm : t0 <= a.w /\ a.w < t0 + W}) <= L
\* C1 by authorization instant (the clock at the granting statement)
C1tau == IF Fixed THEN \A w \in Windows : Cardinality({a \in adm : Floor(a.tau) = w}) <= L
                  ELSE \A t0 \in Starts : Cardinality({a \in adm : t0 <= a.tau /\ a.tau < t0 + W}) <= L
\* provider observed: billed calls in any interval of length W (at most L; at most 2L)
ProvL  == \A t0 \in Starts : Cardinality({c \in calls : Billed(c.o) /\ t0 <= c.t /\ c.t < t0 + W}) <= L
Prov2L == \A t0 \in Starts : Cardinality({c \in calls : Billed(c.o) /\ t0 <= c.t /\ c.t < t0 + W}) <= 2 * L
\* C2, billing bound, in the implementation's attribution: billed messages per window
C2 == IF Fixed THEN \A w \in Windows : Cardinality(BilledAdm(AdmIn(w))) <= L
               ELSE \A t0 \in Starts : Cardinality(BilledAdm({a \in adm : t0 <= a.w /\ a.w < t0 + W})) <= L
\* C3, no duplicate billing: each request causes at most one provider call
C3 == \A s \in Req : Cardinality({c \in calls : c.r = s}) <= 1
\* the counter never goes below zero
NonNegative == \A k \in Stores : row[k].used >= 0
\* C4, availability: once every request has finished, the counter of the
\* current window holds no more than the billed admissions plus those whose
\* outcome is unknown and unbilled (an allowance is lost only to an unknown
\* outcome), for the fixed one step designs
C4 == (AllDone /\ Design \in {"ConditionalUpdate", "ReserveBeforeSend", "ConditionalUpdateDb", "ReserveBeforeSendDb"}) =>
        \A k \in Stores : row[k].present =>
          row[k].used <= Cardinality(BilledAdm(AdmIn(row[k].ws)))
                         + Cardinality({a \in AdmIn(row[k].ws) : \E c \in CallOf(a) : c.o = "unkU"})
\* liveness: every request finishes
Termination == <>AllDone
\* per worker stores: at most K times L per window
C1K == IF Fixed THEN \A w \in Windows : Cardinality(AdmIn(w)) <= K * L
                ELSE \A t0 \in Starts : Cardinality({a \in adm : t0 <= a.w /\ a.w < t0 + W}) <= K * L
\* sanity: the limit is reachable within one window
BelowLimit == \A w \in Windows : Cardinality(AdmIn(w)) < L
=============================================================================
