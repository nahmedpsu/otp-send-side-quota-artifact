"""Run TLC on AdmissionTimed.tla: the six designs with time, window rollover,
delayed requests, provider faults, the release rule of reserve before send,
the datastore's clock, and per worker stores.

Every run checks one property with breadth first search, so a reported
counterexample is a shortest one. Output: results_timed.json and
results_timed.md beside this script; the first counterexample of each
(design, property, variant) is kept in traces_timed/.

    python3 formal/tla/run_tlc_timed.py [path/to/tla2tools.jar]
"""
import json
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
JAR = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("TLA2TOOLS", "tla2tools.jar")
SLIDING = ["CountThenInsert", "IncrementAfterSend", "GuardedTransaction"]
FIXED = ["ReadModifyWrite", "ConditionalUpdate", "ReserveBeforeSend"]
ALL = ["CountThenInsert", "ReadModifyWrite", "IncrementAfterSend",
       "ConditionalUpdate", "GuardedTransaction", "ReserveBeforeSend"]
BASE = dict(W=2, T=4, K=1, faults=False, rule="anyError", scope="current", dbclock=False,
            fair=False, D=None)
NL = [(2, 1), (3, 1), (3, 2)]

runs = []


def add(group, design, prop, **kw):
    for N, L in kw.pop("nl", NL):
        runs.append(dict(BASE, group=group, design=design, prop=prop, N=N, L=L, **kw))


# A. every design, no faults: the send bound in three time bases, no duplicate
#    call, the counter never negative; and the sanity check
for d in ALL:
    for p in ("C1", "C1tau", "ProvL", "Prov2L", "C3") + (("NonNegative",) if d in FIXED else ()):
        add("A", d, p)
    add("A", d, "BelowLimit", nl=[(1, 1), (2, 2)])
# B. provider faults: the one step designs, and every release rule of reserve
#    before send
for d in ("ConditionalUpdate", "GuardedTransaction"):
    for p in ("C1", "C2", "C4"):
        add("B", d, p, faults=True)
for rule in ("anyError", "certainOnly"):
    for scope in ("current", "reserved"):
        for p in ("C1", "C2", "NonNegative", "C4"):
            add("B", "ReserveBeforeSend", p, faults=True, rule=rule, scope=scope)
# C. the rollover decided on the datastore's clock instead of the sampled now
for d, kw in (("ConditionalUpdate", {}),
              ("ReserveBeforeSend", dict(faults=True, rule="certainOnly", scope="reserved"))):
    for p in ("C1", "C1tau", "ProvL", "Prov2L", "C2"):
        add("C", d, p, dbclock=True, **kw)
# D. one store per worker (K = 2), as with a per process limiter
for d in ("ConditionalUpdate", "GuardedTransaction"):
    for p in ("C1", "C1K"):
        add("D", d, p, K=2, nl=[(2, 1), (3, 1)])
# E. a longer horizon (three windows) for the conditional update
for db in (False, True):
    for p in ("C1", "C1tau", "Prov2L"):
        add("E", "ConditionalUpdate", p, T=6, dbclock=db, nl=[(3, 1)])
# G. the grant on the datastore's clock (service 2.2.0), the guarded
#    transaction reading the datastore's clock inside the transaction, and the
#    provider call bounded to follow the grant within D = 0 ticks
for d, kw in (("ConditionalUpdateDb", {}), ("ReserveBeforeSendDb", dict(faults=True)),
              ("GuardedTransaction", dict(dbclock=True))):
    for p in ("C1", "C1tau", "ProvL", "Prov2L", "C2", "C3") + (("NonNegative", "C4") if d != "GuardedTransaction" else ()):
        add("G", d, p, **kw)
    add("G", d, "BelowLimit", nl=[(1, 1), (2, 2)], **kw)
for d, kw in (("ConditionalUpdateDb", {}), ("ConditionalUpdate", {}),
              ("GuardedTransaction", dict(dbclock=True)), ("CountThenInsert", {})):
    for p in ("ProvL", "Prov2L"):
        add("G", d, p, D=0, **kw)
for p in ("C1", "C1tau", "Prov2L"):
    add("G", "ConditionalUpdateDb", p, T=6, nl=[(3, 1)])
# F. liveness: every request finishes, under weak fairness
for d in ALL:
    add("F", d, "Termination", fair=True, T=2, nl=[(2, 1)])
add("F", "ReserveBeforeSend", "Termination", fair=True, T=2, faults=True, nl=[(2, 1)])
add("F", "ConditionalUpdateDb", "Termination", fair=True, T=2, nl=[(2, 1)])
add("F", "ReserveBeforeSendDb", "Termination", fair=True, T=2, faults=True, nl=[(2, 1)])


def name(r):
    v = [r["group"], r["design"], f"N{r['N']}", f"L{r['L']}", f"T{r['T']}", r["prop"]]
    if r["K"] > 1:
        v.append(f"K{r['K']}")
    if r["faults"]:
        v.append("faults")
    if r["design"] == "ReserveBeforeSend":
        v += [r["rule"], r["scope"]]
    if r["dbclock"]:
        v.append("dbclock")
    if r["D"] is not None:
        v.append(f"D{r['D']}")
    return "_".join(v)


def run(r):
    nm = name(r)
    cfg = os.path.join(HERE, "cfg_timed", nm + ".cfg")
    os.makedirs(os.path.dirname(cfg), exist_ok=True)
    kind = "PROPERTY" if r["prop"] == "Termination" else "INVARIANT"
    open(cfg, "w").write(
        f"SPECIFICATION {'FairSpec' if r['fair'] else 'Spec'}\n"
        f"CONSTANTS N = {r['N']}\n          L = {r['L']}\n          W = {r['W']}\n"
        f"          T = {r['T']}\n          K = {r['K']}\n          Design = \"{r['design']}\"\n"
        f"          Faults = {str(r['faults']).upper()}\n          ReleaseRule = \"{r['rule']}\"\n"
        f"          ReleaseScope = \"{r['scope']}\"\n          DbClock = {str(r['dbclock']).upper()}\n"
        f"          D = {r['T'] if r['D'] is None else r['D']}\n"
        f"{kind} {r['prop']}\n")
    meta = os.path.join(HERE, "states_timed", nm)
    p = subprocess.run(["java", "-XX:+UseParallelGC", "-cp", JAR, "tlc2.TLC", "-noGenerateSpecTE",
                        "-config", cfg, "-workers", "2", "-metadir", meta, "-cleanup",
                        "AdmissionTimed.tla"], cwd=HERE, capture_output=True, text=True)
    out = p.stdout
    shutil.rmtree(meta, ignore_errors=True)
    m = re.findall(r"(\d+) states generated, (\d+) distinct states found", out)
    res = dict(r, name=nm, distinct=int(m[-1][1]) if m else None)
    if "No error has been found" in out:
        res["verdict"] = "holds"
    elif re.search(r"(Invariant|Temporal properties were) .*violated|is violated", out):
        res["verdict"] = "violated"
        res["trace_states"] = len(re.findall(r"^State \d+:", out, re.M))
        tdir = os.path.join(HERE, "traces_timed")
        os.makedirs(tdir, exist_ok=True)
        key = "_".join(nm.split("_")[:2] + [r["prop"]] + nm.split("_")[6:])
        path = os.path.join(tdir, key + ".txt")
        if not os.path.exists(path):
            open(path, "w").write(out)
    else:
        raise SystemExit(f"TLC did not finish {nm}:\n{out[-3000:]}")
    return res


# Resume: runs already reported in the log of an earlier, interrupted
# invocation (formal/formal_round7_part1.log; that run was stopped on October
# 9, 2026 to apply the budget below) are read back, not rerun.
DONE = {}
_log = os.path.join(os.path.dirname(HERE), "formal_round7_part1.log")
if os.path.exists(_log):
    for _m in re.finditer(r"^\[\d+/\d+\] (\S+): (holds|violated) \((\d+) states\)", open(_log).read(), re.M):
        DONE[_m.group(1)] = (_m.group(2), int(_m.group(3)))

# Budget: with provider faults and the datastore's clock (groups C and G), the
# state space of reserve before send exceeds 1.7e7 distinct states at N = 3,
# L = 1 already; the bound N = 3, L = 2 is checked there only where the earlier
# invocation had completed it, and N = 3, L = 1 is otherwise the largest bound
# of those rows. Group B (the sampled clock) keeps every bound.
runs = [r for r in runs if not (r["faults"] and r["design"].startswith("ReserveBeforeSend")
                                and (r["dbclock"] or r["design"] == "ReserveBeforeSendDb")
                                and (r["N"], r["L"]) == (3, 2) and name(r) not in DONE)]

if __name__ == "__main__":
    if not DONE:
        shutil.rmtree(os.path.join(HERE, "traces_timed"), ignore_errors=True)
    shutil.rmtree(os.path.join(HERE, "cfg_timed"), ignore_errors=True)
    results = []
    for i, r in enumerate(runs, 1):
        if name(r) in DONE:
            v, n = DONE[name(r)]
            res = dict(r, name=name(r), verdict=v, distinct=n, resumed=True)
            results.append(res)
            print(f"[{i}/{len(runs)}] {res['name']}: {res['verdict']} ({res['distinct']} states) [part 1]", flush=True)
            continue
        res = run(r)
        results.append(res)
        print(f"[{i}/{len(runs)}] {res['name']}: {res['verdict']} ({res['distinct']} states)", flush=True)
    shutil.rmtree(os.path.join(HERE, "cfg_timed"), ignore_errors=True)
    shutil.rmtree(os.path.join(HERE, "states_timed"), ignore_errors=True)
    json.dump(results, open(os.path.join(HERE, "results_timed.json"), "w"), indent=1)
    with open(os.path.join(HERE, "results_timed.md"), "w") as f:
        f.write("| group | design | N | L | T | K | faults | release rule | release scope | db clock | call delay D | property | verdict | distinct states | trace states |\n")
        f.write("|" + "---|" * 15 + "\n")
        for r in results:
            f.write(f"| {r['group']} | {r['design']} | {r['N']} | {r['L']} | {r['T']} | {r['K']} | {r['faults']} | "
                    f"{r['rule'] if r['design']=='ReserveBeforeSend' else ''} | "
                    f"{r['scope'] if r['design']=='ReserveBeforeSend' else ''} | {r['dbclock']} | "
                    f"{'' if r['D'] is None else r['D']} | {r['prop']} | "
                    f"{r['verdict']} | {r['distinct']} | {r.get('trace_states', '')} |\n")
    print("wrote", len(results), "runs")
