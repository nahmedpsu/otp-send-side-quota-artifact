| group | design | N | L | T | K | faults | release rule | release scope | db clock | call delay D | property | verdict | distinct states | trace states |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 1193 |  |
| A | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 3491 |  |
| A | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | violated | 42242 |  |
| A | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 1198 |  |
| A | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 4085 |  |
| A | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | violated | 62198 |  |
| A | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 2432 |  |
| A | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 16955 |  |
| A | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 349677 |  |
| A | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 7601 |  |
| A | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | violated | 219274 |  |
| A | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 1091873 |  |
| A | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 7601 |  |
| A | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 467213 |  |
| A | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 1091873 |  |
| A | CountThenInsert | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 39 |  |
| A | CountThenInsert | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 1054 |  |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 1174 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 4569 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | violated | 57064 |  |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 1117 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 3782 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | violated | 65360 |  |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 2971 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 12255 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 298172 |  |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 7967 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | violated | 220823 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 1174400 |  |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 7967 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 505061 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 1174400 |  |
| A | ReadModifyWrite | 2 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 7967 |  |
| A | ReadModifyWrite | 3 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 505061 |  |
| A | ReadModifyWrite | 3 | 2 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 1174400 |  |
| A | ReadModifyWrite | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 37 |  |
| A | ReadModifyWrite | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 848 |  |
| A | IncrementAfterSend | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 410 |  |
| A | IncrementAfterSend | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | violated | 832 |  |
| A | IncrementAfterSend | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | violated | 12412 |  |
| A | IncrementAfterSend | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 463 |  |
| A | IncrementAfterSend | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 818 |  |
| A | IncrementAfterSend | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | violated | 13098 |  |
| A | IncrementAfterSend | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 1660 |  |
| A | IncrementAfterSend | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 4907 |  |
| A | IncrementAfterSend | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 120590 |  |
| A | IncrementAfterSend | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 25628 |  |
| A | IncrementAfterSend | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | violated | 126356 |  |
| A | IncrementAfterSend | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 5232455 |  |
| A | IncrementAfterSend | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 25628 |  |
| A | IncrementAfterSend | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 3113072 |  |
| A | IncrementAfterSend | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 5232455 |  |
| A | IncrementAfterSend | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 24 |  |
| A | IncrementAfterSend | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 808 |  |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 5670 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 212621 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | holds | 430298 |  |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 2001 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 10316 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | violated | 72605 |  |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 3750 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 34647 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 273914 |  |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 5670 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | violated | 210841 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 430298 |  |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 5670 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 212621 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 430298 |  |
| A | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 5670 |  |
| A | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 212621 |  |
| A | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 430298 |  |
| A | ConditionalUpdate | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 35 |  |
| A | ConditionalUpdate | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 1154 |  |
| A | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 4818 |  |
| A | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 136958 |  |
| A | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | holds | 375395 |  |
| A | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 1770 |  |
| A | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | violated | 10137 |  |
| A | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | violated | 81799 |  |
| A | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 3323 |  |
| A | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 29698 |  |
| A | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 244169 |  |
| A | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 4818 |  |
| A | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | violated | 135956 |  |
| A | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 375395 |  |
| A | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 4818 |  |
| A | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 136958 |  |
| A | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 375395 |  |
| A | GuardedTransaction | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 37 |  |
| A | GuardedTransaction | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 791 |  |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | C1 | holds | 5670 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | C1 | holds | 212621 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | C1 | holds | 430298 |  |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | C1tau | violated | 2033 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | C1tau | violated | 10934 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | C1tau | violated | 57615 |  |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | ProvL | violated | 3839 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | ProvL | violated | 30842 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | ProvL | violated | 226546 |  |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | Prov2L | holds | 5670 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | Prov2L | violated | 210841 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | Prov2L | holds | 430298 |  |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | C3 | holds | 5670 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | C3 | holds | 212621 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | C3 | holds | 430298 |  |
| A | ReserveBeforeSend | 2 | 1 | 4 | 1 | False | anyError | current | False |  | NonNegative | holds | 5670 |  |
| A | ReserveBeforeSend | 3 | 1 | 4 | 1 | False | anyError | current | False |  | NonNegative | holds | 212621 |  |
| A | ReserveBeforeSend | 3 | 2 | 4 | 1 | False | anyError | current | False |  | NonNegative | holds | 430298 |  |
| A | ReserveBeforeSend | 1 | 1 | 4 | 1 | False | anyError | current | False |  | BelowLimit | violated | 37 |  |
| A | ReserveBeforeSend | 2 | 2 | 4 | 1 | False | anyError | current | False |  | BelowLimit | violated | 1140 |  |
| B | ConditionalUpdate | 2 | 1 | 4 | 1 | True |  |  | False |  | C1 | holds | 23880 |  |
| B | ConditionalUpdate | 3 | 1 | 4 | 1 | True |  |  | False |  | C1 | holds | 1310864 |  |
| B | ConditionalUpdate | 3 | 2 | 4 | 1 | True |  |  | False |  | C1 | holds | 5866973 |  |
| B | ConditionalUpdate | 2 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 23880 |  |
| B | ConditionalUpdate | 3 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 1310864 |  |
| B | ConditionalUpdate | 3 | 2 | 4 | 1 | True |  |  | False |  | C2 | holds | 5866973 |  |
| B | ConditionalUpdate | 2 | 1 | 4 | 1 | True |  |  | False |  | C4 | violated | 2660 |  |
| B | ConditionalUpdate | 3 | 1 | 4 | 1 | True |  |  | False |  | C4 | violated | 181761 |  |
| B | ConditionalUpdate | 3 | 2 | 4 | 1 | True |  |  | False |  | C4 | violated | 406466 |  |
| B | GuardedTransaction | 2 | 1 | 4 | 1 | True |  |  | False |  | C1 | holds | 20034 |  |
| B | GuardedTransaction | 3 | 1 | 4 | 1 | True |  |  | False |  | C1 | holds | 858821 |  |
| B | GuardedTransaction | 3 | 2 | 4 | 1 | True |  |  | False |  | C1 | holds | 5135171 |  |
| B | GuardedTransaction | 2 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 20034 |  |
| B | GuardedTransaction | 3 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 858821 |  |
| B | GuardedTransaction | 3 | 2 | 4 | 1 | True |  |  | False |  | C2 | holds | 5135171 |  |
| B | GuardedTransaction | 2 | 1 | 4 | 1 | True |  |  | False |  | C4 | holds | 20034 |  |
| B | GuardedTransaction | 3 | 1 | 4 | 1 | True |  |  | False |  | C4 | holds | 858821 |  |
| B | GuardedTransaction | 3 | 2 | 4 | 1 | True |  |  | False |  | C4 | holds | 5135171 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | current | False |  | C1 | violated | 5964 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | current | False |  | C1 | violated | 30406 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | current | False |  | C1 | violated | 460816 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | current | False |  | C2 | violated | 10759 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | current | False |  | C2 | violated | 64219 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | current | False |  | C2 | violated | 2346428 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | current | False |  | NonNegative | violated | 5592 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | current | False |  | NonNegative | violated | 38073 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | current | False |  | NonNegative | violated | 51255 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | current | False |  | C4 | holds | 87219 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | current | False |  | C4 | holds | 15399932 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | current | False |  | C4 | holds | 37545425 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | reserved | False |  | C1 | violated | 5736 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | reserved | False |  | C1 | violated | 27104 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | reserved | False |  | C1 | violated | 611104 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | reserved | False |  | C2 | violated | 11411 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | reserved | False |  | C2 | violated | 63767 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | reserved | False |  | C2 | violated | 2369488 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | reserved | False |  | NonNegative | holds | 75591 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | reserved | False |  | NonNegative | holds | 10868558 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | reserved | False |  | NonNegative | holds | 28808171 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | anyError | reserved | False |  | C4 | holds | 75591 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | anyError | reserved | False |  | C4 | holds | 10868558 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | anyError | reserved | False |  | C4 | holds | 28808171 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | current | False |  | C1 | violated | 6053 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | current | False |  | C1 | violated | 28045 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | current | False |  | C1 | violated | 608889 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | current | False |  | C2 | holds | 64591 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | current | False |  | C2 | violated | 1920043 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | current | False |  | C2 | holds | 28044133 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | current | False |  | NonNegative | violated | 7737 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | current | False |  | NonNegative | violated | 41312 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | current | False |  | NonNegative | violated | 42165 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | current | False |  | C4 | holds | 64591 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | current | False |  | C4 | holds | 7242472 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | current | False |  | C4 | holds | 28044133 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C1 | violated | 6600 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C1 | violated | 30957 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | False |  | C1 | violated | 429249 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C2 | holds | 60715 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C2 | holds | 5826274 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | False |  | C2 | holds | 25131715 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | NonNegative | holds | 60715 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | NonNegative | holds | 5826274 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | False |  | NonNegative | holds | 25131715 |  |
| B | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C4 | holds | 60715 |  |
| B | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | False |  | C4 | holds | 5826274 |  |
| B | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | False |  | C4 | holds | 25131715 |  |
| C | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | True |  | C1 | holds | 10566 |  |
| C | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | True |  | C1 | holds | 481309 |  |
| C | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | True |  | C1 | holds | 882352 |  |
| C | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | True |  | C1tau | violated | 2613 |  |
| C | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | True |  | C1tau | violated | 13726 |  |
| C | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | True |  | C1tau | violated | 86579 |  |
| C | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | True |  | ProvL | violated | 4519 |  |
| C | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | True |  | ProvL | violated | 30062 |  |
| C | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | True |  | ProvL | violated | 309268 |  |
| C | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | True |  | Prov2L | holds | 10566 |  |
| C | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | True |  | Prov2L | violated | 423756 |  |
| C | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | True |  | Prov2L | holds | 882352 |  |
| C | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | True |  | C2 | holds | 10566 |  |
| C | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | True |  | C2 | holds | 481309 |  |
| C | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | True |  | C2 | holds | 882352 |  |
| C | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C1 | violated | 8206 |  |
| C | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C1 | violated | 36894 |  |
| C | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | True |  | C1 | violated | 875249 |  |
| C | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C1tau | violated | 5884 |  |
| C | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C1tau | violated | 24224 |  |
| C | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | True |  | C1tau | violated | 595523 |  |
| C | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | ProvL | violated | 13275 |  |
| C | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | ProvL | violated | 90839 |  |
| C | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | True |  | ProvL | violated | 3909592 |  |
| C | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | Prov2L | holds | 134963 |  |
| C | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | Prov2L | violated | 7241666 |  |
| C | ReserveBeforeSend | 3 | 2 | 4 | 1 | True | certainOnly | reserved | True |  | Prov2L | holds | 56143477 |  |
| C | ReserveBeforeSend | 2 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C2 | holds | 134963 |  |
| C | ReserveBeforeSend | 3 | 1 | 4 | 1 | True | certainOnly | reserved | True |  | C2 | holds | 17602348 |  |
| D | ConditionalUpdate | 2 | 1 | 4 | 2 | False |  |  | False |  | C1 | violated | 3348 | 10 |
| D | ConditionalUpdate | 3 | 1 | 4 | 2 | False |  |  | False |  | C1 | violated | 19010 | 9 |
| D | ConditionalUpdate | 2 | 1 | 4 | 2 | False |  |  | False |  | C1K | holds | 24951 |  |
| D | ConditionalUpdate | 3 | 1 | 4 | 2 | False |  |  | False |  | C1K | holds | 2182679 |  |
| D | GuardedTransaction | 2 | 1 | 4 | 2 | False |  |  | False |  | C1 | violated | 2621 | 9 |
| D | GuardedTransaction | 3 | 1 | 4 | 2 | False |  |  | False |  | C1 | violated | 14752 | 10 |
| D | GuardedTransaction | 2 | 1 | 4 | 2 | False |  |  | False |  | C1K | holds | 23247 |  |
| D | GuardedTransaction | 3 | 1 | 4 | 2 | False |  |  | False |  | C1K | holds | 1755137 |  |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | False |  | C1 | holds | 1725199 |  |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | False |  | C1tau | violated | 9950 | 11 |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | False |  | Prov2L | violated | 1274125 | 20 |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | True |  | C1 | holds | 6095805 |  |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | True |  | C1tau | violated | 22836 | 11 |
| E | ConditionalUpdate | 3 | 1 | 6 | 1 | False |  |  | True |  | Prov2L | violated | 3103979 | 20 |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | C1 | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | C1 | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | C1tau | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | C1tau | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | C1tau | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 1046 | 9 |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | ProvL | violated | 3740 | 9 |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | ProvL | violated | 71509 | 12 |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | Prov2L | violated | 103231 | 14 |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | Prov2L | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | C2 | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | C2 | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | C2 | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | C3 | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | C3 | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | NonNegative | holds | 215618 |  |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False |  | C4 | holds | 3950 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False |  | C4 | holds | 109859 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False |  | C4 | holds | 215618 |  |
| G | ConditionalUpdateDb | 1 | 1 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 13 | 3 |
| G | ConditionalUpdateDb | 2 | 2 | 4 | 1 | False |  |  | False |  | BelowLimit | violated | 114 | 5 |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | C1 | violated | 988 | 7 |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | C1 | violated | 2534 | 7 |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | C1tau | violated | 1309 | 8 |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | C1tau | violated | 1713 | 7 |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | ProvL | violated | 3744 | 9 |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | ProvL | violated | 13621 | 9 |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | Prov2L | holds | 68095 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | Prov2L | violated | 654593 | 14 |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 68095 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | C2 | holds | 6226156 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | C3 | holds | 68095 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | C3 | holds | 6226156 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | NonNegative | holds | 68095 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | NonNegative | holds | 6226156 |  |
| G | ReserveBeforeSendDb | 2 | 1 | 4 | 1 | True |  |  | False |  | C4 | holds | 68095 |  |
| G | ReserveBeforeSendDb | 3 | 1 | 4 | 1 | True |  |  | False |  | C4 | holds | 6226156 |  |
| G | ReserveBeforeSendDb | 1 | 1 | 4 | 1 | True |  |  | False |  | BelowLimit | violated | 11 | 3 |
| G | ReserveBeforeSendDb | 2 | 2 | 4 | 1 | True |  |  | False |  | BelowLimit | violated | 179 | 5 |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | C1 | holds | 4050 |  |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | C1 | holds | 86615 |  |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | C1 | holds | 190079 |  |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | C1tau | violated | 1806 | 12 |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | C1tau | violated | 8223 | 12 |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | C1tau | violated | 50838 | 16 |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | ProvL | violated | 2232 | 14 |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | ProvL | violated | 26064 | 13 |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | ProvL | violated | 122630 | 19 |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | Prov2L | holds | 4050 |  |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | Prov2L | violated | 86197 | 20 |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | Prov2L | holds | 190079 |  |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | C2 | holds | 4050 |  |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | C2 | holds | 86615 |  |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | C2 | holds | 190079 |  |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True |  | C3 | holds | 4050 |  |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True |  | C3 | holds | 86615 |  |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True |  | C3 | holds | 190079 |  |
| G | GuardedTransaction | 1 | 1 | 4 | 1 | False |  |  | True |  | BelowLimit | violated | 40 | 5 |
| G | GuardedTransaction | 2 | 2 | 4 | 1 | False |  |  | True |  | BelowLimit | violated | 845 | 11 |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 646 | 9 |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 3186 | 9 |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 15327 | 12 |
| G | ConditionalUpdateDb | 2 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 1264 |  |
| G | ConditionalUpdateDb | 3 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 23153 |  |
| G | ConditionalUpdateDb | 3 | 2 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 28292 |  |
| G | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 1764 | 13 |
| G | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 22182 | 13 |
| G | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 81761 | 18 |
| G | ConditionalUpdate | 2 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 2700 |  |
| G | ConditionalUpdate | 3 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | violated | 75457 | 20 |
| G | ConditionalUpdate | 3 | 2 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 101420 |  |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True | 0 | ProvL | violated | 1502 | 14 |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True | 0 | ProvL | violated | 11079 | 14 |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True | 0 | ProvL | violated | 30251 | 18 |
| G | GuardedTransaction | 2 | 1 | 4 | 1 | False |  |  | True | 0 | Prov2L | holds | 1704 |  |
| G | GuardedTransaction | 3 | 1 | 4 | 1 | False |  |  | True | 0 | Prov2L | holds | 25883 |  |
| G | GuardedTransaction | 3 | 2 | 4 | 1 | False |  |  | True | 0 | Prov2L | holds | 33233 |  |
| G | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 1786 | 11 |
| G | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 11402 | 11 |
| G | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False | 0 | ProvL | violated | 109359 | 16 |
| G | CountThenInsert | 2 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 3046 |  |
| G | CountThenInsert | 3 | 1 | 4 | 1 | False |  |  | False | 0 | Prov2L | violated | 72026 | 17 |
| G | CountThenInsert | 3 | 2 | 4 | 1 | False |  |  | False | 0 | Prov2L | holds | 206896 |  |
| G | ConditionalUpdateDb | 3 | 1 | 6 | 1 | False |  |  | False |  | C1 | holds | 1262219 |  |
| G | ConditionalUpdateDb | 3 | 1 | 6 | 1 | False |  |  | False |  | C1tau | holds | 1262219 |  |
| G | ConditionalUpdateDb | 3 | 1 | 6 | 1 | False |  |  | False |  | Prov2L | violated | 484803 | 14 |
| F | CountThenInsert | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 1024 |  |
| F | ReadModifyWrite | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 1044 |  |
| F | IncrementAfterSend | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 1929 |  |
| F | ConditionalUpdate | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 787 |  |
| F | GuardedTransaction | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 689 |  |
| F | ReserveBeforeSend | 2 | 1 | 2 | 1 | False | anyError | current | False |  | Termination | holds | 787 |  |
| F | ReserveBeforeSend | 2 | 1 | 2 | 1 | True | anyError | current | False |  | Termination | holds | 6619 |  |
| F | ConditionalUpdateDb | 2 | 1 | 2 | 1 | False |  |  | False |  | Termination | holds | 435 |  |
| F | ReserveBeforeSendDb | 2 | 1 | 2 | 1 | True |  |  | False |  | Termination | holds | 4425 |  |
