# Formal models of the admission designs

Models of the admission designs in `svc/app.py` and `svc/app_pg.py`
(Algorithms 1 and 2 of the paper), checked against the enforcement contract
of the paper's Section 3 (manuscript v5.0):

* **C1, send bound:** the calls whose grants fall in one window of the
  design's family number at most L; checked in the implementation's own
  attribution (`C1`), by authorization instant (`C1tau`), and as the provider
  observes calls in any interval of length W (`ProvL`, at most L; `Prov2L`, at
  most 2L, which a fixed window policy permits).
* **C2, billing bound:** billed calls per window at most L when the provider
  may fail, time out after billing, or time out without billing.
* **C3, no duplicate call;** **C4, availability** (an allowance is lost only
  to an unknown outcome that was in fact not billed); **NonNegative** (the
  counter never goes below zero); **Termination** (every request finishes,
  under weak fairness); **C1K** (at most K·L with one store per worker);
  **BelowLimit** (sanity: the limit is reachable, so a holding verdict is not
  vacuous).

| Folder / file | Tool | What it shows |
|---|---|---|
| `tla/Admission.tla`, `run_tlc.py` | TLA+ (PlusCal), TLC | Untimed, one window: every interleaving of N requests for L = 1, 2, 3 and N up to L + 2; C1 for all six designs, C2 with faults for the one step designs (named R1 and R3 in versions before v5.0). |
| `tla/AdmissionTimed.tla`, `run_tlc_timed.py` | TLA+, TLC | Timed (round 7): a clock with ticks between any two statements, aligned windows of W = 2 ticks, rollover as separate statements, four provider outcomes, four release rules of reserve before send, the two designs on the datastore's clock, a bound D on the delay from grant to call, and K stores. 320 runs; `results_timed.json` and `results_timed.md`; first counterexample of each row in `traces_timed/`. |
| `tamarin/OTPAdmission.spthy`, `run_tamarin.sh`, `sweep_limits.py` | Tamarin 1.10.0, Maude 3.5 | Any number of requests, one window: C1 proved for the one step designs, and a trace with L + 1 grants found for the two step designs, at L = 3 (`results/`); the sweep (`results/sweep/`, `results/sweep.json`) proves the one step designs for every L from 1 to 5 and finds the two step traces for L from 1 to 3 (the trace search at L = 4 did not finish within the host's memory; see `sweep_limits.py`). |
| `tamarin/OTPAdmissionParam.spthy` | Tamarin | The limit is a natural number chosen for each number: for every limit at once, grants consume pairwise distinct counter values below the limit (`results/param/`); that at most L grants follow is a counting step on paper. |

`run_formal_round7.sh` runs the timed TLC suite, the parameterized Tamarin
model, and the sweep, in that order, after the round 7 measurements. The
timed suite was stopped once, on October 9, 2026, to bound its run time: the
206 runs already reported are kept in `formal_round7_part1.log` and read back
by `run_tlc_timed.py`, and, for reserve before send with faults on the
datastore's clock, the bound N = 3, L = 2 is checked only where that first
invocation had completed it (see the comment in `run_tlc_timed.py`).

The statement level mapping from the code to the actions of the timed model
is Appendix A of the paper.

## What the models abstract

* One number per model run. The untimed model and the Tamarin models fix one
  window; the timed model has aligned windows over a horizon of four or six
  ticks and issues the rollover statements as the code does.
* Every labeled step (TLA+) or rule (Tamarin) is atomic: one SQL statement, or
  one serialized transaction. That is the datastore guarantee the designs rely
  on (a single `UPDATE ... WHERE used < L`; `BEGIN IMMEDIATE` on SQLite; a
  transaction scoped advisory lock on PostgreSQL). Weaker isolation than the
  datastore provides is not modeled.
* A count of rows and a counter are the same abstract quantity `count`;
  count then insert increments the current value, the read modify write
  counter writes back the value it read plus one.
* The provider is a single step; with `Faults = TRUE` (TLA+ only) its outcome
  is `ok` (billed), `failed` (not billed, an exception), or, in the timed
  model, `unkB` or `unkU` (the call raises after a timeout, billed or not; the
  service cannot tell them apart). The untimed model's `unknown` is `unkB`.
* Time is discrete; a crash between statements is modeled only through the
  provider outcomes.
* The models check the designs, not the Python code; the measurement
  (paper Section V) checks the code.

## Tool versions used for the reported results

| File | SHA-256 |
|---|---|
| `tla2tools.jar` (release v1.8.0, downloaded October 8, 2026) | `7beec0f04818732a62fa193731711a99aa4f11279499b2360a7d156c519ea78d` |
| `tamarin-prover-1.10.0-linux64-ubuntu.tar.gz` | `538fe055b65f419aac4710015948f0e6a2253d2f61958c136e2d2bd67981028c` |
| `Maude-3.5-linux-x86_64.zip` | `e74cb8cf91b2d8b45440b54ef037180b581279358facf49f656e5b126eb7d1d3` |

The v1.8.0 release of the TLA+ tools is updated in place by its maintainers,
so a later download may report a later TLC build; the verdicts should not
change with the build, although state counts could.

## Running

```bash
# TLA+: Java 11 or later and tla2tools.jar v1.8.0
#   https://github.com/tlaplus/tlaplus/releases/download/v1.8.0/tla2tools.jar
java -cp tla2tools.jar pcal.trans -nocfg formal/tla/Admission.tla   # only after editing the PlusCal
python3 formal/tla/run_tlc.py /path/to/tla2tools.jar                 # about 2 minutes; writes results.json, results.md, traces/
python3 formal/tla/run_tlc_timed.py /path/to/tla2tools.jar           # about two hours on two cores; results_timed.*, traces_timed/

# Tamarin 1.10.0 and Maude 3.5 on the PATH
#   https://github.com/tamarin-prover/tamarin-prover/releases/download/1.10.0/tamarin-prover-1.10.0-linux64-ubuntu.tar.gz
#   https://github.com/maude-lang/Maude/releases/download/Maude3.5/Maude-3.5-linux-x86_64.zip
bash formal/tamarin/run_tamarin.sh                                    # under a minute; writes results/
(cd formal/tamarin && python3 sweep_limits.py)                        # L = 1 to 5; results/sweep/, results/sweep.json
(cd formal/tamarin && tamarin-prover --prove -D=CONDITIONAL OTPAdmissionParam.spthy)   # likewise GUARDED, RESERVE
```

`regenerate.py` reads `tla/results.json` and `tamarin/results/log_*.txt`
into `results/paper_numbers.json` (key `formal`), and `tla/results_timed.json`,
`tamarin/results/sweep.json`, and `tamarin/results/param/log_*.txt` into key
`r7.formal`, from which the paper's formal tables are generated.
