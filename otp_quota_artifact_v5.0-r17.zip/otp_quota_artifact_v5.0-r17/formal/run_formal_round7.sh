#!/bin/bash
# Round 7 formal runs, in order: the timed TLA+ suite, the parameterized
# Tamarin model for the three one step designs, and the Tamarin limit sweep.
# Waits for the round 7 measurement queue to finish first, so that model
# checking does not compete with the timed measurements for the CPU.
set -u
cd "$(dirname "$0")"
export PATH=/home/claude/tools:/home/claude/tools/maude35:$PATH LANG=C.UTF-8 LC_ALL=C.UTF-8
LOG=formal_round7.log
until grep -q "=== .* done" ../results/r7/round7.log 2>/dev/null; do sleep 60; done
echo "=== $(date -u +%FT%TZ) TLC timed" >> $LOG
(cd tla && python3 run_tlc_timed.py /home/claude/tools/tla2tools.jar) >> $LOG 2>&1 || echo "FAILED: TLC timed" >> $LOG
echo "=== $(date -u +%FT%TZ) Tamarin param" >> $LOG
mkdir -p tamarin/results/param
for D in CONDITIONAL GUARDED RESERVE; do
  (cd tamarin && timeout 1800 tamarin-prover --prove -D=$D --output=results/param/proof_$D.spthy \
     OTPAdmissionParam.spthy > results/param/log_$D.txt 2>&1) || echo "FAILED: param $D" >> $LOG
  grep -E "^  [a-zA-Z0-9_]+ \((all-traces|exists-trace)\)" tamarin/results/param/log_$D.txt >> $LOG
done
echo "=== $(date -u +%FT%TZ) Tamarin sweep" >> $LOG
(cd tamarin && python3 sweep_limits.py) >> $LOG 2>&1 || echo "FAILED: sweep" >> $LOG
echo "=== $(date -u +%FT%TZ) formal done" >> $LOG
