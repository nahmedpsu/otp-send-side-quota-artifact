"""Check OTPAdmission.spthy for every limit L = 1..5, not only L = 3.

For each L, the limit constant (L + 1 in Tamarin's naturals) and the two
counting lemmas are rewritten for L + 1 admissions: the bound lemma for the
one step designs (no number admitted L + 1 times) and the violation trace for
the two step designs (L + 1 admissions that all read one version). The
symbolic limit, for every L at once, is OTPAdmissionParam.spthy.

    python3 formal/tamarin/sweep_limits.py      # writes results/sweep.json

Scope: the one step designs are proved for every L from 1 to 5; the violation
trace of the two step designs is searched for L from 1 to 3 only, because
Tamarin's automatic search for a trace with L + 1 concurrent reads of one
version had not finished after 17 minutes at L = 4, by which time it held
more than 3 GB of memory, and a second attempt coincided with a restart of
the container (October 9, 2026). Each run is now capped at 3 GB of heap and
20 minutes. A log
already written by an earlier invocation is read back instead of rerun.
"""
import json
import os
import re
import subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = open(os.path.join(HERE, "OTPAdmission.spthy")).read()
ENV = dict(os.environ, LANG="C.UTF-8", LC_ALL="C.UTF-8")
ONE = ["CONDITIONAL", "GUARDED", "RESERVE"]
TWO = ["COUNTINSERT", "RMW", "AFTERSEND"]


def nat(k):
    return "%+".join(["%1"] * k)


def variant(L):
    s = SRC.replace("%1%+%1%+%1%+%1", nat(L + 1))
    m = L + 1
    rs = [f"r{i}" for i in range(1, m + 1)]
    ts = [f"#t{i}" for i in range(1, m + 1)]
    rd = [f"#a{i}" for i in range(1, m + 1)]
    neq = " & ".join(f"not ({a} = {b})" for i, a in enumerate(rs) for b in rs[i + 1:]) or "T"
    adm = " & ".join(f"Admit(n, {r}) @ {t}" for r, t in zip(rs, ts))
    reads = " & ".join(f"Read(n, {r}, ver) @ {a}" for r, a in zip(rs, rd))
    bound = (f'lemma R1_bounded_consumption:\n  "not (Ex n {" ".join(rs)} {" ".join(ts)}.\n'
             f'     {adm}\n     & {neq})"')
    trace = (f'lemma R1_violation_trace: exists-trace\n  "Ex n ver {" ".join(rs)} {" ".join(ts)} {" ".join(rd)}.\n'
             f'     {reads}\n     & {adm}\n     & {neq}"')
    s = re.sub(r'lemma R1_bounded_consumption:\n  "not \(Ex.*?\)"', bound, s, flags=re.S)
    s = re.sub(r'lemma R1_violation_trace: exists-trace\n  "Ex.*?"', trace, s, flags=re.S)
    # the sanity lemma asks for L admissions (at least one)
    if L != 3:
        rs2 = [f"q{i}" for i in range(1, L + 1)]
        ts2 = [f"#s{i}" for i in range(1, L + 1)]
        neq2 = " & ".join(f"not ({a} = {b})" for i, a in enumerate(rs2) for b in rs2[i + 1:])
        body = " & ".join(f"Admit(n, {r}) @ {t}" for r, t in zip(rs2, ts2)) + (f"\n     & {neq2}" if neq2 else "")
        s = re.sub(r'lemma limit_reachable: exists-trace\n  "Ex.*?"',
                   f'lemma limit_reachable: exists-trace\n  "Ex n {" ".join(rs2)} {" ".join(ts2)}.\n     {body}"',
                   s, flags=re.S)
    return s


out = []
os.makedirs(os.path.join(HERE, "results", "sweep"), exist_ok=True)
for L in range(1, 6):
    fn = os.path.join(HERE, "results", "sweep", f"OTPAdmission_L{L}.spthy")
    open(fn, "w").write(variant(L))
    for D in ONE + (TWO if L <= 3 else []):
        lf = os.path.join(HERE, "results", "sweep", f"log_L{L}_{D}.txt")
        if os.path.exists(lf) and "processing time" in open(lf).read():
            log, rc = open(lf).read(), 0
        else:
            q = subprocess.run(["timeout", "1200", "tamarin-prover", "+RTS", "-M3g", "-RTS", "--prove", f"-D={D}", fn],
                               capture_output=True, text=True, env=ENV)
            log, rc = q.stdout + q.stderr, q.returncode
            open(lf, "w").write(log)
        p = type("R", (), {"returncode": rc})
        lem = {m.group(1): dict(verdict=m.group(3), steps=int(m.group(4)))
               for m in re.finditer(r"^  (\w+) \((all-traces|exists-trace)\): (verified|falsified[^(]*|analysis incomplete)\s*\((\d+) steps\)", log, re.M)}
        rec = dict(L=L, design=D, lemmas=lem, timeout=p.returncode == 124)
        out.append(rec)
        print(L, D, {k: v["verdict"] for k, v in lem.items()}, "TIMEOUT" if rec["timeout"] else "", flush=True)
json.dump(out, open(os.path.join(HERE, "results", "sweep.json"), "w"), indent=1)
