"""Word copy of the v5.0 manuscript, from the same sources as the PDF.

Usage (after a successful `bash paper/build.sh paper/otp_cose.tex`):
    python3 paper/make_docx.py [out.docx]

The LaTeX is flattened; number macros are replaced with their values from
paper/gen/r7.tex; cross references and citations are resolved from the
compiled .aux; TikZ figures and algorithms are rendered to PNG with the same
preamble; PDF figures are rasterized; and pandoc writes the .docx. The PDF is
the version of record; the Word copy is for editing and review.
"""
import os
import re
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MAIN = os.path.join(HERE, "otp_cose.tex")
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "otp_cose.docx")
WORK = tempfile.mkdtemp(prefix="docx_")


def read(p):
    return open(p, encoding="utf-8").read()


def strip_comments(t):
    return re.sub(r"(?<!\\)%.*", "", t)


def flatten(t):
    def rep(m):
        name = m.group(1)
        p = os.path.join(HERE, name if name.endswith(".tex") else name + ".tex")
        if not os.path.exists(p):
            return ""
        return flatten(strip_comments(read(p)))
    t = re.sub(r"\\IfFileExists\{[^}]*\}\{\\input\{([^}]*)\}\}\{\}", lambda m: "\\input{" + m.group(1) + "}", t)
    return re.sub(r"\\input\{([^}]*)\}", rep, t)


# ---------------------------------------------------------------- macros
R = {}
for m in re.finditer(r"\\csname rseven@(.*?)\\endcsname\{(.*)\}$", read(os.path.join(HERE, "gen", "r7.tex")), re.M):
    R[m.group(1)] = m.group(2)

# ---------------------------------------------------------------- aux
aux = read(os.path.join(HERE, "otp_cose.aux"))
LAB = {m.group(1): m.group(2) for m in re.finditer(r"\\newlabel\{([^}]*)\}\{\{([^}]*)\}", aux)}
CIT = {m.group(1): m.group(2) for m in re.finditer(r"\\bibcite\{([^}]*)\}\{\{?(\d+)", aux)}

src = strip_comments(read(MAIN))
pre = src[:src.index("\\begin{document}")]
body = src[src.index("\\begin{document}") + len("\\begin{document}"):src.index("\\end{document}")]
body = flatten(body)

# ---------------------------------------------------------------- render TikZ figures and algorithms
STANDALONE = pre.replace("\\documentclass[preprint,12pt,a4paper]{elsarticle}",
                         "\\documentclass[12pt,border=4pt]{standalone}")
STANDALONE = re.sub(r"\\usepackage\[a4paper[^]]*\]\{geometry\}", "", STANDALONE)
STANDALONE = re.sub(r"\\usepackage\{lineno\}", "", STANDALONE)
STANDALONE = re.sub(r"\\journal\{[^}]*\}", "", STANDALONE)
STANDALONE = STANDALONE.replace("\\input{gen/r7}", "\\input{" + os.path.join(HERE, "gen", "r7") + "}")
n_img = [0]


def render(snippet, width_cm=16):
    n_img[0] += 1
    name = f"img{n_img[0]:02d}"
    doc = STANDALONE + "\\begin{document}\n\\begin{minipage}{" + str(width_cm) + "cm}\n" + snippet + \
        "\n\\end{minipage}\n\\end{document}\n"
    open(os.path.join(WORK, name + ".tex"), "w").write(doc)
    env = dict(os.environ, TEXINPUTS=HERE + "//:" + os.environ.get("TEXINPUTS", ""))
    subprocess.run(["pdflatex", "-interaction=nonstopmode", name + ".tex"], cwd=WORK, env=env,
                   capture_output=True)
    pdf = os.path.join(WORK, name + ".pdf")
    if not os.path.exists(pdf):
        raise SystemExit(f"render failed for {name}; see {WORK}/{name}.log")
    subprocess.run(["pdftoppm", "-r", "200", "-png", "-singlefile", pdf, os.path.join(WORK, name)], check=True)
    return os.path.join(WORK, name + ".png")


def caption_of(block):
    i = block.find("\\caption{")
    if i < 0:
        return "", block
    j, depth = i + len("\\caption{"), 1
    while depth:
        depth += {"{": 1, "}": -1}.get(block[j], 0)
        j += 1
    return block[i + len("\\caption{"):j - 1], block[:i] + block[j:]


def label_of(block):
    m = re.search(r"\\label\{([^}]*)\}", block)
    return m.group(1) if m else None


def figlike(m):
    env, block = m.group(1), m.group(2)
    cap, rest = caption_of(block)
    lab = label_of(block)
    num = LAB.get(lab, "?")
    kind = {"figure": "Fig.", "algorithm": "Algorithm"}[env]
    if env == "algorithm" or "tikzpicture" in rest or "fig_trace" in rest or "\\begin{axis}" in rest:
        inner = re.sub(r"\\label\{[^}]*\}", "", rest).replace("\\centering", "")
        if env == "algorithm":
            inner = inner.replace("\\begin{algorithmic}", "\\begin{algorithmic}").strip()
        png = render(inner)
        g = f"\\includegraphics{{{png}}}"
    else:
        g = re.search(r"\\includegraphics(\[[^]]*\])?\{([^}]*)\}", rest)
        pdf = os.path.join(HERE, g.group(2) + ("" if g.group(2).endswith(".pdf") else ".pdf"))
        n_img[0] += 1
        base = os.path.join(WORK, f"img{n_img[0]:02d}")
        subprocess.run(["pdftoppm", "-r", "200", "-png", "-singlefile", pdf, base], check=True)
        g = f"\\includegraphics{{{base}.png}}"
    return f"\n\n{g}\n\n\\textit{{{kind} {num}. {cap}}}\n\n"


def tablelike(m):
    block = m.group(1)
    cap, rest = caption_of(block)
    num = LAB.get(label_of(block), "?")
    rest = re.sub(r"\\label\{[^}]*\}", "", rest)
    rest = re.sub(r"\\resizebox\{[^}]*\}\{[^}]*\}\{(.*)\}\s*$", r"\1", rest.strip(), flags=re.S)
    for cmd in ("centering", "footnotesize", "scriptsize", "small"):
        rest = rest.replace("\\" + cmd, "")
    rest = re.sub(r"\\setlength\{[^}]*\}\{[^}]*\}", "", rest)
    rest = re.sub(r"\\renewcommand\{\\arraystretch\}\{[^}]*\}", "", rest)
    return f"\n\n\\textit{{Table {num}. {cap}}}\n\n{rest}\n\n"


body = re.sub(r"\\begin\{(figure|algorithm)\}(?:\[[^]]*\])?(.*?)\\end\{\1\}", figlike, body, flags=re.S)
body = re.sub(r"\\begin\{table\}(?:\[[^]]*\])?(.*?)\\end\{table\}", tablelike, body, flags=re.S)

# ---------------------------------------------------------------- text level replacements
body = re.sub(r"\\R\{([^}]*)\}", lambda m: R[m.group(1)], body)
body = re.sub(r"\\ref\{([^}]*)\}", lambda m: LAB.get(m.group(1), "?"), body)
body = re.sub(r"~?\\cite\{([^}]*)\}", lambda m: " [" + ", ".join(CIT.get(k.strip(), "?") for k in m.group(1).split(",")) + "]", body)
body = re.sub(r"\\ident\{", r"\\texttt{", body)
body = body.replace("\\linenumbers", "")
if "\\appendix" in body:
    main_, app_ = body.split("\\appendix", 1)
    letters = iter("ABCDEFG")
    app_ = re.sub(r"\\section\{([^}]*)\}", lambda m: "\\section*{Appendix " + next(letters) + ". " + m.group(1) + "}", app_)
    body = main_ + app_
body = re.sub(r"\\mbox\{([^}]*)\}", r"\1", body)
body = body.replace("\\checkmark", "✓").replace("\\symbol{60}", "\\textless{}")
body = re.sub(r"\\bibliographystyle\{[^}]*\}\s*\\bibliography\{[^}]*\}", "", body)
# frontmatter: keep title, author, abstract, keywords as plain sections
body = re.sub(r"\\begin\{frontmatter\}|\\end\{frontmatter\}", "", body)
body = re.sub(r"\\begin\{highlights\}(.*?)\\end\{highlights\}",
              lambda m: "\\section*{Highlights}\n\\begin{itemize}" + m.group(1) + "\\end{itemize}", body, flags=re.S)
body = re.sub(r"\\begin\{keyword\}(.*?)\\end\{keyword\}",
              lambda m: "\\textbf{Keywords:} " + m.group(1).replace("\\sep", ";"), body, flags=re.S)
body = re.sub(r"\\cortext\[[^]]*\]\{[^}]*\}|\\corref\{[^}]*\}", "", body)
body = re.sub(r"\\affiliation\{.*?country=\{[^}]*\}\}", "College of Computer and Information Sciences, Prince Sultan University, Riyadh, Saudi Arabia", body, flags=re.S)
body = re.sub(r"\\ead\{([^}]*)\}", r"Email: \1", body)
title = re.search(r"\\title\{(.*?)\}", body, re.S).group(1)
author = re.search(r"\\author\{(.*?)\}", body, re.S).group(1)
body = re.sub(r"\\title\{.*?\}", "", body, count=1, flags=re.S)
body = re.sub(r"\\author\{.*?\}", "", body, count=1, flags=re.S)

# numbered sections: prefix the numbers from the aux so the Word copy matches the PDF
sec_nums = {}
for m in re.finditer(r"\\newlabel\{(sec:[^}]*|app:[^}]*)\}\{\{([^}]*)\}", aux):
    sec_nums[m.group(1)] = m.group(2)

# references from the .bbl
bbl = read(os.path.join(HERE, "otp_cose.bbl"))
items = re.split(r"\\bibitem(?:\[[^]]*\])?\{([^}]*)\}", bbl)[1:]
refs = []
for k, txt in zip(items[0::2], items[1::2]):
    txt = txt.split("\\end{thebibliography}")[0]
    txt = re.sub(r"\\newblock", " ", txt)
    txt = re.sub(r"\\url\{([^}]*)\}", r"\1", txt)
    txt = re.sub(r"\\href\s*\{[^}]*\}\s*\{\\path\{([^}]*)\}\}", r"\1", txt)
    txt = re.sub(r"\\href\s*\{[^}]*\}\s*\{([^}]*)\}", r"\1", txt)
    txt = re.sub(r"\\path\{([^}]*)\}", r"\1", txt)
    txt = txt.replace("\\urlprefix", "URL: ").replace("\\newline", " ")
    txt = re.sub(r"\\doi\{([^}]*)\}", r"doi:\1", txt)
    txt = re.sub(r"\\providecommand.*", "", txt)
    refs.append(f"\\item[{CIT.get(k, '?')}] " + " ".join(txt.split()))
body += "\n\\section*{References}\n\\begin{description}\n" + "\n".join(refs) + "\n\\end{description}\n"

doc = ("\\documentclass{article}\n\\usepackage{graphicx}\n\\title{" + title + "}\n\\author{" + author + "}\n"
       "\\begin{document}\n\\maketitle\n" + body + "\n\\end{document}\n")
flat = os.path.join(WORK, "flat.tex")
open(flat, "w").write(doc)
subprocess.run(["pandoc", flat, "-f", "latex", "-t", "docx", "-o", OUT, "--number-sections"],
               check=True, cwd=WORK)
print("wrote", OUT, "(work files in", WORK + ")")
