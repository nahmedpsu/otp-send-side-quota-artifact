"""SlowAPI (on the limits library) guarding the OTP send endpoint.

    OTP_LIMITS_STORAGE   memory:// (the default: one counter per worker
                         process) or redis://127.0.0.1:6379/0 or
                         memcached://127.0.0.1:11211
    OTP_LIMITS_STRATEGY  fixed-window (SlowAPI's default), moving-window, or
                         sliding-window-counter (added in round 7)
The rule is "3/hour" per phone number, the fixed window strategy, which is
SlowAPI's default. The key is the phone number from the query string.
"""
import os

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from slowapi import Limiter
from slowapi.errors import RateLimitExceeded

from svc.libs import common

limiter = Limiter(key_func=lambda request: request.query_params["phone"],
                  storage_uri=os.environ.get("OTP_LIMITS_STORAGE", "memory://"),
                  strategy=os.environ.get("OTP_LIMITS_STRATEGY", "fixed-window"))
app = FastAPI(title="OTP send service, SlowAPI")
app.state.limiter = limiter


@app.exception_handler(RateLimitExceeded)
def _refused(request: Request, exc):
    ev = common.new_event(request.query_params["phone"])
    return JSONResponse(common.finish(ev, "refuse"), status_code=200)


@app.on_event("startup")
def _startup():
    common.init()


@app.post("/otp/request")
@limiter.limit(f"{common.LIMIT}/hour")
def otp_request(request: Request, phone: str):
    ev = common.new_event(phone)
    common.provider_send(phone, ev)
    return common.finish(ev, "admit")


@app.get("/otp/stats")
def stats(phone: str):
    return common.stats(phone)


@app.get("/otp/events")
def events(phone: str):
    return common.events(phone)
