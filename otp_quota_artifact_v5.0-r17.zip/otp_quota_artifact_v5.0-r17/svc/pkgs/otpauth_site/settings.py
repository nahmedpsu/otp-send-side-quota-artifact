"""Minimal Django project serving django-otp-auth 2.3.0's own view
(otp_auth.api_send_otp), round 7. Sessions are stored in the database the
OTP_PKG_DB variable selects: sqlite (default) or postgres. The package keeps
its per number limiter in a module level dictionary of each worker process."""
import os

SECRET_KEY = "experiment-only"
DEBUG = False
ALLOWED_HOSTS = ["*"]
ROOT_URLCONF = "svc.pkgs.otpauth_site.urls"
INSTALLED_APPS = ["django.contrib.sessions"]
MIDDLEWARE = ["django.contrib.sessions.middleware.SessionMiddleware"]
USE_TZ = True
SESSION_ENGINE = "django.contrib.sessions.backends.db"
if os.environ.get("OTP_PKG_DB", "sqlite") == "postgres":
    DATABASES = {"default": {"ENGINE": "django.db.backends.postgresql", "NAME": "otp",
                             "USER": "otp", "PASSWORD": "otp", "HOST": "127.0.0.1"}}
else:
    DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3",
                             "NAME": os.environ.get("OTP_PKG_SQLITE", "/tmp/otpauth.sqlite3"),
                             "OPTIONS": {"timeout": 30}}}
