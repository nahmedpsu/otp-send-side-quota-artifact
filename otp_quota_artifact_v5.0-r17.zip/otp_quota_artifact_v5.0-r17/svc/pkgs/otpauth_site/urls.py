from django.urls import path

import otp_auth

urlpatterns = [path("send/", otp_auth.api_send_otp)]
