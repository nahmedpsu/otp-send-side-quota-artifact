"""fastapi-otp-auth 0.1.4's own router, mounted as its README shows (round 7).
Redis at FASTAPI_OTP_AUTH_REDIS_URL; mail to the local SMTP sink at
FASTAPI_OTP_AUTH_SMTP_SERVER:FASTAPI_OTP_AUTH_SMTP_PORT (study/smtp_sink.py)."""
from fastapi import FastAPI

from fastapi_otp_auth.auth_router import router

app = FastAPI(title="fastapi-otp-auth under the harness")
app.include_router(router, prefix="/auth")
