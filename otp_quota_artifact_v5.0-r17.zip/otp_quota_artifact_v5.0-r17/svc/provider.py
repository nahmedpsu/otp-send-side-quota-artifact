"""An independent provider stub (service 2.2.0, opt in with OTP_PROVIDER_URL).

A separate process with its own clock reading and its own log: every call it
receives is appended to PROVIDER_LOG with the request id the service sent,
the number, the outcome the service drew (billed or not), and the instants at
which this process received and answered the call. It never reads the
service's database or event records, so its log is evidence about the
service that the service did not write.

    uvicorn svc.provider:app --port 8098 --workers 1
"""
import asyncio
import json
import os
import time
import uuid

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

LOG = os.environ.get("PROVIDER_LOG", "/tmp/provider_log.jsonl")
app = FastAPI(title="provider stub", version="2.2.0")
_f = None


class Call(BaseModel):
    rid: str
    phone: str
    outcome: str = "ok"
    sleep_ms: float = 50.0


@app.post("/send")
async def send(c: Call):
    global _f
    t_recv = time.time()
    if c.sleep_ms > 0:
        await asyncio.sleep(c.sleep_ms / 1000.0)
    mid = uuid.uuid4().hex
    rec = dict(rid=c.rid, phone=c.phone, outcome=c.outcome, billed=c.outcome in ("ok", "unkB"),
               message_id=mid, t_recv=t_recv, t_done=time.time(), pid=os.getpid())
    if _f is None:
        _f = open(LOG, "a")
    _f.write(json.dumps(rec) + "\n")
    _f.flush()
    return {"message_id": mid}


def _log(rec):
    global _f
    if _f is None:
        _f = open(LOG, "a")
    _f.write(json.dumps(rec) + "\n")
    _f.flush()


SLEEP_MS = float(os.environ.get("PROVIDER_SLEEP_MS", "50"))


# Local adapters for surveyed packages executed in round 7: the request each
# package sends is answered the way the real API answers a success, and
# logged; nothing leaves the host.
@app.post("/2010-04-01/Accounts/{account}/Messages.json")
async def twilio_messages(account: str, request: Request):
    """Twilio's Messages resource, as django-otp-twilio calls it."""
    t_recv = time.time()
    form = await request.form()
    await asyncio.sleep(SLEEP_MS / 1000.0)
    mid = "SM" + uuid.uuid4().hex
    _log(dict(rid="", phone=str(form.get("To", "")), outcome="ok", billed=True, message_id=mid,
              t_recv=t_recv, t_done=time.time(), pid=os.getpid(), api="twilio-messages"))
    return JSONResponse({"sid": mid, "status": "queued"}, status_code=201)


@app.post("/generate/")
async def otp_generate(request: Request):
    """The hosted OTP API that django-otp-auth calls (POST {base}/generate/)."""
    t_recv = time.time()
    body = await request.json()
    await asyncio.sleep(SLEEP_MS / 1000.0)
    sid = uuid.uuid4().hex
    _log(dict(rid="", phone=str(body.get("mobile_number", "")), outcome="ok", billed=True, message_id=sid,
              t_recv=t_recv, t_done=time.time(), pid=os.getpid(), api="otp-generate"))
    return JSONResponse({"session_id": sid}, status_code=201)


@app.post("/sms")
async def generic_sms(request: Request):
    """A generic SMS gateway call (the two_factor gateway of the harness)."""
    t_recv = time.time()
    body = await request.json()
    await asyncio.sleep(SLEEP_MS / 1000.0)
    mid = uuid.uuid4().hex
    _log(dict(rid=str(body.get("rid", "")), phone=str(body.get("to", "")), outcome="ok", billed=True,
              message_id=mid, t_recv=t_recv, t_done=time.time(), pid=os.getpid(), api="sms"))
    return {"message_id": mid}


@app.get("/log")
def log(phone: str):
    out = []
    if os.path.exists(LOG):
        for line in open(LOG):
            if line.strip():
                r = json.loads(line)
                if r["phone"] == phone:
                    out.append(r)
    return {"phone": phone, "calls": out}


@app.post("/reset")
def reset():
    global _f
    if _f is not None:
        _f.close()
        _f = None
    open(LOG, "w").close()
    return {"status": "reset"}
