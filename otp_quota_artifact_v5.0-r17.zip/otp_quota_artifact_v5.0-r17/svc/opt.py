"""Opt-in switches added in service 2.2.0 (round 7). With none of the
environment variables below set, both services behave exactly as 2.1.0.

  OTP_DELAY_MS_MAX  after a request samples `now`, sleep a uniform random
                    0..OTP_DELAY_MS_MAX milliseconds before its first
                    statement: a request delayed between its clock reading and
                    its decision (default 0, no delay)
  OTP_FAULTS        "p_failed,p_unknown_billed,p_unknown_unbilled": the
                    provider stub fails without billing, or bills and then
                    raises as after a timeout, or raises without billing, with
                    these probabilities (default: never)
  OTP_RELEASE       reserve before send: "any_current" (2.1.0: release on any
                    exception, on the current row), "certain_reserved"
                    (release only a certain failure, and only on the row of
                    the window the claim was made in), "any_reserved",
                    "certain_current"
  OTP_PROVIDER_URL  call an independent provider stub process (svc/provider.py)
                    over HTTP instead of the in-process stub; that process
                    keeps its own log of every call it receives
  OTP_LOG           "full" (default) or "minimal": minimal writes no event
                    records; the provider rows are the only evidence
  OTP_SEED          seed of this worker's random generator (faults and
                    delays), combined with the worker's process id
"""
import os
import random
import time

import httpx

DELAY_MS_MAX = float(os.environ.get("OTP_DELAY_MS_MAX", "0"))
_f = [float(x) for x in os.environ.get("OTP_FAULTS", "0,0,0").split(",")]
P_FAILED, P_UNK_BILLED, P_UNK_UNBILLED = (_f + [0, 0, 0])[:3]
FAULTS = (P_FAILED + P_UNK_BILLED + P_UNK_UNBILLED) > 0
RELEASE = os.environ.get("OTP_RELEASE", "any_current")
assert RELEASE in ("any_current", "certain_reserved", "any_reserved", "certain_current"), RELEASE
PROVIDER_URL = os.environ.get("OTP_PROVIDER_URL", "")
LOG = os.environ.get("OTP_LOG", "full")
assert LOG in ("full", "minimal"), LOG
_rng = random.Random(f"{os.environ.get('OTP_SEED', '0')}-{os.getpid()}")
_client = None


class ProviderError(Exception):
    """A provider call that did not return success. `outcome` is "failed"
    (certainly not sent) or "unknown" (it may or may not have been billed)."""

    def __init__(self, outcome):
        super().__init__(outcome)
        self.outcome = outcome


def sample_now():
    """`now = time.time()`, then the optional delay."""
    t = time.time()
    if DELAY_MS_MAX > 0:
        time.sleep(_rng.uniform(0, DELAY_MS_MAX) / 1000.0)
    return t


def draw_outcome():
    if not FAULTS:
        return "ok"
    r = _rng.random()
    if r < P_FAILED:
        return "failed"
    if r < P_FAILED + P_UNK_BILLED:
        return "unkB"
    if r < P_FAILED + P_UNK_BILLED + P_UNK_UNBILLED:
        return "unkU"
    return "ok"


def billed(outcome):
    return outcome in ("ok", "unkB")


def remote_send(rid, phone, outcome, provider_ms):
    """Call the independent provider stub; returns its message id."""
    global _client
    if _client is None:
        _client = httpx.Client(timeout=60.0)
    r = _client.post(PROVIDER_URL + "/send", json=dict(rid=rid, phone=phone, outcome=outcome,
                                                      sleep_ms=provider_ms))
    return r.json()["message_id"]


def release_applies(exc):
    """Whether the reservation is returned, and on which row."""
    certain = isinstance(exc, ProviderError) and exc.outcome == "failed"
    rule_ok = RELEASE.startswith("any") or certain
    return rule_ok, RELEASE.endswith("reserved")
