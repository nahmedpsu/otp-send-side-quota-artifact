# Service changelog

## 2.2.0 (round 7, artifact v5.0-r17)

Produced: `results/r7/` (every round 7 arm). The round 4 records (2.0.0) and
the round 6 library records are unchanged; 2.1.0 is archived verbatim as
`svc/archive/app_v2.1.0.py` and `svc/archive/app_pg_v2.1.0.py`.

- **Opt in switches, all off by default (`svc/opt.py`).** `OTP_DELAY_MS_MAX`
  (a random delay between the request's clock reading and its first
  statement), `OTP_FAULTS` (provider outcomes failed, timed out and billed, or
  timed out and not billed, each with a probability), `OTP_RELEASE` (the
  reservation's release rule: `any_current`, the 2.1.0 behavior, or
  `certain_reserved`, `any_reserved`, `certain_current`), `OTP_PROVIDER_URL`
  (send every call to the independent provider process `svc/provider.py`),
  `OTP_LOG=minimal` (no event records), and `OTP_SEED`. With every switch off,
  2.2.0 issues the same statements as 2.1.0.
- **Two designs on the datastore's clock.** `atomic_update_db` and
  `reserve_commit_db`: one statement rolls the window on the datastore's
  clock (SQLite `unixepoch('subsec')`, PostgreSQL `statement_timestamp()`) and
  grants if the count is below the limit; the reservation is released only on
  a certain failure and only on the row of the window it was claimed in.
- **Non reserve designs keep the grant on a provider error**
  (`provider_send_kept`), which is what 2.1.0 did implicitly because its stub
  never failed.

Artifact v5.0-r17 (manuscript v5.0 for Computers & Security, service 2.2.0, round 7 records). Artifacts v4.8-r16 (manuscript v4.8: text and four figures, no code or record changed), v4.7-r15 (manuscript v4.7: formal models, the round 6 library arm in svc/libs/, which
leaves svc/app.py and svc/app_pg.py untouched; rebuilt on October 8, 2026 with the notebook's
and README's references renumbered to the v4.7 tables and figures, notebook cells for
Tables IX to XI, and CITATION.cff; no code or record changed), v4.6-r14 (manuscript v4.6: short captions, Fig. 6 redrawn), v4.5-r13 (manuscript v4.5:
figures and algorithms added, main sweep figure redrawn),
v4.3-r11, v4.2-r10 and v4.1-r9 (manuscripts v4.3 to v4.1, text revisions only) and
v4.0-r8 (condensed manuscript with supplementary material) ship the same
service, 2.1.0, and the same records as v3.5-r7; only the manuscript, the
supplement, the README, the notebook's headings and version strings, and the
review documents changed.

The service is the fixture every Study 2 arm runs against. Its version is
the `version=` string of the FastAPI application in `svc/app.py` and
`svc/app_pg.py`. The sources of every version that produced a shipped event
log are archived verbatim under `svc/archive/`.

## 2.1.0 (round 5, artifact v3.3-r5)

Produced: `results/r5/` (the round-5 check arms: a provenance check reported separately
in the paper; they replace or recompute no round-4 result).

- **Read-modify-write counter (`cache_get_set`): `RETURNING window_start,
  used` on the upsert.** The record now carries the value the database
  returned (`window_id_returned`, `counter_returned`) beside the value the
  request submitted (`window_id`, `counter_after`). The upsert sets the columns
  to the submitted values, so the two are equal by the statement's semantics;
  `regenerate.py` (`round5_check`) confirms it for every admission in
  `results/r5/`. The returned value certifies the committed transition, not
  the state the row was in before it; that state is what this pattern never
  asks the database to adjudicate.
- **`window_source` on every fixed-window admission record**: `"returning"`
  for `atomic_update` and `reserve_commit` (the conditional UPDATE returned
  the row's window), `"submitted"` for `cache_get_set` (the request computed
  the window and wrote it).
- **Admission fields assigned by one helper per policy type.**
  `admitted_fixed()` sets `window_id`, `policy_ts`, `counter_after` and
  `window_source`; `admitted_sliding()` sets `policy_ts` and `counter_after`.
  Previously each pattern assigned them itself: the fixed-window patterns
  assigned the same row value to `window_id` and `policy_ts` on consecutive
  lines, and the sliding-window patterns assigned a derived `counter_after`
  (observed + 1) without saying so. `policy_ts` is kept on fixed-window
  records (equal to `window_id`) so that every admission record has it.
- Module docstrings state, per implementation, where the recorded window
  comes from.

No other behaviour changed: the SQL of every pattern except the upsert's
`RETURNING` clause, the provider stub, the event-record fields that existed
before, the endpoints and the environment variables are the same as in 2.0.0.

Diff against 2.0.0: `diff svc/archive/app_v2.0.0.py svc/app.py` and
`diff svc/archive/app_pg_v2.0.0.py svc/app_pg.py`.

## 2.0.0 (round 4, artifact v3.2-r4)

Produced: `results/r4/` (every reported Study 2 number).

- The policy event defined as the admission; one event record per request,
  appended after the request to a per-worker file; `GET /otp/events`.
- `RETURNING window_start, used` on the conditional UPDATE of `atomic_update`
  and `reserve_commit`; `_roll_window` made idempotent within a window.
- SHA-256 in the v3.2-r4 manifest: `svc/app.py`
  `332152e6800384bf62dd9a655e8188f0c1a4233c75e948417967dcd4320b4fcc`,
  `svc/app_pg.py`
  `b1a7ad0468c6033404c94063c403fe193561b6a8dc8c78596a144c4e0a404a9e`;
  the archived copies have these hashes.

## 1.x (rounds 1 to 3)

Provider-call rows only, no event records. The runs are historical
(`results/`, `results/r2/`, `results/r3/`); they replace or contribute to no round-4
result and appear in the paper only in the comparison with round 4.
